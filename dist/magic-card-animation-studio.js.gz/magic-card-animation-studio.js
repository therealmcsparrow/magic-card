(()=>{"use strict";var e={3706(e,t,i){i.d(t,["eo",0,"mc-path-canvas"])},3682(e,t,i){const n={colour:"color",centre:"center",grey:"gray",metre:"meter",customis:"customiz",behaviour:"behavior",favourite:"favorite",maximis:"maximiz",minimis:"minimiz",organis:"organiz"};i.d(t,["A",0,e=>e.toLowerCase().replace(/colour|centre|grey|metre|customis|behaviour|favourite|maximis|minimis|organis/g,e=>n[e])])},201(e,t,i){var n=i(4753);const{t:s,tx:r,m:a,locale:o,ready:l}=(0,n._H)("labels",()=>i.e(8249).then(()=>i(2657)));i.d(t,["G",0,l,"H",0,o,"t",0,s])},1699(e,t,i){const n="mc-i18n-wrap",s="mc-i18n-wrap-query";let r=null,a=!1,o=!1,l=!1;const c={},d=e=>c[e]||=(console.debug("[i18n] "+e),1),p=()=>{o=!0;try{window.dispatchEvent(new CustomEvent(n,{detail:{wrap:r}}))}finally{o=!1}},h=()=>{l||"undefined"==typeof window||(l=!0,window.addEventListener(n,e=>{const t=e.detail?.wrap;"function"!=typeof t&&null!==t||(r=t,a=o)}),window.addEventListener(s,()=>a&&p()),window.dispatchEvent(new Event(s)))};i.d(t,["B6",0,h,"C1",0,(e,t)=>{if(r){try{const i=r(e,t);if("string"==typeof i)return i}catch{}d("bad wrap")}return e},"fo",0,()=>!!r,"iC",0,e=>{h(),r=e,p()},"st",0,d])},4753(e,t,i){var n=i(796),s=i(1699);const r=["en-GB","en-US","nl"];let a,o=0;const l=e=>(0,n.ZV)(a,e),c=/\{((?:[^{}]|\{(?:[^{}]|\{[^{}]*\})*\})*)\}/,d=/\{((?:[^{}]|\{[^{}]*\})*)\}/,p=/^(ar|he|iw|fa|ur|ps|sd|ug|yi|dv|ckb)\b/i,h=/[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/,u=(e,t,i,n)=>t.split(c).flatMap((t,r)=>{if(!(1&r))return void 0===n?t:t.replace(/#/g,l(n));const a=/^\s*(\w+)\s*(?:,\s*(\w+)\s*,([^]*))?$/.exec(t);if(!a)throw 0;const o=i[a[1]];if(void 0===o&&(0,s.st)("missing "+a[1]),!a[2])return"object"==typeof o?[o]:void 0===o?"":"number"==typeof o?l(o):p.test(e)||(0,s.fo)()||h.test(o)?"⁨"+o+"⁩":o;const c=a[3].split(d),m="plural"==a[2],g=m?Math.round(10*+o)/10:o,f=e=>c[c.findIndex((t,i)=>!(1&i)&&t.trim()==e)+1||-1],v=f("="+g)??f(m?new Intl.PluralRules(e).select(g):String(o))??f("other");if(void 0===v)throw 0;return u(e,v,i,m?g:void 0)}).filter(String),m=(e,t)=>{(0,s.B6)();const i=[],n=e=>i[e]||=t()[e].split("|"),a=(i,r=o)=>t()?(n(r)[i]||n(0)[i])??"":((0,s.st)("not ready "+e),""),l=(e,t={})=>{try{return u(r[o],a(e),t)}catch{return(0,s.st)("malformed "+e),[a(e,0)]}};return{ns:e,locale:()=>r[o],t:(e,t)=>(0,s.C1)(l(e,t).join(""),"msg"),tx:(e,t)=>l(e,t).map(e=>"string"==typeof e?(0,s.C1)(e,"msg"):e),en:e=>a(e,0),m:e=>e}};i.d(t,["Zc",0,e=>{a=e;const t=(e=>{const t=/^(nl|en)(-(gb|au|nz|ie|za|in))?\b/.exec((e||"").toLowerCase());return t?"nl"==t[1]?"nl":t[3]?"en-GB":"en-US":"en-GB"})(e?.locale?.language||e?.language||globalThis.navigator?.language);return o=r.indexOf(t),t},"_H",0,(e,t)=>{let i,n;return{...m(e,()=>i),ready:()=>n||=t().then(e=>(i=e.default,!0),()=>(n=void 0,!1))}},"my",0,(e,t)=>m(e,()=>t)])},1474(e,t,i){i.d(t,{a:()=>r,dI:()=>o});var n=i(2637),s=i(201);function r(e,t,i,r,o={}){const l=(0,n.WP)(t).slice(0,64).map((e,t)=>({id:`part-${t+1}`,name:(0,s.t)(349,{n:t+1}),from:[e.index]})),c=o.embed?function(e){const t=(t,i)=>e.evenodd?.[t]?.includes(i)?' fill-rule="evenodd"':"",i=[...(e.secondary??[]).map((e,i)=>`<path class="mc-accent" d="${a(e)}"${t("accent",i)}/>`),...e.paths.map((e,i)=>`<path d="${a(e)}"${t("paths",i)}/>`),...(e.strokes??[]).map(e=>`<path${e.accent?' class="mc-accent"':""} d="${a(e.d)}" fill="none" stroke="currentColor" stroke-width="${e.width}"${e.cap?` stroke-linecap="${a(e.cap)}"`:""}${e.join?` stroke-linejoin="${a(e.join)}"`:""}/>`)],n=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${a(e.viewBox||"0 0 24 24")}">${i.join("")}</svg>`;return("undefined"!=typeof TextEncoder?(new TextEncoder).encode(n).length:n.length)>32768?void 0:n}(t):void 0;return{id:i,name:r,kind:"keyframes",duration:2,easing:"ease-in-out",iterations:"infinite",target:"icon",origin:"center",version:1,keyframes:[{at:0,opacity:1}],rig:c?{svg:c,parts:l}:{icon:e,parts:l}}}const a=e=>e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;");function o(e,t="center"){const[i,n,s,r]=e,a=/left/.test(t)?0:/right/.test(t)?1:.5,o=/top/.test(t)?0:/bottom/.test(t)?1:.5,l=e=>Math.round(100*e)/100;return[l(i+s*a),l(n+r*o)]}i.d(t,["jo",0,(e,t)=>(0,n.Zg)(t.map(t=>e[t]?.bbox).filter(e=>!!e))])},5084(e,t,i){i.d(t,{Cq:()=>b,Z3:()=>x,ar:()=>C,di:()=>A});var n=i(2637),s=i(1474);const r=(e,t,i,n,s,r)=>({id:e,label:t,min:i,max:n,step:s,default:r}),a=(e=100)=>({...r("share",169,10,100,5,e),unit:"%"}),o=()=>({...r("delay",135,0,90,5,0),unit:"%"}),l=()=>r("intensity",259,.25,3,.25,1),c=()=>r("direction",140,-1,1,2,1),d=(e=100)=>[a(e),o(),l(),c()],p=e=>Math.round(1e3*e)/1e3||0,h=(e,t,i="ease-in-out")=>({t:e,k:{transform:{rotate:p(t)},easing:i}}),u=(e,t,i={},n="ease-in-out")=>{const s={};for(const[e,i]of Object.entries(t))s[e]=p(i);return{t:e,k:{transform:s,...i,easing:n}}},m=(e,t)=>e.map(([e,i])=>h(e,t*i)),g=[{id:"swing",name:473,icon:"mdi:metronome",pivot:"top",help:476,params:d(),gen:({intensity:e,direction:t})=>m([[0,0],[.15,1],[.4,-.8],[.6,.5],[.8,-.25],[1,0]],14*e*t)},{id:"ring",name:390,icon:"mdi:bell-ring-outline",pivot:"top",help:394,params:d(70),gen:({intensity:e,direction:t})=>m([[0,0],[.08,1],[.18,-.95],[.28,.85],[.38,-.72],[.48,.58],[.58,-.44],[.68,.3],[.78,-.16],[.88,.06],[1,0]],16*e*t)},{id:"spin",name:446,icon:"mdi:rotate-right",pivot:"center",help:528,params:[a(),o(),r("intensity",527,1,5,1,1),c()],gen:({intensity:e,direction:t})=>[h(0,0,"linear"),h(1,360*Math.max(1,Math.round(e))*t,"linear")]},{id:"pulse",name:369,icon:"mdi:heart-pulse",pivot:"center",help:231,params:d(),gen:({intensity:e,direction:t})=>[u(0,{scale:1}),u(.5,{scale:1+.15*e*t}),u(1,{scale:1})]},{id:"bounce",name:88,icon:"mdi:debug-step-over",pivot:"bottom",help:454,params:d(),gen:({intensity:e,direction:t})=>{const i=-3*e*t;return[u(0,{y:0,scale_x:1,scale_y:1},{},"ease-out"),u(.12,{y:0,scale_x:1.08,scale_y:.9},{},"ease-out"),u(.45,{y:i,scale_x:.96,scale_y:1.06},{},"ease-in"),u(.75,{y:0,scale_x:1.06,scale_y:.92},{},"ease-out"),u(.88,{y:0,scale_x:.98,scale_y:1.02}),u(1,{y:0,scale_x:1,scale_y:1})]}},{id:"shake",name:417,icon:"mdi:vibrate",help:420,params:d(60),gen:({intensity:e,direction:t})=>{const i=1.2*e*t;return[0,-1,1,-1,1,-.6,.6,-.3,.3,0].map((e,t,n)=>u(t/(n.length-1),{x:i*e}))}},{id:"wobble",name:557,icon:"mdi:rotate-3d-variant",pivot:"bottom",help:397,params:d(),gen:({intensity:e,direction:t})=>m([[0,0],[.15,-1],[.3,.75],[.45,-.5],[.6,.3],[.75,-.15],[1,0]],8*e*t)},{id:"blink",name:65,icon:"mdi:eye-outline",help:66,params:[a(),o(),l()],gen:({intensity:e})=>{const t=p(Math.max(0,1-.9*e));return[1,t,1,t,1,1].map((e,t)=>({t:[0,.1,.2,.3,.4,1][t],k:{opacity:e,easing:"linear"}}))}},{id:"fade",name:183,icon:"mdi:circle-opacity",help:185,params:[a(),o(),l()],gen:({intensity:e})=>[{t:0,k:{opacity:1,easing:"ease-in-out"}},{t:.5,k:{opacity:p(Math.max(0,1-.8*e)),easing:"ease-in-out"}},{t:1,k:{opacity:1,easing:"ease-in-out"}}]},...[["slide-up",430,313,"mdi:arrow-up","y",-1],["slide-down",427,310,"mdi:arrow-down","y",1],["slide-left",428,311,"mdi:arrow-left","x",-1],["slide-right",429,312,"mdi:arrow-right","x",1]].map(([e,t,i,n,s,r])=>({id:e,name:t,icon:n,help:i,params:d(),gen:({intensity:e,direction:t})=>{const i=3*e*t*r;return[u(0,{[s]:0}),u(.4,{[s]:i}),u(.6,{[s]:i}),u(1,{[s]:0})]}})),{id:"draw-on",name:160,icon:"mdi:draw",draws:!0,help:161,params:[a(60),o(),c()],gen:({direction:e})=>[{t:0,k:{draw:e>0?0:1,easing:"ease-in-out"}},{t:1,k:{draw:e>0?1:0,easing:"ease-in-out"}}]},{id:"draw-loop",name:159,icon:"mdi:draw-pen",draws:!0,help:162,params:[a(),o()],gen:()=>[{t:0,k:{draw:0,easing:"ease-in-out"}},{t:.45,k:{draw:1,easing:"ease-in-out"}},{t:.7,k:{draw:1,easing:"ease-in-out"}},{t:1,k:{draw:0,easing:"ease-in-out"}}]},{id:"pop",name:360,icon:"mdi:star-four-points-outline",pivot:"center",help:361,params:[a(50),o(),l()],gen:({intensity:e})=>[u(0,{scale:0},{opacity:0},"ease-out"),u(.6,{scale:1+.2*e},{opacity:1},"ease-in-out"),u(1,{scale:1},{opacity:1})]},{id:"float",name:206,icon:"mdi:waves-arrow-up",help:163,params:d(),gen:({intensity:e,direction:t})=>[u(0,{y:0}),u(.5,{y:-1.5*e*t}),u(1,{y:0})]},{id:"flicker",name:203,icon:"mdi:fire",pivot:"bottom",help:204,params:[a(),o(),l()],gen:({intensity:e})=>[[0,1,1,0],[.12,1.08,.85,2],[.25,.96,1,-1.5],[.4,1.1,.9,1],[.55,.97,1,-2],[.7,1.06,.85,1.5],[.85,.98,1,-.5],[1,1,1,0]].map(([t,i,n,s])=>u(t,{scale_y:1+(i-1)*e,skew_x:s*e},{opacity:p(1-(1-n)*Math.min(e,1))}))},{id:"wave",name:547,icon:"mdi:wifi",pivot:"center",help:284,params:d(),gen:({intensity:e})=>{const t=p(Math.max(0,1-.7*Math.min(e,1.4))),i=p(1-.08*e);return[u(0,{scale:i},{opacity:t}),u(.35,{scale:1+.04*e},{opacity:1}),u(.7,{scale:i},{opacity:t}),u(1,{scale:i},{opacity:t})]}}],f=g.map(({gen:e,...t})=>t),v=new Map(g.map(e=>[e.id,e]));function b(e,t={}){const i=v.get(e),n={};for(const e of i?.params??[]){const i=t[e.id];n[e.id]="number"==typeof i&&Number.isFinite(i)?Math.min(e.max,Math.max(e.min,i)):e.default}return n}const y=e=>Math.round(100*e)/100;function x(e,t={}){const i=b(e,t),n=i.delay??0;return _(e,i,n,Math.min(100,n+(i.share??100)))}function _(e,t,i,n){const s=v.get(e);return s?function(e,t,i){const n=i-t,s=e=>{const t={...e};return delete t.easing,t},r=[],a=e=>{const t=r.findIndex(t=>t.at===e.at);t>=0?r[t]={...r[t],...e}:r.push(e)};t>0&&a({at:0,...s(e[0].k)});for(const i of e)a({at:y(t+i.t*n),...i.k});return i<100&&a({at:100,...s(e[e.length-1].k)}),r.sort((e,t)=>e.at-t.at)}(s.gen({intensity:t.intensity??1,direction:(t.direction??1)<0?-1:1}),i,Math.max(n,i+1)):[]}const w=e=>/^(part|group|shape):/.test(e),k=e=>e.slice(e.indexOf(":")+1);function $(e,t){const i=k(t);return t.startsWith("part:")?!!e?.parts.some(e=>e.id===i):t.startsWith("group:")?!!e?.groups?.some(e=>e.id===i):t.startsWith("shape:")?!!e?.shapes?.some(e=>e.id===i):["element","icon","name","state","background"].includes(t)}function M(e,t,i){const n=[...e.tracks??[]],s=n.findIndex(e=>e.target===t);if(s<0&&n.length>=24)return;const r=s>=0?{...n[s],keyframes:i}:{target:t,keyframes:i};return s>=0?n[s]=r:n.push(r),{...e,tracks:n}}function S(e,t,i,r){if(!(i&&r&&e.rig&&w(t)))return e;const a=function(e,t,i){const r=e.rig,a=k(t);if(t.startsWith("shape:")){const e=r?.shapes?.find(e=>e.id===a);return e?(0,n.hd)(e.d):void 0}const o=t.startsWith("group:")?r?.groups?.find(e=>e.id===a)?.parts??[]:[a];return(0,s.jo)(i,o.flatMap(e=>r?.parts.find(t=>t.id===e)?.from??[]))}(e,t,r);if(!a)return e;const[o,l]=(0,s.dI)(a,i),c=`${o}px ${l}px`;return{...e,tracks:(e.tracks??[]).map(e=>e.target===t?{...e,origin:c}:e)}}function z(e,t,i,n){const s=v.get("wave").pivot;return function(e,t){const i=b("wave",e),n=i.delay,s=Math.max(1,Math.min(i.share,100-n)),r=t>1?.6*s:s,a=t>1?(s-r)/(t-1):0;return Array.from({length:t},(e,t)=>[n+t*a,n+t*a+r])}(i,t.length).reduce((e,[r,a],o)=>{const l=M(e,t[o],_("wave",i,r,a));return l?S(l,t[o],s,n.pieces):e},e)}function C(e,t,i,n,s={}){if(t.length<2||"wave"!==i)return t.reduce((e,t)=>function(e,t,i,n,s={}){const r=v.get(i);if(!r||"keyframes"!==e.kind||!$(e.rig,t))return e;if(r.draws&&!w(t))return e;const a=b(i,n);if("wave"===i&&t.startsWith("group:")){let i=e.rig?.groups?.find(e=>e.id===k(t))?.parts??[];a.direction<0&&(i=[...i].reverse());const n={...e,tracks:(e.tracks??[]).filter(e=>e.target!==t)};return n.tracks.length||delete n.tracks,z(n,i.map(e=>`part:${e}`),a,s)}const o=M(e,t,x(i,a));return o?S(o,t,r.pivot,s.pieces):e}(e,t,i,n,s),e);const r=b(i,n),a=(r.direction<0?[...t].reverse():t).filter(t=>$(e.rig,t));return z(e,a,r,s)}function A(e,t){const i=(e.tracks??[]).flatMap(e=>e.target!==t?[e]:e.path?[{...e,keyframes:[]}]:[]),n={...e,tracks:i};return i.length||delete n.tracks,n}i.d(t,["tP",0,f])},1771(e,t,i){i.d(t,{Bq:()=>v,ER:()=>x,Rr:()=>p,fs:()=>f,uD:()=>m});const n=1e-6,s=(e,t)=>Math.abs(e[0]-t[0])<n&&Math.abs(e[1]-t[1])<n,r=(e,t,i)=>e+(t-e)*i,a=(e,t,i)=>[r(e[0],t[0],i),r(e[1],t[1],i)],o=(e,t,i)=>({c1:[e[0]+2/3*(t[0]-e[0]),e[1]+2/3*(t[1]-e[1])],c2:[i[0]+2/3*(t[0]-i[0]),i[1]+2/3*(t[1]-i[1])],to:i}),l=/[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?/y;class c{constructor(e){this.d=e,this.i=0}skip(){for(;this.i<this.d.length&&/[\s,]/.test(this.d[this.i]);)this.i++}done(){return this.skip(),this.i>=this.d.length}command(){this.skip();const e=this.d[this.i];if(e&&/[MmLlHhVvCcSsQqTtAaZz]/.test(e))return this.i++,e}hasNumber(){return this.skip(),/[-+.\d]/.test(this.d[this.i]??"")}number(){this.skip(),l.lastIndex=this.i;const e=l.exec(this.d);if(!e)throw new Error(`Bad path number at ${this.i}`);return this.i+=e[0].length,Number(e[0])}flag(){this.skip();const e=this.d[this.i];if("0"!==e&&"1"!==e)throw new Error(`Bad arc flag at ${this.i}`);return this.i++,"1"===e?1:0}}function d(e,t,i,r,a,o,l){if(s(e,l))return[];if(t=Math.abs(t),i=Math.abs(i),t<n||i<n)return[{to:l}];const c=r*Math.PI/180,d=Math.cos(c),p=Math.sin(c),h=(e[0]-l[0])/2,u=(e[1]-l[1])/2,m=d*h+p*u,g=-p*h+d*u,f=m*m/(t*t)+g*g/(i*i);if(f>1){const e=Math.sqrt(f);t*=e,i*=e}const v=t*t*i*i-t*t*g*g-i*i*m*m,b=t*t*g*g+i*i*m*m;let y=Math.sqrt(Math.max(0,v/b));a===o&&(y=-y);const x=y*t*g/i,_=-y*i*m/t,w=d*x-p*_+(e[0]+l[0])/2,k=p*x+d*_+(e[1]+l[1])/2,$=(e,t,i,n)=>Math.atan2(e*n-t*i,e*i+t*n),M=(m-x)/t,S=(g-_)/i,z=(-m-x)/t,C=(-g-_)/i,A=$(1,0,M,S);let j=$(M,S,z,C);!o&&j>0?j-=2*Math.PI:o&&j<0&&(j+=2*Math.PI);const q=Math.max(1,Math.ceil(Math.abs(j)/(Math.PI/2)-1e-9)),E=j/q,H=4/3*Math.tan(E/4),L=e=>[w+t*Math.cos(e)*d-i*Math.sin(e)*p,k+t*Math.cos(e)*p+i*Math.sin(e)*d],V=e=>[-t*Math.sin(e)*d-i*Math.cos(e)*p,-t*Math.sin(e)*p+i*Math.cos(e)*d],O=[];let P=e;for(let e=0;e<q;e++){const t=A+e*E,i=t+E,n=e===q-1?l:L(i),s=V(t),r=V(i);O.push({c1:[P[0]+H*s[0],P[1]+H*s[1]],c2:[n[0]-H*r[0],n[1]-H*r[1]],to:n}),P=n}return O}function p(e){const t=new c(e),i=[];let n,r,a,l,p=[0,0],h=[0,0];const u=e=>{n||(n={start:p,segs:[],closed:!1},i.push(n),h=p),n.segs.push(e)};try{for(;!t.done();){const e=t.command();if(e)l=e;else{if(!l||!t.hasNumber())break;"M"===l?l="L":"m"===l&&(l="l")}const i=l===l.toLowerCase(),c=i?p[0]:0,m=i?p[1]:0,g=()=>[t.number()+c,t.number()+m];let f,v,b;switch(l.toUpperCase()){case"M":p=g(),h=p,n=void 0;break;case"L":u({to:b=g()});break;case"H":u({to:b=[t.number()+c,p[1]]});break;case"V":u({to:b=[p[0],t.number()+m]});break;case"C":{const e=g();f=g(),u({c1:e,c2:f,to:b=g()});break}case"S":{const e=r?[2*p[0]-r[0],2*p[1]-r[1]]:p;f=g(),u({c1:e,c2:f,to:b=g()});break}case"Q":v=g(),u(o(p,v,b=g()));break;case"T":v=a?[2*p[0]-a[0],2*p[1]-a[1]]:p,u(o(p,v,b=g()));break;case"A":{const e=t.number(),i=t.number(),n=t.number(),s=t.flag(),r=t.flag();b=g(),d(p,e,i,n,s,r,b).forEach(u);break}case"Z":n&&n.segs.length&&(s(p,h)||n.segs.push({to:h}),n.closed=!0),p=h,n=void 0,l=void 0}b&&(p=b),r=f,a=v}}catch{}return i.filter(e=>e.segs.length>0)}const h=e=>{const t=Math.round(100*e)/100;return String(Object.is(t,-0)?0:t)},u=e=>`${h(e[0])} ${h(e[1])}`;function m(e){return e.map(e=>{const t=e.segs.slice(),i=t[t.length-1];return e.closed&&i&&!i.c1&&s(i.to,e.start)&&t.length>1&&t.pop(),[`M${u(e.start)}`,...t.map(e=>e.c1&&e.c2?`C${u(e.c1)} ${u(e.c2)} ${u(e.to)}`:`L${u(e.to)}`),...e.closed?["Z"]:[]].join(" ")}).join(" ")}function g(e,t,i){const n=1-i;return t.c1&&t.c2?[n*n*n*e[0]+3*n*n*i*t.c1[0]+3*n*i*i*t.c2[0]+i*i*i*t.to[0],n*n*n*e[1]+3*n*n*i*t.c1[1]+3*n*i*i*t.c2[1]+i*i*i*t.to[1]]:[e[0]+(t.to[0]-e[0])*i,e[1]+(t.to[1]-e[1])*i]}function f(e,t){const[i,n,s,r]=e,o=a(i,n,t),l=a(n,s,t),c=a(s,r,t),d=a(o,l,t),p=a(l,c,t),h=a(d,p,t);return[[i,o,d,h],[h,p,c,r]]}function v(e,t=12){const i=[e.start];let n=e.start;for(const s of e.segs){if(s.c1)for(let e=1;e<t;e++)i.push(g(n,s,e/t));i.push(s.to),n=s.to}return i.length>1&&s(i[i.length-1],e.start)&&i.pop(),i}const b=(e,t)=>Math.hypot(e[0]-t[0],e[1]-t[1]),y=e=>{const t=Math.round(1e3*e)/1e3;return String(Object.is(t,-0)?0:t)};function x(e){return e.map(e=>{if(!e.length)return"";const t=e=>`${y(e[0])} ${y(e[1])}`,i=e.map(e=>`C${t(e[1])} ${t(e[2])} ${t(e[3])}`).join("");return`M${t(e[0][0])}${i}${(e=>e.length>1&&s(e[0][0],e[e.length-1][3]))(e)?"Z":""}`}).join("")}i.d(t,["Mj",0,e=>p(e).map(e=>{let t=e.start;return e.segs.map(e=>{const i=((e,t)=>t.c1&&t.c2?[e,t.c1,t.c2,t.to]:((e,t)=>[e,a(e,t,1/3),a(e,t,2/3),t])(e,t.to))(t,e);return t=e.to,i})}),"Mo",0,(e,t)=>{const i=1-t;return[i*i*i*e[0][0]+3*i*i*t*e[1][0]+3*i*t*t*e[2][0]+t*t*t*e[3][0],i*i*i*e[0][1]+3*i*i*t*e[1][1]+3*i*t*t*e[2][1]+t*t*t*e[3][1]]},"Wv",0,(e,t,i)=>{const n=i[0]-t[0],s=i[1]-t[1],r=n*n+s*s;if(r<1e-9)return b(e,t);const a=Math.max(0,Math.min(1,((e[0]-t[0])*n+(e[1]-t[1])*s)/r));return b(e,[t[0]+n*a,t[1]+s*a])},"xg",0,b])},8164(e,t,i){i.r(t),i.d(t,{append:()=>w,bounds:()=>H,fmtNum:()=>p,fromEdit:()=>f,insertAt:()=>_,isSmooth:()=>v,moveAnchor:()=>$,nearestOnPath:()=>y,remove:()=>k,reverse:()=>j,segment:()=>g,segmentCount:()=>m,setClosed:()=>q,setHandle:()=>M,setKind:()=>S,smoothAll:()=>C,toEdit:()=>u,toggleSmooth:()=>A,transform:()=>E});var n=i(1771);const s=1e-4,r=(e,t,i=s)=>Math.abs(e[0]-t[0])<i&&Math.abs(e[1]-t[1])<i,a=(e,t,i)=>[e[0]+(t[0]-e[0])*i,e[1]+(t[1]-e[1])*i],o=e=>[e.x,e.y],l=e=>e?[e[0],e[1]]:void 0,c=e=>{const t={x:e.x,y:e.y,in:l(e.in),out:l(e.out)};return e.kind&&(t.kind=e.kind),t},d=e=>({anchors:e.anchors.map(c),closed:e.closed});function p(e){const t=Math.round(100*e)/100;return String(Object.is(t,-0)?0:t)}const h=e=>{const t=Math.max(s,.001*Math.hypot(e[3][0]-e[0][0],e[3][1]-e[0][1]));return r(e[1],a(e[0],e[3],1/3),t)&&r(e[2],a(e[0],e[3],2/3),t)};function u(e){const t=[{x:e.start[0],y:e.start[1]}];let i=e.start;for(const n of e.segs){const e=t[t.length-1],s={x:n.to[0],y:n.to[1]};n.c1&&n.c2&&!h([i,n.c1,n.c2,n.to])&&(r(n.c1,i)||(e.out=[n.c1[0],n.c1[1]]),r(n.c2,n.to)||(s.in=[n.c2[0],n.c2[1]])),t.push(s),i=n.to}const n=e.closed&&e.segs.length>0;if(n&&t.length>1){const e=t.pop();t[0].in=e.in}return{anchors:t,closed:n&&t.length>1}}function m(e){const t=e.anchors.length;return t<2?0:e.closed?t:t-1}function g(e,t){const i=e.anchors[t],n=e.anchors[(t+1)%e.anchors.length];return[o(i),i.out??o(i),n.in??o(n),o(n)]}function f(e){const t=e.anchors[0],i=Array.from({length:m(e)},(t,i)=>{const n=g(e,i);return((e,t)=>!e.anchors[t].out&&!e.anchors[(t+1)%e.anchors.length].in)(e,i)?{to:n[3]}:{c1:n[1],c2:n[2],to:n[3]}});return{start:t?o(t):[0,0],segs:i,closed:e.closed&&e.anchors.length>1}}function v(e){if(!e.in||!e.out)return!1;const t=e.in[0]-e.x,i=e.in[1]-e.y,n=e.out[0]-e.x,r=e.out[1]-e.y,a=Math.hypot(t,i),o=Math.hypot(n,r);return!(a<s||o<s)&&-(t*n+i*r)/(a*o)>.9995}const b=(e,t)=>{const i=1-t,n=i*i*i,s=3*i*i*t,r=3*i*t*t,a=t*t*t;return[n*e[0][0]+s*e[1][0]+r*e[2][0]+a*e[3][0],n*e[0][1]+s*e[1][1]+r*e[2][1]+a*e[3][1]]};function y(e,t,i=[1,1]){const n=m(e);if(!n)return;const s=e=>Math.hypot((e[0]-t[0])*i[0],(e[1]-t[1])*i[1]);let r;for(let t=0;t<n;t++){const i=g(e,t),n=32;let a=0,o=1/0;for(let e=0;e<=n;e++){const t=s(b(i,e/n));t<o&&(o=t,a=e/n)}let l=1/n;for(let e=0;e<12;e++){l/=2;for(const e of[a-l,a+l]){if(e<0||e>1)continue;const t=s(b(i,e));t<o&&(o=t,a=e)}}(!r||o<r.dist)&&(r={seg:t,t:a,point:b(i,a),dist:o})}return r}const x=e=>e.anchors.length<100;function _(e,t,i){const s=d(e),l=s.anchors.length;if(t<0||t>=m(s)||!x(s))return{path:s,index:-1};const c=s.anchors[t],p=s.anchors[(t+1)%l],h=Math.min(1,Math.max(0,i));if(!c.out&&!p.in){const e=a(o(c),o(p),h);return s.anchors.splice(t+1,0,{x:e[0],y:e[1]}),{path:s,index:t+1}}const[u,f]=(0,n.fs)(g(s,t),h);c.out=r(u[1],u[0])?void 0:u[1],p.in=r(f[2],f[3])?void 0:f[2];const v={x:u[3][0],y:u[3][1],in:r(u[2],u[3])?void 0:u[2],out:r(f[1],f[0])?void 0:f[1]};return s.anchors.splice(t+1,0,v),{path:s,index:t+1}}function w(e,t,i=!1){const n=d(e);if(!x(n))return{path:n,index:-1};const s={x:t[0],y:t[1]};return i?(n.anchors.unshift(s),{path:n,index:0}):(n.anchors.push(s),{path:n,index:n.anchors.length-1})}function k(e,t){const i=d(e);return t<0||t>=i.anchors.length||(i.anchors.splice(t,1),i.anchors.length<2&&(i.closed=!1)),i}function $(e,t,i,n){const s=d(e),r=s.anchors[t];if(!r)return s;const a=i-r.x,o=n-r.y;return r.x=i,r.y=n,r.in&&(r.in=[r.in[0]+a,r.in[1]+o]),r.out&&(r.out=[r.out[0]+a,r.out[1]+o]),s}function M(e,t,i,n,s){const a=d(e),l=a.anchors[t];if(!l)return a;const c=s??(e=>e.kind??(v(e)?"smooth":"corner"))(l),p=r(n,o(l))?void 0:[n[0],n[1]];l[i]=p;const h="in"===i?"out":"in";if("symmetric"===c)l[h]=p?[2*l.x-p[0],2*l.y-p[1]]:void 0;else if("smooth"===c&&p&&l[h]){const e=Math.hypot(l[h][0]-l.x,l[h][1]-l.y),t=Math.hypot(l.x-p[0],l.y-p[1]);l[h]=[l.x+(l.x-p[0])/t*e,l.y+(l.y-p[1])/t*e]}return a}function S(e,t,i){const n=d(e),s=n.anchors[t];return s?(s.kind=i,"corner"!==i&&s.in&&s.out?M(n,t,"in",s.in,i):n):n}function z(e,t,i){const n=t.anchors[i],r=function(e,t){const i=e.anchors.length;if(i<2)return;const n=e.anchors[t],r=t>0?e.anchors[t-1]:e.closed?e.anchors[i-1]:n,a=t<i-1?e.anchors[t+1]:e.closed?e.anchors[0]:n,o=(a.x-r.x)/6,l=(a.y-r.y)/6;return Math.hypot(o,l)<s?void 0:[o,l]}(e,i);r&&(n.in=e.closed||i>0?[n.x-r[0],n.y-r[1]]:void 0,n.out=e.closed||i<e.anchors.length-1?[n.x+r[0],n.y+r[1]]:void 0)}function C(e){const t=d(e);for(let i=0;i<t.anchors.length;i++)z(e,t,i);return t}function A(e,t){const i=d(e),n=i.anchors[t];return n?(n.in||n.out?(n.in=void 0,n.out=void 0):z(e,i,t),i):i}function j(e){const t=e.anchors.map(e=>{const t={x:e.x,y:e.y,in:l(e.out),out:l(e.in)};return e.kind&&(t.kind=e.kind),t}).reverse();return e.closed&&t.length&&t.unshift(t.pop()),{anchors:t,closed:e.closed}}function q(e,t){const i=d(e);return i.closed=t&&i.anchors.length>1,!i.closed&&i.anchors.length&&(i.anchors[0].in=void 0,i.anchors[i.anchors.length-1].out=void 0),i}function E(e,t){const i=(e,i)=>[t[0]*e+t[2]*i+t[4],t[1]*e+t[3]*i+t[5]],n=e=>e?i(e[0],e[1]):void 0;return{anchors:e.anchors.map(e=>{const[t,s]=i(e.x,e.y),r={x:t,y:s,in:n(e.in),out:n(e.out)};return e.kind&&(r.kind=e.kind),r}),closed:e.closed}}function H(e){const t=[];for(const i of e.anchors)t.push(o(i)),i.in&&t.push(i.in),i.out&&t.push(i.out);if(!t.length)return;const i=t.map(e=>e[0]),n=t.map(e=>e[1]),s=Math.min(...i),r=Math.min(...n);return{x:s,y:r,w:Math.max(...i)-s,h:Math.max(...n)-r}}i.d(t,["MAX_ANCHORS",0,100,"canAdd",0,x,"copyAnchor",0,c,"copyPath",0,d,"serialize",0,e=>e.anchors.length?(0,n.uD)([f(e)]):"","snap",0,(e,t)=>t>0?Math.round(e/t)*t:e,"straightenAll",0,e=>({anchors:e.anchors.map(e=>({x:e.x,y:e.y})),closed:e.closed}),"translate",0,(e,t,i)=>E(e,[1,0,0,1,t,i])])},3910(e,t,i){i.d(t,{I:()=>o,M7:()=>l,dp:()=>c,wn:()=>a});const n=/[\\<>]|\/\/|\/\*|javascript:|vbscript:|data:|expression\s*\(|@import/i,s=e=>32===e||e>=9&&e<=13||160===e||5760===e||e>=8192&&e<=8202||8232===e||8233===e||8239===e||8287===e||12288===e||65279===e,r=e=>e>=65&&e<=90||e>=97&&e<=122;function a(e,t){for(let i=e.indexOf("(");i>=0;i=e.indexOf("(",i+1)){let n=i;for(;n>0&&s(e.charCodeAt(n-1));)n--;let a=n;for(;a>0&&(r(e.charCodeAt(a-1))||45===e.charCodeAt(a-1));)a--;if(a===n||!t.includes(e.slice(a,n).toLowerCase()))return!1}return!0}function o(e,t){return Object.prototype.hasOwnProperty.call(e.kinds,t)?e.kinds[t]:e.fallback}function l(e,t,i){if(void 0!==i.maxValueChars&&t.length>i.maxValueChars)return;const s=t.trim();if(!function(e,t){if(n.test(e))return!0;if(!t.denyExtra.length)return!1;const i=e.toLowerCase();return t.denyExtra.some(e=>i.includes(e))}(s,i)){if("transform"===e)return a(s,i.transformFunctions)?t:void 0;if(a(s.replace(/url\(\s*(['"]?)#[\w.:-]+\1\s*\)/gi,""),i.colourFunctions))return"id"===e?/^[\w.:-]+$/.test(s)?s:void 0:"class"===e?function(e,t){const i=e.split(/\s+/).filter(e=>t.test(e));return i.length?i.join(" "):void 0}(s,/^[\w-]+$/):t}}function c(e){return"undefined"!=typeof TextEncoder?(new TextEncoder).encode(e).length:e.length}const d=e=>e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");i.d(t,["X1",0,d,"dc",0,e=>d(e).replace(/"/g,"&quot;")])},2637(e,t,i){i.d(t,{WP:()=>p,Zg:()=>h,hd:()=>u});var n=i(1771);function s(e){const t=e.length?[e[0][0]]:[];for(const[i,n,s,r]of e)for(let e=1;e<=8;e++){const a=e/8,o=1-a,l=o*o*o,c=3*o*o*a,d=3*o*a*a,p=a*a*a;t.push([l*i[0]+c*n[0]+d*s[0]+p*r[0],l*i[1]+c*n[1]+d*s[1]+p*r[1]])}return t}function r(e){let t=0;for(let i=0;i<e.length;i++){const[n,s]=e[i],[r,a]=e[(i+1)%e.length];t+=n*a-r*s}return t/2}function a(e){if(!e.length)return[0,0,0,0];let t=1/0,i=1/0,n=-1/0,s=-1/0;for(const[r,a]of e)r<t&&(t=r),a<i&&(i=a),r>n&&(n=r),a>s&&(s=a);const r=e=>+e.toFixed(3);return[r(t),r(i),r(n-t),r(s-i)]}function o(e,t){let i=!1;for(let n=0,s=t.length-1;n<t.length;s=n++){const[r,a]=t[n],[o,l]=t[s];a>e[1]!=l>e[1]&&e[0]<(o-r)*(e[1]-a)/(l-a)+r&&(i=!i)}return i}function l(e,t){if(!((e,t,i=.001)=>e[0]>=t[0]-i&&e[1]>=t[1]-i&&e[0]+e[2]<=t[0]+t[2]+i&&e[1]+e[3]<=t[1]+t[3]+i)(t.box,e.box))return!1;const i=t.poly,n=Math.max(1,Math.floor(i.length/16));let s=0,r=0;for(let t=0;t<i.length;t+=n)s++,o(i[t],e.poly)&&r++;return s>0&&r/s>=.6}const c=1e-6,d=(e,t)=>({index:e,d:(0,n.ER)(t),bbox:a(t.flatMap(s))});function p(e){const t=[],i=e=>t.push({...e,index:t.length}),o=(t,i)=>!!e.evenodd?.[t]?.includes(i),p=e=>e?{evenodd:!0}:{},h=e=>(0,n.Mj)(e).filter(e=>Math.abs(r(s(e)))>c);if((e.secondary??[]).forEach((e,t)=>{const n=h(e);n.length&&i({...d(0,n),secondary:!0,...p(o("accent",t))})}),1===e.paths.length){const t=o("paths",0);for(const o of function(e,t=!1){const i=(0,n.Mj)(e).map(e=>{const t=s(e);return{cubics:e,poly:t,area:r(t),box:a(t)}}).filter(e=>Math.abs(e.area)>c),o=i.map((e,t)=>t),d=i.map((e,t)=>t).sort((e,t)=>Math.abs(i[t].area)-Math.abs(i[e].area)||e-t);d.forEach((e,n)=>{let s=-1,r=0,a=0;for(let t=0;t<n;t++){const n=d[t];Math.abs(i[n].area)<=Math.abs(i[e].area)||l(i[n],i[e])&&(r+=Math.sign(i[n].area),a++,(s<0||Math.abs(i[n].area)<Math.abs(i[s].area))&&(s=n))}const c=t?a%2==1:0!==r&&r+Math.sign(i[e].area)===0;s>=0&&c&&(o[e]=o[s])});const p=new Map;return o.forEach((e,t)=>{const i=p.get(e);i?i.push(t):p.set(e,[t])}),[...p.values()].sort((e,t)=>e[0]-t[0]).map(e=>e.map(e=>i[e].cubics))}(e.paths[0],t))i({...d(0,o),...p(t)})}else e.paths.forEach((e,t)=>{const n=h(e);n.length&&i({...d(0,n),...p(o("paths",t))})});for(const t of e.strokes??[]){const e=(0,n.Mj)(t.d);e.length&&i({...d(0,e),stroke:{width:t.width,...t.cap?{cap:t.cap}:{},...t.join?{join:t.join}:{}},...t.accent?{secondary:!0}:{}})}return t}function h(e){if(!e.length)return;const t=Math.min(...e.map(e=>e[0])),i=Math.min(...e.map(e=>e[1])),n=Math.max(...e.map(e=>e[0]+e[2])),s=Math.max(...e.map(e=>e[1]+e[3])),r=e=>+e.toFixed(3);return[r(t),r(i),r(n-t),r(s-i)]}function u(e){return a((0,n.Mj)(e).flatMap(s))}},2231(e,t,i){i.d(t,{t:()=>s});const n="2026.11.03-beta.2";function s(e,t){if(t?.BUILD===n)return t;console.warn(`Magic Card was updated, reload the page (magic-card.js ${n}, ${e} ${String(t?.BUILD)}).`)}i.d(t,["Q",0,n])},796(e,t,i){i.d(t,{ZV:()=>s});var n=i(1699);function s(e,t,i=1){const s={maximumFractionDigits:i};let r;"none"===e?.locale?.number_format&&(s.useGrouping=!1);try{r=new Intl.NumberFormat(function(e){switch(e?.locale?.number_format){case"comma_decimal":return"en-US";case"decimal_comma":return"de";case"space_comma":return"fr";case"system":return;default:return function(e){return e?.locale?.language||e?.language||void 0}(e)}}(e),s).format(t)}catch{r=String(t)}return(0,n.C1)(r,"num")}},3826(e,t,i){const n=globalThis,s=n.ShadowRoot&&(void 0===n.ShadyCSS||n.ShadyCSS.nativeShadow)&&"adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,r=Symbol(),a=new WeakMap;class o{constructor(e,t,i){if(this._$cssResult$=!0,i!==r)throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=e,this.t=t}get styleSheet(){let e=this.o;const t=this.t;if(s&&void 0===e){const i=void 0!==t&&1===t.length;i&&(e=a.get(t)),void 0===e&&((this.o=e=new CSSStyleSheet).replaceSync(this.cssText),i&&a.set(t,e))}return e}toString(){return this.cssText}}const l=e=>new o("string"==typeof e?e:e+"",void 0,r),c=s?e=>e:e=>e instanceof CSSStyleSheet?(e=>{let t="";for(const i of e.cssRules)t+=i.cssText;return l(t)})(e):e;i.d(t,["AH",0,(e,...t)=>{const i=1===e.length?e[0]:t.reduce((t,i,n)=>t+(e=>{if(!0===e._$cssResult$)return e.cssText;if("number"==typeof e)return e;throw Error("Value passed to 'css' function must be a 'css' function result: "+e+". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.")})(i)+e[n+1],e[0]);return new o(i,e,r)},"Rf",0,(e,t)=>{if(s)e.adoptedStyleSheets=t.map(e=>e instanceof CSSStyleSheet?e:e.styleSheet);else for(const i of t){const t=document.createElement("style"),s=n.litNonce;void 0!==s&&t.setAttribute("nonce",s),t.textContent=i.cssText,e.appendChild(t)}},"iz",0,l,"sk",0,c])},6505(e,t,i){i.d(t,["E",0,e=>(t,i)=>{void 0!==i?i.addInitializer(()=>{customElements.define(e,t)}):customElements.define(e,t)}])},5694(e,t,i){i.d(t,{M:()=>a});var n=i(8760);const s={attribute:!0,type:String,converter:n.W3,reflect:!1,hasChanged:n.Ec},r=(e=s,t,i)=>{const{kind:n,metadata:r}=i;let a=globalThis.litPropertyMetadata.get(r);if(void 0===a&&globalThis.litPropertyMetadata.set(r,a=new Map),"setter"===n&&((e=Object.create(e)).wrapped=!0),a.set(i.name,e),"accessor"===n){const{name:n}=i;return{set(i){const s=t.get.call(this);t.set.call(this,i),this.requestUpdate(n,s,e,!0,i)},init(t){return void 0!==t&&this.C(n,void 0,e,t),t}}}if("setter"===n){const{name:n}=i;return function(i){const s=this[n];t.call(this,i),this.requestUpdate(n,s,e,!0,i)}}throw Error("Unsupported decorator location: "+n)};function a(e){return(t,i)=>"object"==typeof i?r(e,t,i):((e,t,i)=>{const n=t.hasOwnProperty(i);return t.constructor.createProperty(i,e),n?Object.getOwnPropertyDescriptor(t,i):void 0})(e,t,i)}},4290(e,t,i){i.d(t,{w:()=>s});var n=i(5694);function s(e){return(0,n.M)({...e,state:!0,attribute:!1})}},8760(e,t,i){i.d(t,{AH:()=>n.AH,iz:()=>n.iz,mN:()=>v});var n=i(3826);const{is:s,defineProperty:r,getOwnPropertyDescriptor:a,getOwnPropertyNames:o,getOwnPropertySymbols:l,getPrototypeOf:c}=Object,d=globalThis,p=d.trustedTypes,h=p?p.emptyScript:"",u=d.reactiveElementPolyfillSupport,m={toAttribute(e,t){switch(t){case Boolean:e=e?h:null;break;case Object:case Array:e=null==e?e:JSON.stringify(e)}return e},fromAttribute(e,t){let i=e;switch(t){case Boolean:i=null!==e;break;case Number:i=null===e?null:Number(e);break;case Object:case Array:try{i=JSON.parse(e)}catch(e){i=null}}return i}},g=(e,t)=>!s(e,t),f={attribute:!0,type:String,converter:m,reflect:!1,useDefault:!1,hasChanged:g};Symbol.metadata??=Symbol("metadata"),d.litPropertyMetadata??=new WeakMap;class v extends HTMLElement{static addInitializer(e){this._$Ei(),(this.l??=[]).push(e)}static get observedAttributes(){return this.finalize(),this._$Eh&&[...this._$Eh.keys()]}static createProperty(e,t=f){if(t.state&&(t.attribute=!1),this._$Ei(),this.prototype.hasOwnProperty(e)&&((t=Object.create(t)).wrapped=!0),this.elementProperties.set(e,t),!t.noAccessor){const i=Symbol(),n=this.getPropertyDescriptor(e,i,t);void 0!==n&&r(this.prototype,e,n)}}static getPropertyDescriptor(e,t,i){const{get:n,set:s}=a(this.prototype,e)??{get(){return this[t]},set(e){this[t]=e}};return{get:n,set(t){const r=n?.call(this);s?.call(this,t),this.requestUpdate(e,r,i)},configurable:!0,enumerable:!0}}static getPropertyOptions(e){return this.elementProperties.get(e)??f}static _$Ei(){if(this.hasOwnProperty("elementProperties"))return;const e=c(this);e.finalize(),void 0!==e.l&&(this.l=[...e.l]),this.elementProperties=new Map(e.elementProperties)}static finalize(){if(this.hasOwnProperty("finalized"))return;if(this.finalized=!0,this._$Ei(),this.hasOwnProperty("properties")){const e=this.properties,t=[...o(e),...l(e)];for(const i of t)this.createProperty(i,e[i])}const e=this[Symbol.metadata];if(null!==e){const t=litPropertyMetadata.get(e);if(void 0!==t)for(const[e,i]of t)this.elementProperties.set(e,i)}this._$Eh=new Map;for(const[e,t]of this.elementProperties){const i=this._$Eu(e,t);void 0!==i&&this._$Eh.set(i,e)}this.elementStyles=this.finalizeStyles(this.styles)}static finalizeStyles(e){const t=[];if(Array.isArray(e)){const i=new Set(e.flat(1/0).reverse());for(const e of i)t.unshift((0,n.sk)(e))}else void 0!==e&&t.push((0,n.sk)(e));return t}static _$Eu(e,t){const i=t.attribute;return!1===i?void 0:"string"==typeof i?i:"string"==typeof e?e.toLowerCase():void 0}constructor(){super(),this._$Ep=void 0,this.isUpdatePending=!1,this.hasUpdated=!1,this._$Em=null,this._$Ev()}_$Ev(){this._$ES=new Promise(e=>this.enableUpdating=e),this._$AL=new Map,this._$E_(),this.requestUpdate(),this.constructor.l?.forEach(e=>e(this))}addController(e){(this._$EO??=new Set).add(e),void 0!==this.renderRoot&&this.isConnected&&e.hostConnected?.()}removeController(e){this._$EO?.delete(e)}_$E_(){const e=new Map,t=this.constructor.elementProperties;for(const i of t.keys())this.hasOwnProperty(i)&&(e.set(i,this[i]),delete this[i]);e.size>0&&(this._$Ep=e)}createRenderRoot(){const e=this.shadowRoot??this.attachShadow(this.constructor.shadowRootOptions);return(0,n.Rf)(e,this.constructor.elementStyles),e}connectedCallback(){this.renderRoot??=this.createRenderRoot(),this.enableUpdating(!0),this._$EO?.forEach(e=>e.hostConnected?.())}enableUpdating(e){}disconnectedCallback(){this._$EO?.forEach(e=>e.hostDisconnected?.())}attributeChangedCallback(e,t,i){this._$AK(e,i)}_$ET(e,t){const i=this.constructor.elementProperties.get(e),n=this.constructor._$Eu(e,i);if(void 0!==n&&!0===i.reflect){const s=(void 0!==i.converter?.toAttribute?i.converter:m).toAttribute(t,i.type);this._$Em=e,null==s?this.removeAttribute(n):this.setAttribute(n,s),this._$Em=null}}_$AK(e,t){const i=this.constructor,n=i._$Eh.get(e);if(void 0!==n&&this._$Em!==n){const e=i.getPropertyOptions(n),s="function"==typeof e.converter?{fromAttribute:e.converter}:void 0!==e.converter?.fromAttribute?e.converter:m;this._$Em=n;const r=s.fromAttribute(t,e.type);this[n]=r??this._$Ej?.get(n)??r,this._$Em=null}}requestUpdate(e,t,i,n=!1,s){if(void 0!==e){const r=this.constructor;if(!1===n&&(s=this[e]),i??=r.getPropertyOptions(e),!((i.hasChanged??g)(s,t)||i.useDefault&&i.reflect&&s===this._$Ej?.get(e)&&!this.hasAttribute(r._$Eu(e,i))))return;this.C(e,t,i)}!1===this.isUpdatePending&&(this._$ES=this._$EP())}C(e,t,{useDefault:i,reflect:n,wrapped:s},r){i&&!(this._$Ej??=new Map).has(e)&&(this._$Ej.set(e,r??t??this[e]),!0!==s||void 0!==r)||(this._$AL.has(e)||(this.hasUpdated||i||(t=void 0),this._$AL.set(e,t)),!0===n&&this._$Em!==e&&(this._$Eq??=new Set).add(e))}async _$EP(){this.isUpdatePending=!0;try{await this._$ES}catch(e){Promise.reject(e)}const e=this.scheduleUpdate();return null!=e&&await e,!this.isUpdatePending}scheduleUpdate(){return this.performUpdate()}performUpdate(){if(!this.isUpdatePending)return;if(!this.hasUpdated){if(this.renderRoot??=this.createRenderRoot(),this._$Ep){for(const[e,t]of this._$Ep)this[e]=t;this._$Ep=void 0}const e=this.constructor.elementProperties;if(e.size>0)for(const[t,i]of e){const{wrapped:e}=i,n=this[t];!0!==e||this._$AL.has(t)||void 0===n||this.C(t,void 0,i,n)}}let e=!1;const t=this._$AL;try{e=this.shouldUpdate(t),e?(this.willUpdate(t),this._$EO?.forEach(e=>e.hostUpdate?.()),this.update(t)):this._$EM()}catch(t){throw e=!1,this._$EM(),t}e&&this._$AE(t)}willUpdate(e){}_$AE(e){this._$EO?.forEach(e=>e.hostUpdated?.()),this.hasUpdated||(this.hasUpdated=!0,this.firstUpdated(e)),this.updated(e)}_$EM(){this._$AL=new Map,this.isUpdatePending=!1}get updateComplete(){return this.getUpdateComplete()}getUpdateComplete(){return this._$ES}shouldUpdate(e){return!0}update(e){this._$Eq&&=this._$Eq.forEach(e=>this._$ET(e,this[e])),this._$EM()}updated(e){}firstUpdated(e){}}v.elementStyles=[],v.shadowRootOptions={mode:"open"},v.elementProperties=new Map,v.finalized=new Map,u?.({ReactiveElement:v}),(d.reactiveElementVersions??=[]).push("2.1.2"),i.d(t,["Ec",0,g,"W3",0,m])},5228(e,t,i){i.d(t,{AH:()=>n.AH,JW:()=>s.JW,WF:()=>a,iz:()=>n.iz,qy:()=>s.qy,s6:()=>s.s6});var n=i(8760),s=i(6752);const r=globalThis;class a extends n.mN{constructor(){super(...arguments),this.renderOptions={host:this},this._$Do=void 0}createRenderRoot(){const e=super.createRenderRoot();return this.renderOptions.renderBefore??=e.firstChild,e}update(e){const t=this.render();this.hasUpdated||(this.renderOptions.isConnected=this.isConnected),super.update(e),this._$Do=(0,s.XX)(t,this.renderRoot,this.renderOptions)}connectedCallback(){super.connectedCallback(),this._$Do?.setConnected(!0)}disconnectedCallback(){super.disconnectedCallback(),this._$Do?.setConnected(!1)}render(){return s.c0}}a._$litElement$=!0,a.finalized=!0,r.litElementHydrateSupport?.({LitElement:a});const o=r.litElementPolyfillSupport;o?.({LitElement:a}),(r.litElementVersions??=[]).push("4.2.2")},7804(e,t,i){i.d(t,{WL:()=>n});class n{constructor(e){}get _$AU(){return this._$AM._$AU}_$AT(e,t,i){this._$Ct=e,this._$AM=t,this._$Ci=i}_$AS(e,t){return this.update(e,t)}update(e,t){return this.render(...t)}}i.d(t,["OA",0,{ATTRIBUTE:1,CHILD:2,PROPERTY:3,BOOLEAN_ATTRIBUTE:4,EVENT:5,ELEMENT:6},"u$",0,e=>(...t)=>({_$litDirective$:e,values:t})])},6752(e,t,i){const n=globalThis,s=e=>e,r=n.trustedTypes,a=r?r.createPolicy("lit-html",{createHTML:e=>e}):void 0,o="$lit$",l=`lit$${Math.random().toFixed(9).slice(2)}$`,c="?"+l,d=`<${c}>`,p=document,h=()=>p.createComment(""),u=e=>null===e||"object"!=typeof e&&"function"!=typeof e,m=Array.isArray,g=e=>m(e)||"function"==typeof e?.[Symbol.iterator],f="[ \t\n\f\r]",v=/<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,b=/-->/g,y=/>/g,x=RegExp(`>|${f}(?:([^\\s"'>=/]+)(${f}*=${f}*(?:[^ \t\n\f\r"'\`<>=]|("|')|))|$)`,"g"),_=/'/g,w=/"/g,k=/^(?:script|style|textarea|title)$/i,$=e=>(t,...i)=>({_$litType$:e,strings:t,values:i}),M=$(1),S=$(2),z=$(3),C=Symbol.for("lit-noChange"),A=Symbol.for("lit-nothing"),j=new WeakMap,q=p.createTreeWalker(p,129);function E(e,t){if(!m(e)||!e.hasOwnProperty("raw"))throw Error("invalid template strings array");return void 0!==a?a.createHTML(t):t}const H=(e,t)=>{const i=e.length-1,n=[];let s,r=2===t?"<svg>":3===t?"<math>":"",a=v;for(let t=0;t<i;t++){const i=e[t];let c,p,h=-1,u=0;for(;u<i.length&&(a.lastIndex=u,p=a.exec(i),null!==p);)u=a.lastIndex,a===v?"!--"===p[1]?a=b:void 0!==p[1]?a=y:void 0!==p[2]?(k.test(p[2])&&(s=RegExp("</"+p[2],"g")),a=x):void 0!==p[3]&&(a=x):a===x?">"===p[0]?(a=s??v,h=-1):void 0===p[1]?h=-2:(h=a.lastIndex-p[2].length,c=p[1],a=void 0===p[3]?x:'"'===p[3]?w:_):a===w||a===_?a=x:a===b||a===y?a=v:(a=x,s=void 0);const m=a===x&&e[t+1].startsWith("/>")?" ":"";r+=a===v?i+d:h>=0?(n.push(c),i.slice(0,h)+o+i.slice(h)+l+m):i+l+(-2===h?t:m)}return[E(e,r+(e[i]||"<?>")+(2===t?"</svg>":3===t?"</math>":"")),n]};class L{constructor({strings:e,_$litType$:t},i){let n;this.parts=[];let s=0,a=0;const d=e.length-1,p=this.parts,[u,m]=H(e,t);if(this.el=L.createElement(u,i),q.currentNode=this.el.content,2===t||3===t){const e=this.el.content.firstChild;e.replaceWith(...e.childNodes)}for(;null!==(n=q.nextNode())&&p.length<d;){if(1===n.nodeType){if(n.hasAttributes())for(const e of n.getAttributeNames())if(e.endsWith(o)){const t=m[a++],i=n.getAttribute(e).split(l),r=/([.?@])?(.*)/.exec(t);p.push({type:1,index:s,name:r[2],strings:i,ctor:"."===r[1]?D:"?"===r[1]?N:"@"===r[1]?F:R}),n.removeAttribute(e)}else e.startsWith(l)&&(p.push({type:6,index:s}),n.removeAttribute(e));if(k.test(n.tagName)){const e=n.textContent.split(l),t=e.length-1;if(t>0){n.textContent=r?r.emptyScript:"";for(let i=0;i<t;i++)n.append(e[i],h()),q.nextNode(),p.push({type:2,index:++s});n.append(e[t],h())}}}else if(8===n.nodeType)if(n.data===c)p.push({type:2,index:s});else{let e=-1;for(;-1!==(e=n.data.indexOf(l,e+1));)p.push({type:7,index:s}),e+=l.length-1}s++}}static createElement(e,t){const i=p.createElement("template");return i.innerHTML=e,i}}function V(e,t,i=e,n){if(t===C)return t;let s=void 0!==n?i._$Co?.[n]:i._$Cl;const r=u(t)?void 0:t._$litDirective$;return s?.constructor!==r&&(s?._$AO?.(!1),void 0===r?s=void 0:(s=new r(e),s._$AT(e,i,n)),void 0!==n?(i._$Co??=[])[n]=s:i._$Cl=s),void 0!==s&&(t=V(e,s._$AS(e,t.values),s,n)),t}class O{constructor(e,t){this._$AV=[],this._$AN=void 0,this._$AD=e,this._$AM=t}get parentNode(){return this._$AM.parentNode}get _$AU(){return this._$AM._$AU}u(e){const{el:{content:t},parts:i}=this._$AD,n=(e?.creationScope??p).importNode(t,!0);q.currentNode=n;let s=q.nextNode(),r=0,a=0,o=i[0];for(;void 0!==o;){if(r===o.index){let t;2===o.type?t=new P(s,s.nextSibling,this,e):1===o.type?t=new o.ctor(s,o.name,o.strings,this,e):6===o.type&&(t=new T(s,this,e)),this._$AV.push(t),o=i[++a]}r!==o?.index&&(s=q.nextNode(),r++)}return q.currentNode=p,n}p(e){let t=0;for(const i of this._$AV)void 0!==i&&(void 0!==i.strings?(i._$AI(e,i,t),t+=i.strings.length-2):i._$AI(e[t])),t++}}class P{get _$AU(){return this._$AM?._$AU??this._$Cv}constructor(e,t,i,n){this.type=2,this._$AH=A,this._$AN=void 0,this._$AA=e,this._$AB=t,this._$AM=i,this.options=n,this._$Cv=n?.isConnected??!0}get parentNode(){let e=this._$AA.parentNode;const t=this._$AM;return void 0!==t&&11===e?.nodeType&&(e=t.parentNode),e}get startNode(){return this._$AA}get endNode(){return this._$AB}_$AI(e,t=this){e=V(this,e,t),u(e)?e===A||null==e||""===e?(this._$AH!==A&&this._$AR(),this._$AH=A):e!==this._$AH&&e!==C&&this._(e):void 0!==e._$litType$?this.$(e):void 0!==e.nodeType?this.T(e):g(e)?this.k(e):this._(e)}O(e){return this._$AA.parentNode.insertBefore(e,this._$AB)}T(e){this._$AH!==e&&(this._$AR(),this._$AH=this.O(e))}_(e){this._$AH!==A&&u(this._$AH)?this._$AA.nextSibling.data=e:this.T(p.createTextNode(e)),this._$AH=e}$(e){const{values:t,_$litType$:i}=e,n="number"==typeof i?this._$AC(e):(void 0===i.el&&(i.el=L.createElement(E(i.h,i.h[0]),this.options)),i);if(this._$AH?._$AD===n)this._$AH.p(t);else{const e=new O(n,this),i=e.u(this.options);e.p(t),this.T(i),this._$AH=e}}_$AC(e){let t=j.get(e.strings);return void 0===t&&j.set(e.strings,t=new L(e)),t}k(e){m(this._$AH)||(this._$AH=[],this._$AR());const t=this._$AH;let i,n=0;for(const s of e)n===t.length?t.push(i=new P(this.O(h()),this.O(h()),this,this.options)):i=t[n],i._$AI(s),n++;n<t.length&&(this._$AR(i&&i._$AB.nextSibling,n),t.length=n)}_$AR(e=this._$AA.nextSibling,t){for(this._$AP?.(!1,!0,t);e!==this._$AB;){const t=s(e).nextSibling;s(e).remove(),e=t}}setConnected(e){void 0===this._$AM&&(this._$Cv=e,this._$AP?.(e))}}class R{get tagName(){return this.element.tagName}get _$AU(){return this._$AM._$AU}constructor(e,t,i,n,s){this.type=1,this._$AH=A,this._$AN=void 0,this.element=e,this.name=t,this._$AM=n,this.options=s,i.length>2||""!==i[0]||""!==i[1]?(this._$AH=Array(i.length-1).fill(new String),this.strings=i):this._$AH=A}_$AI(e,t=this,i,n){const s=this.strings;let r=!1;if(void 0===s)e=V(this,e,t,0),r=!u(e)||e!==this._$AH&&e!==C,r&&(this._$AH=e);else{const n=e;let a,o;for(e=s[0],a=0;a<s.length-1;a++)o=V(this,n[i+a],t,a),o===C&&(o=this._$AH[a]),r||=!u(o)||o!==this._$AH[a],o===A?e=A:e!==A&&(e+=(o??"")+s[a+1]),this._$AH[a]=o}r&&!n&&this.j(e)}j(e){e===A?this.element.removeAttribute(this.name):this.element.setAttribute(this.name,e??"")}}class D extends R{constructor(){super(...arguments),this.type=3}j(e){this.element[this.name]=e===A?void 0:e}}class N extends R{constructor(){super(...arguments),this.type=4}j(e){this.element.toggleAttribute(this.name,!!e&&e!==A)}}class F extends R{constructor(e,t,i,n,s){super(e,t,i,n,s),this.type=5}_$AI(e,t=this){if((e=V(this,e,t,0)??A)===C)return;const i=this._$AH,n=e===A&&i!==A||e.capture!==i.capture||e.once!==i.once||e.passive!==i.passive,s=e!==A&&(i===A||n);n&&this.element.removeEventListener(this.name,this,i),s&&this.element.addEventListener(this.name,this,e),this._$AH=e}handleEvent(e){"function"==typeof this._$AH?this._$AH.call(this.options?.host??this.element,e):this._$AH.handleEvent(e)}}class T{constructor(e,t,i){this.element=e,this.type=6,this._$AN=void 0,this._$AM=t,this.options=i}get _$AU(){return this._$AM._$AU}_$AI(e){V(this,e)}}const B={M:o,P:l,A:c,C:1,L:H,R:O,D:g,V,I:P,H:R,N,U:F,B:D,F:T},I=n.litHtmlPolyfillSupport;I?.(L,P),(n.litHtmlVersions??=[]).push("3.3.3"),i.d(t,["JW",0,S,"XX",0,(e,t,i)=>{const n=i?.renderBefore??t;let s=n._$litPart$;if(void 0===s){const e=i?.renderBefore??null;n._$litPart$=s=new P(t.insertBefore(h(),e),e,void 0,i??{})}return s._$AI(e),s},"c0",0,C,"ej",0,z,"ge",0,B,"qy",0,M,"s6",0,A])},5707(e,t,i){i.d(t,{EM:()=>n.E,MZ:()=>s.M,wk:()=>r.w});var n=i(6505),s=i(5694),r=i(4290)},6161(e,t,i){i.d(t,{AH:()=>n.AH,JW:()=>n.JW,WF:()=>n.WF,iz:()=>n.iz,qy:()=>n.qy,s6:()=>n.s6}),i(8760),i(6752);var n=i(5228)}};const t={};function i(n){const s=t[n];if(void 0!==s)return s.exports;const r=t[n]={exports:{}};return e[n](r,r.exports,i),r.exports}if(i.m=e,i.d=(e,t)=>{if(Array.isArray(t))for(var n=0;n<t.length;){var s=t[n++],r=t[n++],a=0===r?{enumerable:!0,value:t[n++]}:{enumerable:!0,get:r};i.o(e,s)||Object.defineProperty(e,s,a)}else for(var s in t)i.o(t,s)&&!i.o(e,s)&&Object.defineProperty(e,s,{enumerable:!0,get:t[s]})},i.f={},i.e=e=>{const t=[];return i.f.j(e,t),Promise.all(t)},i.u=e=>"magic-card-"+{1400:"studio-fonts",2334:"icon-library",3575:"path-canvas",3626:"icon-shared",5494:"preset-catalogue",8249:"i18n-labels",8278:"i18n-pseudo",8342:"i18n-icons",9417:"svg-css"}[e]+"."+{1400:"14172e44",2334:"9753ae0c",3575:"75c4e184",3626:"1e68cf0d",5494:"1bdbda74",8249:"2059b301",8278:"dc123c74",8342:"b753959d",9417:"9c5537cc"}[e]+".js",i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),i.r=e=>{Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.j=9885,i.p="",(()=>{const e={3626:0,8126:0,9885:0},t=t=>{let{__webpack_esm_ids__:n,__webpack_esm_modules__:s,__webpack_esm_runtime__:r}=t;var a,o,l=0;for(a in s)i.o(s,a)&&(i.m[a]=s[a]);for(r&&r(i);l<n.length;l++)o=n[l],i.o(e,o)&&e[o]&&e[o][0](),e[o]=0};i.f.j=(n,s)=>{let r=i.o(e,n)?e[n]:void 0;if(0!==r)if(r)s.push(r[1]);else{let a=import(i.p+i.u(n)).then(t,t=>{throw 0!==e[n]&&(e[n]=void 0),t});a=Promise.race([a,new Promise(t=>r=e[n]=[t])]),s.push(r[1]=a)}}})(),"undefined"!=typeof location){const e=function(e,t){try{const i=new URL(e);return i.protocol===t.protocol&&i.host===t.host?new URL(".",i).href:""}catch{return""}}(import.meta.url,location);e&&(i.p=e)}const n="mc-dir-change",s="mc-ui-studio-frame",r="mc-frame-drawer";var a=i(6161),o=i(5707);const l=a.AH`:host{display:contents;font-family:var(--mc-font,inherit)}*,*::before,*::after{box-sizing:border-box}`,c=a.AH`${l} .menu{position:fixed;inset:auto;z-index:30;margin:0;min-width:240px;max-width:calc(100vw - 16px);padding:4px;overflow-y:auto;overscroll-behavior:contain;border:1px solid var(--mc-divider,rgba(0,0,0,.12));border-radius:var(--mc-radius-lg,12px);background:var(--mc-surface,#fff);color:var(--mc-text,#212121);box-shadow:var(--mc-shadow-float,0 4px 16px rgba(0,0,0,.2));font-size:.875rem;line-height:1.3}.item{display:flex;flex-wrap:wrap;align-items:center;gap:2px 12px;min-height:var(--mc-hit,40px);padding:0 12px;border-radius:var(--mc-radius,8px);cursor:pointer;outline:none}.item:hover{background:var(--mc-surface-2,#f2f3f5)}.item:focus-visible{background:var(--mc-surface-2,#f2f3f5);outline:2px solid var(--mc-focus,var(--mc-accent,#03a9f4));outline-offset:-2px}.item.danger{color:var(--mc-error-ink,#b3261e)}.item[aria-disabled='true']{opacity:.6;cursor:default}.item[aria-disabled='true']:hover{background:transparent}.glyph{display:inline-flex;color:var(--mc-text-2,#5f6368)}.label{flex:1}.item:has(.sub-line){padding-block:6px}.sub-line{flex-basis:100%;font-size:.75rem;color:var(--mc-text-2,#5f6368)}.keys,.why{font-size:.75rem;color:var(--mc-text-2,#5f6368)}.keys{font-family:var(--mc-mono,ui-monospace,monospace)}.why{display:none;flex-basis:100%}.item:focus .why{display:block}.sep{height:1px;margin:4px 0;background:var(--mc-divider,rgba(0,0,0,.12))}@media (pointer:coarse){.item{min-height:var(--mc-hit,44px)}.keys{display:none}}`,d=a.AH`dialog{padding:0;border:0;border-radius:var(--mc-radius-xl,16px);background:var(--mc-surface,#fff);color:var(--mc-text,#212121);box-shadow:var(--mc-shadow-dialog,0 24px 64px rgba(0,0,0,.22),0 4px 12px rgba(0,0,0,.1));width:min(480px,calc(100vw - 32px));max-height:min(80vh,720px);overflow:hidden}dialog[open]{display:flex}dialog::backdrop{background:var(--mc-scrim,rgba(0,0,0,.38))}dialog.size-s{width:min(420px,calc(100vw - 32px))}dialog.size-m{width:min(480px,calc(100vw - 32px))}dialog.size-l{width:min(640px,calc(100vw - 32px))}dialog.size-xl{width:min(880px,calc(100vw - 32px))}.panel{display:grid;grid-template-rows:auto minmax(0,1fr) auto;width:100%;max-height:inherit}dialog.placed .panel{height:100%}.header{display:flex;align-items:center;gap:8px;padding:12px 12px 12px 20px;border-bottom:1px solid var(--mc-divider,rgba(0,0,0,.12))}.title{flex:1;min-width:0;margin:0;font-size:1rem;font-weight:500}.tool{display:inline-grid;place-items:center;width:32px;height:32px;padding:0;border:0;border-radius:var(--mc-radius,8px);background:transparent;color:var(--mc-text-2,#5f6368);cursor:pointer}.tool:hover{background:var(--mc-surface-2,#f2f3f5);color:var(--mc-text,#212121)}.tool:focus-visible{outline:2px solid var(--mc-focus,var(--mc-accent,#03a9f4));outline-offset:1px}.tool:disabled{opacity:.45;cursor:not-allowed;background:transparent} .header.movable{padding-inline-start:8px;cursor:grab;touch-action:none;user-select:none}.header.movable:active{cursor:grabbing}.move{cursor:inherit;touch-action:none}.resize{position:absolute;inset-block-end:0;inset-inline-end:0;width:32px;height:32px;z-index:1;cursor:nwse-resize;touch-action:none;border-radius:var(--mc-radius,8px) 0 var(--mc-radius-xl,16px) 0}dialog.rtl .resize{cursor:nesw-resize;border-radius:0 var(--mc-radius,8px) 0 var(--mc-radius-xl,16px)}dialog.rtl .resize svg{transform:scaleX(-1)}.panel.sizable .footer{padding-inline-end:40px}.panel.sizable:not(.has-footer) .body{padding-bottom:36px}.body{min-height:0;padding:16px 20px;overflow:auto;overscroll-behavior:contain}.footer{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:8px;padding:12px 16px;border-top:1px solid var(--mc-divider,rgba(0,0,0,.12))}.footer[hidden]{display:none} @media (max-width:599px){dialog.sheet{width:100vw;max-width:100vw;margin:auto 0 0;max-height:60vh;border-radius:var(--mc-radius-xl,16px) var(--mc-radius-xl,16px) 0 0;padding-bottom:env(safe-area-inset-bottom,0px)}}@media (pointer:coarse){.tool{width:var(--mc-hit,44px);height:var(--mc-hit,44px)}.panel.sizable .footer{padding-inline-end:52px}}@media (prefers-reduced-motion:reduce){*{transition-duration:0s !important;animation-duration:0s !important}}`,p=a.AH`${l}${d}`,h=a.AH`${l} .panel{position:fixed;inset:auto;z-index:30;margin:0;max-width:min(360px,calc(100vw - 16px));padding:12px;overflow:auto;overscroll-behavior:contain;border:1px solid var(--mc-divider,rgba(0,0,0,.12));border-radius:var(--mc-radius-lg,12px);background:var(--mc-surface,#fff);color:var(--mc-text,#212121);box-shadow:var(--mc-shadow-float,0 4px 16px rgba(0,0,0,.2))}`,u={select:"M6 3l12 8-5.5 1.3L10 18z",node:"M5 19L19 5M3 17h4v4H3zM17 3h4v4h-4z",pen:"M4 20l1-5L16 4l4 4L9 19zM14 6l4 4",rect:"M4 6h16v12H4z",ellipse:"M4 12a8 6 0 1 0 16 0a8 6 0 1 0-16 0",line:"M5 19L19 5",polygon:"M12 3l2.5 6.5H21l-5 4 2 7-6-4-6 4 2-7-5-4h6.5z",free:"M3 15c3-8 6 4 9-3s6-3 9 0",knife:"M4 20l6-6M9 11l8-8 4 4-8 8z",hand:"M8 13V6a1.5 1.5 0 0 1 3 0v5m0-1V4.5a1.5 1.5 0 0 1 3 0V11m0-3a1.5 1.5 0 0 1 3 0v6c0 4-2 6-5 6s-4-1-6-4l-2-4a1.5 1.5 0 0 1 2.5-1.5L8 14",undo:"M4 9h10a5 5 0 0 1 0 10H8M4 9l4-4M4 9l4 4",redo:"M20 9H10a5 5 0 0 0 0 10h6M20 9l-4-4M20 9l-4 4",eye:"M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9.5a2.5 2.5 0 1 0 .01 0z",eyeOff:"M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM3 3l18 18",lock:"M6 11h12v9H6zM8 11V8a4 4 0 0 1 8 0v3",unlock:"M6 11h12v9H6zM8 11V8a4 4 0 0 1 7.5-1.5",plus:"M12 5v14M5 12h14",minus:"M5 12h14",fit:"M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",grid:"M4 4h16v16H4zM4 12h16M12 4v16",snap:"M6 4v8a6 6 0 0 0 12 0V4h-4v8a2 2 0 0 1-4 0V4z",up:"M12 19V5M6 11l6-6 6 6",down:"M12 5v14M6 13l6 6 6-6",left:"M19 12H5M11 6l-6 6 6 6",right:"M5 12h14M13 6l6 6-6 6",back:"M15 5l-7 7 7 7",close:"M6 6l12 12M18 6L6 18",help:"M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17v.5",file:"M6 3h8l4 4v14H6zM14 3v4h4",paste:"M9 4h6v3H9zM7 5H5v16h14V5h-2",blank:"M4 4h16v16H4z",iconpick:"M12 3l2.7 5.5 6 .9-4.4 4.2 1 6-5.3-2.8-5.3 2.8 1-6L3.3 9.4l6-.9z",library:"M5 4h4v16H5zM11 4h4v16h-4zM17 6l3 .8-3.5 13-3-.8",group:"M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M9 9h6v6H9z",copy:"M8 8h12v12H8zM4 16V4h12",trash:"M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13",rotL:"M5 12a7 7 0 1 0 2-5M5 4v4h4",rotR:"M19 12a7 7 0 1 1-2-5M19 4v4h-4",rot90L:"M19 20v-8a5 5 0 0 0-5-5H5M9 3L5 7l4 4",rot90R:"M5 20v-8a5 5 0 0 1 5-5h9M15 3l4 4-4 4",ungroup:"M4 4h6v6H4zM14 14h6v6h-6zM14 10l6-6M15 4h5v5",maximize:"M5 5h14v14H5z",restore:"M8 8h11v11H8zM5 15V5h10",resizeCorner:"M19 9L9 19M19 14l-5 5",grip:"M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01",flipH:"M12 3v18M8 7L3 12l5 5zM16 7l5 5-5 5z",flipV:"M3 12h18M7 8l5-5 5 5zM7 16l5 5 5-5z",link:"M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1",save:"M5 4h12l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6",check:"M5 12.5l4.5 4.5L19 7",alignL:"M4 3v18M8 7h12M8 14h8",alignC:"M12 3v18M5 7h14M8 14h8",alignR:"M20 3v18M4 7h12M12 14h8",alignT:"M3 4h18M7 8v12M14 8v8",alignM:"M3 12h18M7 5v14M14 8v8",alignB:"M3 20h18M7 4v12M14 8v8",distH:"M4 3v18M20 3v18M10 8h4v8h-4z",distV:"M3 4h18M3 20h18M8 10h8v4H8z",toFront:"M12 19V6M6 11l6-6 6 6M5 3h14",toBack:"M12 5v13M6 13l6 6 6-6M5 21h14"},m={layersOutline:"M12,16L19.36,10.27L21,9L12,2L3,9L4.63,10.27M12,18.54L4.62,12.81L3,14.07L12,21.07L21,14.07L19.37,12.8L12,18.54Z",tuneVariant:"M8 13C6.14 13 4.59 14.28 4.14 16H2V18H4.14C4.59 19.72 6.14 21 8 21S11.41 19.72 11.86 18H22V16H11.86C11.41 14.28 9.86 13 8 13M8 19C6.9 19 6 18.1 6 17C6 15.9 6.9 15 8 15S10 15.9 10 17C10 18.1 9.1 19 8 19M19.86 6C19.41 4.28 17.86 3 16 3S12.59 4.28 12.14 6H2V8H12.14C12.59 9.72 14.14 11 16 11S19.41 9.72 19.86 8H22V6H19.86M16 9C14.9 9 14 8.1 14 7C14 5.9 14.9 5 16 5S18 5.9 18 7C18 8.1 17.1 9 16 9Z",arrowLeft:"M20,11V13H8L13.5,18.5L12.08,19.92L4.16,12L12.08,4.08L13.5,5.5L8,11H20Z",check:"M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z",chevronDown:"M7.41,8.58L12,13.17L16.59,8.58L18,10L12,16L6,10L7.41,8.58Z",close:"M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z",undo:"M12.5,8C9.85,8 7.45,9 5.6,10.6L2,7V16H11L7.38,12.38C8.77,11.22 10.54,10.5 12.5,10.5C16.04,10.5 19.05,12.81 20.1,16L22.47,15.22C21.08,11.03 17.15,8 12.5,8Z",redo:"M18.4,10.6C16.55,9 14.15,8 11.5,8C6.85,8 2.92,11.03 1.54,15.22L3.9,16C4.95,12.81 7.95,10.5 11.5,10.5C13.45,10.5 15.23,11.22 16.62,12.38L13,16H22V7L18.4,10.6Z",helpCircle:"M11,18H13V16H11V18M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,6A4,4 0 0,0 8,10H10A2,2 0 0,1 12,8A2,2 0 0,1 14,10C14,12 11,11.75 11,15H13C13,12.75 16,12.5 16,10A4,4 0 0,0 12,6Z",dotsVertical:"M12,16A2,2 0 0,1 14,18A2,2 0 0,1 12,20A2,2 0 0,1 10,18A2,2 0 0,1 12,16M12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12A2,2 0 0,1 12,10M12,4A2,2 0 0,1 14,6A2,2 0 0,1 12,8A2,2 0 0,1 10,6A2,2 0 0,1 12,4Z",palette:"M12 3a9 9 0 0 0 0 18c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.3-.5-.8-.5-1.2 0-1.1.9-2 2-2h2.4A4.6 4.6 0 0 0 22 10c0-3.9-4.5-7-10-7Zm-5.5 9a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3-4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z",add:"M19,13H13V19H11V13H5V11H11V5H13V11H19V13Z",delete:"M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",contentCopy:"M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",eyeOn:"M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z",alertCircle:"M11,15H13V17H11V15M11,7H13V13H11V7M12,2C6.47,2 2,6.5 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20Z",information:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z",dotsHorizontal:"M16,12A2,2 0 0,1 18,10A2,2 0 0,1 20,12A2,2 0 0,1 18,14A2,2 0 0,1 16,12M10,12A2,2 0 0,1 12,10A2,2 0 0,1 14,12A2,2 0 0,1 12,14A2,2 0 0,1 10,12M4,12A2,2 0 0,1 6,10A2,2 0 0,1 8,12A2,2 0 0,1 6,14A2,2 0 0,1 4,12Z",restart:"M12,5V1L7,6L12,11V7A6,6 0 0,1 18,13A6,6 0 0,1 12,19A6,6 0 0,1 6,13H4A8,8 0 0,0 12,21A8,8 0 0,0 20,13A8,8 0 0,0 12,5Z",cursorDefault:"M13.64,21.97C13.14,22.21 12.54,22 12.31,21.5L10.13,16.76L7.62,18.78C7.45,18.92 7.24,19 7,19A1,1 0 0,1 6,18V3A1,1 0 0,1 7,2C7.24,2 7.47,2.09 7.64,2.23L7.65,2.22L19.14,11.86C19.57,12.22 19.62,12.85 19.27,13.27C19.12,13.45 18.91,13.57 18.7,13.61L15.54,14.23L17.74,18.96C18,19.46 17.76,20.05 17.26,20.28L13.64,21.97Z",vectorPolylineEdit:"M2 3V9H4.95L6.95 15H6V21H12V16.41L17.41 11H22V5H16V9.57L10.59 15H9.06L7.06 9H8V3H2M4 5H6V7H4V5M18 7H20V9H18V7M21.15 13C21 13 20.87 13.05 20.76 13.16L19.75 14.18L21.82 16.25L22.84 15.24C23.05 15.03 23.05 14.67 22.84 14.46L21.54 13.16C21.43 13.05 21.29 13 21.15 13M19.15 14.76L13 20.91V23H15.09L21.23 16.84L19.15 14.76M8 17H10V19H8V17Z",pen:"M20.71,7.04C20.37,7.38 20.04,7.71 20.03,8.04C20,8.36 20.34,8.69 20.66,9C21.14,9.5 21.61,9.95 21.59,10.44C21.57,10.93 21.06,11.44 20.55,11.94L16.42,16.08L15,14.66L19.25,10.42L18.29,9.46L16.87,10.87L13.12,7.12L16.96,3.29C17.35,2.9 18,2.9 18.37,3.29L20.71,5.63C21.1,6 21.1,6.65 20.71,7.04M3,17.25L12.56,7.68L16.31,11.43L6.75,21H3V17.25Z",rectangleOutline:"M4,6V19H20V6H4M18,17H6V8H18V17Z",ellipseOutline:"M12,6C16.41,6 20,8.69 20,12C20,15.31 16.41,18 12,18C7.59,18 4,15.31 4,12C4,8.69 7.59,6 12,6M12,4C6.5,4 2,7.58 2,12C2,16.42 6.5,20 12,20C17.5,20 22,16.42 22,12C22,7.58 17.5,4 12,4Z",vectorLine:"M15,3V7.59L7.59,15H3V21H9V16.42L16.42,9H21V3M17,5H19V7H17M5,17H7V19H5",vectorPolygon:"M2,2V8H4.28L5.57,16H4V22H10V20.06L15,20.05V22H21V16H19.17L20,9H22V3H16V6.53L14.8,8H9.59L8,5.82V2M4,4H6V6H4M18,5H20V7H18M6.31,8H7.11L9,10.59V14H15V10.91L16.57,9H18L17.16,16H15V18.06H10V16H7.6M11,10H13V12H11M6,18H8V20H6M17,18H19V20H17",draw:"M9.75 20.85C11.53 20.15 11.14 18.22 10.24 17C9.35 15.75 8.12 14.89 6.88 14.06C6 13.5 5.19 12.8 4.54 12C4.26 11.67 3.69 11.06 4.27 10.94C4.86 10.82 5.88 11.4 6.4 11.62C7.31 12 8.21 12.44 9.05 12.96L10.06 11.26C8.5 10.23 6.5 9.32 4.64 9.05C3.58 8.89 2.46 9.11 2.1 10.26C1.78 11.25 2.29 12.25 2.87 13.03C4.24 14.86 6.37 15.74 7.96 17.32C8.3 17.65 8.71 18.04 8.91 18.5C9.12 18.94 9.07 18.97 8.6 18.97C7.36 18.97 5.81 18 4.8 17.36L3.79 19.06C5.32 20 7.88 21.47 9.75 20.85M20.84 5.25C21.06 5.03 21.06 4.67 20.84 4.46L19.54 3.16C19.33 2.95 18.97 2.95 18.76 3.16L17.74 4.18L19.82 6.26M11 10.92V13H13.08L19.23 6.85L17.15 4.77L11 10.92Z",contentCut:"M19,3L13,9L15,11L22,4V3M12,12.5A0.5,0.5 0 0,1 11.5,12A0.5,0.5 0 0,1 12,11.5A0.5,0.5 0 0,1 12.5,12A0.5,0.5 0 0,1 12,12.5M6,20A2,2 0 0,1 4,18C4,16.89 4.9,16 6,16A2,2 0 0,1 8,18C8,19.11 7.1,20 6,20M6,8A2,2 0 0,1 4,6C4,4.89 4.9,4 6,4A2,2 0 0,1 8,6C8,7.11 7.1,8 6,8M9.64,7.64C9.87,7.14 10,6.59 10,6A4,4 0 0,0 6,2A4,4 0 0,0 2,6A4,4 0 0,0 6,10C6.59,10 7.14,9.87 7.64,9.64L10,12L7.64,14.36C7.14,14.13 6.59,14 6,14A4,4 0 0,0 2,18A4,4 0 0,0 6,22A4,4 0 0,0 10,18C10,17.41 9.87,16.86 9.64,16.36L12,14L19,21H22V20L9.64,7.64Z",handBackLeftOutline:"M3 16C3 20.42 6.58 24 11 24C14.43 24 17.5 21.91 18.77 18.73L21.33 12.3C21.58 11.66 21.56 10.92 21.18 10.35C20.69 9.61 19.82 9.29 19 9.5L18.22 9.73C17.76 9.85 17.34 10.08 17 10.39V4.5C17 3.12 15.88 2 14.5 2C14.31 2 14.13 2 13.96 2.06C13.75 .89 12.73 0 11.5 0C10.44 0 9.54 .66 9.17 1.59C8.96 1.53 8.73 1.5 8.5 1.5C7.12 1.5 6 2.62 6 4V4.55C5.84 4.5 5.67 4.5 5.5 4.5C4.12 4.5 3 5.62 3 7V16M5 7C5 6.72 5.22 6.5 5.5 6.5S6 6.72 6 7V12H8V4C8 3.72 8.22 3.5 8.5 3.5S9 3.72 9 4V12H11V2.5C11 2.22 11.22 2 11.5 2S12 2.22 12 2.5V12H14V4.5C14 4.22 14.22 4 14.5 4S15 4.22 15 4.5V15H17L18 12.5C18.15 12.05 18.5 11.71 19 11.59L19.5 11.45L16.91 18C15.95 20.41 13.61 22 11 22C7.69 22 5 19.31 5 16V7Z",eyeOffOutline:"M2,5.27L3.28,4L20,20.72L18.73,22L15.65,18.92C14.5,19.3 13.28,19.5 12,19.5C7,19.5 2.73,16.39 1,12C1.69,10.24 2.79,8.69 4.19,7.46L2,5.27M12,9A3,3 0 0,1 15,12C15,12.35 14.94,12.69 14.83,13L11,9.17C11.31,9.06 11.65,9 12,9M12,4.5C17,4.5 21.27,7.61 23,12C22.18,14.08 20.79,15.88 19,17.19L17.58,15.76C18.94,14.82 20.06,13.54 20.82,12C19.17,8.64 15.76,6.5 12,6.5C10.91,6.5 9.84,6.68 8.84,7L7.3,5.47C8.74,4.85 10.33,4.5 12,4.5M3.18,12C4.83,15.36 8.24,17.5 12,17.5C12.69,17.5 13.37,17.43 14,17.29L11.72,15C10.29,14.85 9.15,13.71 9,12.28L5.6,8.87C4.61,9.72 3.78,10.78 3.18,12Z",lock:"M12,17A2,2 0 0,0 14,15C14,13.89 13.1,13 12,13A2,2 0 0,0 10,15A2,2 0 0,0 12,17M18,8A2,2 0 0,1 20,10V20A2,2 0 0,1 18,22H6A2,2 0 0,1 4,20V10C4,8.89 4.9,8 6,8H7V6A5,5 0 0,1 12,1A5,5 0 0,1 17,6V8H18M12,3A3,3 0 0,0 9,6V8H15V6A3,3 0 0,0 12,3Z",lockOpenVariant:"M18 1C15.24 1 13 3.24 13 6V8H4C2.9 8 2 8.89 2 10V20C2 21.11 2.9 22 4 22H16C17.11 22 18 21.11 18 20V10C18 8.9 17.11 8 16 8H15V6C15 4.34 16.34 3 18 3C19.66 3 21 4.34 21 6V8H23V6C23 3.24 20.76 1 18 1M10 13C11.1 13 12 13.89 12 15C12 16.11 11.11 17 10 17C8.9 17 8 16.11 8 15C8 13.9 8.9 13 10 13Z",minus:"M19,13H5V11H19V13Z",fitToScreenOutline:"M17 4H20C21.1 4 22 4.9 22 6V8H20V6H17V4M4 8V6H7V4H4C2.9 4 2 4.9 2 6V8H4M20 16V18H17V20H20C21.1 20 22 19.1 22 18V16H20M7 18H4V16H2V18C2 19.1 2.9 20 4 20H7V18M16 10V14H8V10H16M18 8H6V16H18V8Z",grid:"M10,4V8H14V4H10M16,4V8H20V4H16M16,10V14H20V10H16M16,16V20H20V16H16M14,20V16H10V20H14M8,20V16H4V20H8M8,14V10H4V14H8M8,8V4H4V8H8M10,14H14V10H10V14M4,2H20A2,2 0 0,1 22,4V20A2,2 0 0,1 20,22H4C2.92,22 2,21.1 2,20V4A2,2 0 0,1 4,2Z",magnet:"M3,7V13A9,9 0 0,0 12,22A9,9 0 0,0 21,13V7H17V13A5,5 0 0,1 12,18A5,5 0 0,1 7,13V7M17,5H21V2H17M3,5H7V2H3",arrowUp:"M13,20H11V8L5.5,13.5L4.08,12.08L12,4.16L19.92,12.08L18.5,13.5L13,8V20Z",arrowDown:"M11,4H13V16L18.5,10.5L19.92,11.92L12,19.84L4.08,11.92L5.5,10.5L11,16V4Z",arrowRight:"M4,11V13H16L10.5,18.5L11.92,19.92L19.84,12L11.92,4.08L10.5,5.5L16,11H4Z",chevronRight:"M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z",swapVertical:"M9,3L5,7H8V14H10V7H13M16,17V10H14V17H11L15,21L19,17H16Z",fileOutline:"M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z",contentPaste:"M19,20H5V4H7V7H17V4H19M12,2A1,1 0 0,1 13,3A1,1 0 0,1 12,4A1,1 0 0,1 11,3A1,1 0 0,1 12,2M19,2H14.82C14.4,0.84 13.3,0 12,0C10.7,0 9.6,0.84 9.18,2H5A2,2 0 0,0 3,4V20A2,2 0 0,0 5,22H19A2,2 0 0,0 21,20V4A2,2 0 0,0 19,2Z",folderOpenOutline:"M6.1,10L4,18V8H21A2,2 0 0,0 19,6H12L10,4H4A2,2 0 0,0 2,6V18A2,2 0 0,0 4,20H19C19.9,20 20.7,19.4 20.9,18.5L23.2,10H6.1M19,18H6L7.6,12H20.6L19,18Z",shapeOutline:"M11,13.5V21.5H3V13.5H11M9,15.5H5V19.5H9V15.5M12,2L17.5,11H6.5L12,2M12,5.86L10.08,9H13.92L12,5.86M17.5,13C20,13 22,15 22,17.5C22,20 20,22 17.5,22C15,22 13,20 13,17.5C13,15 15,13 17.5,13M17.5,15A2.5,2.5 0 0,0 15,17.5A2.5,2.5 0 0,0 17.5,20A2.5,2.5 0 0,0 20,17.5A2.5,2.5 0 0,0 17.5,15Z",bookshelf:"M9 3V18H12V3H9M12 5L16 18L19 17L15 4L12 5M5 5V18H8V5H5M3 19V21H21V19H3Z",group:"M1,1V5H2V19H1V23H5V22H19V23H23V19H22V5H23V1H19V2H5V1M5,4H19V5H20V19H19V20H5V19H4V5H5M6,6V14H9V18H18V9H14V6M8,8H12V12H8M14,11H16V16H11V14H14",ungroup:"M2,2H6V3H13V2H17V6H16V9H18V8H22V12H21V18H22V22H18V21H12V22H8V18H9V16H6V17H2V13H3V6H2V2M18,12V11H16V13H17V17H13V16H11V18H12V19H18V18H19V12H18M13,6V5H6V6H5V13H6V14H9V12H8V8H12V9H14V6H13M12,12H11V14H13V13H14V11H12V12Z",rotateLeft:"M13,4.07V1L8.45,5.55L13,10V6.09C15.84,6.57 18,9.03 18,12C18,14.97 15.84,17.43 13,17.91V19.93C16.95,19.44 20,16.08 20,12C20,7.92 16.95,4.56 13,4.07M7.1,18.32C8.26,19.22 9.61,19.76 11,19.93V17.9C10.13,17.75 9.29,17.41 8.54,16.87L7.1,18.32M6.09,13H4.07C4.24,14.39 4.79,15.73 5.69,16.89L7.1,15.47C6.58,14.72 6.23,13.88 6.09,13M7.11,8.53L5.7,7.11C4.8,8.27 4.24,9.61 4.07,11H6.09C6.23,10.13 6.58,9.28 7.11,8.53Z",rotateRight:"M16.89,15.5L18.31,16.89C19.21,15.73 19.76,14.39 19.93,13H17.91C17.77,13.87 17.43,14.72 16.89,15.5M13,17.9V19.92C14.39,19.75 15.74,19.21 16.9,18.31L15.46,16.87C14.71,17.41 13.87,17.76 13,17.9M19.93,11C19.76,9.61 19.21,8.27 18.31,7.11L16.89,8.53C17.43,9.28 17.77,10.13 17.91,11M15.55,5.55L11,1V4.07C7.06,4.56 4,7.92 4,12C4,16.08 7.05,19.44 11,19.93V17.91C8.16,17.43 6,14.97 6,12C6,9.03 8.16,6.57 11,6.09V10L15.55,5.55Z",rotateLeftVariant:"M4,2H7A2,2 0 0,1 9,4V20A2,2 0 0,1 7,22H4A2,2 0 0,1 2,20V4A2,2 0 0,1 4,2M20,15A2,2 0 0,1 22,17V20A2,2 0 0,1 20,22H11V15H20M14,4A8,8 0 0,1 22,12L21.94,13H19.92L20,12A6,6 0 0,0 14,6V9L10,5L14,1V4Z",rotateRightVariant:"M10,4V1L14,5L10,9V6A6,6 0 0,0 4,12L4.08,13H2.06L2,12A8,8 0 0,1 10,4M17,2H20A2,2 0 0,1 22,4V20A2,2 0 0,1 20,22H17A2,2 0 0,1 15,20V4A2,2 0 0,1 17,2M4,15H13V22H4A2,2 0 0,1 2,20V17A2,2 0 0,1 4,15Z",flipHorizontal:"M15 21H17V19H15M19 9H21V7H19M3 5V19C3 20.1 3.9 21 5 21H9V19H5V5H9V3H5C3.9 3 3 3.9 3 5M19 3V5H21C21 3.9 20.1 3 19 3M11 23H13V1H11M19 17H21V15H19M15 5H17V3H15M19 13H21V11H19M19 21C20.1 21 21 20.1 21 19H19Z",flipVertical:"M3 15V17H5V15M15 19V21H17V19M19 3H5C3.9 3 3 3.9 3 5V9H5V5H19V9H21V5C21 3.9 20.1 3 19 3M21 19H19V21C20.1 21 21 20.1 21 19M1 11V13H23V11M7 19V21H9V19M19 15V17H21V15M11 19V21H13V19M3 19C3 20.1 3.9 21 5 21V19Z",arrangeBringToFront:"M2,2H11V6H9V4H4V9H6V11H2V2M22,13V22H13V18H15V20H20V15H18V13H22M8,8H16V16H8V8Z",arrangeBringForward:"M2,2H16V16H2V2M22,8V22H8V18H10V20H20V10H18V8H22Z",arrangeSendBackward:"M2,2H16V16H2V2M22,8V22H8V18H18V8H22M4,4V14H14V4H4Z",arrangeSendToBack:"M2,2H11V11H2V2M9,4H4V9H9V4M22,13V22H13V13H22M15,20H20V15H15V20M16,8V11H13V8H16M11,16H8V13H11V16Z",dragVertical:"M9,3H11V5H9V3M13,3H15V5H13V3M9,7H11V9H9V7M13,7H15V9H13V7M9,11H11V13H9V11M13,11H15V13H13V11M9,15H11V17H9V15M13,15H15V17H13V15M9,19H11V21H9V19M13,19H15V21H13V19Z",squareOutline:"M3,3H21V21H3V3M5,5V19H19V5H5Z",selectAll:"M9,9H15V15H9M7,17H17V7H7M15,5H17V3H15M15,21H17V19H15M19,17H21V15H19M19,9H21V7H19M19,21A2,2 0 0,0 21,19H19M19,13H21V11H19M11,21H13V19H11M9,3H7V5H9M3,17H5V15H3M5,21V19H3A2,2 0 0,0 5,21M19,3V5H21A2,2 0 0,0 19,3M13,3H11V5H13M3,9H5V7H3M7,21H9V19H7M3,13H5V11H3M3,5H5V3A2,2 0 0,0 3,5Z"},g=e=>Object.prototype.hasOwnProperty.call(m,e),f=["left","right","back","arrowLeft","arrowRight","chevronRight","undo","redo"],v=Object.fromEntries([...Object.keys(u),...Object.keys(m)].map(e=>[e,f.includes(e)?"mirror":"keep"])),b=(e,t=20)=>{const i="mirror"===v[e]?"mirror":a.s6;return g(e)?a.qy`<svg class="gl" data-dir=${i} viewBox="0 0 24 24" width=${t} height=${t} aria-hidden="true" focusable="false"><path d=${m[e]} fill="currentColor"></path></svg>`:a.qy`<svg class="gl" data-dir=${i} viewBox="0 0 24 24" width=${t} height=${t} aria-hidden="true" focusable="false"><path d=${u[e]} fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path></svg>`},y=e=>Object.prototype.hasOwnProperty.call(u,e)||g(e);function x(e){let t=e;for(;t;){const e=t.getAttribute("dir")?.toLowerCase();if("rtl"===e||"ltr"===e)return e;t=t.parentElement??t.getRootNode().host??null}try{return"rtl"===getComputedStyle(document.documentElement).direction?"rtl":"ltr"}catch{return"ltr"}}class _{constructor(e){this.host=e,this.direction="ltr",this.reflected=!1,this.sync=()=>{const e=this.host;if(!this.reflected&&e.hasAttribute("dir"))return void this.set(x(e));this.reflected&&e.removeAttribute("dir");const t=x(e);this.reflected=!1,"rtl"===t&&(e.setAttribute("dir","rtl"),this.reflected=!0),this.set(t)},e.addController(this)}hostConnected(){window.addEventListener(n,this.sync),"function"==typeof MutationObserver&&(this.observer=new MutationObserver(this.sync),this.observer.observe(document.documentElement,{attributes:!0,attributeFilter:["dir"]})),this.sync()}hostDisconnected(){window.removeEventListener(n,this.sync),this.observer?.disconnect(),this.observer=void 0,this.reflected&&(this.host.removeAttribute("dir"),this.reflected=!1)}set(e){e!==this.direction&&(this.direction=e,this.host.requestUpdate())}}function w(e,t,i="start"){const n=window.innerWidth||document.documentElement.clientWidth||0,s=window.innerHeight||document.documentElement.clientHeight||0;e.style.maxHeight="";const r=e.offsetWidth,a=e.offsetHeight,o=s-t.bottom-4-8,l=t.top-4-8,c=s>0&&a>o&&l>o,d=c?l:o;s>0&&a>d&&(e.style.maxHeight=`${Math.max(120,d)}px`);const p=Math.min(a,s>0?Math.max(120,d):a),h=c?Math.max(8,t.top-4-p):t.bottom+4;let u=function(e,t,i,n){return"end"===i!==n?e.right-t:e.left}(t,r,i,"rtl"===x(e));return n>0&&(u=Math.min(u,n-r-8)),u=Math.max(8,u),Object.assign(e.style,{top:`${Math.round(h)}px`,left:`${Math.round(u)}px`,right:"auto",bottom:"auto"}),e.dataset.placement=c?"top":"bottom",c?"top":"bottom"}function k(e,t,i=0){const n=e.getBoundingClientRect(),s=(e,t,n)=>{let s=e+i;return s+t>n-8&&(s=e-i-t),Math.max(8,Math.min(s,n-8-t))},r=[s(t[0],n.width,window.innerWidth),s(t[1],n.height,window.innerHeight)];return Object.assign(e.style,{left:`${r[0]}px`,top:`${r[1]}px`,right:"auto",bottom:"auto"}),r}function $(e){if("undefined"!=typeof HTMLElement&&"function"==typeof HTMLElement.prototype.showPopover)try{e.matches(":popover-open")||e.showPopover()}catch{}}var M=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class S extends a.WF{constructor(){super(...arguments),this.items=[],this.label="",this.align="start",this.touch=!1,this._open=!1,this._sub=-1,this._dir=new _(this),this._outside=e=>{const t=e.composedPath();if(!t.includes(this))return this.anchor&&t.includes(this.anchor)?this.close("outside"):void this.close("outside")},this._key=e=>{const t=this.list();if(!t)return;const i=[...t.querySelectorAll("[role^=menuitem]")],n=i.indexOf(e.composedPath()[0]),s=this.entries(),r=i.length,a=e=>i[(e+r)%r]?.focus(),o=e.key,l="rtl"===this._dir.direction;let c=!0;if("ArrowDown"===o)a(n+1);else if("ArrowUp"===o)a(n<0?r-1:n-1);else if("Home"===o)a(0);else if("End"===o)a(r-1);else if("Enter"===o||" "===o)this.pick(n,i[n]);else if(o===(l?"ArrowLeft":"ArrowRight"))this._sub<0&&s[n]?.items&&this.openSub(n,i[n]);else if(o===(l?"ArrowRight":"ArrowLeft")||"Escape"===o)if(this._sub>=0){const e=this._sub;this._sub=-1,this.updateComplete.then(()=>this.focusIn(this.list(),e))}else"Escape"===o&&this.close("escape");else if("Tab"===o)c=!1,this.close("tab");else if(1!==o.length||e.ctrlKey||e.metaKey||e.altKey)c=!1;else{const e=s.map((e,t)=>(n+1+t)%r).find(e=>s[e].label.toLowerCase().startsWith(o.toLowerCase()));void 0!==e&&a(e)}c&&(e.preventDefault(),e.stopPropagation())}}get open(){return this._open}show(){this._open=!0,this._sub=-1,document.addEventListener("pointerdown",this._outside,!0),this.updateComplete.then(()=>{this.placeMain(),this.focusIn(this.list(),this.firstFree(this.items))})}close(e="escape"){this._open&&(this._open=!1,this._sub=-1,document.removeEventListener("pointerdown",this._outside,!0),this.dispatchEvent(new CustomEvent("mc-menu-close",{detail:{reason:e},bubbles:!0,composed:!0})),"pick"!==e&&(this.opener??this.anchor)?.focus?.({preventScroll:!0}))}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("pointerdown",this._outside,!0)}updated(e){for(const e of this.renderRoot.querySelectorAll(".menu[popover]"))$(e)}placeMain(){const e=this.renderRoot.querySelector(".menu");e&&($(e),this.anchor?w(e,this.anchor.getBoundingClientRect(),this.align):k(e,this.at??[0,0],this.touch?8:0))}list(){return this.renderRoot.querySelector(this._sub>=0?".sub":".menu")}firstFree(e){return Math.max(0,e.findIndex(e=>!e.reason))}focusIn(e,t){e?.querySelectorAll("[role^=menuitem]")[t]?.focus({preventScroll:!0})}entries(){return this._sub>=0?this.items[this._sub]?.items??[]:this.items}openSub(e,t){const i=this.items[e];i?.items?.length&&!i.reason&&(this._sub=e,this._subRow=t,this.updateComplete.then(()=>{const e=this.renderRoot.querySelector(".sub");if(e){$(e);const i=t.getBoundingClientRect(),n=e.getBoundingClientRect().width,s="rtl"===this._dir.direction?i.left-n>=8:i.right+n+8>window.innerWidth;k(e,["rtl"===this._dir.direction?s?i.left-n:i.right:s?Math.max(8,i.left-n):i.right,i.top])}this.focusIn(this.list(),this.firstFree(i.items??[]))}))}pick(e,t){const i=this.entries()[e];if(i&&!i.reason){if(i.items)return this.openSub(e,t);this.dispatchEvent(new CustomEvent("mc-menu-pick",{detail:{id:i.id},bubbles:!0,composed:!0})),this.close("pick")}}mark(e){return e.glyph&&y(e.glyph)?a.qy`<span class="glyph">${b(e.glyph,18)}</span>`:e.icon?a.qy`<span class="glyph"><ha-icon icon=${e.icon}></ha-icon></span>`:a.s6}row(e,t){const i=!!e.items,n=void 0===e.checked?"menuitem":"menuitemcheckbox";return a.qy`${e.separatorBefore?a.qy`<div class="sep" role="separator"></div>`:a.s6}<div class="item ${e.danger?"danger":""}" role=${n} tabindex="-1" aria-checked=${void 0===e.checked?a.s6:String(e.checked)} aria-disabled=${e.reason?"true":a.s6} aria-description=${e.reason??e.sub??a.s6} aria-keyshortcuts=${e.keys??a.s6} aria-haspopup=${i?"menu":a.s6} aria-expanded=${i?String(this._sub===t):a.s6} @click=${e=>this.pick(t,e.currentTarget)} > ${this.mark(e)}<span class="label">${e.label}</span>${e.keys?a.qy`<span class="keys">${e.keys}</span>`:a.s6}${i?"rtl"===this._dir.direction?"‹":"›":a.s6}${e.reason?a.qy`<span class="why">${e.reason}</span>`:a.s6}${e.sub?a.qy`<span class="sub-line">${e.sub}</span>`:a.s6}</div>`}render(){if(!this._open)return a.s6;const e=this.items[this._sub];return a.qy`<div class="menu" role="menu" aria-label=${this.label} popover="manual" style=${`max-height:${window.innerHeight-16}px`} @keydown=${this._key}> ${this.items.map((e,t)=>this.row(e,t))}</div>${e?.items?a.qy`<div class="sub menu" role="menu" aria-label=${e.label} popover="manual" @keydown=${this._key}>${e.items.map((e,t)=>this.row(e,t))}</div>`:a.s6}`}}S.uiKitRevision=7,S.styles=c,M([(0,o.MZ)({attribute:!1})],S.prototype,"items",void 0),M([(0,o.MZ)()],S.prototype,"label",void 0),M([(0,o.MZ)({attribute:!1})],S.prototype,"at",void 0),M([(0,o.MZ)({attribute:!1})],S.prototype,"anchor",void 0),M([(0,o.MZ)()],S.prototype,"align",void 0),M([(0,o.MZ)({type:Boolean})],S.prototype,"touch",void 0),M([(0,o.MZ)({attribute:!1})],S.prototype,"opener",void 0),M([(0,o.wk)()],S.prototype,"_open",void 0),M([(0,o.wk)()],S.prototype,"_sub",void 0);var z=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class C extends a.WF{constructor(){super(...arguments),this.label="",this.align="start",this._open=!1,this._outside=e=>{const t=e.composedPath();t.includes(this)||this.anchor&&t.includes(this.anchor)||this.close("outside")},this._resize=()=>this.close("outside"),this._key=e=>{"Escape"===e.key&&(e.preventDefault(),e.stopPropagation(),this.close("escape"))},this._focusout=e=>{const t=e.relatedTarget;!t||this.contains(t)||this.renderRoot.contains(t)||t===this.anchor||this.close("tab")}}get open(){return this._open}show(){this._open||(this._open=!0,document.addEventListener("pointerdown",this._outside,!0),window.addEventListener("resize",this._resize),this.updateComplete.then(()=>{const e=this.panel();e&&($(e),this.anchor&&w(e,this.anchor.getBoundingClientRect(),this.align))}))}close(e="action"){this._open&&(this._open=!1,document.removeEventListener("pointerdown",this._outside,!0),window.removeEventListener("resize",this._resize),this.dispatchEvent(new CustomEvent("mc-popover-close",{detail:{reason:e},bubbles:!0,composed:!0})),"outside"!==e&&"tab"!==e&&this.anchor?.focus?.({preventScroll:!0}))}disconnectedCallback(){super.disconnectedCallback(),document.removeEventListener("pointerdown",this._outside,!0),window.removeEventListener("resize",this._resize)}panel(){return this.renderRoot.querySelector(".panel")}render(){return this._open?a.qy`<div class="panel" part="panel" role="group" aria-label=${this.label} popover="manual" @keydown=${this._key} @focusout=${this._focusout}><slot></slot></div>`:a.s6}}C.uiKitRevision=7,C.styles=h,z([(0,o.MZ)({attribute:!1})],C.prototype,"anchor",void 0),z([(0,o.MZ)()],C.prototype,"label",void 0),z([(0,o.MZ)()],C.prototype,"align",void 0),z([(0,o.wk)()],C.prototype,"_open",void 0);const A=[420,480,640,880];function j(e,t,i){const n=Math.min(Math.max(e.w,320),t-32);return{w:n,h:Math.min(Math.max(e.h,240),i-32),x:Math.min(Math.max(e.x,48-n),t-48),y:Math.min(Math.max(e.y,0),i-48)}}const q=(e,t,i)=>({...e,x:(t-e.w)/2,y:(i-e.h)/2});function E(e,t,i,n,s,r){const a=j({...e,w:e.w+(n?-t:t),h:e.h+i},s,r);return{...a,x:n?e.x+e.w-a.w:e.x}}var H=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const L=["centre","end","start"],V='button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';class O extends a.WF{constructor(){super(...arguments),this.heading="",this.closeLabel="",this.variant="dialog",this.dismissible=!0,this.movable=!1,this.resizable=!1,this.maximizable=!1,this.maximized=!1,this.moveLabel="",this.resizeLabel="",this.maximizeLabel="",this.restoreLabel="",this._open=!1,this._hasFooter=!1,this._r=null,this._compact=!1,this._dir=new _(this),this._drag=null,this._dock=0,this._downScrim=null,this._id=`mc-ui-win-${Math.random().toString(36).slice(2,8)}`,this._isCompact=()=>"function"==typeof matchMedia&&matchMedia("(max-width: 599px)").matches,this._vw=()=>document.documentElement.clientWidth||window.innerWidth,this._vh=()=>window.innerHeight,this._free=()=>"alert"!==this.variant&&!("sheet"===this.variant&&this._compact),this._viewport=()=>{this._compact=this._isCompact(),this._r&&(this._r=j(this._r,this._vw(),this._vh()))},this._cancel=e=>{e.preventDefault(),e.stopPropagation(),this._abort()||this.close("escape")},this._key=e=>{if("Tab"===e.key)return this._tab(e);"Escape"===e.key&&(e.preventDefault(),e.stopPropagation(),this._abort()||this.close("escape"))},this._press=e=>{this._downScrim=e.target===e.currentTarget},this._click=e=>{const t=this._downScrim;this._downScrim=null,e.target===e.currentTarget&&!1!==t&&this.dismissible&&"alert"!==this.variant&&this.close("scrim")},this._footer=e=>{this._hasFooter=e.target.assignedNodes().length>0},this._moved=e=>{const t=this._drag;if(!t||e.pointerId!==t.id)return;const i=e.clientX-t.sx,n=e.clientY-t.sy;if(!t.moved&&Math.hypot(i,n)<4)return;t.moved=!0,this._dock=0;const s=t.r0;if("move"===t.mode)return this._set({...s,x:s.x+i,y:s.y+n});this._set(E(s,i,n,this._rtl,this._vw(),this._vh()))},this._released=e=>{const t=this._drag;t&&e.pointerId===t.id&&(this._drag=null,"pointercancel"===e.type?this._r=t.was:!t.moved&&t.grip&&("move"===t.mode?this._dockNext():this._stepWidth()))}}get open(){return this._open}dlg(){return this.renderRoot.querySelector("dialog")}show(){this._open||(this._open=!0,this._hasFooter=!!this.querySelector(':scope > [slot="footer"]'),this._compact=this._isCompact(),window.addEventListener("resize",this._viewport),(this.movable&&!this.moveLabel||this.resizable&&!this.resizeLabel||this.maximizable&&!this.maximizeLabel)&&console.debug("[magic-card] <mc-ui-window> needs moveLabel, resizeLabel and maximizeLabel"),this.updateComplete.then(()=>{const e=this.dlg();if(e){if("function"==typeof e.showModal)try{e.showModal()}catch{e.setAttribute("open","")}else e.setAttribute("open","");this.focusFirst()}}))}close(e="action"){if(!this._open)return;this._open=!1,this._forget();const t=this.dlg();t?.open&&"function"==typeof t.close?t.close():t?.removeAttribute("open"),this.dispatchEvent(new CustomEvent("mc-window-close",{detail:{reason:e},bubbles:!0,composed:!0}));const i=this.opener;i?.isConnected&&i.focus({preventScroll:!0})}disconnectedCallback(){if(super.disconnectedCallback(),this._open){this._open=!1,this._forget();const e=this.dlg();e?.open&&"function"==typeof e.close&&e.close()}}_forget(){window.removeEventListener("resize",this._viewport),this._r=null,this._drag=null,this._dock=0,this.maximized=!1}focusFirst(){const e=(this.initialFocus?this.querySelector(`#${CSS.escape(this.initialFocus)}`):null)??this.querySelector(V);(e??this.renderRoot.querySelector(".close"))?.focus({preventScroll:!0})}get _rtl(){return"rtl"===this._dir.direction||"rtl"===getComputedStyle(this).direction}_now(){return this._r??this._measure()}_measure(){const e=this.dlg()?.getBoundingClientRect();return{x:e?.left??0,y:e?.top??0,w:e?.width??0,h:e?.height??0}}_set(e){this._r=j(e,this._vw(),this._vh())}_abort(){const e=this._drag;return!!e&&(this._drag=null,this._r=e.was,!0)}_tab(e){if(e.defaultPrevented)return;const t=[],i=e=>{if(e instanceof HTMLElement&&!e.hasAttribute("hidden")){if(e instanceof HTMLSlotElement)return e.assignedNodes({flatten:!0}).forEach(i);e.matches(V)&&t.push(e),(e.shadowRoot??e).childNodes.forEach(i)}};this.renderRoot.childNodes.forEach(i);const n=t.indexOf(e.composedPath()[0]),s=e.shiftKey?0===n?t[t.length-1]:void 0:n===t.length-1?t[0]:void 0;s&&(e.preventDefault(),s.focus({preventScroll:!0}))}_begin(e,t,i){if(!(this.maximized||"mouse"===e.pointerType&&0!==e.button)&&(i||!e.composedPath()[0]?.closest?.('button, input, select, textarea, a, [role="button"]'))){this._drag={mode:t,id:e.pointerId,sx:e.clientX,sy:e.clientY,r0:this._now(),was:this._r,grip:i,moved:!1};try{e.target.setPointerCapture?.(e.pointerId)}catch{}}}_dockNext(){this.maximized||(this._dock=(this._dock+1)%L.length,this._set(function(e,t,i,n,s){if("centre"===t)return q(e,n,s);const r="end"===t!==i;return{...e,x:r?n-e.w-16:16}}(this._now(),L[this._dock],this._rtl,this._vw(),this._vh())))}_stepWidth(){this.maximized||this._set(function(e,t){const i=A.find(t=>t>e.w+1)??A[0];return{...e,w:Math.min(i,t-32)}}(this._now(),this._vw()))}_grip(e,t){const i=function(e,t){const i=t?64:16;switch(e){case"ArrowLeft":return[-i,0];case"ArrowRight":return[i,0];case"ArrowUp":return[0,-i];case"ArrowDown":return[0,i];default:return null}}(t.key,t.shiftKey);if(this.maximized||!i&&"Home"!==t.key)return;t.preventDefault(),t.stopPropagation();const n=this._now();if(this._dock=0,!i){if("move"===e)return this._set(q(n,this._vw(),this._vh()));const t=this.dlg(),i=t?.getAttribute("style")??null;t?.removeAttribute("style");const s=this._measure();if(null!==i&&t?.setAttribute("style",i),!this._r)return;return this._set({...n,w:s.w,h:s.h})}if("move"===e)return this._set({...n,x:n.x+i[0],y:n.y+i[1]});this._set(E(n,i[0],i[1],this._rtl,this._vw(),this._vh()))}_style(){const e=this.maximized?{x:16,y:16,w:this._vw()-32,h:this._vh()-32}:this._r;return e?`inset:auto;margin:0;max-width:none;max-height:none;left:${e.x}px;top:${e.y}px;width:${e.w}px;height:${e.h}px`:""}render(){if(!this._open)return a.s6;const e="alert"===this.variant,t=this._free(),i=t&&this.movable,n=t&&this.resizable&&!this.maximized,s=t&&this.maximizable;return a.qy`<dialog class="${this.variant} size-${this.size??(e?"s":"picker"===this.variant?"l":"m")}${this._rtl?" rtl":""}${this.maximized||this._r?" placed":""}" style=${this._style()} role=${e?"alertdialog":"dialog"} aria-labelledby="${this._id}-t" @cancel=${this._cancel} @keydown=${this._key} @pointerdown=${this._press} @click=${this._click} @pointermove=${this._moved} @pointerup=${this._released} @pointercancel=${this._released} > <div class="panel${n?" sizable":""}${this._hasFooter?" has-footer":""}" part="panel"> <div class="header${i?" movable":""}" part="header" @pointerdown=${e=>i&&this._begin(e,"move",!1)}> ${i?a.qy`<button type="button" class="tool move" part="move" aria-label=${this.moveLabel} title=${this.moveLabel} ?disabled=${this.maximized} @pointerdown=${e=>this._begin(e,"move",!0)} @keydown=${e=>this._grip("move",e)} @click=${e=>0===e.detail&&this._dockNext()}>${b("grip",20)}</button>`:a.s6}<h2 class="title" id="${this._id}-t" part="title">${this.heading}</h2><slot name="header-actions"></slot> ${s?a.qy`<button type="button" class="tool maximize" part="maximize" aria-pressed=${this.maximized?"true":"false"} aria-label=${this.maximized?this.restoreLabel:this.maximizeLabel} title=${this.maximized?this.restoreLabel:this.maximizeLabel} @click=${()=>this.maximized=!this.maximized}>${b(this.maximized?"restore":"maximize",20)}</button>`:a.s6} <button type="button" class="tool close" part="close" aria-label=${this.closeLabel} title=${this.closeLabel} @click=${()=>this.close("close-button")}>${b("close",20)}</button></div><div class="body" part="body"><slot></slot></div><div class="footer" part="footer" ?hidden=${!this._hasFooter}><slot name="footer" @slotchange=${this._footer}></slot></div></div>${n?a.qy`<button type="button" class="tool resize" part="resize" aria-label=${this.resizeLabel} title=${this.resizeLabel} @pointerdown=${e=>this._begin(e,"size",!0)} @keydown=${e=>this._grip("size",e)} @click=${e=>0===e.detail&&this._stepWidth()}>${b("resizeCorner",20)}</button>`:a.s6}</dialog>`}}O.uiKitRevision=7,O.styles=p,H([(0,o.MZ)()],O.prototype,"heading",void 0),H([(0,o.MZ)()],O.prototype,"closeLabel",void 0),H([(0,o.MZ)()],O.prototype,"variant",void 0),H([(0,o.MZ)({reflect:!0})],O.prototype,"size",void 0),H([(0,o.MZ)()],O.prototype,"initialFocus",void 0),H([(0,o.MZ)({attribute:!1})],O.prototype,"opener",void 0),H([(0,o.MZ)({type:Boolean})],O.prototype,"dismissible",void 0),H([(0,o.MZ)({type:Boolean})],O.prototype,"movable",void 0),H([(0,o.MZ)({type:Boolean})],O.prototype,"resizable",void 0),H([(0,o.MZ)({type:Boolean})],O.prototype,"maximizable",void 0),H([(0,o.MZ)({type:Boolean,reflect:!0})],O.prototype,"maximized",void 0),H([(0,o.MZ)()],O.prototype,"moveLabel",void 0),H([(0,o.MZ)()],O.prototype,"resizeLabel",void 0),H([(0,o.MZ)()],O.prototype,"maximizeLabel",void 0),H([(0,o.MZ)()],O.prototype,"restoreLabel",void 0),H([(0,o.wk)()],O.prototype,"_open",void 0),H([(0,o.wk)()],O.prototype,"_hasFooter",void 0),H([(0,o.wk)()],O.prototype,"_r",void 0),H([(0,o.wk)()],O.prototype,"_compact",void 0);const P=a.AH`:host{--bp-font-ui:'MC Space Grotesk',system-ui,-apple-system,'Segoe UI',sans-serif;--bp-font-mono:'MC Space Mono',ui-monospace,'SF Mono',Consolas,monospace;--bp-t-ruler:.594rem;--bp-t-meta:.6875rem;--bp-t-help:.75rem;--bp-t-mono:.781rem;--bp-t-label:.8125rem;--bp-t-body:.875rem;--bp-t-bar:.9375rem;--bp-t-head:1rem;--bp-t-page:1.125rem;--bp-lh:1.5;--bp-s-1:2px;--bp-s-2:4px;--bp-s-3:6px;--bp-s-4:8px;--bp-s-5:10px;--bp-s-6:12px;--bp-s-7:16px;--bp-s-8:20px;--bp-s-9:24px;--bp-s-10:32px;--bp-r-xs:6px;--bp-r-s:8px;--bp-r-m:10px;--bp-r-l:12px;--bp-r-xl:20px;--bp-r-pill:999px;--bp-bar-h:44px;--bp-ruler:22px;--bp-grid:20px;--bp-drawer-w:360px;--bp-layers-w:240px;--bp-hit:32px;--bp-focus-w:2px;--bp-focus-off:2px;--bp-dur:.15s;--bp-dur-sheet:.22s;color-scheme:light}:host([data-bp-mode="light"]),:host(:not([data-bp-mode])){--bp-bg:oklch(.972 .007 85);--bp-sheet:oklch(.985 .005 85);--bp-surf:oklch(.995 .003 85);--bp-surf2:oklch(.955 .008 85);--bp-hair:oklch(.93 .008 85);--bp-hair2:oklch(.9 .009 85);--bp-line:oklch(.87 .01 85);--bp-edge:oklch(.6 .012 250);--bp-ink:oklch(.27 .015 250);--bp-mute:oklch(.47 .014 250);--bp-acc:oklch(.5 .07 250);--bp-acc-ink:oklch(.99 .003 85);--bp-acc-soft:oklch(.93 .025 250);--bp-warn:oklch(.5 .12 40);--bp-danger:oklch(.5 .15 25);--bp-sw-slate:oklch(.55 .03 250);--bp-sw-sage:oklch(.62 .06 150);--bp-sw-sky:oklch(.6 .07 235);--bp-sw-rose:oklch(.6 .09 20);--bp-shadow:oklch(.3 .02 250 / .08);--bp-shadow-card:0 1px 2px var(--bp-shadow),0 8px 24px var(--bp-shadow);--bp-shadow-pill:0 4px 14px var(--bp-shadow);color-scheme:light}:host([data-bp-mode="dark"]){--bp-bg:oklch(.22 .012 250);--bp-sheet:oklch(.235 .013 250);--bp-surf:oklch(.27 .014 250);--bp-surf2:oklch(.31 .015 250);--bp-hair:oklch(.26 .012 250);--bp-hair2:oklch(.29 .013 250);--bp-line:oklch(.37 .015 250);--bp-edge:oklch(.58 .014 250);--bp-ink:oklch(.93 .008 250);--bp-mute:oklch(.74 .014 250);--bp-acc:oklch(.74 .055 250);--bp-acc-ink:oklch(.2 .02 250);--bp-acc-soft:oklch(.32 .03 250);--bp-warn:oklch(.76 .1 50);--bp-danger:oklch(.74 .12 25);--bp-sw-slate:oklch(.7 .03 250);--bp-sw-sage:oklch(.72 .06 150);--bp-sw-sky:oklch(.72 .06 235);--bp-sw-rose:oklch(.72 .08 20);--bp-shadow:oklch(0 0 0 / .3);--bp-shadow-card:0 1px 2px var(--bp-shadow),0 8px 24px var(--bp-shadow);--bp-shadow-pill:0 4px 14px var(--bp-shadow);color-scheme:dark} @supports not (color:oklch(0 0 0)){:host([data-bp-mode="light"]),:host(:not([data-bp-mode])){--bp-bg:#f8f5f1;--bp-sheet:#fcfaf6;--bp-surf:#fefdfb;--bp-surf2:#f3f0ea;--bp-hair:#eae7e2;--bp-hair2:#e1ded7;--bp-line:#d7d4cd;--bp-edge:#7b8187;--bp-ink:#21272e;--bp-mute:#555c63;--bp-acc:#43668a;--bp-acc-ink:#fdfcf9;--bp-acc-soft:#dceaf8;--bp-warn:#9a4729;--bp-danger:#a83634;--bp-shadow:rgba(30,40,50,.08)}:host([data-bp-mode="dark"]){--bp-bg:#161b20;--bp-sheet:#1a1f24;--bp-surf:#21272d;--bp-surf2:#2b3138;--bp-hair:#20252a;--bp-hair2:#272c32;--bp-line:#3a4148;--bp-edge:#747b83;--bp-ink:#e4e8ed;--bp-mute:#a4acb4;--bp-acc:#91aecd;--bp-acc-ink:#0f171f;--bp-acc-soft:#273442;--bp-warn:#e59e77;--bp-danger:#ed8c84;--bp-shadow:rgba(0,0,0,.3)}}@media (pointer:coarse){:host{--bp-hit:44px}}@media (prefers-reduced-motion:reduce){:host{--bp-dur:0s;--bp-dur-sheet:0s;scroll-behavior:auto}}`,R=a.AH`:host{display:block;position:relative;block-size:100%;min-block-size:0;overflow-x:clip;background:var(--bp-bg);color:var(--bp-ink);font:var(--bp-t-body) / var(--bp-lh) var(--bp-font-ui)}:host([data-bp-w="mid"]){--bp-drawer-w:320px;--bp-layers-w:220px}:host([data-bp-w="narrow"]),:host([data-bp-w="tiny"]){--bp-ruler:16px}:host([dir="rtl"]){--bp-slide-from:-100%}[hidden]{display:none !important}*,*::before,*::after{box-sizing:border-box}:focus-visible{outline:var(--bp-focus-w) solid var(--bp-acc);outline-offset:var(--bp-focus-off)}@media (forced-colors:active){:focus-visible{outline-color:Highlight}}.shell{display:flex;flex-direction:column;block-size:100%;min-block-size:0;min-width:0;scroll-padding:var(--bp-bar-h) var(--bp-s-6) var(--bp-s-9)}[data-bp="bar"]{flex:none;min-width:0;display:flex;align-items:center;gap:var(--bp-s-3);min-block-size:var(--bp-bar-h);padding:0 var(--bp-s-5);border-block-end:1px solid var(--bp-line);background:var(--bp-sheet);overflow-x:auto;scrollbar-width:none}[data-bp="bar"]::-webkit-scrollbar{display:none}[data-bp="bar"] slot{display:contents}.work{flex:1;min-width:0;min-block-size:0;display:grid;grid-template-columns:var(--lw,0px) minmax(0,1fr) var(--dw,0px);transition:grid-template-columns var(--bp-dur-sheet) ease}.work[data-start]{--lw:var(--bp-layers-w)}.work[data-open]{--dw:var(--bp-drawer-w)}.work[data-narrow]{--lw:0px;--dw:0px}.work[data-start][data-narrow][data-rail]{--lw:var(--bp-rail-w,72px)}[data-bp="start"]{grid-column:1;grid-row:1;display:none;min-width:0;min-inline-size:0;overflow:hidden;background:var(--bp-sheet);border-inline-end:1px solid var(--bp-line)}.work[data-start] [data-bp="start"]{display:flex;flex-direction:column}.work[data-start][data-narrow]:not([data-rail]) [data-bp="start"]{position:fixed;inset:0;z-index:20;border:0}[data-bp="stage"]{grid-column:2;grid-row:1;position:relative;min-width:0;min-inline-size:0;min-block-size:0;display:grid;grid-template-columns:var(--bp-ruler) minmax(0,1fr);grid-template-rows:var(--bp-ruler) minmax(0,1fr);background:var(--bp-bg)}[data-bp="stage"][data-rulers="off"]{grid-template-columns:0 minmax(0,1fr);grid-template-rows:0 minmax(0,1fr)}.corner{display:grid;place-items:center;overflow:hidden;font:var(--bp-t-ruler) var(--bp-font-mono);color:var(--bp-mute);border-inline-end:1px solid var(--bp-hair2);border-block-end:1px solid var(--bp-hair2)}[data-bp="ruler"]{position:relative;overflow:hidden;direction:ltr;color:var(--bp-mute);font:var(--bp-t-ruler) var(--bp-font-mono);pointer-events:none;user-select:none}[data-bp="ruler"][data-axis="x"]{border-block-end:1px solid var(--bp-hair2);background:repeating-linear-gradient(90deg,var(--bp-hair2) 0 1px,transparent 1px var(--bp-tick,10px)) bottom / 100% 5px no-repeat}[data-bp="ruler"][data-axis="y"]{border-inline-end:1px solid var(--bp-hair2);background:repeating-linear-gradient(180deg,var(--bp-hair2) 0 1px,transparent 1px var(--bp-tick,10px)) right / 5px 100% no-repeat;}[data-bp="ruler"] span{position:absolute}[data-bp="ruler"][data-axis="x"] span{top:2px;margin-inline-start:3px}[data-bp="ruler"][data-axis="y"] span{margin-top:2px;margin-inline-start:2px}:host([data-bp-w="tiny"]) [data-bp="ruler"] span,:host([data-bp-w="narrow"]) [data-bp="ruler"] span{display:none}[data-bp="grid"]{grid-column:2;grid-row:2;pointer-events:none;background-image:linear-gradient(var(--bp-hair) 1px,transparent 1px),linear-gradient(90deg,var(--bp-hair) 1px,transparent 1px);background-size:var(--bp-grid-step,var(--bp-grid)) var(--bp-grid-step,var(--bp-grid))}[data-bp="grid"][data-lines="off"]{background-image:none}[data-bp="stage"][data-rulers="off"] [data-bp="grid"],[data-bp="stage"][data-rulers="off"] .field{grid-column:1 / -1;grid-row:1 / -1}.field{grid-column:2;grid-row:2;position:relative;min-width:0;min-inline-size:0;min-block-size:0;overflow:auto;scroll-padding:var(--bp-s-9) var(--bp-s-6) 96px;padding:56px var(--bp-s-10) 64px}:host([data-bp-w="narrow"]) .field,:host([data-bp-w="tiny"]) .field{padding:48px var(--bp-s-6) 64px}:host([centre-stage]) .field{display:grid;padding-inline:8px}.content{position:relative;display:grid;justify-items:start;align-content:start;margin:auto;max-inline-size:100%}[data-bp="callout"]{position:absolute;pointer-events:none;border:1px solid var(--bp-acc);border-radius:var(--bp-r-xs)}[data-bp="callout"] output{position:absolute;inset-block-start:-20px;padding:0 var(--bp-s-3);border-radius:4px;background:var(--bp-acc);color:var(--bp-acc-ink);font:var(--bp-t-meta) var(--bp-font-mono);white-space:nowrap}:host([centre-stage]) [data-bp="callout"] output{inset-block-start:auto;inset-block-end:-20px}[data-bp="width-callout"]{position:absolute;inset:-28px 0 auto;display:flex;align-items:center;gap:var(--bp-s-3);color:var(--bp-mute);font:var(--bp-t-meta) var(--bp-font-mono);pointer-events:none}[data-bp="width-callout"]::before,[data-bp="width-callout"]::after{content:"";flex:1;block-size:1px;background:var(--bp-line)}.zoomrow{grid-column:1 / -1;grid-row:1 / -1;position:absolute;inset:0;z-index:3;display:flex;align-items:flex-end;justify-content:flex-end;padding:0 14px 12px;pointer-events:none}[data-bp="zoom"]{display:flex;align-items:center;gap:var(--bp-s-1);padding:3px;border:1px solid var(--bp-line);border-radius:var(--bp-r-pill);background:var(--bp-sheet);box-shadow:var(--bp-shadow-pill);pointer-events:auto}[data-bp="zoom"][data-empty]{display:none}[data-bp="zoom"] slot{display:contents}[data-bp="drawer"]{grid-column:3;grid-row:1;min-width:0;min-inline-size:0;overflow:hidden;border-inline-start:1px solid var(--bp-line)}.panel{display:flex;flex-direction:column;background:var(--bp-sheet);color:var(--bp-ink)}.head{flex:none;display:flex;align-items:center;gap:var(--bp-s-3);min-block-size:var(--bp-bar-h);padding:var(--bp-s-4) var(--bp-s-6);border-block-end:1px solid var(--bp-line)}.head h2{flex:1;min-inline-size:0;margin:0;overflow:hidden;font:600 var(--bp-t-head) var(--bp-font-ui);text-overflow:ellipsis;white-space:nowrap}.ib{flex:none;display:grid;place-items:center;inline-size:var(--bp-hit);block-size:var(--bp-hit);padding:0;border:0;border-radius:var(--bp-r-s);background:none;color:inherit;cursor:pointer}.ib:hover{background:var(--bp-surf2)}.ib[aria-pressed="true"]{background:var(--bp-acc-soft);color:var(--bp-acc);box-shadow:inset 0 0 0 2px var(--bp-acc)}svg{display:block;flex:none}:host([dir="rtl"]) svg[data-dir="mirror"]{transform:scaleX(-1)}.filt{flex:none;display:flex;align-items:center;gap:var(--bp-s-4);padding:var(--bp-s-4) var(--bp-s-6);border-block-end:1px solid var(--bp-line);font-size:var(--bp-t-label)}.filt slot{display:contents}[data-bp="modified-only"]{display:inline-flex;align-items:center;gap:var(--bp-s-4);min-block-size:var(--bp-hit);padding:0;border:0;background:none;color:inherit;font:inherit;cursor:pointer}.track{position:relative;flex:none;inline-size:38px;block-size:22px;border:1px solid var(--bp-edge);border-radius:var(--bp-r-pill);background:var(--bp-surf2)}.track::after{content:"";position:absolute;inset-block-start:2px;inset-inline-start:2px;inline-size:16px;block-size:16px;border-radius:50%;background:var(--bp-mute);transition:transform var(--bp-dur)}[aria-checked="true"] .track{border-color:var(--bp-acc);background:var(--bp-acc)}[aria-checked="true"] .track::after{background:var(--bp-acc-ink);transform:translateX(16px)}:host([dir="rtl"]) [aria-checked="true"] .track::after{transform:translateX(-16px)}.body{flex:1;min-block-size:0;min-width:0;overflow:auto;scroll-padding:var(--bp-s-9) 0;padding:var(--bp-s-2) var(--bp-s-6) var(--bp-s-9)}.none{padding:var(--bp-s-7) 0;color:var(--bp-mute);font-size:var(--bp-t-label)}.none:empty{display:none}[data-bp="sheet"]{position:fixed;inset:0;z-index:20;block-size:100vh;block-size:100dvh;padding:env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);animation:bp-sheet-in var(--bp-dur-sheet) ease-out}@keyframes bp-sheet-in{from{transform:translateX(var(--bp-slide-from,100%))}}@media (prefers-reduced-motion:reduce){:host{scroll-behavior:auto}}`;var D=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const N=[10,20,50,100,200,500,1e3,2e3,5e3],F=a.JW`<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path d="M15 4l5 5-3 1-3.5 3.5.5 4.5-1.5 1.5-3.5-3.5L5 20l-1-1 4.5-4.5L5 11l1.5-1.5 4.5.5L14.5 6.5z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>`;class T extends a.WF{get drawerOpen(){return this._open}get pinned(){return this._pinned}get modifiedOnly(){return this._modified}get narrow(){return this._width>0&&this._width<1024}constructor(){super(),this.studio="card-studio",this.scheme="light",this.strings={pin:"",modifiedOnly:"",noneModified:"",close:"",drawer:"",zoom:""},this.selectionLabel="",this.measure=null,this.rulers=!0,this.startMode="sheet",this.fixedDrawer=!1,this.centreStage=!1,this._open=!1,this._pinned=!1,this._modified=!1,this._width=0,this._opener=null,this._observer=null,this._togglePin=()=>{this._pinned=!this._pinned,this._fire("mc-frame-pin",{pinned:this._pinned})},this._toggleModified=()=>{this._modified=!this._modified,this._fire("mc-frame-modified",{on:this._modified})},this._onKey=e=>{if("Escape"===e.key){if(e.defaultPrevented||!this._open||!this.narrow&&(this._pinned||this.fixedDrawer))return;e.preventDefault(),e.stopPropagation(),this.closeDrawer("escape")}else"Tab"===e.key&&this._open&&this.narrow&&this._trap(e)},this._onSlot=()=>{this.requestUpdate()},this.addEventListener("keydown",this._onKey)}connectedCallback(){super.connectedCallback(),this._observer=new ResizeObserver(e=>{const t=e[e.length-1];t&&(this._width=t.contentRect.width)}),this._observer.observe(this),this._width=this.getBoundingClientRect().width}disconnectedCallback(){super.disconnectedCallback(),this._observer?.disconnect(),this._observer=null}openDrawer(e,t="user"){if(e)this._opener=e;else if(!this._open){const e=this._deepActive();this._opener=!e||this._inDrawer(e)||this._holdsFrame(e)?null:e}this._open||(this._open=!0,this._fire(r,{open:!0,reason:t}),this.narrow&&this.updateComplete.then(()=>this.renderRoot.querySelector('[data-bp="sheet"] button')?.focus()))}closeDrawer(e="user"){if(!this._open)return;const t=this._inDrawer(this._deepActive());this._open=!1,this._fire(r,{open:!1,reason:e});const i=this._opener;if(this._opener=null,"stage"===e)return;const n=()=>{i?.isConnected?i.focus():t&&this._topStops()[0]?.focus()};this.narrow?this.updateComplete.then(n):n()}_holdsFrame(e){if(e===this)return!0;for(let t=this.parentNode;t;t=t.parentNode??t.host??null)if(t===e)return!0;return!1}stageWork(){!this._open||this._pinned||this.fixedDrawer||this.closeDrawer("stage")}_fire(e,t){this.dispatchEvent(new CustomEvent(e,{detail:t,bubbles:!0,composed:!0}))}_deepActive(){let e=document.activeElement;try{for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement}catch{}return e instanceof HTMLElement&&e!==document.body?e:null}_inDrawer(e){const t=this.renderRoot.querySelector('[data-bp="drawer"], [data-bp="sheet"]');for(let i=e;i;i=i.parentNode??i.host??null){if(i===t)return!0;if(i instanceof HTMLElement&&i.parentElement===this&&("drawer"===i.slot||"drawer-actions"===i.slot))return!0}return!1}_stops(e,t){if(!e.hasAttribute("hidden")&&!e.hasAttribute("inert"))if(e.matches('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')&&!e.disabled&&t.push(e),e instanceof HTMLSlotElement)for(const i of e.assignedElements({flatten:!0}))this._stops(i,t);else if(e.shadowRoot)for(const i of Array.from(e.shadowRoot.children))this._stops(i,t);else for(const i of Array.from(e.children))this._stops(i,t)}_topStops(){const e=[];for(const t of Array.from(this.children))"top"===t.slot&&this._stops(t,e);return e}_trap(e){const t=this.renderRoot.querySelector('[data-bp="sheet"]');if(!t)return;const i=[];for(const e of Array.from(t.children))this._stops(e,i);const n=i[0],s=i[i.length-1];if(!n||!s)return;const r=this._deepActive();e.shiftKey&&r===n?(e.preventDefault(),s.focus()):e.shiftKey||r!==s||(e.preventDefault(),n.focus())}_has(e){return Array.from(this.children).some(t=>t.slot===e&&!t.hasAttribute("hidden"))}_size(){const e=this._width;return e>0&&e<640?"tiny":e>0&&e<1024?"narrow":e>0&&e<1280?"mid":"wide"}willUpdate(e){e.has("_width")&&this.setAttribute("data-bp-w",this._size()),e.has("startMode")&&"rail"===this.startMode&&"rail"!==this.getAttribute("start-mode")&&this.setAttribute("start-mode","rail")}_ruler(e){const t=this.measure,i=t&&t.zoom>0?t.zoom:1,n=t?"x"===e?t.width:t.height:0,s=N.find(e=>e*i>=48)??N[N.length-1],r=[];for(let e=0;e<=n&&r.length<200;e+=s)r.push(e);const o=Math.max(4,s/5*i),l="x"===e?"left":"top";return a.qy`<div data-bp="ruler" data-axis=${e} aria-hidden="true" style=${`--bp-tick:${o}px`}> ${r.map(e=>a.qy`<span style=${`${l}:${e*i}px`}>${e}</span>`)}</div>`}_marks(){const e=this.measure;if(!e)return a.s6;const t=e.zoom>0?e.zoom:1,i=e.selection;return a.qy`<div data-bp="width-callout" aria-hidden="true"><output>${Math.round(e.width)} px</output></div>${i?a.qy`<div data-bp="callout" aria-hidden="true" style=${`left:${i.x*t}px;top:${i.y*t}px;width:${i.width*t}px;height:${i.height*t}px`}> <output>${Math.round(i.width)} × ${Math.round(i.height)}</output></div>`:a.s6} `}_stage(){const e=this.measure,t=e&&e.zoom>0?e.zoom:1,i=e&&e.grid>0?e.grid*t:0,n=this._open&&this.narrow,s=e?`min-inline-size:${e.width*t}px;min-block-size:${e.height*t}px`:"";return a.qy`<div data-bp="stage" data-rulers=${this.rulers?"on":"off"} ?inert=${n}> ${this.rulers?a.qy`<div class="corner" aria-hidden="true">px</div>${this._ruler("x")}${this._ruler("y")}`:a.s6}<div data-bp="grid" aria-hidden="true" data-lines=${e&&0===e.grid?"off":"on"} style=${i?`--bp-grid-step:${i}px`:""}></div><div class="field"><div class="content" style=${s}> <slot name="stage"></slot> ${this._marks()}</div></div><div class="zoomrow"><div data-bp="zoom" role="group" aria-label=${this.strings.zoom} ?data-empty=${!this._has("zoom")}> <slot name="zoom" @slotchange=${this._onSlot}></slot></div></div></div>`}_filter(){return a.qy`<div class="filt"><button type="button" data-bp="modified-only" role="switch" aria-checked=${this._modified?"true":"false"} @click=${this._toggleModified}> <span class="track" aria-hidden="true"></span><span>${this.strings.modifiedOnly}</span> </button> <slot name="drawer-actions"></slot></div>`}_body(){const e=this._modified&&!this._has("drawer");return a.qy`<div class="body"><slot name="drawer" @slotchange=${this._onSlot}></slot><div class="none" role="status">${e?this.strings.noneModified:a.s6}</div></div>`}_drawer(){const e=`${this.strings.drawer}: ${this.selectionLabel}`;return a.qy`<aside data-bp="drawer" class="panel" aria-label=${e} ?hidden=${!this._open} ?inert=${!this._open}> <div class="head"><h2 title=${this.selectionLabel}>${this.selectionLabel}</h2>${this.fixedDrawer?a.s6:a.qy`<button type="button" class="ib" data-bp="pin" aria-label=${this.strings.pin} title=${this.strings.pin} aria-pressed=${this._pinned?"true":"false"} @click=${this._togglePin}>${F}</button>`} <button type="button" class="ib" aria-label=${this.strings.close} title=${this.strings.close} @click=${()=>this.closeDrawer("user")}>${b("close",18)}</button></div>${this._filter()}${this._body()} </aside>`}_sheet(){return a.qy`<div data-bp="sheet" class="panel" role="dialog" aria-modal="true" aria-labelledby="bp-sheet-title"><div class="head"><button type="button" class="ib" aria-label=${this.strings.close} title=${this.strings.close} @click=${()=>this.closeDrawer("user")}>${b("left",18)}</button><h2 id="bp-sheet-title" title=${this.selectionLabel}>${this.selectionLabel}</h2></div>${this._filter()}${this._body()}</div>`}render(){const e=this.narrow,t=this._open&&e;return a.qy`<div class="shell"><div data-bp="bar" ?inert=${t}><slot name="top"></slot></div><div class="work" ?data-start=${this._has("start")} ?data-open=${this._open&&!e} ?data-narrow=${e} ?data-rail=${"rail"===this.startMode}> <div data-bp="start" ?inert=${t}><slot name="start" @slotchange=${this._onSlot}></slot></div>${this._stage()} ${e?a.s6:this._drawer()}</div>${t?this._sheet():a.s6}</div>`}}T.uiKitRevision=7,T.styles=[P,R],D([(0,o.MZ)({reflect:!0})],T.prototype,"studio",void 0),D([(0,o.MZ)({attribute:"data-bp-mode",reflect:!0})],T.prototype,"scheme",void 0),D([(0,o.MZ)({attribute:!1})],T.prototype,"strings",void 0),D([(0,o.MZ)({attribute:!1})],T.prototype,"selectionLabel",void 0),D([(0,o.MZ)({attribute:!1})],T.prototype,"measure",void 0),D([(0,o.MZ)({attribute:!1})],T.prototype,"rulers",void 0),D([(0,o.MZ)({attribute:"start-mode"})],T.prototype,"startMode",void 0),D([(0,o.MZ)({type:Boolean,attribute:"fixed-drawer",reflect:!0})],T.prototype,"fixedDrawer",void 0),D([(0,o.MZ)({type:Boolean,attribute:"centre-stage",reflect:!0})],T.prototype,"centreStage",void 0),D([(0,o.wk)()],T.prototype,"_open",void 0),D([(0,o.wk)()],T.prototype,"_pinned",void 0),D([(0,o.wk)()],T.prototype,"_modified",void 0),D([(0,o.wk)()],T.prototype,"_width",void 0),function(e){for(const[t,i]of e){const e=customElements.get(t);e?(e.uiKitRevision??0)<7&&console.debug(`[magic-card] ${t} is defined by an older ui-kit (revision ${e.uiKitRevision??0}); keeping it`):customElements.define(t,i)}}([["mc-ui-window",O],["mc-ui-menu",S],["mc-ui-popover",C],[s,T]]);var B=i(6752),I=i(7804);const{I:Z}=B.ge,W=e=>void 0===e.strings,K={},U=(0,I.u$)(class extends I.WL{constructor(e){if(super(e),e.type!==I.OA.PROPERTY&&e.type!==I.OA.ATTRIBUTE&&e.type!==I.OA.BOOLEAN_ATTRIBUTE)throw Error("The `live` directive is not allowed on child or event bindings");if(!W(e))throw Error("`live` bindings can only contain a single expression")}render(e){return e}update(e,[t]){if(t===B.c0||t===B.s6)return t;const i=e.element,n=e.name;if(e.type===I.OA.PROPERTY){if(t===i[n])return B.c0}else if(e.type===I.OA.BOOLEAN_ATTRIBUTE){if(!!t===i.hasAttribute(n))return B.c0}else if(e.type===I.OA.ATTRIBUTE&&i.getAttribute(n)===t+"")return B.c0;return((e,t=K)=>{e._$AH=t})(e),t}}),G=Symbol.for(""),Y=e=>{if(e?.r===G)return e?._$litStatic$},J=new Map,X=e=>(t,...i)=>{const n=i.length;let s,r;const a=[],o=[];let l,c=0,d=!1;for(;c<n;){for(l=t[c];c<n&&void 0!==(r=i[c],s=Y(r));)l+=s+t[++c],d=!0;c!==n&&o.push(r),a.push(l),c++}if(c===n&&a.push(t[n]),d){const e=a.join("$$lit$$");void 0===(t=J.get(e))&&(a.raw=a,J.set(e,t=a)),i=o}return e(t,...i)},Q=X(B.qy);X(B.JW),X(B.ej);var ee=i(4753),te=i(201);const ie=e=>e.channels.includes("glow")||e.channels.includes("fx")||!!e.colour,ne=[{id:"linear",label:287,css:"linear"},{id:"ease",label:172,css:"ease"},{id:"ease-in",label:173,css:"ease-in"},{id:"ease-out",label:175,css:"ease-out"},{id:"ease-in-out",label:174,css:"ease-in-out"},{id:"spring",label:450,css:"cubic-bezier(0.34, 1.56, 0.64, 1)"},{id:"smooth",label:434,css:"cubic-bezier(0.45, 0, 0.55, 1)"},{id:"snap",label:435,css:"cubic-bezier(0.7, 0, 0.3, 1)"}],se=(e,t=1080)=>({label:e,unit:"deg",min:0,max:t}),re=(e,t=100)=>({label:e,unit:"%",min:0,max:t}),ae=(e,t=60)=>({label:e,unit:"px",min:0,max:t}),oe=(e=350,t=12)=>({label:e,unit:"",min:1,max:t}),le=oe();function ce(e,t,i){const{direction:n="normal",iterations:s="infinite",...r}=i.extra||{};return{id:e,name:t,group:i.group,channels:i.channels,defaults:{duration:`${i.duration}s`,delay:"0s",easing:i.easing??"ease-in-out",iterations:s,direction:n,intensity:i.intensity[1]},intensity:i.intensity[0],...r}}const de={iconKeyframes:!0},pe=[ce("breathe",94,{group:"Glow & pulse",channels:["scale","opacity"],duration:3.2,intensity:[re(408,50),4]}),ce("glow-pulse",222,{group:"Glow & pulse",channels:["glow"],duration:2,intensity:[ae(223),16],extra:de}),ce("halo-ripple",233,{group:"Glow & pulse",channels:["glow"],duration:1.8,easing:"ease-out",intensity:[ae(391),14],extra:de}),ce("aura",34,{group:"Glow & pulse",channels:["glow"],duration:4,intensity:[ae(223),24],extra:de}),ce("heartbeat",235,{group:"Glow & pulse",channels:["scale"],duration:1.4,intensity:[re(408,50),12]}),ce("spin",446,{group:"Motion",channels:["rotate"],duration:2,easing:"linear",intensity:[se(398),360]}),ce("fast-spin",187,{group:"Motion",channels:["rotate"],duration:.6,easing:"linear",intensity:[se(398),360]}),ce("sway",472,{group:"Motion",channels:["rotate"],duration:2.4,intensity:[se(21,90),6]}),ce("wobble",557,{group:"Motion",channels:["translate","rotate"],duration:1.2,intensity:[ae(154),6]}),ce("shake-alert",418,{group:"Motion",channels:["translate"],duration:2,intensity:[ae(154),4]}),ce("rumble",406,{group:"Motion",channels:["translate"],duration:.3,easing:"linear",intensity:[ae(154,10),1]}),ce("float",206,{group:"Motion",channels:["translate"],duration:3,intensity:[ae(154),6]}),ce("flame-flicker",194,{group:"Weather & device",channels:["scale","rotate","filter"],duration:1.2,intensity:[re(203,30),5],extra:{origin:"50% 100%",colour:!0}}),ce("steam-rise",461,{group:"Weather & device",channels:["fx"],duration:3,easing:"ease-out",intensity:[le,4],extra:{particles:"count"}}),ce("bubbles",97,{group:"Weather & device",channels:["fx"],duration:3.5,easing:"ease-in",intensity:[le,6],extra:{particles:"count"}}),ce("snow-fall",437,{group:"Weather & device",channels:["fx"],duration:5,easing:"linear",intensity:[le,6],extra:{particles:"count"}}),ce("rain-fall",375,{group:"Weather & device",channels:["fx"],duration:.9,easing:"linear",intensity:[le,6],extra:{particles:"count"}}),ce("liquid-wave",288,{group:"Weather & device",channels:["fx"],duration:6,easing:"linear",intensity:[re(188),40],extra:{particles:2}}),ce("storm-flash",463,{group:"Weather & device",channels:["fx"],duration:5,easing:"linear",intensity:[re(96),75],extra:{particles:1,front:!0}}),ce("shine-sweep",423,{group:"Light & colour",channels:["fx"],duration:3,intensity:[re(422),45],extra:{particles:1,front:!0}}),ce("bounce",88,{group:"Playful",channels:["translate","scale"],duration:1.6,easing:"ease",intensity:[ae(237),10],extra:{origin:"50% 100%"}}),ce("jello",264,{group:"Playful",channels:["scale"],duration:1.8,easing:"ease",intensity:[re(452,50),12]}),ce("rubber-band",405,{group:"Playful",channels:["scale"],duration:1.6,easing:"ease",intensity:[re(466,50),25]}),ce("tada",502,{group:"Playful",channels:["scale","rotate"],duration:2,easing:"ease",intensity:[se(21,45),3]}),ce("swing",473,{group:"Playful",channels:["rotate"],duration:2,easing:"ease-in-out",intensity:[se(21,90),15],extra:{origin:"50% 0"}}),ce("flip",205,{group:"Playful",channels:["rotate"],duration:2.4,easing:"smooth",intensity:[se(398),360]}),ce("pop",360,{group:"Playful",channels:["scale"],duration:1.8,easing:"ease-out",intensity:[re(408,50),18]}),ce("head-shake",234,{group:"Playful",channels:["translate","rotate"],duration:1.6,easing:"ease-in-out",intensity:[ae(154,30),6]}),ce("blink",65,{group:"Light & colour",channels:["opacity"],duration:1,easing:"linear",intensity:[re(139),85]}),ce("neon-flicker",315,{group:"Light & colour",channels:["opacity","filter"],duration:3,easing:"linear",intensity:[ae(223,30),8],extra:{colour:!0}}),ce("rainbow-hue",376,{group:"Light & colour",channels:["filter"],duration:6,easing:"linear",intensity:[se(241,720),360]}),ce("glitch",219,{group:"Light & colour",channels:["translate","filter"],duration:2.5,easing:"linear",intensity:[ae(327,20),3],extra:{colour:!0}}),ce("fade-pulse",184,{group:"Light & colour",channels:["opacity"],duration:2.4,intensity:[re(183),60]}),ce("ping",353,{group:"Rings & sweeps",channels:["fx"],duration:2,easing:"ease-out",intensity:[re(391,200),90],extra:{particles:1}}),ce("ripple-rings",395,{group:"Rings & sweeps",channels:["fx"],duration:3,easing:"ease-out",intensity:[oe(392,6),3],extra:{particles:"count"}}),ce("radar-sweep",372,{group:"Rings & sweeps",channels:["fx"],duration:3,easing:"linear",intensity:[se(62,180),70],extra:{particles:1}}),ce("conic-border-spin",122,{group:"Rings & sweeps",channels:["fx"],duration:3,easing:"linear",intensity:[ae(82,12),2],extra:{particles:1}}),ce("breathing-border",95,{group:"Rings & sweeps",channels:["glow"],duration:3,intensity:[ae(82,12),2],extra:de}),ce("fireflies",191,{group:"Scenes",channels:["fx"],duration:6,intensity:[le,8],extra:{particles:"count"}}),ce("confetti",121,{group:"Scenes",channels:["fx"],duration:3.5,easing:"linear",intensity:[le,10],extra:{particles:"count"}}),ce("falling-leaves",186,{group:"Scenes",channels:["fx"],duration:7,easing:"linear",intensity:[le,5],extra:{particles:"count"}}),ce("lightning",283,{group:"Scenes",channels:["fx"],duration:4,easing:"linear",intensity:[re(96),90],extra:{particles:1,front:!0}}),ce("ocean-waves",326,{group:"Scenes",channels:["fx"],duration:4,easing:"linear",intensity:[re(548),35],extra:{particles:3}}),ce("sun-rays",470,{group:"Scenes",channels:["fx"],duration:24,easing:"linear",intensity:[se(379,30),6],extra:{particles:1}}),ce("heat-shimmer",236,{group:"Scenes",channels:["translate","filter"],duration:1.2,easing:"ease-in-out",intensity:[ae(465,10),2]}),ce("wind-lines",554,{group:"Scenes",channels:["fx"],duration:2.2,intensity:[le,5],extra:{particles:"count"}}),ce("drip",164,{group:"Scenes",channels:["fx"],duration:2.4,easing:"ease-in",intensity:[le,3],extra:{particles:"count"}}),ce("equalizer-bars",181,{group:"Scenes",channels:["fx"],duration:.9,intensity:[oe(60),5],extra:{particles:"count",direction:"alternate"}}),ce("charging-stripes",104,{group:"Scenes",channels:["fx"],duration:1,easing:"linear",intensity:[re(467),100],extra:{particles:1}}),ce("orbit-dots",332,{group:"Scenes",channels:["fx"],duration:2.4,easing:"linear",intensity:[oe(156,8),3],extra:{particles:"count"}}),ce("typing-dots",530,{group:"Scenes",channels:["fx"],duration:1.2,intensity:[ae(88,20),4],extra:{particles:3}}),ce("pendulum",352,{group:"Motion",channels:["rotate"],duration:2.4,intensity:[se(21,90),20],extra:{origin:"50% 0",direction:"alternate"}}),ce("orbit",331,{group:"Motion",channels:["translate"],duration:4,easing:"linear",intensity:[ae(373,40),6]}),ce("coin-spin",113,{group:"Motion",channels:["rotate"],duration:3,easing:"linear",intensity:[se(398),360]}),ce("rotate-3d",3,{group:"Motion",channels:["rotate"],duration:3,intensity:[se(516,180),25],extra:{direction:"alternate"}}),ce("squash-stretch",453,{group:"Motion",channels:["scale","translate"],duration:1.4,intensity:[re(452,50),14],extra:{origin:"50% 100%"}}),ce("wiggle",553,{group:"Motion",channels:["rotate"],duration:2.5,intensity:[se(21,45),8]}),ce("shadow-lift",416,{group:"Motion",channels:["translate","glow"],duration:3,intensity:[ae(279,20),4],extra:de}),ce("holographic-shimmer",239,{group:"Light & colour",channels:["fx"],duration:5,easing:"linear",intensity:[re(465),35],extra:{particles:1,front:!0}}),ce("scanline",409,{group:"Light & colour",channels:["fx"],duration:3,easing:"linear",intensity:[re(96),50],extra:{particles:1,front:!0}}),ce("twinkle",529,{group:"Light & colour",channels:["fx"],duration:2.4,intensity:[le,6],extra:{particles:"count",front:!0}}),ce("spotlight",449,{group:"Light & colour",channels:["fx"],duration:7,intensity:[re(96),45],extra:{particles:1}}),ce("border-snake",78,{group:"Borders",channels:["fx"],duration:3,easing:"linear",intensity:[ae(552,12),3],extra:{ring:"snake"}}),ce("neon-border",314,{group:"Borders",channels:["glow"],duration:2.4,intensity:[ae(223,30),10],extra:de}),ce("power-flow",364,{group:"Borders",channels:["fx"],duration:4,easing:"linear",intensity:[ae(155,12),5],extra:{ring:"dots"}}),ce("marching-ants",299,{group:"Borders",channels:["fx"],duration:20,easing:"linear",intensity:[ae(552,12),2],extra:{ring:"dashes"}}),ce("aurora",35,{group:"Backgrounds",channels:["fx"],duration:12,intensity:[re(220),55],extra:{particles:3}}),ce("lava-lamp",274,{group:"Backgrounds",channels:["fx"],duration:9,intensity:[le,5],extra:{particles:"count",direction:"alternate"}}),ce("plasma-gradient",354,{group:"Backgrounds",channels:["fx"],duration:10,easing:"linear",intensity:[re(465),70],extra:{particles:1}}),ce("gradient-flow",226,{group:"Backgrounds",channels:["fx"],duration:8,easing:"linear",intensity:[re(465),60],extra:{particles:1,direction:"alternate"}}),ce("color-cycle-bg",116,{group:"Backgrounds",channels:["fx"],duration:10,easing:"linear",intensity:[re(465),35],extra:{particles:1}}),ce("starfield",455,{group:"Backgrounds",channels:["fx"],duration:3.5,intensity:[le,12],extra:{particles:"count"}}),ce("meteor-shower",305,{group:"Backgrounds",channels:["fx"],duration:3,easing:"ease-in",intensity:[le,4],extra:{particles:"count"}}),ce("bokeh",68,{group:"Backgrounds",channels:["fx"],duration:8,intensity:[le,7],extra:{particles:"count",direction:"alternate"}}),ce("matrix-rain",302,{group:"Backgrounds",channels:["fx"],duration:2.4,easing:"linear",intensity:[oe(464),10],extra:{particles:"count"}}),ce("smoke",433,{group:"Backgrounds",channels:["fx"],duration:6,easing:"ease-out",intensity:[le,5],extra:{particles:"count"}}),ce("clouds-drift",111,{group:"Backgrounds",channels:["fx"],duration:30,easing:"linear",intensity:[oe(110,6),3],extra:{particles:"count"}}),ce("water-ripple",546,{group:"Backgrounds",channels:["fx"],duration:4,easing:"ease-out",intensity:[oe(396,8),3],extra:{particles:"count"}}),ce("fireworks",192,{group:"Backgrounds",channels:["fx"],duration:2.2,easing:"ease-out",intensity:[oe(445),10],extra:{particles:"count"}}),...[["winter",556,"winter"],["spring",450,"spring"],["summer",469,"summer"],["autumn",40,"autumn"],["christmas",105,"christmas"],["new_year",316,"new_year"],["valentine",536,"valentine"],["easter",176,"easter"],["halloween",232,"halloween"],["weather",294,"weather"],["daynight",132,"daynight"],["snow",438,"snow"],["rain",377,"rain"],["storm",514,"storm"],["sun",471,"sun"],["clouds",112,"clouds"],["fog",208,"fog"],["wind",555,"wind"],["night",318,"night"],["dusk",171,"dusk"]].map(([e,t,i])=>ce(e,t,{group:"Seasonal",channels:["fx"],duration:1,easing:"linear",intensity:[re(137),50],extra:{seasonal:i}})),ce("tap-ripple",503,{group:"Interaction",channels:["fx"],duration:.6,easing:"ease-out",intensity:[re(96),35],extra:{particles:1,front:!0,trigger:"tap",iterations:1}}),ce("press",368,{group:"Interaction",channels:["scale"],duration:.3,easing:"ease-out",intensity:[re(138,30),6],extra:{trigger:"tap",iterations:1}})],he=["Glow & pulse","Motion","Playful","Light & colour","Rings & sweeps","Borders","Weather & device","Scenes","Backgrounds","Seasonal","Interaction"].filter(e=>pe.some(t=>t.group===e)),ue={"Glow & pulse":221,Motion:308,Playful:356,"Light & colour":281,"Rings & sweeps":393,Borders:84,"Weather & device":550,Scenes:410,Backgrounds:51,Seasonal:412,Interaction:260},me=new Map(pe.map(e=>[e.id,e])),ge=e=>e?me.get(e):void 0,fe={breathe:"0%,100%{scale:1;opacity:1}50%{scale:calc(1 + $i / 100);opacity:.78}","glow-pulse":"0%,100%{box-shadow:0 0 0 0 transparent}50%{box-shadow:0 0 calc($i * 1px) calc($i * .19px) $c}","glow-pulse-icon":"0%,100%{filter:drop-shadow(0 0 0 transparent)}50%{filter:drop-shadow(0 0 calc($i * .375px) $c)}","halo-ripple":"0%{box-shadow:0 0 0 0 $c}100%{box-shadow:0 0 0 calc($i * 1px) transparent}","halo-ripple-icon":"0%{filter:drop-shadow(0 0 0 $c)}100%{filter:drop-shadow(0 0 calc($i * .7px) transparent)}",aura:"0%,100%{box-shadow:0 0 calc($i * .42px) calc($i * .04px) color-mix(in srgb,$c 60%,transparent),inset 0 0 calc($i * .42px) color-mix(in srgb,$c 24%,transparent)}50%{box-shadow:0 0 calc($i * 1px) calc($i * .25px) $c,inset 0 0 calc($i * .75px) color-mix(in srgb,$c 48%,transparent)}","aura-icon":"0%,100%{filter:drop-shadow(0 0 calc($i * .125px) color-mix(in srgb,$c 50%,transparent))}50%{filter:drop-shadow(0 0 calc($i * .42px) $c)}",heartbeat:"0%,70%,100%{scale:1}14%{scale:calc(1 + $i / 100)}28%{scale:1}42%{scale:calc(1 + $i / 150)}",spin:"from{rotate:0deg}to{rotate:calc($i * 1deg)}","fast-spin":"from{rotate:0deg}to{rotate:calc($i * 1deg)}",sway:"0%,100%{rotate:calc($i * -1deg)}50%{rotate:calc($i * 1deg)}",wobble:"0%,100%{translate:0 0;rotate:0deg}15%{translate:calc($i * -1px) 0;rotate:calc($i * -.66deg)}30%{translate:calc($i * .83px) 0;rotate:calc($i * .5deg)}45%{translate:calc($i * -.66px) 0;rotate:calc($i * -.33deg)}60%{translate:calc($i * .33px) 0;rotate:calc($i * .17deg)}75%{translate:calc($i * -.17px) 0;rotate:calc($i * -.08deg)}","shake-alert":"0%,50%,100%{translate:0 0}5%,15%,25%,35%,45%{translate:calc($i * -1px) 0}10%,20%,30%,40%{translate:calc($i * 1px) 0}",rumble:"0%,100%{translate:0 0}25%{translate:calc($i * 1px) calc($i * -1px)}50%{translate:calc($i * -1px) calc($i * 1px)}75%{translate:calc($i * 1px) calc($i * 1px)}",float:"0%,100%{translate:0 0}50%{translate:0 calc($i * -1px)}","flame-flicker":"0%,100%{scale:1 1;rotate:0deg;filter:drop-shadow(0 0 2px $c) brightness(1)}25%{scale:calc(1 - $i * .004) calc(1 + $i / 100);rotate:calc($i * .3deg);filter:drop-shadow(0 -1px 6px $c) brightness(1.15)}50%{scale:calc(1 + $i * .004) calc(1 - $i * .006);rotate:calc($i * -.2deg);filter:drop-shadow(0 0 3px $c) brightness(.95)}75%{scale:calc(1 - $i * .002) calc(1 + $i * .008);rotate:calc($i * -.4deg);filter:drop-shadow(0 -1px 5px $c) brightness(1.1)}","steam-rise":"0%{translate:0 0;scale:.5;opacity:0}25%{opacity:1}100%{translate:0 -100cqh;scale:1.7;opacity:0}",bubbles:"0%{translate:0 0;opacity:0}10%{opacity:1}50%{translate:4px -55cqh}90%{opacity:.8}100%{translate:-3px calc(-100cqh - 12px);opacity:0}","snow-fall":"0%{translate:0 0;opacity:0}10%{opacity:1}50%{translate:6px 50cqh}100%{translate:-2px calc(100cqh + 12px);opacity:.7}","rain-fall":"0%{translate:0 0;opacity:0}10%{opacity:1}100%{translate:0 calc(100cqh + 24px);opacity:.6}","liquid-wave":"from{rotate:0deg}to{rotate:360deg}","storm-flash":"0%,88%,100%{opacity:0}90%{opacity:calc($i / 100)}91.5%{opacity:.1}93.5%{opacity:calc($i / 125)}96%{opacity:0}","shine-sweep":"0%{translate:-100% 0}60%,100%{translate:100cqw 0}",blink:"0%,45%,100%{opacity:1}50%,95%{opacity:calc(1 - $i / 100)}","neon-flicker":"0%,17%,23%,26%,52%,58%,100%{opacity:1;filter:drop-shadow(0 0 calc($i * 1px) $c) brightness(1.1)}20%,25%,55%{opacity:.45;filter:drop-shadow(0 0 0 transparent) brightness(.8)}24%{opacity:.8;filter:drop-shadow(0 0 calc($i * .4px) $c) brightness(1)}","rainbow-hue":"from{filter:hue-rotate(0deg)}to{filter:hue-rotate(calc($i * 1deg))}",glitch:"0%,86%,100%{translate:0 0;filter:none}88%{translate:calc($i * -1px) 0;filter:drop-shadow(calc($i * .7px) 0 0 $c) drop-shadow(calc($i * -.7px) 0 0 color-mix(in srgb,$c 35%,#00e5ff))}90%{translate:calc($i * 1px) calc($i * .3px);filter:drop-shadow(calc($i * -.7px) 0 0 $c) hue-rotate(40deg)}92%{translate:calc($i * -.5px) 0;filter:drop-shadow(calc($i * .4px) 0 0 color-mix(in srgb,$c 35%,#ff1744))}94%{translate:0 0;filter:none}","fade-pulse":"0%,100%{opacity:1}50%{opacity:calc(1 - $i / 100)}",bounce:"0%,20%,53%,100%{translate:0 0;scale:1 1}40%,43%{translate:0 calc($i * -1px);scale:.96 1.06}70%{translate:0 calc($i * -.5px);scale:.98 1.03}80%{translate:0 0;scale:1.04 .96}90%{translate:0 calc($i * -.12px);scale:1 1}",jello:"0%,10%,60%,100%{scale:1 1}18%{scale:calc(1 + $i / 100) calc(1 - $i / 100)}26%{scale:calc(1 - $i / 100) calc(1 + $i / 100)}34%{scale:calc(1 + $i / 200) calc(1 - $i / 200)}42%{scale:calc(1 - $i / 400) calc(1 + $i / 400)}50%{scale:calc(1 + $i / 800) calc(1 - $i / 800)}","rubber-band":"0%,55%,100%{scale:1 1}15%{scale:calc(1 + $i / 100) calc(1 - $i / 100)}20%{scale:calc(1 - $i / 100) calc(1 + $i / 100)}25%{scale:calc(1 + $i / 160) calc(1 - $i / 160)}33%{scale:calc(1 - $i / 500) calc(1 + $i / 500)}42%{scale:calc(1 + $i / 500) calc(1 - $i / 500)}",tada:"0%,50%,100%{scale:1;rotate:0deg}5%,10%{scale:.9;rotate:calc($i * -1deg)}15%,25%,35%,45%{scale:1.1;rotate:calc($i * 1deg)}20%,30%,40%{scale:1.1;rotate:calc($i * -1deg)}",swing:"0%,60%,100%{rotate:0deg}12%{rotate:calc($i * 1deg)}24%{rotate:calc($i * -.66deg)}36%{rotate:calc($i * .33deg)}48%{rotate:calc($i * -.2deg)}",flip:"0%,10%{rotate:y 0deg}60%,100%{rotate:y calc($i * 1deg)}",pop:"0%,40%,100%{scale:1}10%{scale:calc(1 + $i / 100)}20%{scale:calc(1 - $i / 400)}30%{scale:calc(1 + $i / 600)}","head-shake":"0%,50%,100%{translate:0 0;rotate:0deg}6.5%{translate:calc($i * -1px) 0;rotate:calc($i * -1deg)}18.5%{translate:calc($i * .8px) 0;rotate:calc($i * .8deg)}31.5%{translate:calc($i * -.5px) 0;rotate:calc($i * -.5deg)}43.5%{translate:calc($i * .3px) 0;rotate:calc($i * .3deg)}"},ve="animation-delay: calc(var(--mc-fx-delay, 0s) - var(--mc-anim-k) * var(--mc-fx-dur, 1s));",be={ping:"0%{scale:.15;opacity:1}80%,100%{scale:1;opacity:0}","ripple-rings":"0%{scale:.1;opacity:1}100%{scale:1;opacity:0}","radar-sweep":"from{rotate:0deg}to{rotate:360deg}","conic-border-spin":"from{rotate:0deg}to{rotate:360deg}","breathing-border":"0%,100%{box-shadow:inset 0 0 0 calc($i * 1px) color-mix(in srgb,$c 30%,transparent),0 0 0 0 transparent}50%{box-shadow:inset 0 0 0 calc($i * 1px) $c,0 0 calc($i * 4px) color-mix(in srgb,$c 35%,transparent)}","breathing-border-icon":"0%,100%{filter:drop-shadow(0 0 calc($i * .5px) color-mix(in srgb,$c 40%,transparent))}50%{filter:drop-shadow(0 0 calc($i * 1.5px) $c)}",fireflies:"0%{translate:0 0;opacity:0}20%{opacity:1}40%{translate:10px -8px}60%{opacity:.3}75%{translate:-6px -14px;opacity:1}100%{translate:4px -22px;opacity:0}",confetti:"0%{translate:0 0;rotate:0deg;opacity:1}25%{translate:8px 25cqh;rotate:160deg}50%{translate:-6px 50cqh;rotate:300deg}75%{translate:6px 75cqh;rotate:420deg}100%{translate:0 calc(100cqh + 14px);rotate:540deg;opacity:1}","falling-leaves":"0%{translate:0 0;rotate:0deg;opacity:0}10%{opacity:1}30%{translate:14px 30cqh;rotate:60deg}55%{translate:-8px 55cqh;rotate:-20deg}80%{translate:12px 80cqh;rotate:80deg}100%{translate:0 calc(100cqh + 16px);rotate:20deg;opacity:.8}",lightning:"0%,89%,100%{opacity:0}90%{opacity:calc($i / 100)}91.5%{opacity:.15}93%{opacity:calc($i / 100)}96%{opacity:0}","ocean-waves":"from{translate:0 0}to{translate:-40px 0}","sun-rays":"from{rotate:0deg}to{rotate:360deg}","heat-shimmer":"0%,100%{translate:0 0;filter:blur(0)}25%{translate:calc($i * .5px) calc($i * -.5px);filter:blur(calc($i * .3px))}50%{translate:calc($i * -.5px) 0;filter:blur(0)}75%{translate:0 calc($i * .5px);filter:blur(calc($i * .2px))}","wind-lines":"0%{translate:0 0;opacity:0}15%{opacity:1}85%{opacity:.8}100%{translate:calc(100cqw + 100%) 0;opacity:0}",drip:"0%{translate:0 0;scale:.4 .2;opacity:0}15%{scale:1 1;opacity:1}35%{translate:0 2px;scale:.9 1.25}45%{translate:0 4px;scale:1 1}100%{translate:0 calc(100cqh + 12px);scale:.9 1.3;opacity:.7}","equalizer-bars":"0%{scale:1 .15}30%{scale:1 .8}60%{scale:1 .35}100%{scale:1 1}","charging-stripes":"from{translate:0 0}to{translate:28.2843px 0}","orbit-dots":"from{rotate:0deg}to{rotate:360deg}","typing-dots":"0%,60%,100%{translate:0 0;opacity:.35}30%{translate:0 calc($i * -1px);opacity:1}"},ye={ping:"left:50%;top:50%;width:calc($i * 1cqmin);aspect-ratio:1;translate:-50% -50%;border:2px solid $c;border-radius:50%;box-sizing:border-box;","ripple-rings":` left:50%;top:50%;width:110cqmin;aspect-ratio:1;translate:-50% -50%;border:1.5px solid $c;border-radius:50%;box-sizing:border-box;${ve}`,"radar-sweep":"left:50%;top:50%;width:150cqmax;aspect-ratio:1;translate:-50% -50%;border-radius:50%;opacity:1;background:conic-gradient(from 0deg,transparent 0deg calc(360deg - $i * 1deg),$c 360deg);","conic-border-spin":"left:50%;top:50%;width:150cqmax;aspect-ratio:1;translate:-50% -50%;opacity:1;background:conic-gradient(from 0deg,transparent 0% 55%,$c 80%,transparent 100%);",fireflies:"top:calc(12% + var(--mc-anim-phase) * 72%);width:4px;height:4px;margin:-2px 0 0 -2px;border-radius:50%;background:$c;box-shadow:0 0 6px 2px $c;",confetti:"top:-10px;width:6px;height:10px;border-radius:1px;background:$c;","confetti|:nth-child(3n + 2)":"background:color-mix(in srgb,$c 40%,#ffeb3b);","confetti|:nth-child(3n)":"width:8px;height:6px;background:color-mix(in srgb,$c 40%,#e91e63);","falling-leaves":"top:-14px;width:10px;height:10px;border-radius:0 80% 0 80%;background:$c;","falling-leaves|:nth-child(even)":"background:color-mix(in srgb,$c 75%,#7cb342);",lightning:"left:50%;top:0;width:32cqmin;height:100%;translate:-50% 0;background:color-mix(in srgb,$c 40%,#fff);clip-path:polygon(58% 0,22% 56%,46% 56%,32% 100%,80% 40%,56% 40%,72% 0);","ocean-waves":"left:0;bottom:0;width:calc(100% + 40px);height:calc($i * 1%);opacity:1;background:radial-gradient(22px 12px at 20px 0,transparent 98%,color-mix(in srgb,$c 45%,transparent) 100%) 0 0 / 40px 100% repeat-x;","ocean-waves|:nth-child(2)":"height:calc($i * .75%);animation-direction:reverse;animation-duration:calc(var(--mc-fx-dur) * 1.5);background:radial-gradient(22px 10px at 20px 0,transparent 98%,color-mix(in srgb,$c 70%,transparent) 100%) 0 0 / 40px 100% repeat-x;","ocean-waves|:nth-child(3)":"height:calc($i * .5%);animation-duration:calc(var(--mc-fx-dur) * .7);background:radial-gradient(22px 8px at 20px 0,transparent 98%,$c 100%) 0 0 / 40px 100% repeat-x;","sun-rays":"left:50%;top:50%;width:170cqmax;aspect-ratio:1;translate:-50% -50%;opacity:1;background:repeating-conic-gradient(from 0deg,$c 0deg calc($i * 1deg),transparent calc($i * 1deg) calc($i * 3deg));mask:radial-gradient(closest-side,#000 15%,transparent 70%);","wind-lines":"left:-35%;top:calc(10% + var(--mc-anim-phase) * 80%);width:35%;height:2px;border-radius:2px;background:linear-gradient(90deg,transparent,$c);",drip:"top:-4px;width:6px;height:9px;margin-left:-3px;transform-origin:50% 0;border-radius:50% 50% 50% 50% / 40% 40% 60% 60%;background:$c;","equalizer-bars":"left:calc(10% + var(--mc-anim-k) * 80%);bottom:0;width:max(3px,5%);height:70%;opacity:1;border-radius:2px 2px 0 0;transform-origin:50% 100%;background:$c;","charging-stripes":"top:0;bottom:0;left:-28.2843px;width:calc(100% + 28.2843px);opacity:1;background:repeating-linear-gradient(-45deg,color-mix(in srgb,$c calc($i * 1%),transparent) 0 10px,transparent 10px 20px);","orbit-dots":` left:50%;top:calc(50% - 38cqmin);width:6px;height:6px;margin:-3px 0 0 -3px;border-radius:50%;opacity:1;background:$c;transform-origin:3px calc(3px + 38cqmin);${ve}`,"typing-dots":"left:calc(50% - 12px + var(--mc-anim-k) * 36px);top:50%;width:6px;height:6px;margin:-3px 0 0 -3px;border-radius:50%;background:$c;animation-delay:calc(var(--mc-fx-delay,0s) - (1 - var(--mc-anim-k)) * var(--mc-fx-dur,1s) * .5);"},xe={pendulum:"from{rotate:calc($i * -1deg)}to{rotate:calc($i * 1deg)}",orbit:"0%,100%{translate:calc($i * 1px) 0}12.5%{translate:calc($i * .707px) calc($i * .707px)}25%{translate:0 calc($i * 1px)}37.5%{translate:calc($i * -.707px) calc($i * .707px)}50%{translate:calc($i * -1px) 0}62.5%{translate:calc($i * -.707px) calc($i * -.707px)}75%{translate:0 calc($i * -1px)}87.5%{translate:calc($i * .707px) calc($i * -.707px)}","coin-spin":"from{rotate:y 0deg}to{rotate:y calc($i * 1deg)}","rotate-3d":"from{rotate:1 1 0 calc($i * -1deg)}to{rotate:1 1 0 calc($i * 1deg)}","squash-stretch":"0%,100%{scale:1 1;translate:0 0}15%{scale:calc(1 + $i / 100) calc(1 - $i / 100);translate:0 0}45%{scale:calc(1 - $i / 200) calc(1 + $i / 150);translate:0 calc($i * -.8px)}70%{scale:1 1;translate:0 calc($i * -.4px)}85%{scale:calc(1 + $i / 160) calc(1 - $i / 160);translate:0 0}",wiggle:"0%,40%,100%{rotate:0deg}5%{rotate:calc($i * 1deg)}10%{rotate:calc($i * -1deg)}15%{rotate:calc($i * .8deg)}20%{rotate:calc($i * -.6deg)}25%{rotate:calc($i * .4deg)}30%{rotate:calc($i * -.2deg)}","shadow-lift":"0%,100%{translate:0 0;box-shadow:0 1px 2px color-mix(in srgb,$c 20%,rgba(0,0,0,.2))}50%{translate:0 calc($i * -1px);box-shadow:0 calc($i * 2.5px) calc($i * 4px) color-mix(in srgb,$c 25%,rgba(0,0,0,.3))}","shadow-lift-icon":"0%,100%{translate:0 0;filter:drop-shadow(0 1px 1px color-mix(in srgb,$c 20%,rgba(0,0,0,.2)))}50%{translate:0 calc($i * -1px);filter:drop-shadow(0 calc($i * 1.5px) calc($i * 1px) color-mix(in srgb,$c 25%,rgba(0,0,0,.3)))}","holographic-shimmer":"from{translate:0 0;filter:hue-rotate(0deg)}to{translate:-50% 0;filter:hue-rotate(360deg)}",scanline:"from{translate:0 -100%}to{translate:0 100cqh}",twinkle:"0%,100%{scale:0;rotate:0deg;opacity:0}50%{scale:1;rotate:90deg;opacity:1}",spotlight:"0%,100%{translate:-30cqw -10cqh}33%{translate:25cqw 15cqh}66%{translate:10cqw -20cqh}","neon-border":"0%,100%{box-shadow:0 0 0 1px $c,0 0 calc($i * .6px) color-mix(in srgb,$c 70%,transparent),inset 0 0 calc($i * .5px) color-mix(in srgb,$c 45%,transparent)}50%{box-shadow:0 0 0 1.5px $c,0 0 calc($i * 1.4px) $c,inset 0 0 calc($i * .9px) color-mix(in srgb,$c 60%,transparent)}","neon-border-icon":"0%,100%{filter:drop-shadow(0 0 1px $c) drop-shadow(0 0 calc($i * .3px) color-mix(in srgb,$c 70%,transparent))}50%{filter:drop-shadow(0 0 1px $c) drop-shadow(0 0 calc($i * .7px) $c)}","color-cycle-bg":"from{filter:hue-rotate(0deg)}to{filter:hue-rotate(360deg)}",aurora:"0%,100%{translate:-12% 0;rotate:-8deg;scale:1 1;opacity:calc($i / 100)}50%{translate:12% 6%;rotate:6deg;scale:1.15 .85;opacity:calc($i / 160)}","lava-lamp":"0%{translate:0 0;scale:1 1;opacity:.9}50%{translate:6px -45cqh;scale:1.25 .85}100%{translate:-4px -85cqh;scale:.85 1.15;opacity:.9}","plasma-gradient":"0%{rotate:0deg;scale:1}50%{rotate:180deg;scale:1.25}100%{rotate:360deg;scale:1}","gradient-flow":"from{translate:0 0}to{translate:-66.667% 0}",starfield:"0%,100%{opacity:.15;scale:.6}50%{opacity:1;scale:1}","meteor-shower":"0%{translate:0 0;opacity:0}6%{opacity:1}40%,100%{translate:-60cqw 60cqh;opacity:0}",bokeh:"0%{translate:0 0;scale:.8;opacity:.15}50%{opacity:.55}100%{translate:10px -16px;scale:1.15;opacity:.25}","matrix-rain":"0%{translate:0 -100%;opacity:0}10%{opacity:1}100%{translate:0 calc(100cqh + 100%);opacity:.6}",smoke:"0%{translate:0 0;scale:.4;opacity:0}20%{opacity:.5}100%{translate:18px -90cqh;scale:2.6;opacity:0}","clouds-drift":"from{translate:0 0;opacity:.9}to{translate:calc(100cqw + 100%) 0;opacity:.9}","water-ripple":"0%{scale:.05;opacity:.9}100%{scale:1;opacity:0}",fireworks:"0%{transform:rotate(calc(var(--mc-anim-k) * 360deg)) translateY(0) scale(1);opacity:1}70%{opacity:1}100%{transform:rotate(calc(var(--mc-anim-k) * 360deg)) translateY(-38cqmin) scale(.3);opacity:0}","tap-ripple":"0%{scale:0;opacity:calc($i / 100)}100%{scale:1;opacity:0}",press:"0%,100%{scale:1}40%{scale:calc(1 - $i / 100)}"};function _e(e,t){const i=fe[e]??be[e]??xe[e];if(void 0===i)return;const n=ge(e.replace(/-icon$/,"")),s=t??n?.defaults.intensity??1;return i.replace(/\$i/g,String(s)).replace(/\$c/g,"var(--mc-anim-c)")}function we(e){const t=[];for(const i of e.matchAll(/([^{}]+)\{([^{}]*)\}/g)){const e=i[1].split(",").map(e=>e.trim().toLowerCase()).map(e=>"from"===e?0:"to"===e?100:parseFloat(e)).filter(e=>Number.isFinite(e)),n=[];for(const e of i[2].split(";")){const t=e.indexOf(":");if(t<0)continue;const i=e.slice(0,t).trim().toLowerCase(),s=e.slice(t+1).trim().replace(/\s+/g," ");i&&s&&n.push([i,s])}e.length&&n.length&&t.push({offsets:e,decls:n})}return t}const ke=e=>"animation-timing-function"===e?"easing":e.replace(/-([a-z])/g,(e,t)=>t.toUpperCase());var $e=i(1771);const Me=e=>{if(e&&"object"==typeof e){for(const t of Object.values(e))Me(t);Object.freeze(e)}return e},Se=Me(["rgb","rgba","hsl","hsla","hwb","lab","lch","oklab","oklch","color","color-mix"]),ze=Me(["matrix","translate","scale","rotate","skewx","skewy"]),Ce=Me({maxStyleAttrChars:2e3,maxStyleBlocks:16,maxCssChars:32768,maxRules:512,maxDeclarations:64,maxSelectors:32,maxClassTokens:32,maxBracketDepth:8,maxPaintChars:200,maxValueChars:64,maxDashValues:32,maxColourFunctionDepth:2,maxHrefHops:8,maxStopsPerGradient:256,maxStopClones:1024}),Ae=(...e)=>({kind:"keyword",keywords:Me(e)}),je=Me({fill:{kind:"paint"},stroke:{kind:"paint"},"stop-color":{kind:"stop-paint"},opacity:{kind:"alpha"},"fill-opacity":{kind:"alpha"},"stroke-opacity":{kind:"alpha"},"stop-opacity":{kind:"alpha"},"stroke-width":{kind:"width"},"stroke-miterlimit":{kind:"miterlimit"},"stroke-dashoffset":{kind:"offset"},"stroke-dasharray":{kind:"dasharray"},"stroke-linecap":Ae("butt","round","square"),"stroke-linejoin":Ae("miter","round","bevel","arcs","miter-clip"),"fill-rule":Ae("nonzero","evenodd"),"clip-rule":Ae("nonzero","evenodd"),"paint-order":{kind:"paint-order"},"vector-effect":Ae("none","non-scaling-stroke")}),qe=Me({name:"icon",elements:Me(["svg","g","path","circle","ellipse","rect","line","polyline","polygon","defs","linearGradient","radialGradient","stop","clipPath","mask","title"]),kinds:Me(Object.fromEntries(["d","cx","cy","r","rx","ry","x","y","x1","y1","x2","y2","width","height","points","fill","stroke","stroke-width","stroke-linecap","stroke-linejoin","opacity","fill-opacity","stroke-opacity","transform","viewBox","id","class","offset","stop-color","stop-opacity","gradientUnits","gradientTransform","clip-path","mask","fill-rule","clip-rule"].map(e=>{return[e,(t=e,"transform"===t||"gradientTransform"===t?"transform":"id"===t?"id":"class"===t?"class":"value")];var t}))),colourFunctions:Se,transformFunctions:ze,paintVar:!1,maxValueChars:32768,denyExtra:Me([]),limits:Me({maxNodes:32768,maxDepth:64}),css:Me({properties:je,limits:Ce,maxWrittenBytes:32768})});var Ee=i(3910);const He=e=>String(+e.toFixed(3)),Le=e=>{if(null==e||/%/.test(e))return;const t=parseFloat(e);return Number.isFinite(t)?t:void 0},Ve=[1,0,0,1,0,0],Oe=(e,t)=>[e[0]*t[0]+e[2]*t[1],e[1]*t[0]+e[3]*t[1],e[0]*t[2]+e[2]*t[3],e[1]*t[2]+e[3]*t[3],e[0]*t[4]+e[2]*t[5]+e[4],e[1]*t[4]+e[3]*t[5]+e[5]];function Pe(e){let t=Ve;if(!e)return t;for(const[,i,n]of e.matchAll(/(matrix|translate|scale|rotate|skewX|skewY)\s*\(([^)]*)\)/g)){const e=n.split(/[\s,]+/).filter(Boolean).map(Number);if(e.some(e=>!Number.isFinite(e)))continue;let s=Ve;switch(i){case"matrix":6===e.length&&(s=e);break;case"translate":s=[1,0,0,1,e[0]??0,e[1]??0];break;case"scale":s=[e[0]??1,0,0,e[1]??e[0]??1,0,0];break;case"rotate":{const t=(e[0]??0)*Math.PI/180,[i,n]=[e[1]??0,e[2]??0],r=[Math.cos(t),Math.sin(t),-Math.sin(t),Math.cos(t),0,0];s=Oe(Oe([1,0,0,1,i,n],r),[1,0,0,1,-i,-n]);break}case"skewX":s=[1,0,Math.tan((e[0]??0)*Math.PI/180),1,0,0];break;case"skewY":s=[1,Math.tan((e[0]??0)*Math.PI/180),0,1,0,0]}t=Oe(t,s)}return t}function Re(e,t){const i=t=>Le(e.getAttribute(t));switch(t){case"path":{const t=e.getAttribute("d")?.trim();return t||void 0}case"circle":case"ellipse":{const e=i("cx")??0,n=i("cy")??0,s="circle"===t?i("r"):i("rx")??i("ry"),r="circle"===t?s:i("ry")??i("rx");if(!s||!r||s<=0||r<=0)return;const a=`A${He(s)} ${He(r)} 0 1 0`;return`M${He(e-s)} ${He(n)}${a} ${He(e+s)} ${He(n)}${a} ${He(e-s)} ${He(n)}Z`}case"rect":{const e=i("x")??0,t=i("y")??0,n=i("width"),s=i("height");if(!n||!s||n<=0||s<=0)return;let r=i("rx")??i("ry")??0,a=i("ry")??i("rx")??0;if(r=Math.min(Math.max(r,0),n/2),a=Math.min(Math.max(a,0),s/2),!r||!a)return`M${He(e)} ${He(t)}H${He(e+n)}V${He(t+s)}H${He(e)}Z`;const o=`A${He(r)} ${He(a)} 0 0 1`;return`M${He(e+r)} ${He(t)}H${He(e+n-r)}${o} ${He(e+n)} ${He(t+a)}V${He(t+s-a)}${o} ${He(e+n-r)} ${He(t+s)}H${He(e+r)}${o} ${He(e)} ${He(t+s-a)}V${He(t+a)}${o} ${He(e+r)} ${He(t)}Z`}case"line":return`M${He(i("x1")??0)} ${He(i("y1")??0)}L${He(i("x2")??0)} ${He(i("y2")??0)}`;case"polyline":case"polygon":{const i=function(e){const t=(e??"").trim().split(/[\s,]+/).filter(Boolean).map(Number),i=[];for(let e=0;e+1<t.length;e+=2)Number.isFinite(t[e])&&Number.isFinite(t[e+1])&&i.push([t[e],t[e+1]]);return i}(e.getAttribute("points"));if(i.length<2)return;return`M${i.map(([e,t])=>`${He(e)} ${He(t)}`).join("L")}${"polygon"===t?"Z":""}`}}}const De=32768,Ne="0 0 24 24",Fe=e=>new Map(e.map(e=>[e.toLowerCase(),e])),Te=Fe(qe.elements),Be=Fe(Object.keys(qe.kinds)),Ie=new Set(["path","circle","ellipse","rect","line","polyline","polygon"]),Ze=new Set(["defs","clipPath","mask","linearGradient","radialGradient"]);function We(e,t){const i=(0,Ee.I)(qe,e);return i?(0,Ee.M7)(i,t,qe):void 0}const Ke=new Set(["own","painted","accented","body","dim","fill","liquid","wave","paint","draw","dev","glow-copy","flame-glow","ring","snow","primary","secondary","duo","duo-body","duo-line","old","morph-in"]),Ue=e=>"mc-accent"!==e&&(Ke.has(e)||/^(mc-|dev-|xfade-)/.test(e))?`u-${e}`:e,Ge="The SVG is too complex.",Ye=e=>({markup:"",viewBox:Ne,paths:[],accentPaths:[],strokes:[],error:e}),Je={fill:!0,stroke:!1,width:1},Xe=/^(none|transparent)$/i;function Qe(e,t){const i=t=>{const i=e.getAttribute(t);return null===i?void 0:We(t,i)?.trim()},n=i("fill"),s=i("stroke"),r=Le(i("stroke-width")),a=i("stroke-linecap"),o=i("stroke-linejoin"),l=i("fill-rule");return{evenodd:void 0===l?t.evenodd:"evenodd"===l,fill:void 0===n?t.fill:!Xe.test(n),stroke:void 0===s?t.stroke:!Xe.test(s),width:void 0!==r&&r>=0?r:t.width,cap:a&&/^(butt|round|square)$/.test(a)?a:t.cap,join:o&&/^(miter|round|bevel|arcs|miter-clip)$/.test(o)?o:t.join}}function et(e,t={}){const i="string"==typeof e?e:"";if((0,Ee.dp)(i)>De)return Ye("The SVG is larger than 32 KB.");const n=function(e){if("undefined"==typeof DOMParser)return;const t=new DOMParser;try{const i=t.parseFromString(e,"image/svg+xml"),n=i.documentElement;if(n&&"svg"===n.localName&&!i.getElementsByTagName("parsererror").length)return{root:n,via:"xml",doc:i}}catch{}try{const i=t.parseFromString(e,"text/html"),n=i.getElementsByTagName("*");for(let e=0;e<n.length;e++)if("svg"===n[e].localName.toLowerCase())return{root:n[e],via:"html",doc:i}}catch{}}(i)?.root;if(!n)return Ye("No <svg> element found.");const s=function(e){const t=(e.getAttribute("viewBox")??e.getAttribute("viewbox")??"").trim().split(/[\s,]+/).map(Number);if(4===t.length&&t.every(Number.isFinite)&&t[2]>0&&t[3]>0)return t.map(He).join(" ");const i=Le(e.getAttribute("width")),n=Le(e.getAttribute("height"));return i&&n&&i>0&&n>0?`0 0 ${He(i)} ${He(n)}`:Ne}(n);if(t.css)try{if("ok"!==t.css(n,qe).status)return Ye(Ge)}catch{return Ye(Ge)}const r=[],a=[],o=[],l={},c=(e,t,i=[])=>{let n="",s="";for(const i of[...e.attributes]){const e=Be.get(i.name.toLowerCase());if(!e||i.name.includes(":"))continue;if(t&&("viewBox"===e||"width"===e||"height"===e))continue;const r=We(e,i.value);void 0!==r&&("class"===e?s=r.split(" ").map(Ue).join(" "):n+=` ${e}="${(0,Ee.dc)(r)}"`)}const r=[s,...i].filter(Boolean).join(" ");return r?` class="${(0,Ee.dc)(r)}"${n}`:n};let d=!1;const p=(e,t,i,n,s,h)=>{if(h>64||d)return d=!0,"";const u=Te.get(e.localName.toLowerCase());if(!u||"svg"===u)return"";if("title"===u)return`<title>${(0,Ee.X1)(e.textContent??"")}</title>`;const m=Oe(t,Pe(We("transform",e.getAttribute("transform")??"")??null)),g=n||(e.getAttribute("class")??"").split(/\s+/).includes("mc-accent"),f=i&&!Ze.has(u),v=Qe(e,s),b=[];if(f&&Ie.has(u)){const t=Re(e,u);if(t){const e=function(e,t){if((e=>e.every((e,t)=>Math.abs(e-Ve[t])<1e-9))(t))return e;const i=e=>[t[0]*e[0]+t[2]*e[1]+t[4],t[1]*e[0]+t[3]*e[1]+t[5]];return(0,$e.ER)((0,$e.Mj)(e).map(e=>e.map(e=>e.map(i))))}(t,m);if(v.fill&&"line"!==u){const t=g?a:r;v.evenodd&&(g?l.accent??=[]:l.paths??=[]).push(t.length),t.push(e),b.push("mc-f")}if(v.stroke&&v.width>0){const t=+(v.width*Math.sqrt(Math.abs(m[0]*m[3]-m[1]*m[2]))).toFixed(3);o.push({d:e,width:t,...v.cap?{cap:v.cap}:{},...v.join?{join:v.join}:{},...g?{accent:!0}:{}}),b.push("mc-s")}}}const y=[...e.children].map(e=>p(e,m,f,g,v,h+1)).join("");return`<${u}${c(e,!1,b)}>${y}</${u}>`},h=Pe(We("transform",n.getAttribute("transform")??"")??null),u=Qe(n,Je),m=[...n.children].map(e=>p(e,h,!0,!1,u,1)).join("");return d?Ye(Ge):r.length||a.length||o.length?{markup:`<svg viewBox="${s}"${c(n,!0)}>${m}</svg>`,viewBox:s,paths:r,accentPaths:a,strokes:o,...l.paths||l.accent?{evenodd:l}:{}}:Ye("The SVG has no shapes to draw.")}const tt=["x","y","scale","scale_x","scale_y","rotate","skew","opacity","color","background","shadow","blur","radius","filter","draw","stroke"];function it(e){const t=e=>Array.isArray(e)&&e.length>0,i=e.rig;return t(e.tracks)||t(e.clips)||t(e.bindings)||!!i&&"object"==typeof i&&(t(i.parts)||t(i.shapes))}const nt={epoch:0,failedSims:new Set},st="custom:",rt=e=>"string"==typeof e&&e.startsWith(st),at=e=>e.slice(7).trim(),ot=["keyframes","particles","path","sequence"],lt=["fall","rise","drift","burst","orbit","spiral"],ct=60,dt=12,pt=8192,ht=/^[a-z0-9][a-z0-9_-]{0,63}$/,ut={count:12,direction:"fall",speed:1,size:[6,12],colors:[],spin:0,fade:!0,spread:100,gravity:0,layer:"back"};function mt(e,t,i="New animation"){const n={id:t,name:i,kind:e,duration:2,easing:"ease-in-out",iterations:"infinite",target:"element",origin:"center",version:1};switch(e){case"keyframes":return{...n,keyframes:[{at:0,transform:{scale:1}},{at:50,transform:{scale:1.1}},{at:100,transform:{scale:1}}]};case"particles":return{...n,duration:4,easing:"linear",particles:{...ut,size:[...ut.size],colors:[]}};case"path":return{...n,duration:3,easing:"linear",path:{d:"M0 0 C 20 -30 40 30 60 0 S 20 -10 0 0",units:"px",follow_rotation:!1,subject:"element"}};case"sequence":return{...n,steps:[{animation:"pop",delay:0,repeat:1},{animation:"wiggle",delay:.2,repeat:1}],loop:!0,stagger:{children:!1,delay:.15}}}}const gt=["rgb","rgba","hsl","hsla","hwb","lab","lch","oklab","oklch","color","color-mix","var","light-dark","calc","min","max","clamp"],ft={color:new Set(gt),background:new Set([...gt,"linear-gradient","radial-gradient","conic-gradient","repeating-linear-gradient","repeating-radial-gradient","repeating-conic-gradient"]),shadow:new Set(gt),filter:new Set([...gt,"blur","brightness","contrast","drop-shadow","grayscale","hue-rotate","invert","opacity","saturate","sepia"])};function vt(e,t){if("string"!=typeof e)return;const i=e.trim();if(!i||i.length>600||!/^[#\w\s(),.%+*/-]+$/.test(i)||i.includes("/*")||i.includes("*/"))return;let n=0;for(const e of i)if("("===e)n++;else if(")"===e&&--n<0)return;if(0!==n)return;const s=i.match(/\(/g)?.length??0,r=[...i.matchAll(/([a-z-]+)\s*\(/gi)];return r.length!==s||r.some(e=>!ft[t].has(e[1].toLowerCase()))||[...i.matchAll(/var\(\s*([^,)\s]*)/gi)].some(e=>!/^--[\w-]+$/.test(e[1]))?void 0:i}const bt=String.raw`(?:left|right|top|bottom|center|-?(?:\d+(?:\.\d+)?|\.\d+)(?:px|%|em|rem)?)`,yt=new RegExp(String.raw`^${bt}(?:\s+${bt}){0,2}\s*$`),xt=e=>e.length<=64&&yt.test(e),_t=/^[MmLlHhVvCcSsQqTtAaZz0-9eE\s,.+-]+$/,wt=/^[a-z0-9_-]+:[a-z0-9_-]+$/i,kt=["normal","reverse","alternate","alternate-reverse"];function $t(e){if("string"!=typeof e)return!1;const t=e.trim();return ne.some(e=>e.id===t)||/^cubic-bezier\(\s*-?[\d.]+\s*(,\s*-?[\d.]+\s*){3}\)$/.test(t)||/^steps\(\s*\d+\s*(,\s*(start|end|jump-start|jump-end|jump-none|jump-both)\s*)?\)$/.test(t)}const Mt=new Set(pe.filter(e=>!e.channels.includes("fx")).map(e=>e.id)),St=new Set(pe.filter(e=>e.channels.includes("fx")).map(e=>e.id)),zt=e=>"undefined"!=typeof TextEncoder?(new TextEncoder).encode(e).length:e.length;class Ct{constructor(){this.errors=[]}err(e,t){this.errors.push({path:e,message:t})}num(e,t,i,n,s,r,a=!1){const o=e[t];if(null==o||""===o)return void 0===r?void 0:r;const l="string"==typeof o?Number(o):o;return"number"==typeof l&&Number.isFinite(l)?a&&!Number.isInteger(l)?this.err(i,"Must be a whole number."):l<n||l>s?this.err(i,`Must be between ${n} and ${s}.`):l:this.err(i,"Must be a number.")}bool(e,t,i,n){const s=e[t];return null==s?n:"boolean"!=typeof s?this.err(i,"Must be true or false.")??n:s}oneOf(e,t,i,n,s){const r=e[t];return null==r||""===r?s:n.includes(r)?r:this.err(i,`Must be one of: ${n.join(", ")}.`)}css(e,t,i,n){const s=e[t];if(null!=s&&""!==s)return vt(s,n)??this.err(i,"color"===n?"Not a valid colour.":`Not an allowed ${n} value.`)}obj(e,t){return!e||"object"!=typeof e||Array.isArray(e)?this.err(t,"Must be an object."):e}list(e,t,i,n=0){return Array.isArray(e)?e.length<n?this.err(t,1===n?"Needs at least one entry.":`Needs at least ${n} entries.`):e.length>i?this.err(t,`At most ${i} entries.`):e:this.err(t,"Must be a list.")}}function At(e,t,i,n=!1,s=!1){const r=e.obj(t,i);if(!r)return;const a=e.num(r,"at",`${i}.at`,0,100);void 0===r.at&&e.err(`${i}.at`,"Required.");const o={at:a??0};if(void 0!==r.transform){const t=function(e,t,i){const n=e.obj(t,i);if(!n)return;const s={},r=(t,r,a)=>{const o=e.num(n,t,`${i}.${t}`,r,a);void 0!==o&&(s[t]=o)};if(r("x",-1e4,1e4),r("y",-1e4,1e4),r("scale",0,100),r("scale_x",-100,100),r("scale_y",-100,100),r("rotate",-36e3,36e3),r("skew_x",-89,89),r("skew_y",-89,89),void 0!==n.axis){const t=n.axis;!Array.isArray(t)||3!==t.length||t.some(e=>"number"!=typeof e||!Number.isFinite(e))||t.every(e=>0===e)?e.err(`${i}.axis`,"Must be three numbers [x, y, z], not all 0."):s.axis=[t[0],t[1],t[2]]}return s}(e,r.transform,`${i}.transform`);t&&Object.keys(t).length&&(o.transform=t)}const l=e.num(r,"opacity",`${i}.opacity`,0,1);void 0!==l&&(o.opacity=l);const c=e.css(r,"color",`${i}.color`,"color");c&&(o.color=c);const d=e.css(r,"background",`${i}.background`,"background");d&&(o.background=d);const p=e.css(r,"shadow",`${i}.shadow`,"shadow");p&&(o.shadow=p);const h=e.css(r,"filter",`${i}.filter`,"filter");h&&(o.filter=h);const u=e.num(r,"blur",`${i}.blur`,0,200);void 0!==u&&(o.blur=u);const m=e.num(r,"radius",`${i}.radius`,0,1e3);void 0!==m&&(o.radius=m),void 0!==r.easing&&""!==r.easing&&($t(r.easing)?o.easing=r.easing.trim():e.err(`${i}.easing`,"Not a valid easing."));const g=s?new Ct:e,f=g.css(r,"stroke",`${i}.stroke`,"color");if(f&&(o.stroke=f),void 0!==r.draw&&null!==r.draw&&""!==r.draw)if(n){const e=g.num(r,"draw",`${i}.draw`,0,1);void 0!==e&&(o.draw=e)}else g.err(`${i}.draw`,"Draw-on is only for icon parts and shapes.");if(void 0!==r.easings&&null!==r.easings){const e=g.obj(r.easings,`${i}.easings`),t={};for(const[n,s]of Object.entries(e??{}))tt.includes(n)?$t(s)?t[n]=s.trim():g.err(`${i}.easings.${n}`,"Not a valid easing."):g.err(`${i}.easings.${n}`,"Not a timeline lane.");Object.keys(t).length&&(o.easings=t)}return o}function jt(e,t,i,n){const s=e.num(t,"count",`${i}.count`,1,ct,n.count,!0)??n.count;let r=[...n.size];if(void 0!==t.size){const n=t.size;"number"==typeof n&&n>0&&n<=200?r=[n,n]:Array.isArray(n)&&2===n.length&&n.every(e=>"number"==typeof e&&e>0&&e<=200)&&n[0]<=n[1]?r=[n[0],n[1]]:e.err(`${i}.size`,"Must be [min, max] px between 1 and 200, min ≤ max.")}const a=[];if(void 0!==t.colors){const n=e.list(t.colors,`${i}.colors`,dt);n?.forEach((t,n)=>{const s=vt(t,"color");s?a.push(s):e.err(`${i}.colors[${n}]`,"Not a valid colour.")})}const o=void 0!==t.shape&&null!==t.shape?function(e,t,i){const n=e.obj(t,i);if(!n)return;const s=["icon","emoji","svg"].filter(e=>void 0!==n[e]&&""!==n[e]);if(1!==s.length)return e.err(i,"Set one of icon, emoji or svg.");const r=s[0],a=n[r];if("string"!=typeof a)return e.err(`${i}.${r}`,"Must be text.");if("icon"===r)return wt.test(a.trim())?{icon:a.trim()}:e.err(`${i}.icon`,"Must be an icon id like mdi:star.");if("emoji"===r){const t=a.trim();return t&&[...t].length<=8&&!/[<>&"'\\{};]/.test(t)?{emoji:t}:e.err(`${i}.emoji`,"Must be up to 8 characters (an emoji or a symbol).")}if(zt(a)>De)return e.err(`${i}.svg`,"The SVG is larger than 32 KB.");if(!/<svg[\s>]/i.test(a))return e.err(`${i}.svg`,"No <svg> element found.");if("undefined"!=typeof DOMParser){const t=et(a);if(t.error)return e.err(`${i}.svg`,t.error)}return{svg:a}}(e,t.shape,`${i}.shape`):void 0;return{...o?{shape:o}:{},count:s,size:r,colors:a}}const qt=["rig","tracks","clips","bindings"];let Et;function Ht(e,t={}){const i=new Ct,n=i.obj(e,"");if(!n)return{ok:!1,errors:i.errors};let s;try{s=JSON.stringify(n)}catch{return{ok:!1,errors:[{path:"",message:"Not serialisable."}]}}if(zt(s)>65536)return{ok:!1,errors:[{path:"",message:"The animation is larger than 64 KB."}]};const r="string"==typeof n.id?n.id.trim():"";ht.test(r)||i.err("id","Use 1-64 lowercase letters, digits, - or _ (starting with a letter or digit).");const a="string"==typeof n.name?n.name.trim():"";a?a.length>80&&i.err("name","At most 80 characters."):i.err("name","Required."),void 0!==n.version&&1!==n.version&&i.err("version","Unsupported version (expected 1).");const o=i.oneOf(n,"kind","kind",ot);n.kind||i.err("kind","Required.");const l={id:r,name:a,kind:o??"keyframes",duration:i.num(n,"duration","duration",.05,600,1)??1,easing:"ease-in-out",iterations:"infinite",target:i.oneOf(n,"target","target",["element","icon"],"element")??"element",origin:"center",version:1};if(void 0!==n.easing&&""!==n.easing&&($t(n.easing)?l.easing=n.easing.trim():i.err("easing","Not a valid easing.")),void 0!==n.iterations&&"infinite"!==n.iterations){const e=i.num(n,"iterations","iterations",.01,1e3);void 0!==e&&(l.iterations=e)}const c=i.oneOf(n,"direction","direction",kt);switch(c&&"normal"!==c&&(l.direction=c),Object.prototype.hasOwnProperty.call(n,"mirror")&&("mirror"===n.mirror||"keep"===n.mirror?l.mirror=n.mirror:i.err("mirror","Use mirror or keep.")),void 0!==n.origin&&""!==n.origin&&("string"==typeof n.origin&&xt(n.origin.trim())?l.origin=n.origin.trim():i.err("origin",'Use keywords, lengths or percentages, e.g. "50% 100%".')),o){case"keyframes":{const e=Array.isArray(n.tracks)&&n.tracks.length>0,s=void 0===n.keyframes?e?[]:i.err("keyframes","Required."):i.list(n.keyframes,"keyframes",40,e?0:1),r="lenient"===t.v2,a=(s??[]).map((e,t)=>At(i,e,`keyframes[${t}]`,!1,r)).filter(e=>!!e);l.keyframes=a.sort((e,t)=>e.at-t.at);break}case"particles":void 0===n.particles?i.err("particles","Required."):l.particles=function(e,t,i,n){const s=e.obj(t,i);if(!s)return;const r=ut,a={...jt(e,s,i,r),direction:e.oneOf(s,"direction",`${i}.direction`,lt,r.direction)??r.direction,speed:e.num(s,"speed",`${i}.speed`,.1,10,r.speed)??r.speed,spin:e.num(s,"spin",`${i}.spin`,-3600,3600,r.spin)??r.spin,fade:e.bool(s,"fade",`${i}.fade`,r.fade),spread:e.num(s,"spread",`${i}.spread`,0,100,r.spread)??r.spread,gravity:e.num(s,"gravity",`${i}.gravity`,-1,1,r.gravity)??r.gravity,layer:e.oneOf(s,"layer",`${i}.layer`,["back","front"],r.layer)??r.layer};if(void 0!==s.preset&&""!==s.preset){"string"==typeof s.preset&&St.has(s.preset)?a.preset=s.preset:e.err(`${i}.preset`,"Must be a particle, ring or scene preset.");const t=e.num(s,"intensity",`${i}.intensity`,-1e5,1e5);void 0!==t&&(a.intensity=t)}if(void 0!==s.sim&&null!==s.sim&&(n?new Ct:e).obj(s.sim,`${i}.sim`))if(nt.simValidator){const t=nt.simValidator(s.sim,n?"lenient":"strict",{count:a.count,layer:a.layer});n||e.errors.push(...t.errors),!t.sim||!n&&t.errors.length||(a.sim=t.sim)}else a.sim=s.sim;return a}(i,n.particles,"particles","lenient"===t.v2);break;case"path":void 0===n.path?i.err("path","Required."):l.path=function(e,t,i){const n=e.obj(t,i);if(!n)return;let s="";"string"==typeof n.d&&n.d.trim()?n.d.length>pt?e.err(`${i}.d`,"At most 8192 characters."):_t.test(n.d)&&/^\s*[Mm]/.test(n.d)?(0,$e.Mj)(n.d).some(e=>e.length)?s=n.d.trim().replace(/\s+/g," "):e.err(`${i}.d`,"The path draws nothing."):e.err(`${i}.d`,"Not valid path data (it must start with M)."):e.err(`${i}.d`,"Required.");const r={d:s,units:e.oneOf(n,"units",`${i}.units`,["percent","px"],"px")??"px",follow_rotation:e.bool(n,"follow_rotation",`${i}.follow_rotation`,!1),subject:e.oneOf(n,"subject",`${i}.subject`,["element","icon","particles"],"element")??"element"};if(void 0!==n.particles&&null!==n.particles){const t=e.obj(n.particles,`${i}.particles`);t&&(r.particles=jt(e,t,`${i}.particles`,{...ut,count:3}))}return r}(i,n.path,"path");break;case"sequence":{l.steps=void 0===n.steps?(i.err("steps","Required."),[]):function(e,t,i,n){const s=e.list(t,i,20,1);if(!s)return[];const r=[];return s.forEach((t,s)=>{const a=`${i}[${s}]`,o=e.obj(t,a);if(!o)return;const l="string"==typeof o.animation?o.animation.trim():"";l?rt(l)?at(l)===n?e.err(`${a}.animation`,"A sequence cannot play itself."):ht.test(at(l))||e.err(`${a}.animation`,"Not a valid animation id."):Mt.has(l)||e.err(`${a}.animation`,"Must be a motion preset or a custom keyframes / path animation."):e.err(`${a}.animation`,"Required.");const c={animation:l,delay:e.num(o,"delay",`${a}.delay`,0,600,0)??0,repeat:e.num(o,"repeat",`${a}.repeat`,1,100,1,!0)??1},d=e.num(o,"duration",`${a}.duration`,.05,600);void 0!==d&&(c.duration=d),r.push(c)}),r}(i,n.steps,"steps",r),l.loop=i.bool(n,"loop","loop",!0);const e=void 0===n.stagger||null===n.stagger?{}:i.obj(n.stagger,"stagger");e&&(l.stagger={children:i.bool(e,"children","stagger.children",!1),delay:i.num(e,"delay","stagger.delay",0,10,.1)??.1});break}}if(o)if(Et)"lenient"===t.v2?Object.assign(l,Et(n,new Ct)):Object.assign(l,Et(n,i));else for(const e of qt)void 0===n[e]||null===n[e]||"clips"!==e&&"keyframes"!==o||(l[e]=n[e]);return i.errors.length?{ok:!1,errors:i.errors}:{ok:!0,doc:l,errors:[]}}function Lt(e){const t=e.replace(/calc\(/g,"(").replace(/(\d)(px|deg|%)/g,"$1");let i=0;const n=()=>{for(;" "===t[i];)i++;return t[i]},s=()=>{const r=n();if("("===r){i++;const t=a();if(")"!==n())throw new Error(`Expected ) in "${e}"`);return i++,t}if("-"===r||"+"===r){i++;const e=s();return"-"===r?-e:e}const o=/^\d*\.?\d+(?:e[-+]?\d+)?/i.exec(t.slice(i));if(!o)throw new Error(`Not a number in "${e}"`);return i+=o[0].length,Number(o[0])},r=()=>{let e=s();for(let t=n();"*"===t||"/"===t;t=n()){i++;const n=s();e="*"===t?e*n:e/n}return e},a=()=>{let e=r();for(let t=n();"+"===t||"-"===t;t=n()){i++;const n=r();e="+"===t?e+n:e-n}return e},o=a();if(void 0!==n())throw new Error(`Unexpected "${t.slice(i)}" in "${e}"`);return+o.toFixed(4)}function Vt(e){const t=[];let i=0,n="";for(const s of e.trim())"("===s&&i++,")"===s&&i--," "===s&&0===i?(n&&t.push(n),n=""):n+=s;return n&&t.push(n),t}const Ot={x:[1,0,0],y:[0,1,0]};function Pt(e,t,i,n){const s=e.transform??={};switch(t){case"translate":{const[e,t="0"]=Vt(i);return s.x=Lt(e),void(s.y=Lt(t))}case"scale":{const e=Vt(i).map(Lt);return void(1===e.length?s.scale=e[0]:(s.scale_x=e[0],s.scale_y=e[1]))}case"rotate":{const e=Vt(i);return s.rotate=Lt(e[e.length-1]),void(2===e.length&&Ot[e[0]]?s.axis=Ot[e[0]]:4===e.length&&(s.axis=[Lt(e[0]),Lt(e[1]),Lt(e[2])]))}case"opacity":return void(e.opacity=Lt(i));case"filter":return void(e.filter=i);case"box-shadow":return void(e.shadow=i)}throw new Error(`Preset ${n}: cannot convert "${t}"`)}function Rt(e){const t=_e(e);if(void 0===t)throw new Error(`Preset ${e} has no keyframes`);const i=new Map;for(const n of we(t))for(const t of n.offsets){const s=i.get(t)??{at:t};for(const[t,i]of n.decls)Pt(s,t,i,e);i.set(t,s)}return[...i.values()].map(e=>e.transform&&!Object.keys(e.transform).length?(({transform:e,...t})=>t)(e):e).sort((e,t)=>e.at-t.at)}const Dt=e=>`${e.toLowerCase().replace(/[^a-z0-9_-]/g,"-")}-custom`.slice(0,64);function Nt(e,t=Dt(e),i){const n=ge(e);if(!n)return;const s=n.defaults,r={id:t,name:i??(0,te.t)(n.name),kind:"keyframes",duration:parseFloat(s.duration),easing:s.easing,iterations:s.iterations,..."normal"!==s.direction?{direction:s.direction}:{},target:"element",origin:n.origin??"center",version:1};return n.channels.includes("fx")?{...r,kind:"particles",particles:{...ut,size:[...ut.size],colors:[],..."count"===n.particles?{count:Math.max(1,Math.round(s.intensity))}:{},layer:n.front?"front":"back",preset:n.id,intensity:s.intensity}}:{...r,keyframes:Rt(n.id)}}var Ft=i(3682),Tt=Symbol("NOT_RESOLVED");function Bt(e,t){return{tagName:e,nodeKind:"scalar",implicit:t.implicit??!1,matchByTagPrefix:t.matchByTagPrefix??!1,implicitFirstChars:t.implicitFirstChars??null,resolve:t.resolve,identify:t.identify,represent:t.represent??(e=>String(e)),representTagName:t.representTagName??(()=>e)}}function It(e,t){const i=void 0===t.finalize;return{tagName:e,nodeKind:"sequence",implicit:!1,matchByTagPrefix:t.matchByTagPrefix??!1,create:t.create,addItem:t.addItem,finalize:t.finalize??(e=>e),carrierIsResult:i,identify:t.identify,represent:t.represent??(e=>e),representTagName:t.representTagName??(()=>e)}}function Zt(e,t){const i=void 0===t.finalize;return{tagName:e,nodeKind:"mapping",implicit:!1,matchByTagPrefix:t.matchByTagPrefix??!1,create:t.create,addPair:t.addPair,has:t.has,keys:t.keys,get:t.get,finalize:t.finalize??(e=>e),carrierIsResult:i,identify:t.identify,represent:t.represent??(e=>e),representTagName:t.representTagName??(()=>e)}}var Wt=Bt("tag:yaml.org,2002:str",{resolve:e=>e,identify:e=>"string"==typeof e}),Kt=["","~","null","Null","NULL"],Ut=Bt("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["","~","n","N"],resolve:e=>-1!==Kt.indexOf(e)?null:Tt,identify:e=>null===e,represent:()=>"null"}),Gt=Bt("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["n"],resolve:(e,t)=>"null"===e||t&&""===e?null:Tt,identify:e=>null===e,represent:()=>"null"}),Yt=["","~","null","Null","NULL"],Jt=Bt("tag:yaml.org,2002:null",{implicit:!0,implicitFirstChars:["","~","n","N"],resolve:e=>-1!==Yt.indexOf(e)?null:Tt,identify:e=>null===e,represent:()=>"null"}),Xt=["true","True","TRUE"],Qt=["false","False","FALSE"],ei=Bt("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["t","T","f","F"],resolve:e=>-1!==Xt.indexOf(e)||-1===Qt.indexOf(e)&&Tt,identify:e=>"[object Boolean]"===Object.prototype.toString.call(e),represent:e=>e?"true":"false"}),ti=["true"],ii=["false"],ni=Bt("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["t","f"],resolve:e=>-1!==ti.indexOf(e)||-1===ii.indexOf(e)&&Tt,identify:e=>"[object Boolean]"===Object.prototype.toString.call(e),represent:e=>e?"true":"false"}),si=["true","True","TRUE","y","Y","yes","Yes","YES","on","On","ON"],ri=["false","False","FALSE","n","N","no","No","NO","off","Off","OFF"],ai=Bt("tag:yaml.org,2002:bool",{implicit:!0,implicitFirstChars:["y","Y","n","N","t","T","f","F","o","O"],resolve:e=>-1!==si.indexOf(e)||-1===ri.indexOf(e)&&Tt,identify:e=>"[object Boolean]"===Object.prototype.toString.call(e),represent:e=>e?"true":"false"}),oi=new RegExp("^(?:0o[0-7]+|0x[0-9a-fA-F]+|[-+]?[0-9]+)$"),li=new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$"),ci=Bt("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-","+",..."0123456789"],resolve:function(e,t){if(t){if(!li.test(e))return Tt}else if(!oi.test(e))return Tt;const i=function(e){let t=e,i=1;return"-"!==t[0]&&"+"!==t[0]||("-"===t[0]&&(i=-1),t=t.slice(1)),t.startsWith("0b")?i*parseInt(t.slice(2),2):t.startsWith("0o")?i*parseInt(t.slice(2),8):t.startsWith("0x")?i*parseInt(t.slice(2),16):i*parseInt(t,10)}(e);return Number.isFinite(i)?i:Tt},identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),di=new RegExp("^-?(?:0|[1-9][0-9]*)$"),pi=new RegExp("^(?:[-+]?0b[0-1]+|[-+]?0o[0-7]+|[-+]?0x[0-9a-fA-F]+|[-+]?[0-9]+)$"),hi=Bt("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-",..."0123456789"],resolve:function(e,t){if(t){if(!pi.test(e))return Tt}else if(!di.test(e))return Tt;const i=function(e){let t=e,i=1;return"-"!==t[0]&&"+"!==t[0]||("-"===t[0]&&(i=-1),t=t.slice(1)),t.startsWith("0b")?i*parseInt(t.slice(2),2):t.startsWith("0o")?i*parseInt(t.slice(2),8):t.startsWith("0x")?i*parseInt(t.slice(2),16):i*parseInt(t,10)}(e);return Number.isFinite(i)?i:Tt},identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),ui=new RegExp("^(?:[-+]?0b[0-1_]+|[-+]?0[0-7_]+|[-+]?0x[0-9a-fA-F_]+|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+|[-+]?(?:0|[1-9][0-9_]*))$"),mi=Bt("tag:yaml.org,2002:int",{implicit:!0,implicitFirstChars:["-","+",..."0123456789"],resolve:function(e){if(!ui.test(e))return Tt;const t=function(e){let t=e.replace(/_/g,""),i=1;if("-"!==t[0]&&"+"!==t[0]||("-"===t[0]&&(i=-1),t=t.slice(1)),t.startsWith("0b"))return i*parseInt(t.slice(2),2);if(t.startsWith("0x"))return i*parseInt(t.slice(2),16);if(t.includes(":")){let e=0;for(const i of t.split(":"))e=60*e+Number(i);return i*e}return"0"!==t&&"0"===t[0]?i*parseInt(t,8):i*parseInt(t,10)}(e);return Number.isFinite(t)?t:Tt},identify:e=>Number.isInteger(e)&&!Object.is(e,-0)&&e.toString(10).indexOf("e")<0,represent:e=>e.toString(10)}),gi=new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),fi=new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),vi=Bt("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-","+",".",..."0123456789"],resolve:function(e){if(!gi.test(e))return Tt;let t=e.toLowerCase();const i="-"===t[0]?-1:1;if("+-".includes(t[0])&&(t=t.slice(1)),".inf"===t)return 1===i?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(".nan"===t)return NaN;const n=i*parseFloat(t);return Number.isFinite(n)||fi.test(e)?n:Tt},identify:e=>"number"==typeof e&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:function(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";const t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}}),bi=new RegExp("^-?(?:0|[1-9][0-9]*)(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?$"),yi=new RegExp("^(?:[-+]?[0-9]+(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|[-+]?\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),xi=Bt("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-",..."0123456789"],resolve:function(e,t){if(t){if(!yi.test(e))return Tt;let t=e.toLowerCase();const i="-"===t[0]?-1:1;if("+-".includes(t[0])&&(t=t.slice(1)),".inf"===t)return 1===i?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(".nan"===t)return NaN;const n=i*parseFloat(t);return Number.isFinite(n)?n:Tt}if(!bi.test(e))return Tt;const i=Number(e);return Number.isFinite(i)?i:Tt},identify:e=>"number"==typeof e&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:function(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";const t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}}),_i=new RegExp("^(?:[-+]?(?:(?:[0-9][0-9_]*)?\\.[0-9_]*)(?:[eE][-+][0-9]+)?|[-+]?[0-9][0-9_]*(?::[0-5]?[0-9])+\\.[0-9_]*|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),wi=new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"),ki=Bt("tag:yaml.org,2002:float",{implicit:!0,implicitFirstChars:["-","+",".",..."0123456789"],resolve:function(e){if(!_i.test(e))return Tt;let t=e.toLowerCase().replace(/_/g,"");const i="-"===t[0]?-1:1;if("+-".includes(t[0])&&(t=t.slice(1)),".inf"===t)return 1===i?Number.POSITIVE_INFINITY:Number.NEGATIVE_INFINITY;if(".nan"===t)return NaN;let n=0;if(t.includes(":")){for(const e of t.split(":"))n=60*n+Number(e);n*=i}else n=i*parseFloat(t);return Number.isFinite(n)||wi.test(e)?n:Tt},identify:e=>"number"==typeof e&&(!Number.isInteger(e)||Object.is(e,-0)||e.toString(10).indexOf("e")>=0),represent:function(e){if(isNaN(e))return".nan";if(e===Number.POSITIVE_INFINITY)return".inf";if(e===Number.NEGATIVE_INFINITY)return"-.inf";if(Object.is(e,-0))return"-0.0";const t=e.toString(10);return/^[-+]?[0-9]+e/.test(t)?t.replace("e",".e"):t}}),$i=Bt("tag:yaml.org,2002:merge",{implicit:!0,implicitFirstChars:["<"],resolve:(e,t)=>"<<"===e||t&&""===e?"<<":Tt,identify:()=>!1}),Mi=/^[A-Za-z0-9+/]*={0,2}$/,Si=Bt("tag:yaml.org,2002:binary",{resolve:function(e){const t=e.replace(/\s/g,"");if(t.length%4!=0||!Mi.test(t))return Tt;const i=atob(t),n=new Uint8Array(i.length);for(let e=0;e<i.length;e++)n[e]=i.charCodeAt(e);return n},identify:e=>"[object Uint8Array]"===Object.prototype.toString.call(e),represent:function(e){let t="";for(let i=0;i<e.length;i++)t+=String.fromCharCode(e[i]);return btoa(t)}}),zi=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"),Ci=new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$");function Ai(e,t,i,n=0,s=0,r=0,a=0){const o=new Date(Date.UTC(e,t,i,n,s,r,a));return o.setUTCFullYear(e,t,i),o}var ji=Bt("tag:yaml.org,2002:timestamp",{implicit:!0,implicitFirstChars:[..."0123456789"],resolve:function(e){let t=zi.exec(e);if(null===t&&(t=Ci.exec(e)),null===t)return Tt;const i=+t[1],n=+t[2]-1,s=+t[3];if(!t[4]){const e=Ai(i,n,s);return e.getUTCFullYear()!==i||e.getUTCMonth()!==n||e.getUTCDate()!==s?Tt:e}const r=+t[4],a=+t[5],o=+t[6];let l=0;if(r>23||a>59||o>59)return Tt;if(t[7]){let e=t[7].slice(0,3);for(;e.length<3;)e+="0";l=+e}const c=Ai(i,n,s,r,a,o,l);if(c.getUTCFullYear()!==i||c.getUTCMonth()!==n||c.getUTCDate()!==s)return Tt;if(t[9]){const e=+t[10],i=+(t[11]||0);if(e>23||i>59)return Tt;const n=6e4*(60*e+i);c.setTime(c.getTime()-("-"===t[9]?-n:n))}return c},identify:e=>e instanceof Date,represent:e=>e.toISOString()}),qi=It("tag:yaml.org,2002:seq",{create:()=>[],addItem:(e,t)=>{e.push(t)},identify:Array.isArray});function Ei(e){if(null===e||"object"!=typeof e||Array.isArray(e))return!1;const t=Object.getPrototypeOf(e);return null===t||t===Object.prototype}var Hi=It("tag:yaml.org,2002:omap",{create:()=>({list:[],seen:new Set}),addItem:(e,t)=>{let i;if(t instanceof Map){if(1!==t.size)return"cannot resolve an ordered map item";i=t.keys().next().value}else{if(!Ei(t))return"cannot resolve an ordered map item";{const e=Object.keys(t);if(1!==e.length)return"cannot resolve an ordered map item";i=e[0]}}return e.seen.has(i)?"duplicate key in ordered map":(e.seen.add(i),e.list.push(t),"")},finalize:e=>e.list,identify:()=>!1}),Li=It("tag:yaml.org,2002:pairs",{create:()=>[],addItem:(e,t)=>{if(t instanceof Map)return 1!==t.size?"cannot resolve a pairs item":(e.push(t.entries().next().value),"");if("[object Object]"!==Object.prototype.toString.call(t))return"cannot resolve a pairs item";const i=t,n=Object.keys(i);return 1!==n.length?"cannot resolve a pairs item":(e.push([n[0],i[n[0]]]),"")},identify:()=>!1}),Vi=Zt("tag:yaml.org,2002:map",{create:()=>({}),identify:Ei,represent:e=>{const t=new Map;for(const i of Object.keys(e))t.set(i,e[i]);return t},addPair:(e,t,i)=>{if(null!==t&&"object"==typeof t)return"object-based map does not support complex keys";const n=String(t);return"__proto__"===n?Object.defineProperty(e,n,{value:i,enumerable:!0,configurable:!0,writable:!0}):e[n]=i,""},has:(e,t)=>(null===t||"object"!=typeof t)&&Object.prototype.hasOwnProperty.call(e,String(t)),keys:e=>Object.keys(e),get:(e,t)=>{const i=String(t);return Object.prototype.hasOwnProperty.call(e,i)?e[i]:null}}),Oi=Zt("tag:yaml.org,2002:set",{create:()=>new Set,identify:e=>e instanceof Set,represent:e=>{const t=new Map;for(const i of e)t.set(i,null);return t},addPair:(e,t,i)=>null!==i?"cannot resolve a set item":(e.add(t),""),has:(e,t)=>e.has(t),keys:e=>e.keys(),get:()=>null}),Pi=class e{tags;implicitScalarTags;implicitScalarByFirstChar;implicitScalarAnyFirstChar;defaultScalarTag;defaultSequenceTag;defaultMappingTag;exact;prefix;constructor(e){const t=function(e){const t=[];for(const i of e){let e=t.length;for(let n=0;n<t.length;n++){const s=t[n];if(s.nodeKind===i.nodeKind&&s.tagName===i.tagName&&s.matchByTagPrefix===i.matchByTagPrefix){e=n;break}}t[e]=i}return t}(e),i=[],n={scalar:Object.create(null),sequence:Object.create(null),mapping:Object.create(null)},s={scalar:[],sequence:[],mapping:[]};for(const e of t){if("scalar"===e.nodeKind&&e.implicit){if(e.matchByTagPrefix)throw new Error("Implicit scalar tags cannot match by tag prefix");i.push(e)}switch(e.nodeKind){case"scalar":e.matchByTagPrefix?s.scalar.push(e):n.scalar[e.tagName]=e;break;case"sequence":e.matchByTagPrefix?s.sequence.push(e):n.sequence[e.tagName]=e;break;case"mapping":e.matchByTagPrefix?s.mapping.push(e):n.mapping[e.tagName]=e}}const r=i.filter(e=>null===e.implicitFirstChars),a=new Set;for(const e of i)if(null!==e.implicitFirstChars)for(const t of e.implicitFirstChars)a.add(t);const o=new Map;for(const e of a)o.set(e,i.filter(t=>null===t.implicitFirstChars||-1!==t.implicitFirstChars.indexOf(e)));const l=n.scalar["tag:yaml.org,2002:str"];if(!l)throw new Error("schema does not define the default scalar tag (tag:yaml.org,2002:str)");this.tags=t,this.implicitScalarTags=i,this.implicitScalarByFirstChar=o,this.implicitScalarAnyFirstChar=r,this.defaultScalarTag=l,this.defaultSequenceTag=n.sequence["tag:yaml.org,2002:seq"],this.defaultMappingTag=n.mapping["tag:yaml.org,2002:map"],this.exact=n,this.prefix=s}lookupScalarTag(e){const t=this.exact.scalar[e];if(t)return t;for(const t of this.prefix.scalar)if(e.startsWith(t.tagName))return t}lookupSequenceTag(e){const t=this.exact.sequence[e];if(t)return t;for(const t of this.prefix.sequence)if(e.startsWith(t.tagName))return t}lookupMappingTag(e){const t=this.exact.mapping[e];if(t)return t;for(const t of this.prefix.mapping)if(e.startsWith(t.tagName))return t}resolveImplicitScalarTag(e){const t=this.implicitScalarByFirstChar.get(e.charAt(0))??this.implicitScalarAnyFirstChar;for(const i of t){const t=i.resolve(e,!1,i.tagName);if(t!==Tt)return{value:t,tag:i}}const i=this.defaultScalarTag;return{value:i.resolve(e,!1,i.tagName),tag:i}}withTags(...t){let i=[];for(const e of t)i=i.concat(e);return new e([...this.tags,...i])}},Ri=new Pi([Wt,qi,Vi]),Di=(new Pi([...Ri.tags,Gt,ni,hi,xi]),new Pi([...Ri.tags,Ut,ei,ci,vi]));function Ni(e){if(Array.isArray(e)){const t=Array.prototype.slice.call(e);for(let e=0;e<t.length;e++){if(Array.isArray(t[e]))return null;"object"==typeof t[e]&&"[object Object]"===Object.prototype.toString.call(t[e])&&(t[e]="[object Object]")}return String(t)}return"object"==typeof e&&"[object Object]"===Object.prototype.toString.call(e)?"[object Object]":String(e)}function Fi(e){switch(e){case 48:return"\0";case 97:return"";case 98:return"\b";case 116:case 9:return"\t";case 110:return"\n";case 118:return"\v";case 102:return"\f";case 114:return"\r";case 101:return"";case 32:return" ";case 34:return'"';case 47:return"/";case 92:return"\\";case 78:return"";case 95:return" ";case 76:return"\u2028";case 80:return"\u2029";default:return""}}new Pi([...Ri.tags,Jt,ai,mi,ki,ji,$i,Si,Hi,Li,Oi]).withTags({...mi,resolve:(e,t,i)=>{const n=mi.resolve(e,t,i);return n===Tt?ci.resolve(e,t,i):n}},{...ki,resolve:(e,t,i)=>{const n=ki.resolve(e,t,i);return n===Tt?vi.resolve(e,t,i):n}}),Zt("tag:yaml.org,2002:map",{create:()=>new Map,addPair:(e,t,i)=>(e.set(t,i),""),has:(e,t)=>e.has(t),keys:e=>e.keys(),get:(e,t)=>e.get(t),identify:e=>e instanceof Map||Ei(e),represent:e=>{if(e instanceof Map)return e;const t=new Map,i=e;for(const e of Object.keys(i))t.set(e,i[e]);return t}}),Zt("tag:yaml.org,2002:map",{create:()=>({}),identify:Ei,represent:e=>{const t=new Map;for(const i of Object.keys(e))t.set(i,e[i]);return t},addPair:(e,t,i)=>{const n=Ni(t);return null===n?"nested arrays are not supported inside keys":("__proto__"===n?Object.defineProperty(e,n,{value:i,enumerable:!0,configurable:!0,writable:!0}):e[n]=i,"")},has:(e,t)=>{const i=Ni(t);return null!==i&&Object.prototype.hasOwnProperty.call(e,i)},keys:e=>Object.keys(e),get:(e,t)=>{const i=String(t);return Object.prototype.hasOwnProperty.call(e,i)?e[i]:null}}),Error;var Ti=new Array(256),Bi=new Array(256);for(let e=0;e<256;e++)Ti[e]=Fi(e)?1:0,Bi[e]=Fi(e);Object.assign(Object.create(null),{"!":"!","!!":"tag:yaml.org,2002:"}),Object.prototype.hasOwnProperty;var Ii=String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$,_.!~*'()\[\]])`,Zi=String.raw`(?:%[0-9A-Fa-f]{2}|[0-9A-Za-z\-#;/?:@&=+$.~*'()_])`;function Wi(e,t){return!!(e&1<<t)}new RegExp(`^(?:${Ii})*$`),new RegExp(`^(?:${Zi})+$`),new RegExp(`^(?:!(?:${Ii})*|${Zi}(?:${Ii})*)$`),Symbol("INVALID"),Symbol("visit:break"),Symbol("visit:skip");var Ki={applyQuoteFlowKeysOption:function(e){e.presenterOptions.quoteFlowKeys&&e.isKey&&e.flowOnly&&1===e.style&&(e.style=3)},doubleQuoteForInvisibles:function(e){1===e.style&&/[\t\x7F-\xA0\u2028\u2029\uFEFF\uFFFE\uFFFF]/.test(e.node.value)&&(e.style=3)},doubleQuoteWhitespaceOnly:function(e){1===e.style&&/^\s+$/.test(e.node.value)&&(e.style=3)},applyForceQuotesOption:function(e){e.presenterOptions.forceQuotes&&(e.isKey||1!==e.style||e.node.tag===e.presenterOptions.schema.defaultScalarTag.tagName&&(e.style=e.node.value.includes("\n")?3:Ui(e)))},tryLongOrMultilineAsBlock:function(e){if(1!==e.style||e.isKey)return;const t=e.node.value,i=-1!==t.indexOf("\n");if(!Wi(e.allowedStylesMask,4))return void(i&&(e.style=3));const n=e.presenterOptions.lineWidth;if(-1===n)return void(i&&(e.style=4));const s=Math.max(Math.min(n,40),n-e.shiftOfContent);let r=0,a=!1;for(;r<=t.length;){let e=t.length;const i=t.indexOf("\n",r);-1!==i&&(e=i);const n=t.slice(r,e);if(n.length>s&&" "!==n[0]&&/ [^ \t]/.test(n)&&(a=!0),-1===i)break;r=i+1}a?e.style=5:i&&(e.style=4)},quoteInvalidPlain:function(e){1!==e.style||Wi(e.allowedStylesMask,1)||(e.style=Ui(e))},fallbackToDoubleQuoted:function(e){Wi(e.allowedStylesMask,e.style)||(e.style=3)}};function Ui(e){return"single"===e.presenterOptions.quoteStyle&&Wi(e.allowedStylesMask,2)?2:3}var Gi="[ \\t]",Yi="(?:(?!(?:[\\n\\r]|\\uFEFF))[\\x09\\x0A\\x0D\\x20-\\x7E\\x85\\xA0-\\uD7FF\\uE000-\\uFFFD\\u{10000}-\\u{10FFFF}])",Ji=`(?:(?!${Gi})${Yi})`,Xi="[\\x09\\x20-\\uD7FF\\uE000-\\uFFFF\\u{10000}-\\u{10FFFF}]",Qi="[-?:,\\[\\]{}#&*!|>'\"%@`]",en=`(?:(?![,\\[\\]{}])${Ji})`,tn=`(?:(?:(?![:#])${Ji})|:(?=${Ji}))#*`,nn=`(?:(?:(?![:#])${en})|:(?=${en}))#*`,sn=`(?:${Gi}*${tn})*`,rn=`(?:${Gi}*${nn})*`,an=`(?:(?:(?!${Qi})${Ji})|[?:-](?=${Ji}))#*${sn}`,on=`(?:(?:(?!${Qi})${Ji})|[?:-](?=${en}))#*${rn}`,ln=an,cn=on,dn=`${on}(?:\\n+${nn}${rn})*`;new RegExp(`^(?:${an}(?:\\n+${tn}${sn})*)$`,"u"),new RegExp(`^(?:${dn})$`,"u"),new RegExp(`^(?:${ln})$`,"u"),new RegExp(`^(?:${cn})$`,"u"),new RegExp(`^(?:${Xi})*$`,"u"),new RegExp(`^(?:${Xi}|\\n)*$`,"u"),new RegExp(`^(?:${Yi}|\\n)*$`,"u"),Object.keys(Ki).map(e=>Reflect.get(Ki,e)),Di.withTags($i);const pn=64,hn=48,un=/^[a-z0-9][a-z0-9_-]{0,31}$/,mn=["element","icon","name","state","background"],gn=["rotate","x","y","scale","opacity","draw","color_mix","speed","rotate_speed"],fn=["cut","crossfade","finish"],vn=/^[a-z0-9_][a-z0-9_.-]{0,63}$/i;function bn(e,t,i,n){return Array.isArray(t)?t.length>n?e.err(`${i}[${n}]`,`At most ${n} entries.`):t:e.err(i,"Must be a list.")}function yn(e,t,i,n){const s="string"==typeof t.id?t.id.trim():"";return un.test(s)?n.has(s)?e.err(`${i}.id`,`Duplicate id "${s}".`):(n.add(s),s):e.err(`${i}.id`,"Use 1-32 lowercase letters, digits, - or _ (starting with a letter or digit).")}function xn(e,t,i,n){if(void 0===t.name||null===t.name||""===t.name)return n;if("string"!=typeof t.name||!t.name.trim())return e.err(`${i}.name`,"Must be text.")??n;const s=t.name.trim();return s.length>80?e.err(`${i}.name`,"At most 80 characters.")??n:s}function _n(e,t,i){if(null!=t)return!Array.isArray(t)||2!==t.length||t.some(e=>"number"!=typeof e||!Number.isFinite(e)||Math.abs(e)>1e4)?e.err(i,"Must be two numbers [x, y]."):[t[0],t[1]]}function wn(e,t,i){return"string"==typeof t&&t.trim()?t.length>pt?e.err(i,"At most 8192 characters."):_t.test(t)&&/^\s*[Mm]/.test(t)?(0,$e.Mj)(t).some(e=>e.length)?t.trim().replace(/\s+/g," "):e.err(i,"The path draws nothing."):e.err(i,"Not valid path data (it must start with M)."):e.err(i,"Required.")}function kn(e,t,i,n){if("string"!=typeof t||!t.trim())return e.err(i,"Must be SVG markup.");if(("undefined"!=typeof TextEncoder?(new TextEncoder).encode(t).length:t.length)>De)return e.err(i,"The SVG is larger than 32 KB.");const s=n&&!/^\s*<svg[\s>]/i.test(t)?`<svg viewBox="0 0 24 24">${t}</svg>`:t;if(!/<svg[\s>]/i.test(s))return e.err(i,"No <svg> element found.");if("undefined"!=typeof DOMParser){const t=et(s);if(t.error)return e.err(i,t.error)}return t}function $n(e,t,i,n){const s=function(e){if("string"!=typeof e)return;if(mn.includes(e))return{kind:e};const t=/^(part|group|shape):(.+)$/.exec(e);return t&&un.test(t[2])?{kind:t[1],id:t[2]}:void 0}(t);if(!s)return e.err(i,"Must be element, icon, name, state, background, part:<id>, group:<id> or shape:<id>.");if(void 0!==s.id){const t="part"===s.kind?n?.parts:"group"===s.kind?n?.groups:n?.shapes;if(!t?.some(e=>e.id===s.id))return e.err(i,`No ${s.kind} "${s.id}" in the rig.`)}return t}function Mn(e,t){const i={},n=t=>void 0!==e[t]&&null!==e[t],s="keyframes"===e.kind;let r;return s&&n("rig")&&(r=function(e,t,i){const n=e.obj(t,i);if(!n)return;const s={parts:[]},r=void 0!==n.icon&&null!==n.icon&&""!==n.icon,a=void 0!==n.svg&&null!==n.svg&&""!==n.svg;if(r&&a&&e.err(i,"Set icon or svg, not both."),r&&("string"==typeof n.icon&&wt.test(n.icon.trim())?s.icon=n.icon.trim():e.err(`${i}.icon`,"Must be an icon id like mdi:bell.")),a){const t=kn(e,n.svg,`${i}.svg`,!1);t&&(s.svg=t)}const o=new Set,l=void 0===n.parts?[]:bn(e,n.parts,`${i}.parts`,pn);if(l?.forEach((t,n)=>{const r=`${i}.parts[${n}]`,a=e.obj(t,r);if(!a)return;const l=yn(e,a,r,o);if(!l)return;const c={id:l,name:xn(e,a,r,l)},d=void 0!==a.from&&null!==a.from;if(d===(void 0!==a.svg&&null!==a.svg&&""!==a.svg))return void e.err(r,"Set one of from or svg.");if(d){const t=e.list(a.from,`${r}.from`,256,1),i=[];t?.forEach((t,n)=>{"number"==typeof t&&Number.isInteger(t)&&t>=0&&t<=4095?i.push(t):e.err(`${r}.from[${n}]`,"Must be a subpath index (a whole number from 0).")}),c.from=i}else{const t=kn(e,a.svg,`${r}.svg`,!0);t&&(c.svg=t)}const p=_n(e,a.origin,`${r}.origin`);p&&(c.origin=p),s.parts.push(c)}),void 0!==n.groups&&null!==n.groups){const t=new Set(s.parts.map(e=>e.id)),r=[];bn(e,n.groups,`${i}.groups`,16)?.forEach((n,s)=>{const a=`${i}.groups[${s}]`,l=e.obj(n,a);if(!l)return;const c=yn(e,l,a,o);if(!c)return;const d=[];e.list(l.parts,`${a}.parts`,pn,1)?.forEach((i,n)=>{"string"==typeof i&&t.has(i)?d.includes(i)||d.push(i):e.err(`${a}.parts[${n}]`,"Not a part of this rig.")});const p={id:c,name:xn(e,l,a,c),parts:d},h=_n(e,l.origin,`${a}.origin`);h&&(p.origin=h),d.length&&r.push(p)}),s.groups=r}if(void 0!==n.shapes&&null!==n.shapes){const t=[];bn(e,n.shapes,`${i}.shapes`,hn)?.forEach((n,s)=>{const r=`${i}.shapes[${s}]`,a=e.obj(n,r);if(!a)return;const l=yn(e,a,r,o);if(!l)return;const c=wn(e,a.d,`${r}.d`),d={id:l,name:xn(e,a,r,l),d:c??"",layer:"over"},p=e.css(a,"fill",`${r}.fill`,"color");p&&(d.fill=p);const h=e.css(a,"stroke",`${r}.stroke`,"color");h&&(d.stroke=h);const u=e.num(a,"stroke_width",`${r}.stroke_width`,0,100);void 0!==u&&(d.stroke_width=u);const m=e.oneOf(a,"linecap",`${r}.linecap`,["round","butt","square"]);m&&(d.linecap=m),d.layer=e.oneOf(a,"layer",`${r}.layer`,["over","under"],"over")??"over";const g=_n(e,a.origin,`${r}.origin`);g&&(d.origin=g),c&&t.push(d)}),s.shapes=t}return s}(t,e.rig,"rig"),r&&(i.rig=r)),s&&n("tracks")&&(i.tracks=function(e,t,i){const n=[],s=new Set;return bn(e,t,"tracks",24)?.forEach((t,r)=>{const a=`tracks[${r}]`,o=e.obj(t,a);if(!o)return;let l=$n(e,o.target,`${a}.target`,i);l&&s.has(l)&&(l=e.err(`${a}.target`,"Another track already animates this target.")),l&&s.add(l);const c=!!l&&/^(part|group|shape):/.test(l),d=((void 0===o.keyframes?[]:bn(e,o.keyframes,`${a}.keyframes`,40))??[]).map((t,i)=>At(e,t,`${a}.keyframes[${i}]`,c)).filter(e=>!!e).sort((e,t)=>e.at-t.at),p={target:l??"element",keyframes:d};if(void 0!==o.origin&&""!==o.origin&&("string"==typeof o.origin&&xt(o.origin.trim())?p.origin=o.origin.trim():e.err(`${a}.origin`,'Use keywords, lengths or percentages, e.g. "50% 100%".')),void 0!==o.path&&null!==o.path){const t=e.obj(o.path,`${a}.path`);if(t){const i=wn(e,t.d,`${a}.path.d`);i&&(p.path={d:i,...void 0!==t.follow_rotation?{follow_rotation:e.bool(t,"follow_rotation",`${a}.path.follow_rotation`,!1)}:{}})}}l&&n.push(p)}),n}(t,e.tracks,r)),n("clips")&&(i.clips=function(e,t,i){const n=[],s=new Set(pe.map(e=>e.id));return bn(e,t,"clips",12)?.forEach((t,r)=>{const a=`clips[${r}]`,o=e.obj(t,a);if(!o)return;const l=function(e,t,i){const n=e.obj(t,i);if(!n)return;const s=["state","state_not","entity_on","above","below"].filter(e=>void 0!==n[e]&&null!==n[e]);if(1!==s.length)return e.err(i,"Set one of state, state_not, entity_on, above or below.");const r=s[0],a=n[r];if("state"===r||"state_not"===r){const t="boolean"==typeof a?a?"on":"off":"string"==typeof a||"number"==typeof a?String(a).trim():"";return!t||t.length>255?e.err(`${i}.${r}`,"Must be a state (text)."):"state"===r?{state:t}:{state_not:t}}if("entity_on"===r)return"boolean"==typeof a?{entity_on:a}:e.err(`${i}.entity_on`,"Must be true or false.");const o=e.num(n,r,`${i}.${r}`,-1e9,1e9);return void 0===o?void 0:"above"===r?{above:o}:{below:o}}(e,o.when,`${a}.when`),c="string"==typeof o.animation?o.animation.trim():"";let d=!0;if(c)if(rt(c)){const t=at(c);t===i?d=!!e.err(`${a}.animation`,"A clip cannot play its own document (use self)."):ht.test(t)||(d=!!e.err(`${a}.animation`,"Not a valid animation id."))}else"self"===c||"none"===c||s.has(c)||(d=!!e.err(`${a}.animation`,"Must be self, none, a preset or custom:<id>."));else d=!!e.err(`${a}.animation`,"Required.");const p=e.oneOf(o,"transition",`${a}.transition`,fn);l&&d&&n.push({when:l,animation:c,...p?{transition:p}:{}})}),n}(t,e.clips,"string"==typeof e.id?e.id.trim():"")),s&&n("bindings")&&(i.bindings=function(e,t,i){const n=[];return bn(e,t,"bindings",8)?.forEach((t,s)=>{const r=`bindings[${s}]`,a=e.obj(t,r);if(!a)return;const o=$n(e,a.target,`${r}.target`,i),l=e.oneOf(a,"property",`${r}.property`,gn);void 0===a.property&&e.err(`${r}.property`,"Required.");const c=e.obj(a.input,`${r}.input`);let d,p;if(c){const t=e.num(c,"min",`${r}.input.min`,-1e9,1e9,0),i=e.num(c,"max",`${r}.input.max`,-1e9,1e9,100);void 0!==t&&void 0!==i&&t===i?e.err(`${r}.input.max`,"Must differ from min."):void 0!==t&&void 0!==i&&(d={min:t,max:i}),void 0!==c.attribute&&null!==c.attribute&&""!==c.attribute&&("string"==typeof c.attribute&&vn.test(c.attribute.trim())?d=d&&{attribute:c.attribute.trim(),...d}:(e.err(`${r}.input.attribute`,"Must be an attribute name."),d=void 0))}const h=a.output;if(Array.isArray(h)&&2===h.length)if("color_mix"===l){const t=vt(h[0],"color"),i=vt(h[1],"color");t&&i?p=[t,i]:e.err(`${r}.output`,"color_mix needs two colours.")}else h.every(e=>"number"==typeof e&&Number.isFinite(e)&&Math.abs(e)<=1e6)?p=[h[0],h[1]]:e.err(`${r}.output`,"Must be two numbers (colours only for color_mix).");else e.err(`${r}.output`,"Must be a pair [from, to].");const u=e.num(a,"smoothing",`${r}.smoothing`,0,10);o&&l&&d&&p&&n.push({target:o,property:l,input:d,output:p,...void 0!==u?{smoothing:u}:{}})}),n}(t,e.bindings,r)),i}Et=Mn;const Sn=e=>+e.toFixed(4);function zn(e){let t=5381;for(let i=0;i<e.length;i++)t=(t<<5)+t+e.charCodeAt(i)|0;return(t>>>0).toString(36)}const Cn=e=>`mcc-${e.id}-${zn(JSON.stringify(e))}`,An=(e,t)=>`--mcc-${e}-${t}`;function jn(e){return ne.find(t=>t.id===e)?.css??e??"ease"}const qn=e=>({len:(t,i)=>0===t?`0${i}`:`calc(${Sn(t)}${i} * var(${An(e,"i")}, 1))`,scale:t=>1===t?"1":`calc(1 + ${Sn(t-1)} * var(${An(e,"i")}, 1))`,color:t=>((e,t)=>t?e.replace(/var\(\s*--mc-anim-c\s*\)/g,(e=>`color-mix(in srgb, var(${An(e,"c")}, var(--mc-anim-c)) calc(var(${An(e,"s")}, 1) * 100%), transparent)`)(t)):e)(t,e)}),En=(e=1)=>({len:(t,i)=>`${Sn(t*e)}${i}`,scale:t=>String(Sn(1+(t-1)*e)),color:e=>e});function Hn(e,t){const i=[],n=e.transform;if(n){if(void 0===n.x&&void 0===n.y||i.push(["translate",`${t.len(n.x??0,"px")} ${t.len(n.y??0,"px")}`]),void 0!==n.scale||void 0!==n.scale_x||void 0!==n.scale_y){const e=n.scale??1,s=e*(n.scale_x??1),r=e*(n.scale_y??1);i.push(["scale",s===r?t.scale(s):`${t.scale(s)} ${t.scale(r)}`])}void 0!==n.rotate&&i.push(["rotate",`${n.axis?`${n.axis.join(" ")} `:""}${t.len(n.rotate,"deg")}`]),void 0===n.skew_x&&void 0===n.skew_y||i.push(["transform",`skew(${t.len(n.skew_x??0,"deg")}, ${t.len(n.skew_y??0,"deg")})`])}if(void 0!==e.opacity&&i.push(["opacity",String(e.opacity)]),e.color&&i.push(["color",t.color(e.color)]),e.background&&i.push(["background",t.color(e.background)]),e.shadow&&i.push(["box-shadow",t.color(e.shadow)]),void 0!==e.filter||void 0!==e.blur){const n=[e.filter&&"none"!==e.filter?t.color(e.filter):"",void 0!==e.blur?`blur(${t.len(e.blur,"px")})`:""].filter(Boolean).join(" ");i.push(["filter",n||"none"])}return void 0!==e.radius&&i.push(["border-radius",`${e.radius}px`]),void 0!==e.draw&&i.push(["stroke-dashoffset",String(Sn(1-e.draw))]),e.stroke&&i.push(["stroke",t.color(e.stroke)]),e.easing&&i.push(["animation-timing-function",jn(e.easing)]),i}const Ln=(e,t)=>`  ${e} { ${t.map(([e,t])=>`${e}: ${t};`).join(" ")} }`,Vn=(e,t)=>`@keyframes ${e} {\n${t.join("\n")}\n}`,On={translate:["x","y"],scale:["scale","scale_x","scale_y"],rotate:["rotate"],transform:["skew"],opacity:["opacity"],color:["color"],background:["background"],"box-shadow":["shadow"],filter:["filter","blur"],"border-radius":["radius"],"stroke-dashoffset":["draw"],stroke:["stroke"]};function Pn(e,t,i){const n=t.map(e=>Hn(e,i)),s=Object.keys(On).filter(e=>t.some(t=>On[e].some(e=>void 0!==t.easings?.[e]))),r=Vn(e,t.map((e,t)=>Ln(`${Sn(e.at)}%`,n[t].filter(([e])=>!s.includes(e)))));if(!s.length)return{css:r,lanes:[]};const a=[],o=[r];for(const i of s){const s=`${e}-l${On[i][0]}`,r=[];t.forEach((e,t)=>{const s=n[t].filter(([e])=>e===i);if(!s.length)return;const a=On[i].map(t=>e.easings?.[t]).find(e=>void 0!==e)??e.easing;r.push(Ln(`${Sn(e.at)}%`,a?[...s,["animation-timing-function",jn(a)]]:s))}),r.length&&(a.push(s),o.push(Vn(s,r)))}return{css:o.join("\n"),lanes:a}}const Rn=e=>"animation-timing-function"===e?"easing":e.replace(/-([a-z])/g,(e,t)=>t.toUpperCase()),Dn=(e,t)=>{const i=1-t,n=i*i*i,s=3*i*i*t,r=3*i*t*t,a=t*t*t;return[n*e[0][0]+s*e[1][0]+r*e[2][0]+a*e[3][0],n*e[0][1]+s*e[1][1]+r*e[2][1]+a*e[3][1]]};function Nn(e,t=48){const i=(0,$e.Mj)(e).flat();if(!i.length)return[];const n=[i[0][0]];for(const e of i)for(let t=1;t<=16;t++)n.push(Dn(e,t/16));const s=[0];for(let e=1;e<n.length;e++)s.push(s[e-1]+Math.hypot(n[e][0]-n[e-1][0],n[e][1]-n[e-1][1]));const r=s[s.length-1],a=e=>{if(0===r)return n[0];let t=1;for(;t<s.length-1&&s[t]<e;)t++;const i=s[t]-s[t-1]||1,a=Math.min(1,Math.max(0,(e-s[t-1])/i));return[n[t-1][0]+(n[t][0]-n[t-1][0])*a,n[t-1][1]+(n[t][1]-n[t-1][1])*a]},o=[];let l;const c=r/(4*t)||.001;for(let e=0;e<=t;e++){const i=r*e/t,n=a(i),s=a(Math.max(0,i-c)),d=a(Math.min(r,i+c));let p=180*Math.atan2(d[1]-s[1],d[0]-s[0])/Math.PI;if(void 0!==l){for(;p-l>180;)p-=360;for(;p-l<-180;)p+=360}l=p,o.push({t:e/t,x:n[0],y:n[1],angle:p})}return o}function Fn(e,t,i){return Nn(e.d).map(n=>{const s=[["translate",`${t.len(Sn(n.x),i[0])} ${t.len(Sn(n.y),i[1])}`]];return e.follow_rotation&&s.push(["rotate",`${Sn(n.angle)}deg`]),[Sn(100*n.t),s]})}const Tn=.618034,Bn=e=>e-Math.floor(e);function In(e){const t=e.replace(/^<svg\b(?![^>]*\bxmlns=)/,'<svg xmlns="http://www.w3.org/2000/svg"');return`url("data:image/svg+xml,${encodeURIComponent(t)}")`}function Zn(e,t){if(!e)return"border-radius: 50%; background: currentColor;";if("svg"in e){const i=t(e.svg);if(!i)return"border-radius: 50%; background: currentColor;";const n=In(i);return`background: currentColor; -webkit-mask: ${n} center / contain no-repeat; mask: ${n} center / contain no-repeat;`}return""}const Wn=e=>e&&"icon"in e?{icon:e.icon}:e&&"emoji"in e?{text:e.emoji}:void 0;function Kn(e,t=100){const i=e.count;return Array.from({length:i},(n,s)=>{const r=(Bn(s*Tn)-.5)*(60/i),a=Math.min(96,Math.max(4,(s+.5)/i*100+r)),o=50+t/100*(a-50),l=e.size[0]+(e.size[1]-e.size[0])*Bn(.381966*s+.25),c=e.colors.length?e.colors[s%e.colors.length]:"",d=[`--mcc-sz: ${Sn(l)}px`,"--mcc-sp: "+(s%2?-1:1),`--mcc-dx: ${Sn(16*(2*Bn(.7548*s)-1))}`,c&&`--mcc-pc: ${c}`].filter(Boolean).join("; ");return{x:Sn(o),phase:Sn(Bn(s*Tn)),k:i>1?Sn(s/i):0,style:d}})}const Un=(e,t)=>`.mc-anim-fx[data-fx="${e}"] { opacity: var(${An(t,"s")}, 1); }\n.mc-anim-fx[data-fx="${e}"] > i { width: var(--mcc-sz); height: var(--mcc-sz); margin-left: calc(var(--mcc-sz) / -2); color: var(--mcc-pc, var(${An(t,"c")}, var(--mc-anim-c))); display: flex; align-items: center; justify-content: center; font-size: var(--mcc-sz); line-height: 1; font-style: normal; --mdc-icon-size: var(--mcc-sz);`;function Gn(e,t,i,n){const s=i.fade?0:1,r=`calc(var(--mcc-sp, 1) * ${Sn(i.spin)}deg)`,a=i.gravity,o=`${Sn(i.spread/2)}cqmin`,l=a>0?" animation-timing-function: cubic-bezier(0.5, 0, 1, 1);":a<0?" animation-timing-function: cubic-bezier(0, 0, 0.5, 1);":"";let c,d;switch(i.direction){case"fall":case"rise":{const e="fall"===i.direction?"":"-";c="fall"===i.direction?"top: calc(var(--mcc-sz) * -1);":"top: 100%;",d=[`  0% { translate: 0 0; rotate: 0deg; opacity: ${s};${l} }`,"  10%, 90% { opacity: 1; }",`  100% { translate: calc(var(--mcc-dx, 0) * 1px) calc(${e}100cqh ${e?"-":"+"} var(--mcc-sz) * 2); rotate: ${r}; opacity: ${s}; }`];break}case"drift":c="left: calc(var(--mcc-sz) * -1); top: var(--mc-anim-x); margin-left: 0; margin-top: calc(var(--mcc-sz) / -2);",d=[`  0% { translate: 0 0; rotate: 0deg; opacity: ${s}; }`,"  10%, 90% { opacity: 1; }",`  50% { translate: calc(50cqw + var(--mcc-sz)) calc(var(--mcc-dx, 0) * 1px + ${Sn(15*a)}cqh); }`,`  100% { translate: calc(100cqw + var(--mcc-sz) * 2) ${Sn(30*a)}cqh; rotate: ${r}; opacity: ${s}; }`];break;case"burst":c="left: 50%; top: 50%; margin-top: calc(var(--mcc-sz) / -2); animation-delay: var(--mc-fx-delay, 0s);",d=["  0% { transform: rotate(calc(var(--mc-anim-k) * 360deg)) translateY(0) rotate(0deg); translate: 0 0; opacity: 1; }",`  100% { transform: rotate(calc(var(--mc-anim-k) * 360deg)) translateY(calc(${o} * -1)) rotate(${r}); translate: 0 ${Sn(30*a)}cqh; opacity: ${s}; }`];break;case"orbit":c="left: 50%; top: 50%; margin-top: calc(var(--mcc-sz) / -2); animation-delay: var(--mc-fx-delay, 0s);",d=[`  0% { transform: rotate(calc(var(--mc-anim-k) * 360deg)) translateY(calc(${o} * -1)) rotate(0deg); opacity: 1; }`,i.fade?"  50% { opacity: 0.35; }":"",`  100% { transform: rotate(calc(var(--mc-anim-k) * 360deg + 360deg)) translateY(calc(${o} * -1)) rotate(${r}); opacity: 1; }`].filter(Boolean);break;case"spiral":c="left: 50%; top: 50%; margin-top: calc(var(--mcc-sz) / -2); animation-delay: calc(var(--mc-fx-delay, 0s) - var(--mc-anim-k) * var(--mc-fx-dur, 1s));",d=[`  0% { transform: rotate(calc(var(--mc-anim-k) * 360deg)) translateY(0) rotate(0deg); opacity: ${s}; }`,"  20%, 80% { opacity: 1; }",`  100% { transform: rotate(calc(var(--mc-anim-k) * 360deg + 720deg)) translateY(calc(${o} * -1)) rotate(${r}); opacity: ${s}; }`]}return`${Un(e,t)} ${c} ${Zn(i.shape,n)} }\n${Vn(e,d)}`}function Yn(e,t,i,n,s){const r=qn(t),a=i.follow_rotation?"auto":"0deg",o=e=>Vn(e,Fn(i,r,"px"===i.units?["px","px"]:["cqw","cqh"]).map(([e,t])=>Ln(`${e}%`,[...t,["opacity","1"]]))),l=`${Un(e,t)} left: 0; top: 0; margin: calc(var(--mcc-sz) / -2) 0 0 calc(var(--mcc-sz) / -2); animation-delay: calc(var(--mc-fx-delay, 0s) - var(--mc-anim-k) * var(--mc-fx-dur, 1s)); ${Zn(n.shape,s)} }`;if("px"!==i.units)return`${l}\n${o(e)}`;const c='offset-path: path("M0 0 L1 1")';return[l,`@supports (${c}) {`,`  .mc-anim-fx[data-fx="${e}"] > i { offset-path: path("${i.d}"); offset-rotate: ${a}; offset-anchor: center; margin: 0; }`,`  @keyframes ${e} { from { offset-distance: 0%; opacity: 1; } to { offset-distance: 100%; opacity: 1; } }`,"}",`@supports not (${c}) {`,o(e),"}"].join("\n")}function Jn(e,t){const i=[],n=[];let s=0;const r="icon"===e.target;return(e.steps??[]).forEach((e,a)=>{let o,l,c,d=e.duration;if(rt(e.animation)){const i=t?.(at(e.animation));i&&("keyframes"===i.kind||"path"===i.kind&&"particles"!==i.path?.subject)&&(o=function(e,t=1){if("path"===e.kind&&e.path)return Fn(i=e.path,En(t),"px"===i.units?["px","px"]:["%","%"]).map(([e,t])=>({...Object.fromEntries(t.map(([e,t])=>[Rn(e),t])),offset:Sn(e/100)}));var i;if("keyframes"!==e.kind||!e.keyframes)return[];const n=new Map;for(const i of e.keyframes){const e=n.get(i.at)??{};for(const[n,s]of Hn(i,En(t)))e[Rn(n)]=s;n.set(i.at,e)}return[...n.entries()].sort((e,t)=>e[0]-t[0]).map(([e,t])=>({...t,offset:Sn(e/100)}))}(i),d??=i.duration,l=jn(i.easing),c=i.origin)}else{const t=ge(e.animation);o=t&&!t.channels.includes("fx")?function(e,t={}){const i=ge(e);if(!i)return;const n=_e(t.icon&&i.iconKeyframes?`${e}-icon`:e,t.intensity);return void 0===n?void 0:function(e){const t=new Map;for(const i of e)for(const e of i.offsets){const n=t.get(e)??{};for(const[e,t]of i.decls)n[ke(e)]=t;t.set(e,n)}return[...t.entries()].sort((e,t)=>e[0]-t[0]).map(([e,t])=>({...t,offset:+(e/100).toFixed(4)}))}(we(n))}(t.id,{icon:r}):void 0,t&&(d??=parseFloat(t.defaults.duration),l=jn(t.defaults.easing),c=t.origin)}if(!o?.length||!d)return void n.push(a);const p=s+e.delay;i.push({start:Sn(p),duration:d,iterations:e.repeat,easing:l??"ease",frames:o,...c&&"center"!==c?{origin:c}:{}}),s=p+d*e.repeat}),{steps:i,total:Sn(s),loop:!1!==e.loop,target:e.target,...e.stagger?.children?{stagger:e.stagger.delay}:{},skipped:n}}const Xn=new WeakMap;function Qn(e,t={}){const i=!t.reducedMotion&&(e=>"particles"===e.kind&&!!e.particles?.sim&&!e.particles.preset)(e);let n=i&&function(e){if(nt.failedSims.has(e.id))return;ts!==nt.epoch&&(es=new WeakMap,ts=nt.epoch);let t=es.get(e);const i=e.particles;try{const n=nt.particles&&!t&&nt.checkSim?.(i.sim,"lenient",{count:i.count,layer:i.layer}).sim;if(n){const s={...i,sim:n},r=e.duration/i.speed,a=nt.particles(e.id,s,r,{aspect:0}),o=a.other;es.set(e,t={kind:"particles",name:a.name,css:o?`${a.css}\n${o.css}`:a.css,layer:{front:a.front,particles:a.slots,speed:i.speed},sim:{docId:e.id,spec:s,period:r},...o?{split:{name:o.name,layer:{front:o.front,particles:o.slots,speed:i.speed},sim:{docId:e.id,spec:s,period:r,part:1}}}:{}})}}catch{nt.failedSims.add(e.id)}return t}(e)||function(e,t){if(t.reducedMotion)return{kind:e.kind,name:"",css:"",reduced:!0,..."sequence"===e.kind?{schedule:{steps:[],total:0,loop:!1,target:e.target,skipped:[]}}:{}};if("sequence"===e.kind)return{kind:"sequence",name:Cn(e),css:"",schedule:Jn(e,t.lookup)};const i=Xn.get(e);if(i)return i;const n=Cn(e),s=e=>et(e).markup;let r;switch(e.kind){case"keyframes":{const{css:t,lanes:i}=Pn(n,e.keyframes??[],qn(e.id));r={kind:"keyframes",name:n,css:t,motion:{target:e.target,origin:e.origin},...i.length?{lanes:i}:{}};break}case"particles":{const t=e.particles;if(t.preset){r={kind:"particles",name:"",css:"",preset:{id:t.preset,...void 0!==t.intensity?{intensity:t.intensity}:{}}};break}r={kind:"particles",name:n,css:Gn(n,e.id,t,s),layer:{front:"front"===t.layer,particles:Kn(t,t.spread),speed:t.speed,...Wn(t.shape)?{symbol:Wn(t.shape)}:{}}};break}case"path":{const t=e.path;if("particles"===t.subject){const i=t.particles??{count:3,size:[8,8],colors:[]};r={kind:"path",name:n,css:Yn(n,e.id,t,i,s),layer:{front:!1,particles:Kn(i),speed:1,...Wn(i.shape)?{symbol:Wn(i.shape)}:{}}};break}const i=Fn(t,qn(e.id),"px"===t.units?["px","px"]:["%","%"]).map(([e,t])=>Ln(`${e}%`,t));r={kind:"path",name:n,css:Vn(n,i),motion:{target:"icon"===t.subject?"icon":"element",origin:e.origin}};break}}return Xn.set(e,r),r}(e,t);return i&&!nt.particles&&(n={...n,needsParticles:!0}),nt.v2&&it(e)?{...n,v2:nt.v2(e,t)}:n}let es=new WeakMap,ts=0;const is=new WeakMap,ns=new WeakMap;function ss(e){let t=ns.get(e);if(!t){const i={...e};delete i.rig,delete i.tracks,delete i.clips,delete i.bindings,t={...i,...Mn(e,new Ct)},ns.set(e,t)}return t}function rs(e,t={}){if(t.reducedMotion||!Array.isArray(e.tracks)||!e.tracks.length)return[];let i=is.get(e);return i||is.set(e,i=function(e,t){const i=qn(e.id);return(e.tracks??[]).map((e,n)=>{const s=`${t}-t${n}`,r=[],a=[];if(e.keyframes.length){const t=Pn(s,e.keyframes,i);r.push(t.css),a.push(...t.lanes)}if(e.path){const t=e.keyframes.length?`${s}-path`:s,n={d:e.path.d,units:"px",follow_rotation:!!e.path.follow_rotation,subject:"element"};r.push(Vn(t,Fn(n,i,["px","px"]).map(([e,t])=>Ln(`${e}%`,t)))),t!==s&&a.push(t)}return{target:e.target,name:s,css:r.join("\n"),...e.origin?{origin:e.origin}:{},...a.length?{lanes:a}:{}}})}(ss(e),Cn(e))),i}nt.v2=function(e,t={}){const i=ss(e),n=rs(e,t),s=[],r=i.clips?.filter((i,n)=>{if(!rt(i.animation))return!0;const r=t.lookup?.(at(i.animation));return!(r===e||r&&Array.isArray(r.clips)&&r.clips.length)||(s.push(n),!1)});return{tracks:n,...i.rig?{rig:i.rig}:{},...r?{clips:r}:{},...i.bindings?{bindings:i.bindings}:{},...s.length?{skipped:s}:{}}};const{t:as,tx:os,m:ls,locale:cs}=(0,ee.my)("anim-studio",["\"{name}\" has changes that are not saved yet.|\"{name}\" has changes that were not saved last time.|% of size|(prefers-reduced-motion: reduce)|, large|, {count} skipped|. Text, icons and background of the card.|0 pulls down, 90 left, 180 up, 270 right.|0 stops on impact, 1 bounces back at full speed.|0.1 s|1%|30 fps|5%|; {skipped} skipped (not for this target or lane)|A baked loop keeps lifetimes inside one loop.|A clip cannot play its own document (use self).|A looping SVG file of the animation|A looping SVG file of the baked particles|A sequence cannot play itself.|A sequence lasts as long as its steps. Cards can still scale it with their Duration.|A sequence needs at least one step|About {percent}% of particles|Add a keyframe at the playhead|Add a property to {target}|Add a shape to mix shapes. Each one gets a weight.|Add a {name} keyframe at the playhead|Add as shapes|Add colour|Add emitter|Add keyframe|Add motion path|Add point|Add property|Add property to {target} at the playhead ({at})|Add shape|Add state|Add step|Add the animations to play one after another.|Add the drawing as shapes over the icon, or use it as the icon itself.|Add value binding|Add {lane} keyframe|Add {name} keyframe at the playhead|Adds random swirls to the motion.|Alarm panel|All|All domains|All layers shown|All layers shown. Locks kept.|All particles|Already at the bottom|Already at the top|Also at {at}|Alt+ArrowDown|Alt+ArrowUp|Alt+Down|Alt+Up|Alternate|Alternate reverse|An open line is drawn by its stroke.|Anchor points|Angle|Angle (deg)|Animated SVG|Animated SVG copied|Animation|Animation colour|Animation settings (Esc)|Another track already animates this target.|Arc|Arrow keys move the cursor, Enter places points, Escape cancels.|Arrows move the keyframe, Alt and arrows go to the next one, Delete removes it.|At end of life|At the playhead: {filter}|At the playhead: {text}|At {at} · {secs} s|Attribute|Attribute names use letters, digits, _ . and - (no spaces).|Attribute names use letters, digits, _ . and -.|Background|Baked loop|Baking…|Based on a built-in {kind}|Behind the content|Between {min} and {max}; empty uses {intensity}. Timing and colour come from the animation settings.|Binary sensor|Binding added: {property}.|Binding deleted.|Binding {n}|Black in an <img>, the text colour inline.|Blank keyframes|Blank particles|Blank path|Blank sequence|Blends from the first colour to the second.|Blur|Blur has its own lane and is added to this list.|Bottom|Bottom left|Bottom right|Bounce|Brighten|Bring forward|Bring over the icon|Bring shape forward|Bring shape over the icon|Bring {name} forward|Bring {name} over the icon|Browsers play its CSS keyframes.|Browsers play its CSS keyframes; the SMIL copy plays where CSS animation is missing.|Build one from scratch or customise one of the presets. Saved animations appear in every card's animation picker, under My animations.|Burst|Button|Calendar|Camera|Cancel|Cannot play|Card|Card YAML copied: paste it into a module|Card YAML to copy|Card content|Card content. Text, icons and background of the card.|Card parts|Card theme|Cards that use it stop playing it, unless they embed a copy.|Cards use it as|Ceiling|Centre|Change count|Change fill|Change point type|Change speed|Change spread|Change stroke|Change weight|Changes the last stroke too. The dotted line is what you drew.|Child colour|Child particles|Child particles of {name}|Child shape|Children burst out from the point where they spawn.|Children cannot have children of their own.|Choose a preset|Choose an .svg file.|Choose another|Choose file|Circle|Clear path|Clear search|Click a part to animate it on the timeline. Shift or Ctrl adds to the selection; double-click or F2 renames. H hides, S solos, L locks (preview only).|Click a shape to select it, drag to move it.|Click or drag over shapes to delete them.|Click the stage to add a point, click the line to insert one.|Click to add points, drag for curves. Click the first point to close, or choose Finish path.|Click to add the next point|Click to place the first point|Climate|Close|Close inspector|Close layers|Close path|Closed|Closed path|Collapse|Collapse {name}|Collide with|Collisions|Colour|Colour mix|Colour {i}|Colour {n}|Colour {n}: entity colour|Colour {n}: {colour}|Colour: currentColor|Colours|Common emoji|Complete at|Contains a link.|Contains an element that runs or fetches.|Contains an event handler.|Contains an external reference.|Content box|Convert the preset to custom particles to export it.|Convert to custom particles|Copies icon: svg and the SVG as card YAML|Copy|Copy (Ctrl+C)|Copy SVG|Copy failed: select the text below and copy it|Copy keyframes|Copy keyframes first|Corner radius|Corner radius (icon units)|Couldn't load the drawing tools.|Count|Count per spawn|Cover|Crossfade|Ctrl + wheel zooms|Ctrl+G|Ctrl+Shift+G|Cursor at x {x}, y {y}. Press Enter to add a point.|Cursor at x {x}, y {y}. Press Enter to finish.|Cursor at x {x}, y {y}. Press Enter to start.|Curved|Custom|Custom axis ({axis})|Custom curve|Custom state|Customise a preset|Customise a preset…|Cut|Cycle|Dark card|Default|Default ({inherited})|Delay|Delay between children|Delay counts from the end of the previous step. Empty duration uses the animation's own ({seconds} s).|Delay counts from the end of the previous step. Empty duration uses the animation's own.|Delete|Delete \"{name}\"?|Delete (Del)|Delete binding|Delete binding {n}|Delete handle|Delete keyframe|Delete keyframes|Delete point|Delete points|Delete shape|Delete state|Delete state {i}|Delete step|Delete step {i}|Delete {name}|Deleted \"{name}\".|Deleting failed: {message}|Detail|Device tracker|Direction|Discard|Domain|Doorbell|Dot|Double-click a point to make it smooth or a corner.|Download .svg|Download started|Drag|Drag any of them on the timeline, or use the arrow keys, to move them together.|Drag points and handles.|Drag to draw a line.|Drag to draw. Shift: circle, Alt: from the centre.|Drag to draw. Shift: square, Alt: from the centre.|Drag to move (snaps; Shift: free, Alt: duplicate). Ctrl-click adds a key, Shift-click selects a range. Arrows move, Alt and arrows go to the next key, Delete removes.|Drag to reorder (Alt+Up / Alt+Down)|Drag to resize the stage (double-click: reset)|Drag, or press Alt+Up or Alt+Down, to move the step.|Draw|Draw freely; the stroke is smoothed when you let go.|Draw motion path|Draw off|Draw on|Draw on the stage where the shape travels, starting where it rests.|Draw the path the selected part travels, starting where it rests.|Draw-on is only for icon parts and shapes.|Drawing|Drawing cancelled.|Drawing tools|Drawn|Draws the line on (a battery or level).|Drift|Drive {name} from the entity’s value: rotation speed from a fan’s percentage, a fill from a battery level.|Drop an .svg file here|Drop shadow|Drop the .svg to import it|Duplicate|Duplicate emitter|Duplicate id \"{id}\".|Duplicate {count, plural, one {keyframe} other {keyframes}}|Duplicate {name}|Duplicated as \"{name}\".|Duplicating failed: {message}|Duration|Each particle picks a speed in this range, measured in % of the card's shorter side per second. At 100, a particle crosses a square card in one second.|Each particle turns the way it picks, left or right.|Easing|Easing to the next keyframe|Easing value|Edit the keyframe's easing|Effect presets cannot play as a state: plays nothing.|Effects with their own layer cannot play in a sequence. This step is skipped.|Element|Ellipse|Emitter name|Emitters|Emoji|Emoji or symbol|Empty keyframe|Empty reads the state. For example percentage (fan) or brightness (light).|End handle|End solo|Enter an emoji or a symbol.|Entity colour|Entity is off|Entity is on|Entity value|Erase|Event|Expand|Expand {name}|Explode and fall|Export|Export all|Export animations|Export {name}|Export {n} selected|Fade in and out|Fade out and back in (0.2 s)|Fades in with the value.|Fall|Fan|Figure 8|Fill|Fill colour|Filter|Filter presets|Finish cycle|Finish path|Fireflies|Fit the cycle|Fit the whole cycle|Fix the marked fields first.|Flat|Flat (Z)|Flip over (X)|Flip sideways (Y)|Floor|Flow|Follow a drawn path|Follow a path|Follow rotation|Follow the path|Forward|Fountain|Freehand|From|From colour|From{unit}|Front door|Glow|Got it|Gravity|Gravity direction|Gravity {strength} {direction}|Greyscale|Grid|Group|Group pivot|Grows with the value.|Has errors|Heart|Hide and solo are unavailable: the particle preview could not be built.|Hide in preview|Hide in preview (not saved)|Hide in preview: the layer rests at its normal value|Hide {noun} ({keys})|Hide, solo and lock only change this preview.|Highest {noun}|Hue shift|Humidifier|Icon|Icon and emoji particles export as dots.|Icon animation|Icon animation…|Icon moves only the module's icon. Cards can override it.|Icon parts|Icon parts on the stage|Icon to split|Icon {percent}%|Icons, emoji or shapes that fall, rise or burst|Import|Import SVG|Import animations|Imported {count, plural, one {# animation} other {# animations}}.|In front of the content|In front: particles draw over text and icons. They never block clicks.|In-out|Infinite|Inspector|Inspector panel|It is used by {count, plural, one {# card} other {# cards}}; they stop playing it, unless they embed a copy.|It turns with the direction it travels.|Keep editing|Keep inspector open|Keyframe|Keyframe inspector|Keyframe timeline|Keyframe tools|Keyframes|Keys|Kind|Largest|Largest size|Lawn mower|Layer|Layer actions|Layer actions, {name}|Layer name|Layers|Layers hidden in the preview|Layers panel|Left|Left edge|Let the current cycle end first|Library|Lifetime (s)|Lift|Light|Light card|Line|Line ends|Live simulation|Live simulation exports as its baked loop.|Live simulation runs on every dashboard that shows this card and uses more CPU, especially on wall tablets. Animated SVG export plays the baked loop instead.|Living room|Loading icon library…|Loading the {kind} editor…|Loading…|Lock|Locked|Locked. Unlock to edit.|Look|Loop|Loop off|Loop on|Loop speed (×)|Loops|Lowest {noun}|Magic Card is not loaded on this page|Max|Maximise|Media player|Merge parts|Min|Min and max must differ.|Min must not be above max.|Mixed|Mode|Modified only|More presets could not load. The built-in presets still work.|More smoothing: fewer points and a calmer line.|More smoothing: fewer points and a calmer line. The dotted line is what you drew.|Motion|Motion path|Motion path. Click to add points, drag to move them.|Motion path: select a part or shape first|Motion removed|Move X|Move Y|Move away from the start first.|Move down|Move down (drawn underneath)|Move down (plays later)|Move emitter behind the content|Move emitter down|Move emitter in front of the content|Move emitter up|Move handle|Move keyframe|Move path|Move path point|Move pivot|Move point|Move points|Move state {i} down|Move state {i} up|Move step|Move step {i}|Move the element instead|Move the icon instead|Move up|Move up (drawn on top)|Move up (plays earlier)|Move window|Move {count, plural, one {keyframe} other {keyframes}}|Move {name} down|Move {name} down (drawn underneath)|Move {name} down (plays later)|Move {name} up (drawn on top)|Move {name} up (plays earlier)|Move {name} {where}|Move {where}|Move, scale, turn and colour on a timeline|Moved down: drawn underneath|Moved up: drawn on top|Movement|Moves|Moves along: {subject}|Moves sideways.|Moves the part along a curve, from its rest position. Drag the points on the stage.|Moves up or down.|Moving {target}.|Must be 1-16 of a-z, 0-9 and -, and unique.|Must be SVG markup.|Must be [min, max] px between 1 and 200, min ≤ max.|Must be [min, max].|Must be a list.|Must be a motion preset or a custom keyframes / path animation.|Must be a number.|Must be a pair [from, to].|Must be a particle, ring or scene preset.|Must be a state (text).|Must be a subpath index (a whole number from 0).|Must be a whole number.|Must be an attribute name.|Must be an icon id like mdi:bell.|Must be an icon id like mdi:star.|Must be an object.|Must be between 0 and 100%.|Must be between {min} and {max} {unit}.|Must be between {min} and {max}.|Must be element, icon, name, state, background, part:<id>, group:<id> or shape:<id>.|Must be one of: {options}.|Must be self, none, a preset or custom:<id>.|Must be text of at most 40 characters.|Must be text.|Must be three numbers [x, y, z], not all 0.|Must be true or false.|Must be two numbers (colours only for color_mix).|Must be two numbers [x, y].|Must be up to 8 characters (an emoji or a symbol).|Must differ from min.|My animations|Name|Name of {name}|Needs at least one entry.|Needs at least {min} entries.|Negative blows the rain to the left, positive to the right. It sets the gravity direction.|New|New animation|New in this release|New keyframes|New particles|New path|New sequence|New shapes|Next keyframe|No <svg> element found.|No animation|No animation matches “{query}”.|No animations found.|No animations match \"{query}\".|No animations match.|No animations yet|No changed fields yet.|No colours: particles use the animation colour.|No free particles left. Lower a count to add an emitter.|No gravity|No icon animations match \"{query}\".|No keyframes yet: use Add property, or double-click its lane.|No keys yet. Add keys on the timeline to rotate, move, scale, fade or colour this part.|No motion path yet. Draw one on the stage.|No presets match \"{query}\".|No properties animate yet. Use Add property, or double-click a lane.|No shapes yet: pick a drawing tool.|No steps yet|No steps yet. Add a clip to start the sequence.|No {kind} \"{id}\" in the rig.|None|None set: the particles take the animation colour.|Normal|Not a part of this rig.|Not a timeline lane.|Not a valid animation id.|Not a valid colour.|Not a valid easing.|Not an allowed shadow: x y blur spread colour.|Not an allowed {kind} value.|Not changed: {big}|Not found|Not found in My animations. This step is skipped.|Not imported: {list}.|Not in your animations: plays nothing until it is saved there.|Not on this tile|Not renamed: {message}|Not serialisable.|Not used|Not valid YAML.|Not valid path data (it must start with M).|Nothing|Nothing (stop)|Nothing is drawn.|Nothing pasted: those properties do not fit here|Nothing plays yet.|Nothing to export yet.|Nothing to set here yet.|Number|Off|On|On collision|On means active for its domain (open, home, playing...).|One click animates the selection; fine-tune the keys on the timeline.|Onion skin|Onion skin: mark the keyframes around the playhead|Only for the trigger time.|Only keyframe animations export as an animated SVG.|Only this property. Default follows the keyframe's easing (the animation easing).|Only this property. Default follows the keyframe's easing.|Opacity|Opacity (%)|Open|Open a particles animation to design its particles.|Open path|Or start from the icon library|Orbit|Origin|Output|Over the icon|Own SVG|Own child colour|Own timeline|Paint|Part|Part actions|Part pivot|Part presets|Part {i}|Part {n}|Particle and sequence animations cannot play as a state.|Particle icon|Particle layers|Particle preset|Particle speed (% of short side/s)|Particles|Particles along a path cannot play in a sequence. This step is skipped.|Particles appear and vanish softly.|Particles play on the whole element.|Particles take the colours in turn. Pick one to change it.|Particles travel the path one after another, over the whole element.|Particles {n}|Parts merged|Paste at the playhead into {target} (Ctrl+V)|Paste keyframes at the playhead|Paste or load some YAML first.|Paste the markup of an <svg>.|Path|Path layers|Path layers (no stacking order)|Paths and shapes only: scripts, styles and links are removed. The shape is filled with the particle colour.|Pause (Space)|Pause preview|Pen|Pen. Click to add points, click the first point to close.|Person|Physics|Pick an animation for this step.|Pick an icon, or type an id like mdi:bell-ring.|Pivot|Pivot of {name}|Pivot on the group's box|Pivot on the part's box|Pivot: {position}|Pixels|Placement|Plant|Play|Play (Space)|Play animations one after another|Play on a row's columns or a column's modules one after another.|Play order|Play preview|Play something else per entity state: a light that glows when on and rests when off. The entity is the module’s, or the one set on the animation in the card.|Playback|Playback speed|Playhead|Plays|Plays on tap|Plays this animation faster or slower.|Point {count} placed. Enter again on the same spot finishes the stroke.|Points are in % of the moving element, so the path scales with it.|Points are in pixels, the same at every size.|Points jump to the icon’s and other shapes’ points nearby.|Points land on whole icon units. Hold Shift to place freely.|Points snap to a 10 px grid. Hold {key} to place freely.|Points snap to a 5% grid. Hold {key} to place freely.|Position|Position in the cycle|Preset|Preset pivot|Preset pivot of {name}|Preview|Preview entity|Preview hides {count, plural, one {# layer} other {# layers}}|Preview state|Preview tile|Preview value|Preview with reduced motion|Previous keyframe|Property|Property keys get their own easing; whole keyframes set the keyframe's easing.|Pseudo RTL|Radius|Rain|Rectangle|Redo (Ctrl+Y)|Redraw|Reduced motion|Reduced motion is on, so the preview stays still.|Reload page|Reloading the page discards changes that are not saved. Reload anyway?|Remove|Remove colour|Remove colour {i}|Remove colour {n}|Remove draw-on|Remove emitter|Remove fill|Remove from this keyframe|Remove motion|Remove motion path|Remove shape|Remove shape {n}|Remove stroke|Remove this part's animation|Remove {name} from this keyframe|Rename|Rename group|Rename part|Rename {name}|Renamed|Renamed to \"{clean}\".|Renaming failed: {message}|Repeat|Repeat count|Replace the path with a {name}|Replace with…|Required.|Reset pivot|Reset to group pivot|Reset to part pivot|Reset {field}|Resize window|Restore size|Restore unsaved changes|Restore unsaved changes?|Reverse|Reverse direction|Right|Right edge|Ring|Ring preset|Rise|Rotate|Rotation|Rotation speed|Round|Ruler in percent of the cycle or in seconds|Ruler in percent; show seconds|Ruler in seconds; show percent|SMIL fallback|SVG|SVG copied|SVG shape|SVG to copy|Save|Save (Ctrl+S)|Save as animated SVG|Save as icon|Save your changes?|Saved \"{name}\".|Saving failed.|Saving…|Scale|Scale X|Scale Y|Scene preset|Schedule|Search animations|Search icons|Search presets|Search the icon library|Seasonal scene|Seconds|Seed|Seed {seed} · spin {span}|Select|Select a part or shape first.|Select a part or shape, then draw its motion path.|Select every {name} keyframe (Shift adds)|Select two or more parts to group them.|Select {name}|Send backward|Send shape backward|Send shape under the icon|Send under the icon|Send {name} backward|Send {name} under the icon|Sensor|Sequence|Sequence steps|Sequence steps (plays first to last)|Sequences that play it skip that step: {names}.|Set icon or svg, not both.|Set one of builtin, icon, emoji or svg.|Set one of from or svg.|Set one of icon, emoji or svg.|Set one of state, state_not, entity_on, above or below.|Settings|Shadow|Shadow and glow|Shadow colour|Shadow presets|Shadow {name}|Shape|Shape mix|Shape over the icon|Shape points. Drag a point to move it.|Shape under the icon|Shape {n}|Shape {n}: {shape}|Shape {n}: {shape}, weight {weight}|Shapes over the icon|Shapes under the icon|Shortcut: {keys}|Show all|Show all hidden layers|Show in preview|Show {noun} ({keys})|Shuffle|Shuffle: new random paths|Simulation|Siren|Size|Size (px)|Skew|Skew X|Skew Y|Slows particles down over time.|Smallest|Smallest size|Smooth|Smooth all|Smoothing|Smoothing (s)|Snap grid|Snap to keyframes, the playhead and the grid (hold Shift to drag freely)|Snapping|Solo in preview|Solo in preview (hides the others, not saved)|Solo on|Some panels are hidden, as you left them. Use the arrows on the edges to show them.|Spaced evenly along the path, 1 to {particles}.|Spark|Spawn|Spawn child particles|Spawns {seconds} s after birth (set in YAML).|Speed|Speed (% of short side/s)|Spin per loop (deg)|Spins continuously, faster as the value rises (a fan).|Spiral|Split again|Split and start|Split back into shapes|Split icon|Split the icon to animate its shapes one by one: a bell's clapper, a fan's blades.|Splitting again replaces the parts, their groups and their keys.|Splitting…|Spread|Spread across|Spread down|Square|Stage height|Stagger children|Stagger off|Stagger on|Star|Start|Start again after the last step.|Start delay (s)|Start from a template|Start from an icon|Start handle|Started at x {x}, y {y}. Move the cursor and press Enter to finish. Escape cancels.|Starts at|State|State is|State is not|State is not {state_not}|State is {state}|State moved to position {to}.|State {count} added: {when}.|State {i}|State {i} deleted.|States|States (clips) are not exported: the file plays the animation’s own timeline.|Step animation|Step moved to position {to} of {count}.|Step moved to position {to} of {n}.|Step {count} added: {name}.|Step {index} deleted.|Step {index} is skipped|Step {index}: {from} to {to}|Step {i}|Step {i} is locked. Unlock it in Layers.|Steps|Steps jump between values; there is no curve to edit.|Stop drawing|Straight|Straighten all|Streak|Stroke|Stroke colour|Stroke width (icon units)|Sun|Swaps the preset for your own particles: shape, movement, size and colours become editable.|Swirl|Switch|Switch at once|Tap|Target|Text|Text and icon colour|That animation has states of its own: the card skips this state.|That layer is locked. Unlock it in Layers.|The SMIL fallback plays the animation forwards only.|The SVG draws nothing.|The SVG has no shapes to draw.|The SVG is larger than 32 KB.|The SVG is too complex.|The YAML is too large to import (over 1 MB).|The animation is larger than {size} KB.|The animation is not valid: {message}|The animation library is not connected.|The animation would be larger than {max} KB ({size} KB).|The animation's easing ({easingLabel})|The animation's keyframes move the element.|The animation's keyframes move the icon.|The animation's keyframes move the module's icon.|The animation's keyframes move the whole element.|The box of the card's icon or of its text.|The colour is not a valid CSS colour: the file uses currentColor.|The drawing tools are not loaded yet.|The drawing tools are ready.|The drawing tools on this page are from another Magic Card version. Reload the page to draw here.|The entity colour button uses the animation colour (the card entry's colour, else the entity's).|The entity’s value drives {name}. Preview it with the value slider on the stage.|The file could not be read.|The file is {size} KB, larger than 256 KB.|The file loops: the repeat count is not exported.|The first state that matches plays; with no match (or an unavailable entity) the own timeline plays. The entity is the module’s, or the one set on the animation in the card.|The icon at rest, without animation. Ids stay on each part and shape.|The icon has no shapes to export.|The icon has {count, plural, one {# shape} other {# shapes}}: {parts, plural, one {the first # became a part} other {the first # became parts}} (the most a rig holds), the rest stay at rest.|The icon is split into its parts. Select a part, then give it a preset: swing, spin, draw on and more.|The icon library could not be loaded. Check your connection, then try again.|The import and export tool could not be loaded. Reload the page and try again.|The layers panel is hidden, as you collapsed it before. Use the arrow on the edge to show it.|The library holds at most {cap, plural, one {# animation} other {# animations}}: only {fit, plural, one {# more fits} other {# more fit}}, {skipped, plural, one {# was} other {# were}} not imported.|The line draws in over the cycle.|The look changes a little.|The loop hit the size limit, so the file shows fewer particles.|The module's icon moves along the path.|The motion runs back to the start along the path.|The new animation \"{name}\" was not saved last time.|The outline draws in over the cycle, then the shape fills.|The outline is traced, then the part fills in.|The particle engine is not loaded yet.|The parts come from the document's own SVG, one part per shape.|The path draws nothing.|The path has the most points it can hold.|The point it scales and turns around.|The point the group rotates and scales around, in icon units. Drag it on the stage.|The point the part rotates and scales around, in icon units. Drag it on the stage.|The point the preset turns this group around, in icon units. It wins over the group's own pivot. Drag it on the stage.|The point the preset turns this part around, in icon units. It wins over the part's own pivot. Drag it on the stage.|The preset becomes your own animation to edit: motion presets as keyframes, particle and ring presets with their settings.|The preview is scaled to fit the stage|The preview plays on a real magic-card. Load magic-card.js (your dashboard resource) before the animation studio.|The rig holds the most shapes it can (48).|The same seed gives the same loop every time.|The selected keyframes use different easings; a choice here sets all of them.|The shape as a mask|The shape turns with the direction it travels.|The studio works out every particle's path once and plays it as a loop. Light on dashboards.|The timeline also animates the draw here: while it plays, it wins over this binding.|The timeline also animates the opacity here: while it plays, its opacity wins over this binding.|The timeline also animates this colour: while it plays, its colour wins over this binding.|The timeline skews this target: while it plays, the skew replaces this binding’s movement.|The whole element moves along the path from where it rests.|The {noun} panel is hidden, as you left it. Use the arrow on the edge to show it.|These apply to every emitter. Placement is set per emitter.|They replace the preset's look.|This animation|This animation already has 24 animated targets: remove one to add a preset.|This card plays engine {engine}; update Magic Card to play this animation.|This icon could not be loaded. Check the icon id, or try again when Home Assistant is reachable.|This icon has no shapes to animate.|This icon has no shapes to split.|This is the lane's last key: no segment follows it, so its easing has no effect.|This is the last keyframe: no segment follows it, so its easing has no effect.|This keyframe sets no property. Add one with Add property.|This loop hit the size limit, so it shows fewer particles. Lower the count or the child particles.|This loop is large, so it takes longer to load on wall tablets. Lower the count or the child particles.|This part has its own draw keys on the timeline.|This preset could not be opened: {message}|This preset is not available in this version of Magic Card.|Timeline|Timeline view|Timer|Timing|To|To colour|Tool: {tool}|Top|Top left|Top right|To{unit}|Tracks (combined, no order)|Tracks of card parts (name, state, background) are not exported.|Transition|Triangle|Trimmed|Try again|Turbulence|Turn|Turn collider off|Turn collider on|Turn fade off|Turn fade on|Turn on a collider first.|Turn the subject to face the direction of travel.|Turn with the path|Turns to an angle (a needle or a dial).|Unavailable|Under the icon|Undo (Ctrl+Z)|Unexpected element <{element}>.|Ungroup|Units|Unknown preset|Unknown preset. This step is skipped.|Unknown preset: plays nothing.|Unlock|Unlocked|Unsaved changes|Unsupported version (expected 1).|Untitled animation|Up to {parentsLeft} for this emitter. All emitters share {parents} particles.|Use 1-32 lowercase letters, digits, - or _ (starting with a letter or digit).|Use 1-64 lowercase letters, digits, - or _ (starting with a letter or digit).|Use Own timeline to play this animation.|Use a colour or a gradient.|Use a preset name, cubic-bezier(x1, y1, x2, y2) or steps(n).|Use an icon id like mdi:bell-ring.|Use as icon|Use baked loop|Use currentColor|Use filter functions like brightness(1.2) hue-rotate(30deg); url() is not allowed.|Use in card|Use keywords, lengths or percentages, e.g. \"50% 100%\".|Use live simulation|Use the parent's colours|Use up to 8 characters.|Use {emoji}|Used by {count, plural, one {# card} other {# cards}}|Vacuum|Value|Value above|Value above {above}|Value below|Value below {below}|Value bindings|Value bindings are not exported: the file plays at the drawn values.|Valve|Variation|Wave|Weather|Weight|What moves|What to save|When|Whole keyframe|Wind angle (deg)|With reduced motion the card shows its still state: this animation does not play.|X|Y|Zigzag|Zone|Zoom|Zoom in|Zoom in (Ctrl +)|Zoom out|Zoom out (Ctrl -)|Zoomed to the icon while you edit its parts or draw|after {seconds}|after {seconds} s|animated|at end of life|at {angle}°|behind the content|child size|child speed|color_mix needs two colours.|custom:{id}|down|down left|down right|drag {value}|drawing area|draws on|emoji|hidden because another layer is soloed|hidden because {name} is hidden|hidden in the preview|in front of the content|inspector|keyframe|keyframe track|keyframe tracks of {name}|layers|left|lifetime|live|locked|locked because the layer it belongs to is locked|loops|my animations|not on the {tile} tile|not valid|on|on collision|opacity|over the icon|plays once|right|selected|speed|spin|start delay|state|step {i} of {count}|step {i} of {count}, {problem}|the background|the element|the icon|the name|the state|turbulence {value}|under the icon|units|unknown error|up|up left|up right|{animation} (unknown)|{below} hidden|{below} hidden below|{cLIPS_MAX, plural, one {At most # state.} other {At most # states.}}|{cap, plural, one {The library is full (# animation): nothing was imported.} other {The library is full (# animations): nothing was imported.}}|{colours, plural, one {At most # colour} other {At most # colours}}|{count, plural, one {# dot} other {# dots}}|{count, plural, one {# icon} other {# icons}}|{count, plural, one {# keyframe} other {# keyframes}}|{count, plural, one {# keyframe} other {# keyframes}} copied|{count, plural, one {# keyframe} other {# keyframes}} deleted|{count, plural, one {# keyframe} other {# keyframes}} pasted at {at}{skipped}|{count, plural, one {# keyframe} other {# keyframes}} selected.|{count, plural, one {# key} other {# keys}}|{count, plural, one {# key} other {# keys}} on the timeline. Rotate, move, scale, fade and colour this part there.|{count, plural, one {# particle} other {# particles}} · {flow}|{count, plural, one {# part} other {# parts}}|{count, plural, one {# point} other {# points}}|{count, plural, one {# shape} other {# shapes}}|{count, plural, one {# shape} other {# shapes}}, scaled into the icon|{count, plural, one {# step} other {# steps}}|{count, plural, one {# target selected: a preset plays on each (Wave: one after another).} other {# targets selected: a preset plays on each (Wave: one after another).}}|{count, plural, one {# target} other {# targets}}|{count, plural, one {# {shape}} other {# {shape}s}} {trigger}|{count, plural, one {At most # shape fits in a rig.} other {At most # shapes fit in a rig.}}|{count, plural, one {Delete # keyframe} other {Delete # keyframes}}|{count, plural, one {Erase shape} other {Erase shapes}}|{count, plural, one {Group of # part} other {Group of # parts}}|{count, plural, one {Group removed} other {Groups removed}}|{count, plural, one {Grouped # part} other {Grouped # parts}}|{count, plural, one {Import shape} other {Import shapes}}|{count, plural, one {Replace # part} other {Replace # parts}}|{count, plural, one {Split into # part} other {Split into # parts}}|{count, plural, one {Split into # part} other {Split into # parts}} (the first {parts})|{count, plural, one {{names} is not on the {tile} tile. Switch the preview tile to Card to see it.} other {{names} are not on the {tile} tile. Switch the preview tile to Card to see them.}}|{count, plural, one {{name} added, # point.} other {{name} added, # points.}}|{count} of {colours}|{emitters, plural, one {At most # emitter.} other {At most # emitters.}}|{from} to {to}{unit}|{groups, plural, one {A rig has at most # group.} other {A rig has at most # groups.}}|{id} (not found)|{id}: the library is full|{kb} of 32 KB|{key} moves one handle alone.|{key} removes it.|{kind} cannot play in a sequence. This step is skipped.|{label} (the animation moves it)|{label} (the animation moves it) · not on the {tile} tile|{label} at {at}|{label} at {at} · {value}|{label} easing to the next key|{label} is not on the {tile} tile|{label} lane|{label} preset|{label} tool. {hint}|{label} · not on the {tile} tile|{lane} keyframe|{list}, bounce {bounce}|{mAX_SHAPES, plural, one {At most # shape} other {At most # shapes}}|{max, plural, one {At most # animation.} other {At most # animations.}}|{max, plural, one {At most # binding per animation.} other {At most # bindings per animation.}}|{max, plural, one {At most # character.} other {At most # characters.}}|{max, plural, one {At most # entry.} other {At most # entries.}}|{max, plural, one {At most # particle over all emitters.} other {At most # particles over all emitters.}}|{min}–{max} px|{modified} of {total} settings changed|{n, plural, one {# animation} other {# animations}}|{names} share this curve.|{name} (copy {n})|{name} (copy)|{name} added.|{name} animation|{name} copy|{name} hidden in the preview|{name} is locked. Unlock it in Layers.|{name} is now step {to} of {count}|{name} is now {where}.|{name} keyframes|{name} locked|{name} moved behind the content|{name} moved in front of the content|{name} moved {direction}|{name} moved {direction}, position {position} of {count}|{name} moved {where}|{name} no longer soloed|{name} settings|{name} shown in the preview|{name} soloed in the preview|{name} unlocked|{name}, behind the content|{name}, in front of the content|{name}: {count, plural, one {# key} other {# keys}}|{now} of {total} seconds|{panels} hidden|{panels} shown|{particles, plural, one {# particle} other {# particles}} · {emitters, plural, one {# emitter} other {# emitters}}|{parts, plural, one {# part} other {# parts}}, {shapes, plural, one {# shape} other {# shapes}}|{parts, plural, one {# part} other {# parts}}, {shapes, plural, one {# shape} other {# shapes}}, no icon|{pct} % of the input range|{pct}, {seconds} seconds|{pieces, plural, one {Part of # shape} other {Part of # shapes}}|{preset} on {targets}|{room, plural, one {The SVG has too many shapes; at most # fits.} other {The SVG has too many shapes; at most # fit.}}|{seconds} s loop|{shapes, plural, one {At most # shape fits in a rig.} other {At most # shapes fit in a rig.}}|{size} KB|{size} icon units|{steps, plural, one {A sequence has at most # step.} other {A sequence has at most # steps.}}|{steps, plural, one {At most # step} other {At most # steps}}|{steps}, {total} per cycle, {loop}{skipped}.|{target} keyframe|{target} {lane} keyframe|{target} · at {at} · {secs} s|{tracks, plural, one {At most # animated target.} other {At most # animated targets.}}|{tracks, plural, one {This animation has # animated target, the most it can hold. Remove it to animate this part.} other {This animation has # animated targets, the most it can hold. Remove one to animate this part.}}|{where} · {from} to {to}","|||||||||||||||||||||||||||Add color||||||||||||||||||||||||||||||||||||||Animation color||||||||||||||||||Between {min} and {max}; empty uses {intensity}. Timing and color come from the animation settings.|||||Black in an <img>, the text color inline.|||||Blends from the first color to the second.||||||||||||||||Build one from scratch or customize one of the presets. Saved animations appear in every card's animation picker, under My animations.|||||||||||||||||Center|||||||||Child color|||||||||||||||||||||||||||||||Color|Color mix|Color {i}|Color {n}|Color {n}: entity color|Color {n}: {colour}|Color: currentColor|Colors|||||||||||||||||||||||||||||||||||Customize a preset|Customize a preset…||||||||||||||||||||||||||||||||||||||||||Drag to draw. Shift: circle, Alt: from the center.|Drag to draw. Shift: square, Alt: from the center.||||||||||||||Drawing canceled.||||||||||||||||||||||||||||||||||||Entity color|||||||||||||||||||||Fill color|||||||||||||||||||||||From color||||||||Grayscale||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Maximize||||||||||||||||||||||||||||||||||||||||||||||||||||Move, scale, turn and color on a timeline||||||||||||||||||||||||||||||||||||Must be two numbers (colors only for color_mix).|||||||||||||||||||||||||||No colors: particles use the animation color.|||||No keys yet. Add keys on the timeline to rotate, move, scale, fade or color this part.|||||||||None set: the particles take the animation color.|||||Not a valid color.||Not an allowed shadow: x y blur spread color.|||||||||||||||||||||||||||||||||||||||||||Own child color||||||||||||||||||Particles take the colors in turn. Pick one to change it.|||||||||||Paths and shapes only: scripts, styles and links are removed. The shape is filled with the particle color.|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Remove color|Remove color {i}|Remove color {n}|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Shadow color||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||Stroke color|||Swaps the preset for your own particles: shape, movement, size and colors become editable.|||||||Text and icon color|||||||||||||||||||The color is not a valid CSS color: the file uses currentColor.||||The entity color button uses the animation color (the card entry's color, else the entity's).||||||||||||||||||||||||||||||||||||||||||The timeline also animates this color: while it plays, its color wins over this binding.|||||||||||||||||||||||||To color||||||||||||||||||||||||||||||||||||||||Use a color or a gradient.||||||||||Use the parent's colors|||||||||||||||||||||||||||||||||||||||||color_mix needs two colors.|||||||||||||||||||||||||||||||||||||||||||||||||||||||||{colours, plural, one {At most # color} other {At most # colors}}|||||||||{count, plural, one {# key} other {# keys}} on the timeline. Rotate, move, scale, fade and color this part there.|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||",'"{name}" heeft wijzigingen die nog niet zijn opgeslagen.|"{name}" had de vorige keer wijzigingen die niet zijn opgeslagen.|% van de grootte||, groot|, {count} overgeslagen|. Tekst, pictogrammen en achtergrond van de kaart.|0 trekt omlaag, 90 naar links, 180 omhoog, 270 naar rechts.|0 stopt bij de botsing, 1 kaatst terug op volle snelheid.|0,1 s||||; {skipped} overgeslagen (niet voor dit doel of deze baan)|Een ingebakken lus houdt levensduren binnen één lus.|Een clip kan zijn eigen document niet afspelen (gebruik self).|Een SVG-bestand van de animatie dat zich herhaalt|Een SVG-bestand van de ingebakken deeltjes dat zich herhaalt|Een reeks kan zichzelf niet afspelen.|Een reeks duurt zo lang als haar stappen. Kaarten kunnen haar nog schalen met hun Duur.|Een reeks heeft minstens één stap nodig|Ongeveer {percent}% van de deeltjes|Een keyframe toevoegen op de afspeelkop|Een eigenschap toevoegen aan {target}|Voeg een vorm toe om vormen te mengen. Elke vorm krijgt een gewicht.|Een {name}-keyframe toevoegen op de afspeelkop|Toevoegen als vormen|Kleur toevoegen|Emitter toevoegen|Keyframe toevoegen|Bewegingspad toevoegen|Punt toevoegen|Eigenschap toevoegen|Eigenschap toevoegen aan {target} op de afspeelkop ({at})|Vorm toevoegen|Status toevoegen|Stap toevoegen|Voeg de animaties toe die na elkaar worden afgespeeld.|Voeg de tekening toe als vormen over het pictogram, of gebruik haar als het pictogram zelf.|Waardekoppeling toevoegen|{lane}-keyframe toevoegen|{name}-keyframe toevoegen op de afspeelkop|Voegt willekeurige wervelingen toe aan de beweging.|Alarmpaneel|Alle|Alle domeinen|Alle lagen getoond|Alle lagen getoond. Vergrendelingen blijven behouden.|Alle deeltjes|Staat al onderaan|Staat al bovenaan|Ook op {at}|Alt+pijl-omlaag|Alt+pijl-omhoog|Alt+omlaag|Alt+omhoog|Afwisselend|Afwisselend omgekeerd|Een open lijn wordt getekend met haar lijn.|Ankerpunten|Hoek|Hoek (gr.)|Geanimeerde SVG|Geanimeerde SVG gekopieerd|Animatie|Animatiekleur|Animatie-instellingen (Esc)|Een andere track animeert dit doel al.|Boog|Met de pijltjestoetsen verplaats je de cursor, Enter zet punten, Escape annuleert.|Pijltjes verplaatsen het keyframe, Alt en pijltjes gaan naar het volgende, Delete verwijdert het.|Aan het einde van de levensduur|Op de afspeelkop: {filter}|Op de afspeelkop: {text}|Op {at} · {secs} s|Attribuut|Attribuutnamen gebruiken letters, cijfers, _ . en - (geen spaties).|Attribuutnamen gebruiken letters, cijfers, _ . en -.|Achtergrond|Ingebakken lus|Bezig met inbakken…|Gebaseerd op een ingebouwde {kind}|Achter de inhoud|Tussen {min} en {max}; leeg gebruikt {intensity}. Timing en kleur komen uit de animatie-instellingen.|Binaire sensor|Koppeling toegevoegd: {property}.|Koppeling verwijderd.|Koppeling {n}|Zwart in een <img>, de tekstkleur inline.|Lege keyframes|Lege deeltjes|Leeg pad|Lege reeks|Vloeit van de eerste kleur naar de tweede.|Vervagen|Vervaging heeft een eigen baan en wordt aan deze lijst toegevoegd.|Onder|Linksonder|Rechtsonder|Stuiteren|Verhelderen|Naar voren halen|Over het pictogram halen|Vorm naar voren halen|Vorm over het pictogram halen|{name} naar voren halen|{name} over het pictogram halen|Browsers spelen de CSS-keyframes af.|Browsers spelen de CSS-keyframes af; de SMIL-kopie speelt waar CSS-animatie ontbreekt.|Bouw er een vanaf nul of pas een van de voorinstellingen aan. Opgeslagen animaties staan in de animatiekiezer van elke kaart, onder Mijn animaties.|Uitbarsting|Knop|Agenda||Annuleren|Kan niet afspelen|Kaart|Kaart-YAML gekopieerd: plak hem in een module|Kaart-YAML om te kopiëren|Kaartinhoud|Kaartinhoud. Tekst, pictogrammen en achtergrond van de kaart.|Kaartonderdelen|Kaartthema|Kaarten die hem gebruiken, spelen hem niet meer af, tenzij ze een kopie insluiten.|Kaarten gebruiken hem als|Plafond|Midden|Aantal wijzigen|Vulling wijzigen|Puntsoort wijzigen|Snelheid wijzigen|Spreiding wijzigen|Lijn wijzigen|Gewicht wijzigen|Wijzigt ook de laatste lijn. De stippellijn is wat je tekende.|Kleur van kind|Kinddeeltjes|Kinddeeltjes van {name}|Kindvorm|Kinderen barsten uit vanaf het punt waar ze ontstaan.|Kinderen kunnen geen eigen kinderen hebben.|Kies een voorinstelling|Kies een .svg-bestand.|Kies een andere|Bestand kiezen|Cirkel|Pad wissen|Zoekopdracht wissen|Klik op een onderdeel om het op de tijdlijn te animeren. Shift of Ctrl voegt toe aan de selectie; dubbelklik of F2 hernoemt. H verbergt, S solo, L vergrendelt (alleen voorbeeld).|Klik op een vorm om hem te selecteren, sleep om hem te verplaatsen.|Klik of sleep over vormen om ze te verwijderen.|Klik op het canvas om een punt toe te voegen, klik op de lijn om er een in te voegen.|Klik om punten toe te voegen, sleep voor bochten. Klik op het eerste punt om te sluiten, of kies Pad afronden.|Klik om het volgende punt toe te voegen|Klik om het eerste punt te plaatsen|Klimaat|Sluiten|Inspecteur sluiten|Lagen sluiten|Pad sluiten|Gesloten|Gesloten pad|Samenvoegen|{name} inklappen|Botsen met|Botsingen|Kleur|Kleurmenging|Kleur {i}|Kleur {n}|Kleur {n}: entiteitskleur|Kleur {n}: {colour}|Kleur: currentColor|Kleuren|Veelgebruikte emoji|Klaar op|Bevat een link.|Bevat een element dat iets uitvoert of ophaalt.|Bevat een gebeurtenis-handler.|Bevat een externe verwijzing.|Inhoudsvak|Zet het voorinstel om naar eigen deeltjes om het te exporteren.|Omzetten naar eigen deeltjes|Kopieert pictogram: svg en de SVG als kaart-YAML|Kopiëren|Kopiëren (Ctrl+C)|SVG kopiëren|Kopiëren mislukt: selecteer de tekst hieronder en kopieer hem|Keyframes kopiëren|Kopieer eerst keyframes|Hoekstraal|Hoekradius (pictogrameenheden)|De tekengereedschappen konden niet worden geladen.|Aantal|Aantal per keer|Bedekkend|Overvloeien|Ctrl + scrollwiel zoomt|||Cursor op x {x}, y {y}. Druk op Enter om een punt toe te voegen.|Cursor op x {x}, y {y}. Druk op Enter om af te ronden.|Cursor op x {x}, y {y}. Druk op Enter om te beginnen.|Gebogen|Aangepast|Eigen as ({axis})|Eigen curve|Eigen status|Een voorinstelling aanpassen|Een voorinstelling aanpassen…|Knippen|Cyclus|Donkere kaart|Standaard|Standaard ({inherited})|Vertraging|Vertraging tussen kinderen|De vertraging telt vanaf het einde van de vorige stap. Een lege duur gebruikt die van de animatie zelf ({seconds} s).|De vertraging telt vanaf het einde van de vorige stap. Een lege duur gebruikt die van de animatie zelf.|Verwijderen|"{name}" verwijderen?|Verwijderen (Del)|Koppeling verwijderen|Koppeling {n} verwijderen|Handvat verwijderen|Keyframe verwijderen|Keyframes verwijderen|Punt verwijderen|Punten verwijderen|Vorm verwijderen|Status verwijderen|Status {i} verwijderen|Stap verwijderen|Stap {i} verwijderen|{name} verwijderen|"{name}" verwijderd.|Verwijderen mislukt: {message}||Apparaattracker|Richting|Verwerpen|Domein|Deurbel|Stip|Dubbelklik op een punt om het glad of een hoekpunt te maken.|.svg downloaden|Download gestart|Slepen|Sleep een ervan op de tijdlijn, of gebruik de pijltjestoetsen, om ze samen te verplaatsen.|Sleep punten en handvatten.|Sleep om een lijn te tekenen.|Sleep om te tekenen. Shift: cirkel, Alt: vanuit het midden.|Sleep om te tekenen. Shift: vierkant, Alt: vanuit het midden.|Sleep om te verplaatsen (klikt vast; Shift: vrij, Alt: dupliceren). Ctrl-klik voegt een key toe, Shift-klik selecteert een bereik. Pijltjes verplaatsen, Alt en pijltjes gaan naar de volgende key, Delete verwijdert.|Sleep om te herschikken (Alt+omhoog / Alt+omlaag)|Sleep om het canvas te vergroten of verkleinen (dubbelklik: herstellen)|Sleep, of druk op Alt+omhoog of Alt+omlaag, om de stap te verplaatsen.|Tekenen|Teken vrij; de lijn wordt gladgestreken als je loslaat.|Bewegingspad tekenen|Tekenen uit|Tekenen aan|Teken op het canvas waar de vorm langs gaat, beginnend waar hij rust.|Teken het pad dat het geselecteerde onderdeel volgt, beginnend waar het rust.|Tekenen is alleen voor pictogramonderdelen en vormen.|Tekening|Tekenen geannuleerd.|Tekengereedschap|Getekend|Tekent de lijn bij (een batterij of niveau).||Stuur {name} aan met de waarde van de entiteit: draaisnelheid vanuit het percentage van een ventilator, een vulling vanuit een batterijniveau.|Zet hier een .svg-bestand neer|Slagschaduw|Laat de .svg los om te importeren|Dupliceren|Emitter dupliceren|Dubbele id "{id}".|{count, plural, one {Keyframe} other {Keyframes}} dupliceren|{name} dupliceren|Gedupliceerd als "{name}".|Dupliceren mislukt: {message}|Duur|Elk deeltje kiest een snelheid in dit bereik, gemeten in % van de kortste zijde van de kaart per seconde. Bij 100 steekt een deeltje een vierkante kaart in één seconde over.|Elk deeltje draait de kant die het kiest, naar links of rechts.|Versnelling|Versoepeling naar het volgende keyframe|Versoepelingswaarde|De versoepeling van het keyframe bewerken|Effectvoorinstellingen kunnen niet als status afspelen: speelt niets.|Effecten met een eigen laag kunnen niet in een reeks afspelen. Deze stap wordt overgeslagen.||Ellips|Naam van emitter|||Emoji of symbool|Leeg keyframe|Leeg leest de status. Bijvoorbeeld percentage (ventilator) of helderheid (lamp).|Eindhandvat|Solo beëindigen|Voer een emoji of symbool in.|Entiteitskleur|Entiteit is uit|Entiteit is aan|Entiteitswaarde|Wissen|Gebeurtenis|Uitvouwen|{name} uitklappen|Ontploffen en vallen|Exporteren|Alles exporteren|Animaties exporteren|{name} exporteren|{n} geselecteerde exporteren|In- en uitfaden|Uitfaden en weer infaden (0,2 s)|Fadet in met de waarde.|Vallen|Ventilator|Acht|Vullen|Vulkleur||Voorinstellingen filteren|Cyclus afmaken|Pad afronden|Vuurvliegjes|Cyclus passend maken|De hele cyclus passend maken|Herstel eerst de gemarkeerde velden.|Plat|Plat (Z)|Omslaan (X)|Zijwaarts kantelen (Y)|Vloer|Stroom|Een getekend pad volgen|Een pad volgen|Rotatie volgen|Het pad volgen|Eén naar voren|Fontein|Uit de vrije hand|Van|Van kleur|Van{unit}|Voordeur|Gloed|Begrepen|Zwaartekracht|Richting van de zwaartekracht|Zwaartekracht {strength} {direction}|Grijstinten|Raster|Groep|Draaipunt van groep|Groeit met de waarde.|Bevat fouten|Hart|Verbergen en solo zijn niet beschikbaar: het deeltjesvoorbeeld kon niet worden opgebouwd.|Verbergen in voorbeeld|Verbergen in voorbeeld (niet opgeslagen)|Verbergen in voorbeeld: de laag blijft op zijn normale waarde|Verberg {noun} ({keys})|Verbergen, solo en vergrendelen werken alleen in dit voorbeeld.|Hoogste {noun}|Tintverschuiving|Luchtbevochtiger|Pictogram|Pictogram- en emoji-deeltjes worden als stippen geëxporteerd.|Pictogramanimatie|Pictogramanimatie…|Pictogram beweegt alleen het pictogram van de module. Kaarten kunnen het overschrijven.|Pictogramonderdelen|Pictogramonderdelen op het canvas|Pictogram om te splitsen|Pictogram {percent}%|Pictogrammen, emoji of vormen die vallen, stijgen of uitbarsten|Importeren|SVG importeren|Animaties importeren|{count, plural, one {# animatie} other {# animaties}} geïmporteerd.|Voor de inhoud|Ervoor: deeltjes worden over tekst en pictogrammen getekend. Ze blokkeren nooit klikken.|In-uit|Oneindig|Inspecteur|Inspectorpaneel|Wordt gebruikt door {count, plural, one {# kaart} other {# kaarten}}; die spelen hem niet meer af, tenzij ze een kopie insluiten.|Draait mee met de richting waarin het beweegt.|Verder bewerken|Inspecteur open houden||Keyframe-inspecteur|Keyframe-tijdlijn|Keyframe-gereedschap|||Soort|Grootste|Grootste afmeting|Grasmaaier|Laag|Laagacties|Laagacties, {name}|Laagnaam|Lagen|Lagen verborgen in het voorbeeld|Lagenpaneel|Links|Linkerrand|Laat eerst de huidige cyclus eindigen|Bibliotheek|Levensduur (s)|Optillen|Licht|Lichte kaart|Lijn|Lijneinden|Live simulatie|Live simulatie wordt als zijn ingebakken lus geëxporteerd.|Live simulatie draait op elk dashboard dat deze kaart toont en gebruikt meer processor, vooral op wandtablets. De export als geanimeerde SVG speelt in plaats daarvan de ingebakken lus af.|Woonkamer|Pictogrambibliotheek laden…|De {kind}-editor laden…|Laden…|Vergrendelen|Vergrendeld|Vergrendeld. Ontgrendel om te bewerken.|Uiterlijk|Herhalen|Lus uit|Lus aan|Lussnelheid (×)|Lussen|Laagste {noun}|Magic Card is niet geladen op deze pagina||Maximaliseren|Mediaspeler|Onderdelen samenvoegen||Min en max moeten verschillen.|Min mag niet boven max liggen.|Gemengd|Modus|Alleen gewijzigd|Meer voorinstellingen konden niet laden. De ingebouwde voorinstellingen werken nog.|Meer afvlakken: minder punten en een rustiger lijn.|Meer afvlakken: minder punten en een rustiger lijn. De stippellijn is wat je tekende.|Beweging|Bewegingspad|Bewegingspad. Klik om punten toe te voegen, sleep om ze te verplaatsen.|Bewegingspad: selecteer eerst een onderdeel of vorm|Beweging verwijderd|X verplaatsen|Y verplaatsen|Ga eerst weg van het beginpunt.|Omlaag|Omlaag verplaatsen (eronder getekend)|Omlaag verplaatsen (speelt later)|Emitter achter de inhoud zetten|Emitter omlaag verplaatsen|Emitter voor de inhoud zetten|Emitter omhoog verplaatsen|Handvat verplaatsen|Keyframe verplaatsen|Pad verplaatsen|Padpunt verplaatsen|Draaipunt verplaatsen|Punt verplaatsen|Punten verplaatsen|Status {i} omlaag verplaatsen|Status {i} omhoog verplaatsen|Stap verplaatsen|Stap {i} verplaatsen|Verplaats in plaats daarvan het element|Verplaats in plaats daarvan het pictogram|Omhoog|Omhoog verplaatsen (bovenop getekend)|Omhoog verplaatsen (speelt eerder)|Venster verplaatsen|{count, plural, one {Keyframe} other {Keyframes}} verplaatsen|{name} omlaag verplaatsen|{name} omlaag verplaatsen (eronder getekend)|{name} omlaag verplaatsen (speelt later)|{name} omhoog verplaatsen (bovenop getekend)|{name} omhoog verplaatsen (speelt eerder)|{name} {where} verplaatsen|{where} verplaatsen|Verplaats, schaal, draai en kleur op een tijdlijn|Omlaag verplaatst: eronder getekend|Omhoog verplaatst: bovenop getekend|Beweging|Bewegingen|Beweegt mee met: {subject}|Beweegt zijwaarts.|Beweegt het onderdeel langs een curve, vanaf zijn rustpositie. Sleep de punten op het canvas.|Beweegt omhoog of omlaag.|{target} verplaatsen.|Moet 1-16 tekens uit a-z, 0-9 en - zijn, en uniek.|Moet SVG-opmaak zijn.|Moet [min, max] px zijn tussen 1 en 200, min ≤ max.|Moet [min, max] zijn.|Moet een lijst zijn.|Moet een bewegingsvoorinstelling of een eigen keyframes- of padanimatie zijn.|Moet een getal zijn.|Moet een paar [van, naar] zijn.|Moet een deeltjes-, ring- of scènevoorinstelling zijn.|Moet een status (tekst) zijn.|Moet een subpad-index zijn (een geheel getal vanaf 0).|Moet een geheel getal zijn.|Moet een attribuutnaam zijn.|Moet een pictogram-id zijn zoals mdi:bell.|Moet een pictogram-id zijn zoals mdi:star.|Moet een object zijn.|Moet tussen 0 en 100% liggen.|Moet tussen {min} en {max} {unit} liggen.|Moet tussen {min} en {max} liggen.|Moet element, icon, name, state, background, part:<id>, group:<id> of shape:<id> zijn.|Moet een van deze zijn: {options}.|Moet self, none, een voorinstelling of custom:<id> zijn.|Moet tekst van hooguit 40 tekens zijn.|Moet tekst zijn.|Moet drie getallen [x, y, z] zijn, niet allemaal 0.|Moet waar of onwaar zijn.|Moet twee getallen zijn (kleuren alleen voor color_mix).|Moet twee getallen [x, y] zijn.|Moet hooguit 8 tekens zijn (een emoji of een symbool).|Moet afwijken van min.|Mijn animaties|Naam|Naam van {name}|Heeft minstens één item nodig.|Heeft minstens {min} items nodig.|Negatief blaast de regen naar links, positief naar rechts. Het bepaalt de richting van de zwaartekracht.|Nieuw|Nieuwe animatie|Nieuw in deze versie|Nieuwe keyframes|Nieuwe deeltjes|Nieuw pad|Nieuwe reeks|Nieuwe vormen|Volgend keyframe|Geen <svg>-element gevonden.|Geen animatie|Geen animatie komt overeen met “{query}”.|Geen animaties gevonden.|Geen animaties komen overeen met "{query}".|Geen animaties komen overeen.|Nog geen animaties|Nog geen gewijzigde velden.|Geen kleuren: deeltjes gebruiken de animatiekleur.|Geen vrije deeltjes meer. Verlaag een aantal om een emitter toe te voegen.|Geen zwaartekracht|Geen pictogramanimaties komen overeen met "{query}".|Nog geen keyframes: gebruik Eigenschap toevoegen, of dubbelklik op de baan.|Nog geen keys. Voeg keys toe op de tijdlijn om dit onderdeel te draaien, verplaatsen, schalen, te laten vervagen of te kleuren.|Nog geen bewegingspad. Teken er een op het canvas.|Geen voorinstellingen komen overeen met "{query}".|Nog geen eigenschappen geanimeerd. Gebruik Eigenschap toevoegen, of dubbelklik op een baan.|Nog geen vormen: kies een tekengereedschap.|Nog geen stappen|Nog geen stappen. Voeg een clip toe om de reeks te beginnen.|Geen {kind} "{id}" in de rig.|Geen|Niet ingesteld: de deeltjes nemen de animatiekleur.|Normaal|Geen onderdeel van deze rig.|Geen tijdlijnbaan.|Geen geldige animatie-id.|Geen geldige kleur.|Geen geldige versoepeling.|Geen toegestane schaduw: x y vervaging spreiding kleur.|Geen toegestane {kind}-waarde.|Niet gewijzigd: {big}|Niet gevonden|Niet gevonden in Mijn animaties. Deze stap wordt overgeslagen.|Niet geïmporteerd: {list}.|Niet in je animaties: speelt niets tot hij daar is opgeslagen.|Niet op deze tegel|Niet hernoemd: {message}|Niet te serialiseren.|Niet gebruikt|Geen geldige YAML.|Geen geldige paddata (moet met M beginnen).|Niets|Niets (stoppen)|Er wordt niets getekend.|Niets geplakt: die eigenschappen passen hier niet|Er speelt nog niets.|Er is nog niets om te exporteren.|Hier valt nog niets in te stellen.|Getal|Uit|Aan|Bij botsing|Aan betekent actief voor het domein (open, thuis, speelt...).|Eén klik animeert de selectie; stem de keys af op de tijdlijn.||Onion skin: markeer de keyframes rond de afspeelkop|Alleen voor het activeringsmoment.|Alleen keyframe-animaties exporteren als geanimeerde SVG.|Alleen deze eigenschap. Standaard volgt de versoepeling van het keyframe (de animatieversoepeling).|Alleen deze eigenschap. Standaard volgt de versoepeling van het keyframe.|Dekking|Dekking (%)|Openen|Open een deeltjesanimatie om de deeltjes te ontwerpen.|Pad openen|Of begin met de pictogrambibliotheek|Baan|Oorsprong|Uitvoer|Over het pictogram|Eigen SVG|Eigen kinderkleur|Eigen tijdlijn|Verf|Onderdeel|Onderdeelacties|Draaipunt van onderdeel|Onderdeelvoorinstellingen|Onderdeel {i}|Onderdeel {n}|Deeltjes- en reeksanimaties kunnen niet als status afspelen.|Deeltjespictogram|Deeltjeslagen|Deeltjesvoorinstelling|Deeltjessnelheid (% van korte zijde/s)|Deeltjes|Deeltjes langs een pad kunnen niet in een reeks afspelen. Deze stap wordt overgeslagen.|Deeltjes verschijnen en verdwijnen zacht.|Deeltjes spelen op het hele element.|Deeltjes nemen om beurten de kleuren. Kies er een om hem te wijzigen.|Deeltjes volgen het pad na elkaar, over het hele element.|Deeltjes {n}|Onderdelen samengevoegd|Plakken op de afspeelkop in {target} (Ctrl+V)|Keyframes plakken op de afspeelkop|Plak eerst YAML of laad het.|Plak de opmaak van een <svg>.|Pad|Padlagen|Padlagen (geen stapelvolgorde)|Alleen paden en vormen: scripts, stijlen en links worden verwijderd. De vorm wordt gevuld met de deeltjeskleur.|Pauzeren (spatie)|Voorbeeld pauzeren||Pen. Klik om punten toe te voegen, klik op het eerste punt om te sluiten.|Persoon|Fysica|Kies een animatie voor deze stap.|Kies een pictogram, of typ een id zoals mdi:bell-ring.|Draaipunt|Draaipunt van {name}|Draaipunt op het vak van de groep|Draaipunt op het vak van het onderdeel|Draaipunt: {position}||Plaatsing||Afspelen|Afspelen (spatie)|Animaties na elkaar afspelen|Speel de kolommen van een rij of de modules van een kolom na elkaar af.|Afspeelvolgorde|Voorbeeld afspelen|Speel per status van de entiteit iets anders af: een lamp die gloeit als hij aan is en rust als hij uit is. De entiteit is die van de module, of die welke op de animatie in de kaart is ingesteld.|Afspelen|Afspeelsnelheid|Afspeelkop|Speelt|Speelt bij tikken|Speelt deze animatie sneller of langzamer af.|Punt {count} geplaatst. Nogmaals Enter op dezelfde plek rondt de lijn af.|Punten staan in % van het bewegende element, dus het pad schaalt mee.|Punten staan in pixels, bij elke grootte hetzelfde.|Punten springen naar nabije punten van het pictogram en andere vormen.|Punten komen op hele pictogrameenheden. Houd Shift ingedrukt om vrij te plaatsen.|Punten klikken vast op een raster van 10 px. Houd {key} ingedrukt om vrij te plaatsen.|Punten klikken vast op een raster van 5%. Houd {key} ingedrukt om vrij te plaatsen.|Positie|Positie in de cyclus|Voorinstelling|Draaipunt van voorinstelling|Draaipunt van voorinstelling van {name}|Voorbeeld|Voorbeeldentiteit|Voorbeeld verbergt {count, plural, one {# laag} other {# lagen}}|Voorbeeldstatus|Voorbeeldtegel|Voorbeeldwaarde|Voorbeeld met verminderde beweging|Vorig keyframe|Eigenschap|Eigenschapskeys krijgen hun eigen versoepeling; hele keyframes bepalen de versoepeling van het keyframe.|Pseudo-RTL|Straal|Regen|Rechthoek|Opnieuw (Ctrl+Y)|Opnieuw tekenen|Verminderde beweging|Verminderde beweging staat aan, dus het voorbeeld blijft stil.|Pagina opnieuw laden|Door de pagina te herladen gaan wijzigingen verloren die niet zijn opgeslagen. Toch herladen?|Verwijderen|Kleur verwijderen|Kleur {i} verwijderen|Kleur {n} verwijderen|Intekenen verwijderen|Emitter verwijderen|Vulling verwijderen|Uit dit keyframe verwijderen|Beweging verwijderen|Bewegingspad verwijderen|Vorm verwijderen|Vorm {n} verwijderen|Lijn verwijderen|De animatie van dit onderdeel verwijderen|{name} uit dit keyframe verwijderen|Hernoemen|Groep hernoemen|Onderdeel hernoemen|{name} hernoemen|Hernoemd|Hernoemd naar "{clean}".|Hernoemen mislukt: {message}|Herhalen|Aantal herhalingen|Het pad vervangen door een {name}|Vervangen door…|Verplicht.|Draaipunt herstellen|Herstellen naar draaipunt van groep|Herstellen naar draaipunt van onderdeel|{field} terugzetten|Venstergrootte wijzigen|Oorspronkelijke grootte|Niet-opgeslagen wijzigingen herstellen|Niet-opgeslagen wijzigingen herstellen?|Omgekeerd|Richting omkeren|Rechts|Rechterrand||Ringvoorinstelling|Stijgen|Draaien|Rotatie|Draaisnelheid|Rond|Liniaal in procenten van de cyclus of in seconden|Liniaal in procenten; toon seconden|Liniaal in seconden; toon procenten|SMIL-terugval||SVG gekopieerd|SVG-vorm|SVG om te kopiëren|Opslaan|Opslaan (Ctrl+S)|Opslaan als geanimeerde SVG|Opslaan als pictogram|Je wijzigingen opslaan?|"{name}" opgeslagen.|Opslaan mislukt.|Opslaan…|Schaal|Schaal X|Schaal Y|Scènevoorinstelling|Schema|Animaties zoeken|Pictogrammen zoeken|Voorinstellingen zoeken|De pictogrambibliotheek doorzoeken|Seizoensscène|Seconden|Startwaarde|Seed {seed} · draai {span}|Kiezen|Selecteer eerst een onderdeel of vorm.|Selecteer een onderdeel of vorm en teken dan zijn bewegingspad.|Alle {name}-keyframes selecteren (Shift voegt toe)|Selecteer twee of meer onderdelen om ze te groeperen.|{name} selecteren|Naar achteren sturen|Vorm naar achteren sturen|Vorm onder het pictogram sturen|Onder het pictogram sturen|{name} naar achteren sturen|{name} onder het pictogram sturen||Reeks|Reeksstappen|Reeksstappen (speelt van eerste naar laatste)|Reeksen die hem afspelen, slaan die stap over: {names}.|Stel icon of svg in, niet beide.|Stel een van builtin, icon, emoji of svg in.|Stel een van from of svg in.|Stel een van icon, emoji of svg in.|Stel een van state, state_not, entity_on, above of below in.|Instellingen|Schaduw|Schaduw en gloed|Schaduwkleur|Schaduwvoorinstellingen|Schaduw {name}|Vorm|Vormmix|Vorm over het pictogram|Punten van de vorm. Sleep een punt om het te verplaatsen.|Vorm onder het pictogram|Vorm {n}|Vorm {n}: {shape}|Vorm {n}: {shape}, gewicht {weight}|Vormen over het pictogram|Vormen onder het pictogram|Sneltoets: {keys}|Alles tonen|Alle verborgen lagen tonen|Tonen in voorbeeld|Toon {noun} ({keys})|Willekeurig|Willekeurig: nieuwe willekeurige paden|Simulatie|Sirene|Grootte|Grootte (px)|Scheeftrekken|Scheeftrekken X|Scheeftrekken Y|Vertraagt deeltjes in de loop van de tijd.|Kleinste|Kleinste afmeting|Vloeiend|Alles afvlakken|Afvlakking|Afvlakking (s)|Magnetisch raster|Vastklikken op keyframes, de afspeelkop en het raster (houd Shift ingedrukt om vrij te slepen)|Vastklikken|Solo in voorbeeld|Solo in voorbeeld (verbergt de rest, niet opgeslagen)|Solo aan|Een paar panelen zijn verborgen, zoals je ze had achtergelaten. Gebruik de pijlen aan de randen om ze te tonen.|Gelijkmatig verdeeld langs het pad, 1 tot {particles}.|Vonk|Ontstaan|Kinddeeltjes laten ontstaan|Ontstaat {seconds} s na de geboorte (in te stellen in YAML).|Snelheid|Snelheid (% van korte zijde/s)|Draaiing per lus (gr.)|Draait continu, sneller naarmate de waarde stijgt (een ventilator).|Spiraal|Opnieuw splitsen|Splitsen en beginnen|Terug splitsen in vormen|Pictogram splitsen|Splits het pictogram om zijn vormen een voor een te animeren: de klepel van een bel, de bladen van een ventilator.|Opnieuw splitsen vervangt de onderdelen, hun groepen en hun keys.|Bezig met splitsen…|Spreiding|Verspreid over|Verspreid omlaag|Vierkant|Hoogte van het canvas|Kinderen gespreid|Spreiding uit|Spreiding aan|Ster|Begin|Begin opnieuw na de laatste stap.|Startvertraging (s)|Beginnen met een sjabloon|Beginnen met een pictogram|Beginhandvat|Begonnen bij x {x}, y {y}. Verplaats de cursor en druk op Enter om af te ronden. Escape annuleert.|Begint op|Status|Status is|Status is niet|Status is niet {state_not}|Status is {state}|Status verplaatst naar positie {to}.|Status {count} toegevoegd: {when}.|Status {i}|Status {i} verwijderd.|Statussen|Statussen (clips) worden niet geëxporteerd: het bestand speelt de eigen tijdlijn van de animatie.|Stapanimatie|Stap verplaatst naar positie {to} van {count}.|Stap verplaatst naar positie {to} van {n}.|Stap {count} toegevoegd: {name}.|Stap {index} verwijderd.|Stap {index} wordt overgeslagen|Stap {index}: {from} tot {to}|Stap {i}|Stap {i} is vergrendeld. Ontgrendel hem in Lagen.|Stappen|Stappen springen tussen waarden; er is geen curve om te bewerken.|Stoppen met tekenen|Recht|Alles recht maken|Streep|Lijn|Lijnkleur|Lijndikte (pictogrameenheden)|Zon|Vervangt het voorinstel door je eigen deeltjes: vorm, beweging, grootte en kleuren worden bewerkbaar.|Wervel|Schakelaar|Direct wisselen|Tikken|Doel|Tekst|Tekst- en pictogramkleur|Die animatie heeft eigen statussen: de kaart slaat deze status over.|Die laag is vergrendeld. Ontgrendel hem in Lagen.|De SMIL-terugval speelt de animatie alleen vooruit af.|De SVG tekent niets.|De SVG heeft geen vormen om te tekenen.|De SVG is groter dan 32 KB.|De SVG is te complex.|De YAML is te groot om te importeren (meer dan 1 MB).|De animatie is groter dan {size} KB.|De animatie is niet geldig: {message}|De animatiebibliotheek is niet verbonden.|De animatie zou groter worden dan {max} KB ({size} KB).|De versoepeling van de animatie ({easingLabel})|De keyframes van de animatie verplaatsen het element.|De keyframes van de animatie verplaatsen het pictogram.|De keyframes van de animatie verplaatsen het pictogram van de module.|De keyframes van de animatie verplaatsen het hele element.|Het vak van het pictogram of van de tekst van de kaart.|De kleur is geen geldige CSS-kleur: het bestand gebruikt currentColor.|De tekengereedschappen zijn nog niet geladen.|De tekengereedschappen zijn klaar.|De tekengereedschappen op deze pagina komen uit een andere versie van Magic Card. Laad de pagina opnieuw om hier te tekenen.|De entiteitskleurknop gebruikt de animatiekleur (de kleur van het kaartitem, anders die van de entiteit).|De waarde van de entiteit stuurt {name} aan. Bekijk het met de waardeschuif op het canvas.|Het bestand kon niet worden gelezen.|Het bestand is {size} KB, groter dan 256 KB.|Het bestand loopt in een lus: het aantal herhalingen wordt niet geëxporteerd.|De eerste status die past, speelt; zonder match (of bij een niet-beschikbare entiteit) speelt de eigen tijdlijn. De entiteit is die van de module, of die welke op de animatie in de kaart is ingesteld.|Het pictogram in rust, zonder animatie. Id\'s blijven op elk onderdeel en elke vorm staan.|Het pictogram heeft geen vormen om te exporteren.|Het pictogram heeft {count, plural, one {# vorm} other {# vormen}}: {parts, plural, one {het eerste werd een onderdeel} other {de eerste # werden onderdelen}} (het meeste wat een rig aankan), de rest blijft in rust.|Het pictogram is gesplitst in zijn onderdelen. Selecteer een onderdeel en geef het een voorinstelling: slingeren, draaien, intekenen en meer.|De pictogrambibliotheek kon niet worden geladen. Controleer je verbinding en probeer het opnieuw.|Het import- en exportgereedschap kon niet worden geladen. Laad de pagina opnieuw en probeer het nog eens.|Het paneel lagen is verborgen, zoals je het eerder had ingeklapt. Gebruik de pijl aan de rand om het te tonen.|De bibliotheek bevat hooguit {cap, plural, one {# animatie} other {# animaties}}: {fit, plural, one {er past nog maar #} other {er passen nog maar #}}, {skipped, plural, one {# is} other {# zijn}} niet geïmporteerd.|De lijn wordt in de loop van de cyclus ingetekend.|Het uiterlijk verandert een beetje.|De lus haalde de groottelimiet, dus het bestand toont minder deeltjes.|Het pictogram van de module beweegt langs het pad.|De beweging loopt langs het pad terug naar het begin.|De nieuwe animatie "{name}" is de vorige keer niet opgeslagen.|De omtrek wordt in de loop van de cyclus ingetekend, daarna wordt de vorm gevuld.|De omtrek wordt gevolgd, daarna wordt het onderdeel gevuld.|De deeltjesengine is nog niet geladen.|De onderdelen komen uit de eigen SVG van het document, een onderdeel per vorm.|Het pad tekent niets.|Het pad heeft het maximale aantal punten.|Het punt waaromheen het schaalt en draait.|Het punt waaromheen de groep draait en schaalt, in pictogrameenheden. Sleep het op het canvas.|Het punt waaromheen het onderdeel draait en schaalt, in pictogrameenheden. Sleep het op het canvas.|Het punt waaromheen het voorinstel deze groep draait, in pictogrameenheden. Het gaat voor het eigen draaipunt van de groep. Sleep het op het canvas.|Het punt waaromheen het voorinstel dit onderdeel draait, in pictogrameenheden. Het gaat voor het eigen draaipunt van het onderdeel. Sleep het op het canvas.|Het voorinstel wordt je eigen animatie om te bewerken: bewegingsvoorinstellingen als keyframes, deeltjes- en ringvoorinstellingen met hun instellingen.|Het voorbeeld is geschaald om op het canvas te passen|Het voorbeeld speelt op een echte magic-card. Laad magic-card.js (je dashboardbron) vóór de animatiestudio.|De rig bevat het maximale aantal vormen (48).|Dezelfde seed geeft elke keer dezelfde lus.|De geselecteerde keyframes gebruiken verschillende versoepelingen; een keuze hier stelt ze allemaal in.|De vorm als masker|De vorm draait mee met de richting waarin hij beweegt.|De studio berekent het pad van elk deeltje eenmaal en speelt het af als lus. Licht voor dashboards.|De tijdlijn animeert hier ook het intekenen: terwijl hij speelt, gaat hij voor deze koppeling.|De tijdlijn animeert hier ook de dekking: terwijl hij speelt, gaat zijn dekking voor deze koppeling.|De tijdlijn animeert deze kleur ook: terwijl hij speelt, gaat zijn kleur voor deze koppeling.|De tijdlijn trekt dit doel scheef: terwijl hij speelt, vervangt het scheeftrekken de beweging van deze koppeling.|Het hele element beweegt langs het pad vanaf waar het rust.|Het paneel {noun} is verborgen, zoals je het had achtergelaten. Gebruik de pijl aan de rand om het te tonen.|Deze gelden voor elke emitter. Plaatsing wordt per emitter ingesteld.|Ze vervangen het uiterlijk van het voorinstel.|Deze animatie|Deze animatie heeft al 24 geanimeerde doelen: verwijder er een om een voorinstelling toe te voegen.|Deze kaart speelt engine {engine}; werk Magic Card bij om deze animatie af te spelen.|Dit pictogram kon niet worden geladen. Controleer de pictogram-id, of probeer het opnieuw als Home Assistant bereikbaar is.|Dit pictogram heeft geen vormen om te animeren.|Dit pictogram heeft geen vormen om te splitsen.|Dit is de laatste key van de baan: er volgt geen segment, dus de versoepeling heeft geen effect.|Dit is het laatste keyframe: er volgt geen segment, dus de versoepeling heeft geen effect.|Dit keyframe stelt geen eigenschap in. Voeg er een toe met Eigenschap toevoegen.|Deze lus haalde de groottelimiet, dus hij toont minder deeltjes. Verlaag het aantal of de kinddeeltjes.|Deze lus is groot en laadt daarom trager op wandtablets. Verlaag het aantal of de kinddeeltjes.|Dit onderdeel heeft eigen intekenkeys op de tijdlijn.|Deze voorinstelling kon niet worden geopend: {message}|Deze voorinstelling is niet beschikbaar in deze versie van Magic Card.|Tijdlijn|Tijdlijnweergave|||Tot|Naar kleur|Gereedschap: {tool}|Boven|Linksboven|Rechtsboven|Naar{unit}|Tracks (gecombineerd, geen volgorde)|Tracks van kaartonderdelen (naam, status, achtergrond) worden niet geëxporteerd.|Overgang|Driehoek|Bijgesneden|Opnieuw proberen|Turbulentie|Draaien|Botser uitzetten|Botser aanzetten|Vervagen uitzetten|Vervagen aanzetten|Zet eerst een botser aan.|Draai het onderwerp in de reisrichting.|Meedraaien met het pad|Draait naar een hoek (een naald of een wijzerplaat).|Niet beschikbaar|Onder het pictogram|Ongedaan maken (Ctrl+Z)|Onverwacht element <{element}>.|Groep opheffen|Eenheden|Onbekende voorinstelling|Onbekende voorinstelling. Deze stap wordt overgeslagen.|Onbekende voorinstelling: speelt niets.|Ontgrendelen|Ontgrendeld|Niet-opgeslagen wijzigingen|Niet-ondersteunde versie (verwacht 1).|Naamloze animatie|Tot {parentsLeft} voor deze emitter. Alle emitters delen {parents} deeltjes.|Gebruik 1-32 kleine letters, cijfers, - of _ (beginnend met een letter of cijfer).|Gebruik 1-64 kleine letters, cijfers, - of _ (beginnend met een letter of cijfer).|Gebruik Eigen tijdlijn om deze animatie af te spelen.|Gebruik een kleur of een kleurverloop.|Gebruik een voorinstellingsnaam, cubic-bezier(x1, y1, x2, y2) of steps(n).|Gebruik een pictogram-id zoals mdi:bell-ring.|Gebruiken als pictogram|Ingebakken lus gebruiken|currentColor gebruiken|Gebruik filterfuncties zoals brightness(1.2) hue-rotate(30deg); url() is niet toegestaan.|Gebruiken in kaart|Gebruik trefwoorden, lengtes of percentages, bijv. "50% 100%".|Live simulatie gebruiken|De kleuren van de ouder gebruiken|Gebruik hooguit 8 tekens.|{emoji} gebruiken|Gebruikt door {count, plural, one {# kaart} other {# kaarten}}|Stofzuiger|Waarde|Waarde boven|Waarde boven {above}|Waarde onder|Waarde onder {below}|Waardekoppelingen|Waardekoppelingen worden niet geëxporteerd: het bestand speelt af op de getekende waarden.|Klep|Variatie|Golf|Weer|Gewicht|Wat beweegt|Wat opslaan|Wanneer|Heel keyframe|Windhoek (gr.)|Bij verminderde beweging toont de kaart zijn stilstaande staat: deze animatie speelt niet.||||||Inzoomen|Inzoomen (Ctrl +)|Uitzoomen|Uitzoomen (Ctrl -)|Ingezoomd op het pictogram terwijl je zijn onderdelen bewerkt of tekent|na {seconds}|na {seconds} s|geanimeerd|aan het einde van de levensduur|op {angle}°|achter de inhoud|kindgrootte|kindsnelheid|color_mix heeft twee kleuren nodig.||omlaag|linksonder|rechtsonder|sleep {value}|tekengebied|tekent in||verborgen omdat een andere laag solo staat|verborgen omdat {name} verborgen is|verborgen in het voorbeeld|voor de inhoud|||keyframe-track|keyframe-tracks van {name}|lagen|links|levensduur||vergrendeld|vergrendeld omdat de laag waartoe hij behoort vergrendeld is|lussen|mijn animaties|niet op de tegel {tile}|ongeldig|aan|bij botsing|dekking|over het pictogram|speelt eenmaal|rechts|geselecteerd|snelheid|draaiing|startvertraging|status|stap {i} van {count}|stap {i} van {count}, {problem}|de achtergrond|het element|het pictogram|de naam|de status|turbulentie {value}|onder het pictogram|eenheden|onbekende fout|omhoog|linksboven|rechtsboven|{animation} (onbekend)|{below} verborgen|{below} hieronder verborgen|{cLIPS_MAX, plural, one {Hooguit # status.} other {Hooguit # statussen.}}|{cap, plural, one {De bibliotheek is vol (# animatie): er is niets geïmporteerd.} other {De bibliotheek is vol (# animaties): er is niets geïmporteerd.}}|{colours, plural, one {Hooguit # kleur} other {Hooguit # kleuren}}|{count, plural, one {# stip} other {# stippen}}|{count, plural, one {# pictogram} other {# pictogrammen}}||{count, plural, one {# keyframe} other {# keyframes}} gekopieerd|{count, plural, one {# keyframe} other {# keyframes}} verwijderd|{count, plural, one {# keyframe} other {# keyframes}} geplakt op {at}{skipped}|{count, plural, one {# keyframe} other {# keyframes}} geselecteerd.||{count, plural, one {# key} other {# keys}} op de tijdlijn. Draai, verplaats, schaal, fade en kleur dit onderdeel daar.|{count, plural, one {# deeltje} other {# deeltjes}} · {flow}|{count, plural, one {# onderdeel} other {# onderdelen}}|{count, plural, one {# punt} other {# punten}}|{count, plural, one {# vorm} other {# vormen}}|{count, plural, one {# vorm} other {# vormen}}, geschaald in het pictogram|{count, plural, one {# stap} other {# stappen}}|{count, plural, one {# doel geselecteerd: op elk speelt een voorinstelling af (Golf: na elkaar).} other {# doelen geselecteerd: op elk speelt een voorinstelling af (Golf: na elkaar).}}|{count, plural, one {# doel} other {# doelen}}|{count, plural, one {# {shape}} other {# {shape}}} {trigger}|{count, plural, one {Hooguit # vorm past in een rig.} other {Hooguit # vormen passen in een rig.}}|{count, plural, one {# keyframe verwijderen} other {# keyframes verwijderen}}|{count, plural, one {Vorm wissen} other {Vormen wissen}}|{count, plural, one {Groep van # onderdeel} other {Groep van # onderdelen}}|{count, plural, one {Groep verwijderd} other {Groepen verwijderd}}|{count, plural, one {# onderdeel gegroepeerd} other {# onderdelen gegroepeerd}}|{count, plural, one {Vorm importeren} other {Vormen importeren}}|{count, plural, one {Vervang # onderdeel} other {Vervang # onderdelen}}|{count, plural, one {Splitsen in # onderdeel} other {Splitsen in # onderdelen}}|{count, plural, one {Splitsen in # onderdeel} other {Splitsen in # onderdelen}} (de eerste {parts})|{count, plural, one {{names} staat niet op de tegel {tile}. Schakel de voorbeeldtegel naar Kaart om het te zien.} other {{names} staan niet op de tegel {tile}. Schakel de voorbeeldtegel naar Kaart om ze te zien.}}|{count, plural, one {{name} toegevoegd, # punt.} other {{name} toegevoegd, # punten.}}|{count} van {colours}|{emitters, plural, one {Hooguit # emitter.} other {Hooguit # emitters.}}|{from} tot {to}{unit}|{groups, plural, one {Een rig heeft hooguit # groep.} other {Een rig heeft hooguit # groepen.}}|{id} (niet gevonden)|{id}: de bibliotheek is vol|{kb} van 32 KB|{key} verplaatst één handvat afzonderlijk.|{key} verwijdert het.|{kind} kan niet in een reeks afspelen. Deze stap wordt overgeslagen.|{label} (de animatie beweegt het)|{label} (de animatie beweegt het) · niet op de tegel {tile}|{label} op {at}|{label} op {at} · {value}|{label} versoepeling naar de volgende key|{label} staat niet op de tegel {tile}|Baan {label}|Voorinstelling {label}|Gereedschap {label}. {hint}|{label} · niet op de tegel {tile}|{lane}-keyframe|{list}, stuiter {bounce}|{mAX_SHAPES, plural, one {Hooguit # vorm} other {Hooguit # vormen}}|{max, plural, one {Hooguit # animatie.} other {Hooguit # animaties.}}|{max, plural, one {Hooguit # koppeling per animatie.} other {Hooguit # koppelingen per animatie.}}|{max, plural, one {Hooguit # teken.} other {Hooguit # tekens.}}|{max, plural, one {Hooguit # item.} other {Hooguit # items.}}|{max, plural, one {Hooguit # deeltje over alle emitters.} other {Hooguit # deeltjes over alle emitters.}}||{modified} van {total} instellingen gewijzigd|{n, plural, one {# animatie} other {# animaties}}|{names} delen deze curve.|{name} (kopie {n})|{name} (kopie)|{name} toegevoegd.|Animatie {name}|{name} kopie|{name} verborgen in het voorbeeld|{name} is vergrendeld. Ontgrendel hem in Lagen.|{name} is nu stap {to} van {count}|{name} staat nu {where}.|Keyframes van {name}|{name} vergrendeld|{name} achter de inhoud gezet|{name} voor de inhoud gezet|{name} {direction} verplaatst|{name} {direction} verplaatst, positie {position} van {count}|{name} {where} verplaatst|{name} staat niet meer solo|Instellingen van {name}|{name} getoond in het voorbeeld|{name} solo in het voorbeeld|{name} ontgrendeld|{name}, achter de inhoud|{name}, voor de inhoud||{now} van {total} seconden|{panels} verborgen|{panels} getoond|{particles, plural, one {# deeltje} other {# deeltjes}} · {emitters, plural, one {# emitter} other {# emitters}}|{parts, plural, one {# onderdeel} other {# onderdelen}}, {shapes, plural, one {# vorm} other {# vormen}}|{parts, plural, one {# onderdeel} other {# onderdelen}}, {shapes, plural, one {# vorm} other {# vormen}}, geen pictogram|{pct} % van het invoerbereik|{pct}, {seconds} seconden|{pieces, plural, one {Deel van # vorm} other {Deel van # vormen}}|{preset} op {targets}|{room, plural, one {De SVG heeft te veel vormen; er past nog maar #.} other {De SVG heeft te veel vormen; er passen nog maar #.}}|Lus van {seconds} s|{shapes, plural, one {Hooguit # vorm past in een rig.} other {Hooguit # vormen passen in een rig.}}||{size} pictogrameenheden|{steps, plural, one {Een reeks heeft hooguit # stap.} other {Een reeks heeft hooguit # stappen.}}|{steps, plural, one {Hooguit # stap} other {Hooguit # stappen}}|{steps}, {total} per cyclus, {loop}{skipped}.|{target}-keyframe|{target} {lane}-keyframe|{target} · op {at} · {secs} s|{tracks, plural, one {Hooguit # geanimeerd doel.} other {Hooguit # geanimeerde doelen.}}|{tracks, plural, one {Deze animatie heeft # geanimeerd doel, het maximum. Verwijder het om dit onderdeel te animeren.} other {Deze animatie heeft # geanimeerde doelen, het maximum. Verwijder er een om dit onderdeel te animeren.}}|{where} · {from} tot {to}']),ds=e=>e.length<2?e[0]??"":new Intl.ListFormat(cs(),{style:"long",type:"conjunction"}).format(e),ps="sensor.mc_studio_living_room",hs=[{id:"icon",label:370,icon:"mdi:bell-ring-outline",targets:["element","icon"]},{id:"button",label:111,icon:"mdi:gesture-tap-button",targets:["element","icon","name"]},{id:"text",label:921,icon:"mdi:format-text",targets:["element","name"]},{id:"card",label:116,icon:"mdi:card-text-outline",targets:["element","icon","name","state","background"],entities:{[ps]:{state:"21.5",name:424,attributes:{unit_of_measurement:"°C",device_class:"temperature",state_class:"measurement"}}}}],us=e=>hs.find(t=>t.id===e)??hs[0];function ms(e,t,i,n){const s={text_align:"center",...n?{animations:n}:{}};switch(e){case"icon":return{id:t,type:"icon",icon:"mdi:bell-ring",size:i?"36px":"64px",design:s};case"button":return{id:t,type:"button",label:as(242),icon:"mdi:bell",design:s};case"text":return{id:t,type:"text",text:as(348),design:{...s,font_size:i?"18px":"28px",font_weight:"500"}};case"card":return{id:t,type:"info",entity:ps,icon:"mdi:thermometer",show_icon:!0,show_name:!0,show_state:!0,design:{...s,text_align:"left",background_color:"var(--secondary-background-color, #f2f3f5)",border_radius:"12px",padding:i?"8px 10px":"14px 18px"}}}}function gs(e,t){const i=us(e).entities;if(!i)return t;let n=fs.get(t);n||fs.set(t,n=new Map);const s=n.get(e);if(s)return s;const r={};for(const[e,t]of Object.entries(i))r[e]={entity_id:e,state:t.state,attributes:{...t.attributes,friendly_name:as(t.name)},last_changed:"",last_updated:"",context:{id:""}};const a={...t,states:{...r,...t.states??{}}};return n.set(e,a),a}const fs=new WeakMap,vs={"A clip cannot play its own document (use self).":()=>as(15),"A sequence cannot play itself.":()=>as(18),"Another track already animates this target.":()=>as(67),"Children cannot have children of their own.":()=>as(140),"color_mix needs two colours.":()=>as(1103),"Draw-on is only for icon parts and shapes.":()=>as(264),"Min must not be above max.":()=>as(445),"Must be [min, max] px between 1 and 200, min ≤ max.":()=>as(504),"Must be [min, max].":()=>as(505),"Must be 1-16 of a-z, 0-9 and -, and unique.":()=>as(502),"Must be a list.":()=>as(506),"Must be a motion preset or a custom keyframes / path animation.":()=>as(507),"Must be a number.":()=>as(508),"Must be a pair [from, to].":()=>as(509),"Must be a particle, ring or scene preset.":()=>as(510),"Must be a state (text).":()=>as(511),"Must be a subpath index (a whole number from 0).":()=>as(512),"Must be a whole number.":()=>as(513),"Must be an attribute name.":()=>as(514),"Must be an icon id like mdi:bell.":()=>as(515),"Must be an icon id like mdi:star.":()=>as(516),"Must be an object.":()=>as(517),"Must be element, icon, name, state, background, part:<id>, group:<id> or shape:<id>.":()=>as(521),"Must be self, none, a preset or custom:<id>.":()=>as(523),"Must be SVG markup.":()=>as(503),"Must be text of at most 40 characters.":()=>as(524),"Must be text.":()=>as(525),"Must be three numbers [x, y, z], not all 0.":()=>as(526),"Must be true or false.":()=>as(527),"Must be two numbers (colours only for color_mix).":()=>as(528),"Must be two numbers [x, y].":()=>as(529),"Must be up to 8 characters (an emoji or a symbol).":()=>as(530),"Must differ from min.":()=>as(531),"Needs at least one entry.":()=>as(535),"No <svg> element found.":()=>as(547),"Not a part of this rig.":()=>as(571),"Not a timeline lane.":()=>as(572),"Not a valid animation id.":()=>as(573),"Not a valid colour.":()=>as(574),"Not a valid easing.":()=>as(575),"Not serialisable.":()=>as(585),"Not valid path data (it must start with M).":()=>as(588),"Only for the trigger time.":()=>as(604),"Required.":()=>as(736),"Set icon or svg, not both.":()=>as(802),"Set one of builtin, icon, emoji or svg.":()=>as(803),"Set one of from or svg.":()=>as(804),"Set one of icon, emoji or svg.":()=>as(805),"Set one of state, state_not, entity_on, above or below.":()=>as(806),"The path draws nothing.":()=>as(969),"The SVG draws nothing.":()=>as(926),"The SVG has no shapes to draw.":()=>as(927),"The SVG is larger than 32 KB.":()=>as(928),"The SVG is too complex.":()=>as(929),"Unsupported version (expected 1).":()=>as(1046),"Use 1-32 lowercase letters, digits, - or _ (starting with a letter or digit).":()=>as(1049),"Use 1-64 lowercase letters, digits, - or _ (starting with a letter or digit).":()=>as(1050),'Use keywords, lengths or percentages, e.g. "50% 100%".':()=>as(1060)},bs=[[/^At most (\d+) animations\.$/,e=>as(1214,{max:+e[1]})],[/^At most (\d+) characters\.$/,e=>as(1216,{max:+e[1]})],[/^At most (\d+) entries\.$/,e=>as(1217,{max:+e[1]})],[/^At most (\d+) particles over all emitters\.$/,e=>as(1218,{max:+e[1]})],[/^Duplicate id "(.*)"\.$/,e=>as(277,{id:e[1]})],[/^Must be between (\S+) and (\S+)\.$/,e=>as(520,{min:e[1],max:e[2]})],[/^Must be one of: (.+)\.$/,e=>as(522,{options:e[1]})],[/^Needs at least (\d+) entries\.$/,e=>as(536,{min:+e[1]})],[/^No (\w+) "(.*)" in the rig\.$/,e=>as(567,{kind:e[1],id:e[2]})],[/^Not an allowed (\w+) value\.$/,e=>as(577,{kind:e[1]})],[/^The animation is larger than (\d+) KB\.$/,e=>as(931,{size:+e[1]})],[/^The SVG has too many shapes; at most (\d+) fit\.$/,e=>as(1257,{room:+e[1]})],[/^This card plays engine (\d+); update Magic Card to play this animation\.$/,e=>as(995,{engine:+e[1]})]];function ys(e){const t=vs[e];if(t)return t();for(const[t,i]of bs){const n=t.exec(e);if(n)return i(n)}return e}const xs={keyframes:398,particles:633,path:645,sequence:798},_s={keyframes:"mdi:vector-polyline",particles:"mdi:shimmer",path:"mdi:vector-curve",sequence:"mdi:format-list-numbered"};class ws{constructor(e,t=600,i=100){this.current=e,this._mergeMs=t,this._limit=i,this._past=[],this._future=[],this._lastAt=0}push(e,t,i=Date.now()){void 0!==t&&t===this._lastKey&&i-this._lastAt<this._mergeMs&&this._past.length>0||(this._past.push(this.current),this._past.length>this._limit&&this._past.shift()),this.current=e,this._future=[],this._lastKey=t,this._lastAt=i}replace(e){this.current=e,this._future=[]}revert(){const e=this._past.pop();void 0!==e&&(this.current=e,this._lastKey=void 0)}canUndo(){return this._past.length>0}canRedo(){return this._future.length>0}undo(){const e=this._past.pop();if(void 0!==e)return this._future.push(this.current),this.current=e,this._lastKey=void 0,e}redo(){const e=this._future.pop();if(void 0!==e)return this._past.push(this.current),this.current=e,this._lastKey=void 0,e}reset(e){this.current=e,this._past=[],this._future=[],this._lastKey=void 0}}function ks(e,t){const i=e.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,48)||"animation";if(!t(i))return i;for(let e=2;;e++){const n=`${i.slice(0,60)}-${e}`;if(!t(n))return n}}function $s(e,t){const i=as(1224,{name:e});if(!t.has(i))return i.slice(0,80);for(let i=2;;i++){const n=as(1223,{name:e,n:i});if(!t.has(n))return n.slice(0,80)}}function Ms(e){return(e.steps??[]).filter(e=>e.animation.startsWith(st)).map(e=>e.animation.slice(7))}function Ss(e,t,i){const n=i.as??"studio-preview",s={...e,id:n},r=i.still?[]:[{id:"preview",preset:st+n,...i.entity?{entity:i.entity}:{}}],a=(e=>"particles"===e.kind||"path"===e.kind&&"particles"===e.path?.subject||"sequence"===e.kind&&!!e.stagger?.children)(e),o="sequence"===e.kind&&!!e.stagger?.children,l=!a&&r.length?r:void 0,c={type:"custom:magic-card",rows:[{id:"r",layout:o?"1-1-1":"1",columns:(o?["a","b","c"]:["a"]).map(e=>({id:`c${e}`,vertical_align:"center",modules:[ms(i.tile,`m${e}`,!!i.thumb,l)]})),design:{min_height:i.thumb?"112px":"icon"!==i.tile||a?"240px":"144px",border_radius:"12px",...a&&r.length?{animations:r}:{}}}]},d=new Map([[n,s]]);return function(e,t){const i=new Map((n=e.custom_animations,Array.isArray(n)?n.filter(e=>!!e&&"object"==typeof e):n&&"object"==typeof n?Object.entries(n).filter(([,e])=>!!e&&"object"==typeof e).map(([e,t])=>({id:e,...t})):[]).map(e=>[String(e.id),e]));var n;const s=new Map,r=[],a=function(e){const t=new Set,i=e=>{if(Array.isArray(e))e.forEach(i);else if(e&&"object"==typeof e)for(const[n,s]of Object.entries(e))if("custom_animations"!==n)if("preset"===n&&rt(s)){const e=at(s);e&&t.add(e)}else s&&"object"==typeof s&&i(s)};return i(e),[...t]}(e);for(;a.length;){const e=a.shift();if(s.has(e)||r.includes(e))continue;const n=t(e)??i.get(e);if(!n){r.push(e);continue}s.set(e,n);const o=n.steps;for(const e of Array.isArray(o)?o:[])"string"==typeof e?.animation&&e.animation.startsWith(st)&&a.push(at(e.animation))}if(!s.size)return{config:e,embedded:[],missing:r};const o=[...s.keys()];for(const[e,t]of i)s.has(e)||s.set(e,t);return{config:{...e,custom_animations:[...s.values()]},embedded:o,missing:r}}(c,e=>d.get(e)??t(e)).config}function zs(e,t){const i=new Map,n=e=>{if(!i.has(e.id)){i.set(e.id,e);for(const i of Ms(e)){const e=t.get(i);e&&n(e)}}};return e.forEach(n),[...i.values()].map(e=>{const{id:t,name:i,...n}=JSON.parse(JSON.stringify(e));return{id:t,name:i,data:n}})}const Cs=a.AH`:host{--mc-accent:var(--primary-color,#03a9f4);--mc-accent-ink:color-mix(in srgb,var(--primary-color,#03a9f4) 60%,var(--primary-text-color,#212121)); --mc-accent-fill:color-mix(in srgb,var(--primary-color,#03a9f4) 70%,#000);--mc-on-accent:#fff;--mc-accent-tint:color-mix(in srgb,var(--primary-color,#03a9f4) 12%,transparent);--mc-surface:var(--card-background-color,#fff);--mc-surface-2:var(--secondary-background-color,#f2f3f5);--mc-ground:var(--primary-background-color,#fafafa);--mc-text:var(--primary-text-color,#212121);--mc-text-2:var(--secondary-text-color,#5f6368);--mc-divider:var(--divider-color,rgba(0,0,0,.12)); --mc-field-border:var(--secondary-text-color,#727272);--mc-warn-ink:color-mix(in srgb,var(--warning-color,#ff9800) 45%,var(--primary-text-color,#212121));--mc-warn-tint:color-mix(in srgb,var(--warning-color,#ff9800) 12%,transparent);--mc-error-ink:color-mix(in srgb,var(--error-color,#db4437) 75%,var(--primary-text-color,#212121));--mc-success:var(--success-color,#43a047); --mc-sel-module:var(--mc-accent);--mc-sel-module-fill:var(--mc-accent-fill);--mc-sel-module-ink:var(--mc-accent-ink);--mc-sel-module-tint:var(--mc-accent-tint);--mc-sel-col:color-mix(in srgb,var(--success-color,#43a047) 85%,var(--primary-text-color,#212121));--mc-sel-col-fill:color-mix(in srgb,var(--success-color,#43a047) 70%,#000);--mc-sel-col-ink:color-mix(in srgb,var(--success-color,#43a047) 60%,var(--primary-text-color,#212121));--mc-sel-col-tint:color-mix(in srgb,var(--success-color,#43a047) 12%,transparent);--mc-sel-row:color-mix(in srgb,var(--warning-color,#ff9800) 70%,var(--primary-text-color,#212121));--mc-sel-row-fill:color-mix(in srgb,var(--warning-color,#ff9800) 55%,#000);--mc-sel-row-ink:var(--mc-warn-ink);--mc-sel-row-tint:var(--mc-warn-tint);--mc-sel-card:var(--mc-text-2);--mc-sel-card-fill:color-mix(in srgb,var(--secondary-text-color,#5f6368) 70%,#000);--mc-sel-card-ink:color-mix(in srgb,var(--secondary-text-color,#5f6368) 60%,var(--primary-text-color,#212121));--mc-sel-card-tint:color-mix(in srgb,var(--secondary-text-color,#5f6368) 12%,transparent);--mc-canvas:color-mix(in srgb,var(--primary-text-color,#212121) 6%,var(--primary-background-color,#fafafa));--mc-canvas-dot:color-mix(in srgb,var(--primary-text-color,#212121) 16%,transparent);--mc-shadow-float:0 8px 24px rgba(0,0,0,.16),0 2px 6px rgba(0,0,0,.08);--mc-mono:'Roboto Mono',ui-monospace,SFMono-Regular,Consolas,monospace;--mc-radius:8px;--mc-radius-lg:12px; --mc-hit:40px;--mc-font:var(--ha-font-family-body,var(--paper-font-body1_-_font-family,Roboto,system-ui,sans-serif));--mc-focus:var(--mc-accent);--mc-error-tint:color-mix(in srgb,var(--error-color,#db4437) 12%,transparent);--mc-error-fill:color-mix(in srgb,var(--error-color,#db4437) 75%,#000);--mc-success-ink:color-mix(in srgb,var(--success-color,#43a047) 55%,var(--primary-text-color,#212121));--mc-success-tint:color-mix(in srgb,var(--success-color,#43a047) 12%,transparent);--mc-scrim:rgba(0,0,0,.38);font-family:inherit;color:var(--mc-text);caret-color:var(--mc-accent)}@supports (color:color-mix(in srgb,red 50%,blue)){:host{--mc-field-border:color-mix(in srgb,var(--primary-text-color,#212121) 50%,transparent);--mc-focus:color-mix(in srgb,var(--mc-accent) 80%,var(--mc-text))}}@media (pointer:coarse){:host{--mc-hit:44px}}`,As=a.AH`*,*::before,*::after{box-sizing:border-box}::selection{background:var(--mc-accent-tint);color:var(--mc-text)}  .k-module{--k:var(--mc-sel-module);--k-fill:var(--mc-sel-module-fill);--k-ink:var(--mc-sel-module-ink);--k-tint:var(--mc-sel-module-tint)}.k-column{--k:var(--mc-sel-col);--k-fill:var(--mc-sel-col-fill);--k-ink:var(--mc-sel-col-ink);--k-tint:var(--mc-sel-col-tint)}.k-row{--k:var(--mc-sel-row);--k-fill:var(--mc-sel-row-fill);--k-ink:var(--mc-sel-row-ink);--k-tint:var(--mc-sel-row-tint)}.k-card{--k:var(--mc-sel-card);--k-fill:var(--mc-sel-card-fill);--k-ink:var(--mc-sel-card-ink);--k-tint:var(--mc-sel-card-tint)}*{scrollbar-width:thin;scrollbar-color:var(--mc-field-border) transparent}::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:var(--mc-divider);border-radius:9999px;border:2px solid transparent;background-clip:padding-box}::-webkit-scrollbar-thumb:hover{background-color:var(--mc-field-border)}button,input,select,textarea{font:inherit;color:inherit}button{cursor:pointer}:focus-visible{outline:2px solid var(--mc-focus);outline-offset:2px}.mono{font-family:var(--mc-mono);font-size:.8125rem}[hidden]{display:none !important}.sr-only{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap} .seg{display:inline-flex;align-items:stretch;gap:2px;padding:3px;background:var(--mc-surface-2);border:1px solid var(--mc-divider);border-radius:10px;max-width:100%;overflow-x:auto;scrollbar-width:none}.seg::-webkit-scrollbar{display:none}.seg.full{display:flex;width:100%}.seg.full>button{flex:1 0 auto;justify-content:center}.seg>button{display:inline-flex;align-items:center;gap:6px;min-height:32px;padding:0 10px;border:0;border-radius:7px;background:transparent;white-space:nowrap;font-size:.8125rem;font-weight:500;color:var(--mc-text-2);transition:background-color .15s ease-out,color .15s ease-out}.seg>button ha-icon{--mdc-icon-size:18px}.seg>button:hover{color:var(--mc-text);background:color-mix(in srgb,var(--mc-surface) 55%,transparent)}.seg>button[aria-selected='true'],.seg>button[aria-checked='true'],.seg>button.active{background:var(--mc-surface);color:var(--mc-accent-ink);box-shadow:0 0 0 1px var(--mc-divider),0 1px 2px rgba(0,0,0,.08)}.seg>button:focus-visible{outline-offset:-2px} .layout-glyph{display:inline-grid;gap:2px;width:28px;height:14px;flex:none}.layout-glyph i{display:block;min-width:2px;border-radius:2px;background:currentColor;opacity:.45}.seg>button[aria-checked='true'] .layout-glyph i{opacity:.85} .chip{display:inline-flex;align-items:center;gap:4px;min-height:24px;padding:0 10px;border-radius:9999px;border:1px solid var(--mc-divider);background:var(--mc-surface);font-size:.75rem;font-weight:500;line-height:1;color:var(--mc-text-2);white-space:nowrap}.chip ha-icon{--mdc-icon-size:14px}button.chip{min-height:28px}button.chip:hover{border-color:var(--mc-field-border);color:var(--mc-text)}.chip.is-accent{color:var(--mc-accent-ink);border-color:color-mix(in srgb,var(--mc-accent) 45%,transparent);background:var(--mc-accent-tint)}.chip.is-warn{color:var(--mc-warn-ink);border-color:color-mix(in srgb,var(--mc-warn-ink) 40%,transparent);background:var(--mc-warn-tint)}.chip.is-count{min-height:20px;padding:0 8px} .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 16px;border-radius:var(--mc-radius);border:1px solid transparent;font-size:.875rem;font-weight:500;white-space:nowrap;transition:background-color .15s ease-out,border-color .15s ease-out,box-shadow .15s ease-out}.btn ha-icon{--mdc-icon-size:18px}.btn-primary{background:var(--mc-accent-fill);color:var(--mc-on-accent)}.btn-primary:hover{box-shadow:inset 0 0 0 999px rgba(255,255,255,.1)}.btn-primary:active{box-shadow:inset 0 0 0 999px rgba(0,0,0,.1)}.btn-secondary{background:var(--mc-surface);border-color:var(--mc-field-border);color:var(--mc-text)}.btn-secondary:hover{background:var(--mc-surface-2)}.btn-text{background:transparent;color:var(--mc-accent-ink);padding:0 12px}.btn-text:hover{background:var(--mc-accent-tint)}.btn-sm{min-height:32px;padding:0 12px;font-size:.8125rem}.btn:disabled,.icon-btn:disabled{opacity:.45;cursor:not-allowed;box-shadow:none}.icon-btn{display:inline-grid;place-items:center;width:40px;height:40px;flex:none;padding:0;border:0;border-radius:var(--mc-radius);background:transparent;color:var(--mc-text-2);--mdc-icon-size:20px}.icon-btn:hover:not(:disabled){background:var(--mc-surface-2);color:var(--mc-text)}.icon-btn.sm{width:32px;height:32px;--mdc-icon-size:18px}.icon-btn.danger:hover:not(:disabled){color:var(--mc-error-ink)} .field{display:grid;gap:6px;min-width:0}.field-head{display:flex;align-items:center;gap:8px;min-height:24px}.field-head label,.field-head .lbl{font-size:.8125rem;font-weight:500;color:var(--mc-text);flex:1;min-width:0} .field-reset{margin:-4px -6px -4px 0}.help{margin:0;font-size:.75rem;color:var(--mc-text-2)}.help.error{color:var(--mc-error-ink)}.help.lead{font-size:.875rem}.input{width:100%;min-height:40px;margin:0;padding:8px 12px;border:1px solid var(--mc-field-border);border-radius:var(--mc-radius);background:var(--mc-surface);color:var(--mc-text);font-size:.875rem;font-weight:400;line-height:1.4;transition:border-color .15s ease-out,box-shadow .15s ease-out}.input::placeholder{color:var(--mc-text-2);opacity:1}.input:hover{border-color:var(--mc-text-2)}.input:focus{outline:none;border-color:var(--mc-focus);box-shadow:0 0 0 1px var(--mc-focus)}.input:disabled{background:var(--mc-surface-2);color:var(--mc-text-2);cursor:not-allowed} .input[aria-invalid='true']{border-color:var(--mc-error-ink)}.input[aria-invalid='true']:focus{box-shadow:0 0 0 1px var(--mc-error-ink)}textarea.input{resize:vertical;min-height:88px;line-height:1.5;font-family:var(--mc-mono);font-size:.8125rem}.input.mono{font-family:var(--mc-mono);font-size:.8125rem}.with-icon{position:relative}.with-icon>ha-icon{position:absolute;left:12px;inset-inline:12px auto;top:50%;transform:translateY(-50%);--mdc-icon-size:18px;color:var(--mc-text-2);pointer-events:none}.with-icon>.input{padding-left:40px;padding-inline:40px 12px} .with-action>.input{padding-right:44px;padding-inline:12px 44px}.with-icon.with-action>.input{padding-inline:40px 44px}.with-icon>.field-action{position:absolute;right:4px;inset-inline:auto 4px;top:50%;transform:translateY(-50%)}.with-icon + .entity-meta{margin:6px 0 0}.select{position:relative;display:block;min-width:0}.select select{appearance:none;-webkit-appearance:none;padding-right:36px;padding-inline:12px 36px;cursor:pointer}.select>ha-icon{position:absolute;right:10px;inset-inline:auto 10px;top:50%;transform:translateY(-50%);pointer-events:none;color:var(--mc-text-2);--mdc-icon-size:18px}.unit{display:flex;min-width:0;direction:ltr;}.unit>.input{flex:1 1 auto;min-width:7ch;border-radius:var(--mc-radius) 0 0 var(--mc-radius)}.unit>.select{flex:none;width:76px}.unit>.select select{border-radius:0 var(--mc-radius) var(--mc-radius) 0;margin-left:-1px;margin-inline:-1px 0;padding-left:10px;padding-inline:10px 36px}.unit>.input:focus,.unit>.select select:focus{position:relative;z-index:1}.color{display:flex;gap:8px;align-items:center;min-width:0}.color .input{flex:1;min-width:0}.swatch{flex:none;width:40px;height:40px;padding:0;border:1px solid var(--mc-field-border);border-radius:var(--mc-radius);background:none;cursor:pointer}.box-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 12px}.box-side{display:grid;gap:4px;min-width:0}.box-side-label{display:flex;align-items:center;gap:4px;font-size:.75rem;color:var(--mc-text-2);--mdc-icon-size:16px}.box-foot{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:8px}.box-foot .select{width:96px}.switch-row{display:flex;align-items:center;gap:12px;min-height:40px}.switch-row .txt{flex:1;min-width:0;font-size:.8125rem;font-weight:500}.switch-row .txt .help{margin-top:2px;font-weight:400}.switch{position:relative;flex:none;width:40px;height:24px;border-radius:9999px;border:0;padding:0;background:var(--mc-field-border);transition:background-color .15s ease-out}.switch::after{content:'';position:absolute;top:3px;left:3px;inset-inline:3px auto;width:18px;height:18px;border-radius:50%;background:#fff;transition:left .15s ease-out,inset-inline-start .15s ease-out;box-shadow:0 1px 2px rgba(0,0,0,.3)}.switch[aria-checked='true']{background:var(--mc-accent-fill)}.switch[aria-checked='true']::after{left:19px;inset-inline:19px auto}.switch:disabled{opacity:.45;cursor:not-allowed}.sync{display:inline-flex;align-items:center;gap:4px;min-height:24px;padding:0 6px;border:0;border-radius:6px;background:transparent;color:var(--mc-text-2);font-size:.75rem;font-weight:500;white-space:nowrap;--mdc-icon-size:16px}.sync:hover{background:var(--mc-surface-2);color:var(--mc-text)}.sync.is-over{color:var(--mc-warn-ink)}.sync.is-over:hover{background:var(--mc-warn-tint);color:var(--mc-warn-ink)}.entity-meta{display:flex;align-items:center;gap:6px;font-size:.75rem;color:var(--mc-text-2)}.entity-meta .dot,.dot{width:8px;height:8px;border-radius:50%;background:var(--mc-success);flex:none} .group{display:grid;gap:16px}.group + .group{padding-top:20px;border-top:1px solid var(--mc-divider)}.group-head{display:flex;align-items:center;gap:8px;--mdc-icon-size:18px}.group-head>ha-icon{color:var(--mc-text-2)}.group-head h3{margin:0;font-size:.875rem;font-weight:500;flex:1}.cond{border:1px solid var(--mc-divider);border-radius:var(--mc-radius-lg);padding:12px;display:grid;gap:12px}.cond-head{display:flex;align-items:center;gap:8px}.cond-head .n{font-size:.8125rem;font-weight:500;flex:1;min-width:0}.cond-head .n .sub{color:var(--mc-text-2);font-weight:400} .range-list{display:grid;gap:12px}.two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,200px),1fr));gap:16px 12px}.empty{display:grid;justify-items:center;text-align:center;gap:8px;padding:24px 16px;border:1px dashed var(--mc-divider);border-radius:var(--mc-radius-lg)}.empty>ha-icon{--mdc-icon-size:28px;color:var(--mc-text-2)}.empty strong{font-weight:500}.empty p{margin:0;color:var(--mc-text-2);font-size:.8125rem;max-width:32ch}.sectors{display:grid;border:1px solid var(--mc-divider);border-radius:var(--mc-radius-lg);overflow:hidden}.sector + .sector{border-top:1px solid var(--mc-divider)}.sector-btn{width:100%;display:flex;align-items:center;gap:10px;min-height:48px;padding:8px 12px;border:0;background:transparent;text-align:start}.sector-btn:hover{background:var(--mc-surface-2)}.sector-btn:focus-visible{outline-offset:-2px}.sector-btn>ha-icon:first-child{--mdc-icon-size:18px;color:var(--mc-text-2)}.sector-btn .nm{flex:1;min-width:0;font-weight:500}.sector-btn .chev{--mdc-icon-size:20px;color:var(--mc-text-2);transition:transform .15s ease-out}.sector-btn[aria-expanded='true'] .chev{transform:rotate(180deg)}.sector-body{padding:4px 12px 16px;display:grid;gap:16px}.no-results{color:var(--mc-text-2);font-size:.8125rem;padding:12px} .menu{position:absolute;z-index:30;min-width:240px;padding:6px;border-radius:var(--mc-radius-lg);background:var(--mc-surface);border:1px solid var(--mc-divider);box-shadow:var(--mc-shadow-float);display:grid} .menu[popover]{position:fixed;inset:auto;margin:0;color:var(--mc-text);overflow:auto;overscroll-behavior:contain;box-sizing:border-box}.menu button{display:flex;align-items:center;gap:12px;min-height:40px;padding:0 12px;border:0;border-radius:var(--mc-radius);background:transparent;text-align:start}.menu button:hover,.menu button:focus-visible{background:var(--mc-surface-2);outline:none}.menu button:focus-visible{outline:2px solid var(--mc-focus);outline-offset:-2px}.menu button:disabled{opacity:.45;cursor:not-allowed;background:transparent}.menu button.danger,.menu button.danger ha-icon{color:var(--mc-error-ink)}.menu button ha-icon{--mdc-icon-size:18px;color:var(--mc-text-2)}.menu .menu-note{font-size:.75rem;color:var(--mc-text-2);padding:6px 12px 8px}.menu hr{border:0;border-top:1px solid var(--mc-divider);margin:4px 0}@media (prefers-reduced-motion:reduce){*,*::before,*::after{transition-duration:0s !important;animation-duration:0s !important}}`,js=a.AH`:host{--mc-hit-sm:32px;--mc-hit-xs:24px;--mc-radius-tag:6px;--mc-radius-seg:10px;--mc-radius-xl:16px;--mc-ease:.15s ease-out;--mc-shadow-dialog:0 24px 64px rgba(0,0,0,.22),0 4px 12px rgba(0,0,0,.1)}@media (pointer:coarse){:host{--mc-hit-sm:44px;--mc-hit-xs:44px}}`,qs=a.AH`svg.gl{display:block;flex:none}.btn-danger{background:var(--mc-error-fill);color:var(--mc-on-accent)}.btn-danger:hover{box-shadow:inset 0 0 0 999px rgba(255,255,255,.1)}.btn-danger:active{box-shadow:inset 0 0 0 999px rgba(0,0,0,.1)}.btn[aria-pressed='true']{background:var(--mc-accent-tint);color:var(--mc-accent-ink);border-color:color-mix(in srgb,var(--mc-accent) 45%,transparent)}.icon-btn[aria-pressed='true']{background:var(--mc-accent-tint);color:var(--mc-accent-ink)} .btn[aria-disabled='true'],.icon-btn[aria-disabled='true']{opacity:.45;cursor:not-allowed;box-shadow:none} .icon-btn.xs{width:var(--mc-hit-xs,24px);height:var(--mc-hit-xs,24px);border-radius:var(--mc-radius-tag,6px);gap:0;--mdc-icon-size:16px}@media (pointer:coarse){.icon-btn.xs{width:var(--mc-hit,44px);height:var(--mc-hit,44px)}}`,Es=a.AH`.check{appearance:none;flex:none;width:20px;height:20px;margin:0;border:2px solid var(--mc-field-border);border-radius:5px;background:var(--mc-surface);display:inline-grid;place-items:center;cursor:pointer;transition:background-color .15s ease-out,border-color .15s ease-out}.check:checked,.check:indeterminate{border-color:var(--mc-accent-fill);background:var(--mc-accent-fill)}.check:checked::after{content:'';width:10px;height:5px;border:solid var(--mc-on-accent);border-width:0 0 2px 2px;transform:translateY(-1px) rotate(-45deg)}.check:indeterminate::after{content:'';width:10px;height:2px;background:var(--mc-on-accent)}.check:disabled{opacity:.45;cursor:not-allowed}`,Hs=[Cs,As,a.AH`.topbar{display:flex;flex-wrap:wrap;align-items:center;gap:8px 12px;min-height:56px;padding:8px 16px;background:var(--mc-surface);border-bottom:1px solid var(--mc-divider);position:relative;z-index:6}.topbar .title{min-width:0;margin:0;font-size:1rem;font-weight:500;overflow-wrap:anywhere}.topbar .name{width:180px;max-width:40vw;min-width:0}.topbar .spacer{flex:1}`,qs,Es,a.AH`
    :host {
      display: block;
      position: relative;
      height: 100%;
      min-height: 480px;
      overflow: hidden;
      background: var(--mc-ground);
      color: var(--mc-text);
      font-size: 0.875rem;
      line-height: 1.5;
      -webkit-font-smoothing: antialiased;
    }
    /* the live region after the shell: at the top, not one px under it (the host would scroll by it) */
    .shell + .sr-only {
      top: 0;
      left: 0; /* physical */
    }
    .shell {
      display: grid;
      grid-template-rows: auto minmax(0, 1fr);
      height: 100%;
      min-height: 0;
    }

    .grp {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
    }
    .title {
      display: flex;
      align-items: center;
      gap: 8px;
      min-width: 0;
      flex-wrap: wrap;
    }
    .title h1,
    .title strong {
      margin: 0;
      font-size: 1rem;
      font-weight: 500;
      overflow-wrap: anywhere;
    }
    .title-icon {
      --mdc-icon-size: 22px;
      color: var(--mc-text-2);
    }
    .vr {
      width: 1px;
      height: 24px;
      background: var(--mc-divider);
    }
    .spacer {
      flex: 1;
    }
    .chip.kind ha-icon {
      --mdc-icon-size: 14px;
    }
    .btn .chev {
      --mdc-icon-size: 16px;
      margin: 0 -4px 0 -2px;
      margin-inline: -2px -4px;
    }
    .btn-danger {
      background: var(--error-color, #db4437);
      background: color-mix(in srgb, var(--error-color, #db4437) 80%, #000);
      color: #fff;
    }
    .btn-danger:hover {
      box-shadow: inset 0 0 0 999px rgba(255, 255, 255, 0.1);
    }

    /* new animation menu */
    .menu-anchor {
      position: relative;
    }
    .scrim {
      position: fixed;
      inset: 0;
      z-index: 29;
    }
    .new-menu {
      right: 0;
      inset-inline: auto 0;
      top: calc(100% + 6px);
      width: 300px;
    }
    .menu button {
      min-height: 52px;
      padding: 6px 12px;
      align-items: center;
    }
    .mi {
      display: grid;
      min-width: 0;
    }
    .mi-t {
      font-weight: 500;
    }
    .mi-s {
      font-size: 0.75rem;
      color: var(--mc-text-2);
    }

    /* the studio frame: its palette maps onto the studio's tokens, so every field inherits the soft-blueprint look */
    mc-ui-studio-frame,
    mc-ui-studio-frame * {
      --mc-ground: var(--bp-bg);
      --mc-surface: var(--bp-sheet);
      --mc-surface-2: var(--bp-surf2);
      --mc-text: var(--bp-ink);
      --mc-text-2: var(--bp-mute);
      --mc-divider: var(--bp-line);
      --mc-field-border: var(--bp-edge);
      --mc-accent: var(--bp-acc);
      --mc-accent-tint: var(--bp-acc-soft);
      --mc-radius: var(--bp-r-s);
      --mc-font: var(--bp-font-ui);
      --mc-mono: var(--bp-font-mono);
    }
    .shell > mc-ui-studio-frame {
      min-block-size: 0;
    }
    .fr-bar {
      display: flex;
      flex: 1;
      align-items: center;
      gap: var(--bp-s-3);
      min-inline-size: 0;
      block-size: 100%;
    }
    .fr-bar .spacer {
      flex: 1;
    }
    .fr-bar {
      flex-wrap: wrap;
      gap: 4px var(--bp-s-3);
      block-size: auto;
      padding-block: 4px;
    }
    .fr-bar .grp {
      flex: 0 1 auto;
      flex-wrap: wrap;
    }
    .fr-bar .doc-name {
      font-size: var(--bp-t-bar);
    }
    .fr-start {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-block-size: 0;
      background: var(--bp-sheet);
    }
    /* narrow: Layers is a sheet over the stage area, so the top bar stays in view */
    .layers-sheet {
      position: absolute;
      inset: 0;
      z-index: 6;
      display: flex;
      flex-direction: column;
      background: var(--bp-sheet);
    }
    /* the stage and the timeline fill the frame's stage area (its bar, ruler and padding taken off) */
    .center {
      inline-size: 100%;
      block-size: max(360px, calc(100dvh - var(--bp-bar-h) - var(--bp-ruler) - 120px));
      background: var(--mc-surface);
      border: 1px solid var(--bp-line);
      border-radius: var(--bp-r-m);
      box-shadow: var(--bp-shadow-card);
    }
    .insp .ctx {
      margin-inline: -16px;
    }

    /* library */
    :host([editing]) {
      position: fixed;
      inset: 0;
      z-index: 1000;
      height: auto;
    }
    :host(:not([editing])) {
      background: transparent;
    }
    .shell[data-view='library'] {
      grid-template-rows: minmax(0, 1fr);
    }
    .lib {
      overflow: auto;
      min-height: 0;
      padding: 16px;
    }
    .lib-inner {
      display: grid;
      gap: 12px;
      align-content: start;
      min-width: 0;
    }
    .bar {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      align-items: center;
    }
    .search input::-webkit-search-cancel-button {
      cursor: pointer;
    }
    .lib-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 2px;
      min-width: 0;
    }
    .lib-row {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 4px 8px;
      min-height: var(--mc-hit, 40px);
      padding: 2px 4px 2px 8px;
      border-radius: var(--mc-radius, 8px);
      font-size: 0.875rem;
    }
    .lib-row:hover {
      background: var(--mc-surface-2);
    }
    .lib-row.selected {
      background: var(--mc-accent-tint);
    }
    .name-cell {
      flex: 1 1 120px;
      min-width: 0;
    }
    .open {
      display: block;
      border: 0;
      background: transparent;
      padding: 0;
      font: inherit;
      color: inherit;
      text-align: start;
      cursor: pointer;
      border-radius: 4px;
    }
    .open:focus-visible {
      outline: 2px solid var(--mc-focus);
      outline-offset: 2px;
    }
    .open .nm,
    .open .id {
      display: block;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .open:hover .nm {
      text-decoration: underline;
    }
    .open .id {
      font-size: 0.75rem;
      color: var(--mc-text-2);
    }
    .lib-row .chip.kind {
      flex: none;
    }
    .used {
      font-size: 0.8125rem;
      color: var(--mc-text-2);
      white-space: nowrap;
    }
    .acts {
      display: flex;
      gap: 2px;
      margin-inline-start: auto;
    }
    .rename {
      width: 100%;
    }
    .no-results {
      margin: 0;
      color: var(--mc-text-2);
    }
    .lib-empty {
      padding: 32px 16px;
      text-align: center;
    }
    .lib-empty > ha-icon {
      --mdc-icon-size: 32px;
      color: var(--mc-text-2);
    }
    .lib-empty p {
      margin: 8px 0 0;
    }

    /* editor (layout v2): layers | centre (stage, splitter, timeline) | inspector, exactly the
       viewport; only the layers list, the timeline lanes and the inspector scroll */
    .layers {
      display: grid;
      grid-template-rows: auto minmax(0, 1fr);
      min-height: 0;
      min-width: 0;
      overflow: hidden;
      flex: 1;
      min-block-size: 0;
    }
    .layers-head {
      display: flex;
      align-items: center;
      gap: 4px;
      min-height: 44px;
      padding: 4px 6px 4px 16px;
      padding-inline: 16px 6px;
      border-bottom: 1px solid var(--mc-divider);
    }
    .layers-head h2 {
      flex: 1;
      margin: 0;
      font-size: 0.8125rem;
      font-weight: 500;
      color: var(--mc-text-2);
    }
    .layers-body {
      position: relative;
      min-height: 0;
      overflow-y: auto;
      overscroll-behavior: contain;
      padding: 8px;
    }
    .layers-note,
    .layers-help {
      padding: 4px 8px;
    }
    .layers-help {
      margin: 8px 0 0;
    }
    /* registered layers panels (card parts, icon parts, shapes), each under a small heading */
    .layer-group + .layer-group {
      margin-top: 8px;
      padding-top: 8px;
      border-top: 1px solid var(--mc-divider);
    }
    .layer-head {
      margin: 0;
      padding: 4px 8px 6px;
      font-size: 0.6875rem;
      font-weight: 500;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      color: var(--mc-text-2);
    }
    .layer-group:focus {
      outline: none;
    }
    .layer-group > .panel {
      display: block;
    }
    .layer-list {
      display: grid;
      gap: 2px;
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .layer {
      display: flex;
      align-items: center;
      gap: 10px;
      width: 100%;
      min-height: 40px;
      padding: 0 8px 0 10px;
      padding-inline: 10px 8px;
      border: 0;
      border-radius: var(--mc-radius);
      background: transparent;
      color: var(--mc-text);
      font-size: 0.8125rem;
      font-weight: 500;
      text-align: start;
      transition: background-color 0.15s ease-out;
    }
    .layer ha-icon {
      --mdc-icon-size: 18px;
      color: var(--mc-text-2);
      flex: none;
    }
    .layer:hover {
      background: var(--mc-surface-2);
    }
    .layer[aria-pressed='true'] {
      background: var(--mc-accent-tint);
      color: var(--mc-accent-ink);
    }
    .layer[aria-pressed='true'] ha-icon {
      color: var(--mc-accent-ink);
    }
    .layer.off {
      color: var(--mc-text-2);
    }
    .layer.off .layer-name {
      text-decoration: line-through;
      text-decoration-color: var(--mc-field-border);
    }
    .layer-name {
      flex: 1;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .layer-main {
      height: 20px;
      padding: 0 8px;
      font-size: 0.6875rem;
    }
    .layer-count {
      min-width: 20px;
      font-size: 0.75rem;
      font-weight: 400;
      text-align: end;
      color: var(--mc-text-2);
      font-variant-numeric: tabular-nums;
    }
    .center {
      display: grid;
      position: relative;
      grid-template-rows: minmax(0, 1fr);
      min-height: 0;
      min-width: 0;
      overflow: hidden;
    }
    mcas-stage {
      direction: ltr;
    }
    :host([dir='rtl']) .back ha-icon,
    :host([dir='rtl']) .ctx-back ha-icon {
      transform: scaleX(-1);
    }
    .center.with-panel {
      grid-template-rows:
        minmax(${(0,a.iz)(160)}px, calc(var(--split, 0.4) * 100%))
        9px minmax(0, 1fr);
    }
    .splitter {
      position: relative;
      cursor: row-resize;
      touch-action: none;
      background: var(--mc-surface);
      border-top: 1px solid var(--mc-divider);
      border-bottom: 1px solid var(--mc-divider);
    }
    .splitter::before {
      content: '';
      position: absolute;
      left: 50%; /* physical */
      top: 50%;
      width: 40px;
      height: 3px;
      margin: -1.5px 0 0 -20px;
      border-radius: 2px;
      background: var(--mc-field-border);
      transition: background-color 0.15s ease-out;
    }
    /* a 24 px grab area over the 9 px bar (touch) */
    .splitter::after {
      content: '';
      position: absolute;
      left: 0; /* physical */
      right: 0; /* physical */
      top: -8px;
      bottom: -8px;
      z-index: 2;
    }
    .splitter:hover::before,
    .splitter:focus-visible::before {
      background: var(--mc-accent);
    }
    .splitter:focus-visible {
      outline: 2px solid var(--mc-accent);
      outline-offset: -2px;
    }
    .insp:focus {
      outline: none;
    }
    .insp {
      /* the containing block of the panels' absolutely placed bits (sr-only text): they scroll with it */
      position: relative;
      min-height: 0;
      min-width: 0;
      padding: 0 16px 16px;
      display: flex;
      flex-direction: column;
    }
    .ctx {
      position: sticky;
      top: 0;
      z-index: 2;
      display: flex;
      align-items: center;
      gap: 8px;
      min-height: 44px;
      margin: 0 -16px;
      padding: 4px 16px 4px 8px;
      padding-inline: 8px 16px;
      background: var(--mc-surface);
      border-bottom: 1px solid var(--mc-divider);
    }
    .ctx-what {
      flex: 1;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      text-align: end;
      font-size: 0.75rem;
      color: var(--mc-text-2);
    }
    .ctx-note {
      padding-top: 16px;
    }
    .field-head:has(.reset-field) {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
    .reset-field {
      inline-size: 28px;
      block-size: 28px;
      min-inline-size: 28px;
    }
    .mod-count {
      margin: 0;
      padding-block: 12px 4px;
      padding-inline: 16px;
    }
    .zoom-read {
      font-family: var(--mc-font-mono, ui-monospace, monospace);
      font-size: 0.75rem;
      padding-inline: 8px;
    }
    /* collapsible inspector sections: the kit's section head (h3 + .sector-btn) on the studio's flat rule between sections */
    .sec {
      position: relative;
      border-bottom: 1px solid var(--mc-divider);
    }
    .sec:last-child {
      border-bottom: 0;
    }
    .sec .sector-btn {
      width: calc(100% + 8px);
      margin: 0 -4px;
      padding: 8px 4px;
    }
    .sec-err {
      position: absolute;
      top: 20px;
      right: 36px;
      inset-inline: auto 36px;
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--mc-error-ink, var(--error-color, #db4437));
    }
    .sec-body {
      display: grid;
      gap: 16px;
      padding: 0 0 20px;
      min-width: 0;
    }
    .mono.ref {
      font-size: 0.75rem;
    }
    .suffix {
      position: relative;
    }
    .suffix .input {
      padding-inline-end: 36px;
    }
    .suffix span {
      position: absolute;
      right: 12px;
      inset-inline: auto 12px;
      top: 50%;
      transform: translateY(-50%);
      color: var(--mc-text-2);
      pointer-events: none;
    }
    .errors {
      margin: 16px 0 0;
      padding: 10px 12px;
      border-radius: var(--mc-radius);
      background: color-mix(in srgb, var(--error-color, #db4437) 10%, transparent);
      color: var(--mc-error-ink);
      font-size: 0.8125rem;
    }
    .errors strong {
      font-weight: 500;
    }
    .errors ul {
      margin: 4px 0 0;
      padding-inline-start: 18px;
    }
    .errors .mono {
      font-size: 0.75rem;
    }
    /* kind editors (editor-slots.ts): the timeline fills the panel under the stage, the others sit in the inspector */
    .kind-slot {
      display: grid;
      min-width: 0;
    }
    .kind-slot.place-panel {
      grid-auto-rows: minmax(0, 1fr) auto;
      min-height: 0;
      overflow: hidden;
      padding: 8px 12px 10px;
      background: var(--mc-surface);
    }
    .kind-slot.place-panel > .kind-editor {
      min-height: 0;
      height: 100%;
      overflow: auto;
    }
    .kind-editor,
    .panel {
      display: block;
      min-width: 0;
    }
    .insp > .panel + .panel {
      border-top: 1px solid var(--mc-divider);
    }

    /* what goes into an <mc-ui-window>: the body is a grid, the footer's buttons join the window's own footer row */
    .dlg {
      display: grid;
      gap: 12px;
      min-width: 0;
    }
    .dlg p {
      margin: 0;
    }
    .dlg > p:not(.help) {
      color: var(--mc-text-2);
    }
    .foot {
      display: contents;
    }
    textarea.yaml {
      min-height: 260px;
      white-space: pre;
    }
    .file {
      position: relative;
      cursor: pointer;
    }
    .file input {
      position: absolute;
      inset: 0;
      opacity: 0;
      cursor: pointer;
    }
    .file:focus-within {
      outline: 2px solid var(--mc-accent);
      outline-offset: 2px;
    }
    .ok {
      color: var(--mc-text) !important;
    }
    mc-preset-grid.preset-list {
      min-height: 0;
    }

    .toast {
      position: absolute;
      left: 50%; /* physical */
      bottom: 24px;
      transform: translateX(-50%);
      z-index: 40;
      max-width: min(520px, calc(100% - 32px));
      padding: 10px 16px;
      border-radius: var(--mc-radius);
      background: var(--mc-text);
      color: var(--mc-surface);
      box-shadow: var(--mc-shadow-float);
      font-size: 0.8125rem;
      pointer-events: none;
    }

    @media (prefers-reduced-motion: reduce) {
      .splitter::before,
      .layer {
        transition: none;
      }
    }

    @media (max-width: 760px) {
      .lib-row .chip.kind,
      .used {
        display: none;
      }
    }
  `],Ls={keyframes:{tag:"mc-anim-keyframes-editor",place:"panel",title:1007},particles:{tag:"mc-anim-particles-editor",place:"inspector",title:633},path:{tag:"mc-anim-path-editor",place:"inspector",title:645},sequence:{tag:"mc-anim-sequence-editor",place:"inspector",title:905}},Vs="mc-anim-path-host",Os=e=>"undefined"!=typeof customElements&&!!customElements.get(e),Ps={kind:"none"},Rs=[];function Ds(e){const t=Rs.findIndex(t=>t.tag===e.tag&&t.place===e.place);t>=0?Rs[t]=e:Rs.push(e)}function Ns(e,t,i){return Rs.map((e,t)=>({p:e,i:t})).filter(({p:n})=>{if(n.place!==e)return!1;try{return n.when(t,i)}catch{return!1}}).sort((e,t)=>e.p.order-t.p.order||e.i-t.i).map(({p:e})=>e)}const Fs="var(--mc-anim-c)",Ts=[{id:"x",label:457,group:"Transform",icon:"mdi:arrow-left-right",kind:"number",def:{transform:{x:0}}},{id:"y",label:458,group:"Transform",icon:"mdi:arrow-up-down",kind:"number",def:{transform:{y:0}}},{id:"scale",label:772,group:"Transform",icon:"mdi:resize",kind:"number",def:{transform:{scale:1}}},{id:"scale_x",label:773,group:"Transform",icon:"mdi:arrow-expand-horizontal",kind:"number",def:{transform:{scale_x:1}}},{id:"scale_y",label:774,group:"Transform",icon:"mdi:arrow-expand-vertical",kind:"number",def:{transform:{scale_y:1}}},{id:"rotate",label:752,group:"Transform",icon:"mdi:rotate-right",kind:"number",def:{transform:{rotate:0}}},{id:"skew",label:834,group:"Transform",icon:"mdi:vector-polygon",kind:"number",def:{transform:{skew_x:0,skew_y:0}}},{id:"opacity",label:608,group:"Appearance",icon:"mdi:circle-opacity",kind:"number",def:{opacity:1}},{id:"color",label:166,group:"Appearance",icon:"mdi:format-color-text",kind:"css",def:{color:Fs}},{id:"background",label:78,group:"Appearance",icon:"mdi:format-color-fill",kind:"css",def:{background:`color-mix(in srgb, ${Fs} 20%, transparent)`}},{id:"shadow",label:809,group:"Appearance",icon:"mdi:box-shadow",kind:"css",def:{shadow:`0 0 16px 2px ${Fs}`}},{id:"blur",label:94,group:"Appearance",icon:"mdi:blur",kind:"number",def:{blur:0}},{id:"radius",label:190,group:"Appearance",icon:"mdi:rounded-corner",kind:"number",def:{radius:0}},{id:"filter",label:324,group:"Appearance",icon:"mdi:auto-fix",kind:"css",def:{filter:"brightness(1.2)"}}],Bs=[{id:"draw",label:261,group:"Appearance",icon:"mdi:draw",kind:"number",def:{draw:1},rig:!0},{id:"stroke",label:912,group:"Appearance",icon:"mdi:border-color",kind:"css",def:{stroke:Fs},rig:!0}],Is=[...Ts,...Bs],Zs=Object.fromEntries(Is.map(e=>[e.id,e])),Ws=e=>!!e&&/^(part|group|shape):/.test(e),Ks=e=>as(Zs[e].label),Us=e=>Ws(e)?Is:Ts,Gs=[["x","y"],["scale","scale_x","scale_y"],["filter","blur"]],Ys=e=>Gs.find(t=>t.includes(e))??[e],Js={x:["x"],y:["y"],scale:["scale"],scale_x:["scale_x"],scale_y:["scale_y"],rotate:["rotate","axis"],skew:["skew_x","skew_y"]};function Xs(e,t){if("*"===t)return!0;const i=Js[t];return i?"rotate"===t?void 0!==e.transform?.rotate:i.some(t=>void 0!==e.transform?.[t]):void 0!==e[t]}const Qs=e=>Is.every(t=>!Xs(e,t.id));function er(e,t){const i=Js[t];if(i){const t={};for(const n of i){const i=e.transform?.[n];void 0!==i&&(t[n]=Array.isArray(i)?[...i]:i)}return{transform:t}}const n=e[t];return void 0===n?{}:{[t]:n}}function tr(e,t){const i={...e};for(const[n,s]of Object.entries(t))"transform"===n?i.transform={...e.transform??{},...s}:i[n]=s;return i.transform&&!Object.keys(i.transform).length&&delete i.transform,i}function ir(e,t){const i={...e};if(i.easings&&void 0!==i.easings[t]){const e={...i.easings};delete e[t],Object.keys(e).length?i.easings=e:delete i.easings}const n=Js[t];if(n){if(i.transform){const e={...i.transform};for(const t of n)delete e[t];Object.keys(e).length?i.transform=e:delete i.transform}}else delete i[t];return i}const nr=e=>Is.filter(t=>e.some(e=>Xs(e,t.id))).map(e=>e.id),sr=e=>`${e.lane}@${e.at}`;function rr(e){const t=e.lastIndexOf("@");return{lane:e.slice(0,t),at:Number(e.slice(t+1))}}function ar(e,t){return[...new Set(e.filter(e=>Xs(e,t)).map(e=>e.at))].sort((e,t)=>e-t)}const or=(e,t)=>e.some(e=>e.at===t.at&&Xs(e,t.lane));function lr(e,t,i){return e.filter(e=>e.at===i&&Xs(e,t)).reduce((e,i)=>tr(e,er(i,t)),{})}function cr(e,t){let i;for(const n of e)n.at===t&&n.easing&&(i=n.easing);return i}function dr(e,t,i){let n;for(const s of e)s.at===i&&s.easings?.[t]&&(n=s.easings[t]);return n}function pr(e,t,i,n){const s=Ys(t),r=e.map((e,t)=>e.at===i&&s.some(t=>Xs(e,t))?t:-1).filter(e=>e>=0);return r.length?e.map((e,t)=>{if(e.at!==i)return e;const a={...e.easings??{}};for(const e of s)delete a[e];if(n&&r.includes(t))for(const t of s)Xs(e,t)&&(a[t]=n);const o={...e};return Object.keys(a).length?o.easings=a:delete o.easings,o}):e}const hr=e=>e.map((e,t)=>[e,t]).sort((e,t)=>e[0].at-t[0].at||e[1]-t[1]).map(([e])=>e),ur=e=>Math.min(100,Math.max(0,Math.round(100*e)/100));function mr(e,t,i,n,s){const r=s&&Object.keys(s).length?{...s}:void 0,a=e.map(e=>e.at).lastIndexOf(t);if(a<0)return[...e,{at:t,...tr({},i),...n?{easing:n}:{},...r?{easings:r}:{}}];const o=[...e];return o[a]=tr(o[a],i),n&&!o[a].easing&&(o[a]={...o[a],easing:n}),r&&(o[a]={...o[a],easings:{...o[a].easings??{},...r}}),o}function gr(e,t){if("*"===t.lane)return e.filter(e=>e.at!==t.at);const i=t.lane;return e.flatMap(e=>{if(e.at!==t.at||!Xs(e,i))return[e];const n=ir(e,i);return Qs(n)?[]:[n]})}function fr(e,t,i){const n={};for(const s of e)if(s.at===t&&s.easings)for(const[e,t]of Object.entries(s.easings))void 0===t||i&&!i.includes(e)||(n[e]=t);return Object.keys(n).length?n:void 0}function vr(e,t){if(!or(e,t))return;if("*"===t.lane){const i=e.filter(e=>e.at===t.at);return{key:t,frag:i.reduce((e,t)=>tr(e,function(e){return Is.reduce((t,i)=>Xs(e,i.id)?tr(t,er(e,i.id)):t,{})}(t)),{}),easing:cr(e,t.at),easings:fr(e,t.at)}}const i=e.filter(e=>e.at===t.at).every(e=>Is.every(i=>i.id===t.lane||!Xs(e,i.id)));return{key:t,frag:lr(e,t.lane,t.at),easing:i?cr(e,t.at):void 0,easings:fr(e,t.at,[t.lane])}}function br(e){const t=new Set(e.filter(e=>"*"===e.lane).map(e=>e.at)),i=new Set;return e.filter(e=>{const n=sr(e);return!(i.has(n)||"*"!==e.lane&&t.has(e.at)||(i.add(n),0))})}function yr(e,t){if(!e.length)return 0;const i=Math.min(...e.map(e=>e.at)),n=Math.max(...e.map(e=>e.at));return Math.min(100-n,Math.max(-i,t))}function xr(e,t,i,n=!1){const s=br(t).filter(t=>or(e,t)),r=yr(s,i);if(!s.length||0===r&&!n)return{keyframes:e,selection:s};const a=s.map(t=>vr(e,t)).filter(Boolean);let o=e;if(!n)for(const e of a)o=gr(o,e.key);const l=[];for(const e of[...a].sort((e,t)=>("*"===e.key.lane?0:1)-("*"===t.key.lane?0:1))){const t=ur(e.key.at+r);o=mr(o,t,e.frag,e.easing,e.easings),l.push({lane:e.key.lane,at:t})}return{keyframes:hr(o),selection:l}}function _r(e,t){let i=e;for(const e of br(t))i=gr(i,e);return i}const wr=(e,t,i)=>e+(t-e)*i,kr=(e,t=4)=>Math.round(e*10**t)/10**t;function $r(e,t,i,n="ease"){const s=ar(e,t);if(!s.length)return;if(s.includes(i))return lr(e,t,i);const r=s.find(e=>e>i),a=[...s].reverse().find(e=>e<i);if(void 0===a)return lr(e,t,r);if(void 0===r)return lr(e,t,a);const o=(i-a)/(r-a),l=function(e,t){const i=e?.match(/^steps\(\s*(\d+)\s*(?:,\s*([a-z-]+)\s*)?\)$/);if(i){const e=Math.max(1,Number(i[1])),n="start"===i[2]||"jump-start"===i[2];return Math.min(1,(n?Math.ceil(t*e):Math.floor(t*e))/e)}return function([e,t,i,n],s){if(s<=0)return 0;if(s>=1)return 1;const r=t=>3*e*t*(1-t)**2+3*i*t**2*(1-t)+t**3,a=e=>3*t*e*(1-e)**2+3*n*e**2*(1-e)+e**3,o=t=>3*e*(1-t)**2+6*(i-e)*t*(1-t)+3*(1-i)*t**2;let l=s;for(let e=0;e<8;e++){const e=r(l)-s;if(Math.abs(e)<1e-6)return a(l);const t=o(l);if(Math.abs(t)<1e-6)break;l-=e/t}let c=0,d=1;l=s;for(let e=0;e<40;e++){const e=r(l);if(Math.abs(e-s)<1e-6)break;e<s?c=l:d=l,l=(c+d)/2}return a(l)}(na(e)??[0,0,1,1],t)}(((e,t,i)=>dr(e,t,i)??cr(e,i))(e,t,a)??n,o);return function(e){const t={...e};for(const e of["opacity","blur","radius","draw"])void 0!==t[e]&&(t[e]=kr(t[e],"opacity"===e||"draw"===e?3:2));if(t.transform){const e={...t.transform};for(const[t,i]of Object.entries(e))"number"==typeof i&&(e[t]=kr(i,t.startsWith("scale")?3:2));t.transform=e}return t}(function(e,t,i){const n={},s=["opacity","blur","radius","draw"];for(const r of s){const s=e[r],a=t[r];void 0===s&&void 0===a||(n[r]=wr(s??a,a??s,i))}if(e.transform||t.transform){const s=e.transform??{},r=t.transform??{},a={};for(const e of["x","y","scale","scale_x","scale_y","rotate","skew_x","skew_y"]){const t=s[e],n=r[e];void 0===t&&void 0===n||(a[e]=wr(t??n,n??t,i))}const o=s.axis??r.axis;o&&(a.axis=[...o]),n.transform=a}for(const s of["color","background","shadow","filter","stroke"]){const r=i<1?e[s]??t[s]:t[s]??e[s];void 0!==r&&(n[s]=r)}return n}(lr(e,t,a),lr(e,t,r),l))}function Mr(e,t,i){return e.map(e=>{if(e.at!==t)return e;const n={...e};return i?n.easing=i:delete n.easing,n})}function Sr(e,t){const i=br(t).filter(t=>or(e,t));if(!i.length)return;const n=Math.min(...i.map(e=>e.at));return{items:i.map(t=>{const i=vr(e,t);return{lane:t.lane,dt:t.at-n,frag:zr(i.frag),easing:i.easing,...i.easings?{easings:{...i.easings}}:{}}})}}const zr=e=>JSON.parse(JSON.stringify(e));function Cr(e,t,i){let n=e;const s=[],r=[...t.items].sort((e,t)=>("*"===e.lane?0:1)-("*"===t.lane?0:1));for(const e of r){const t=ur(i+e.dt);n=mr(n,t,zr(e.frag),e.easing,e.easings),s.push({lane:e.lane,at:t})}return{keyframes:hr(n),selection:s}}let Ar;const jr=new Set,qr=()=>Ar;function Er(e){Ar=e;for(const e of jr)e()}const Hr={x:e=>({transform:{x:e}}),y:e=>({transform:{y:e}}),scale:e=>({transform:{scale:e}}),scale_x:e=>({transform:{scale_x:e}}),scale_y:e=>({transform:{scale_y:e}}),rotate:e=>({transform:{rotate:e}}),skew:e=>({transform:{skew_x:e,skew_y:0}}),opacity:e=>({opacity:Math.min(1,Math.max(0,e))}),blur:e=>({blur:Math.max(0,e)}),radius:e=>({radius:Math.max(0,e)}),draw:e=>({draw:Math.min(1,Math.max(0,e))})},Lr=["color","background","stroke"];function Vr(e,t,i){if(e===t)return zr(i);const n=e=>["x","y"].includes(e)?"move":["scale","scale_x","scale_y"].includes(e)?"scale":["opacity","draw"].includes(e)?"unit":["blur","radius"].includes(e)?"px":e;if(Hr[e]&&Hr[t]&&n(e)===n(t)){const n=function(e,t){const i=t.transform??{};switch(e){case"x":case"y":case"scale":case"scale_x":case"scale_y":case"rotate":return i[e];case"skew":return i.skew_x;default:{const i=t[e];return"number"==typeof i?i:void 0}}}(e,i);return void 0===n?void 0:Hr[t](n)}if(Lr.includes(e)&&Lr.includes(t)){const n=i[e];return"string"==typeof n?{[t]:n}:void 0}}const Or={element:{label:291,icon:"mdi:card-outline"},icon:{label:370,icon:"mdi:emoticon-outline"},name:{label:533,icon:"mdi:format-text"},state:{label:885,icon:"mdi:information-outline"},background:{label:78,icon:"mdi:texture-box"}};function Pr(e,t){if(Or[t])return as(Or[t].label);const i=/^(part|group|shape):(.+)$/.exec(t);if(!i)return t;const n="part"===i[1]?e.rig?.parts:"group"===i[1]?e.rig?.groups:e.rig?.shapes;return n?.find(e=>e.id===i[2])?.name??i[2]}const Rr=e=>Or[e]?.icon??(e.startsWith("group:")?"mdi:group":e.startsWith("shape:")?"mdi:vector-square":"mdi:puzzle-outline"),Dr=e=>"icon"===e.target?"icon":"element";function Nr(e){const t=[{target:Dr(e),keyframes:e.keyframes??[],main:!0}];for(const i of e.tracks??[])t.some(e=>e.target===i.target)||t.push({target:i.target,keyframes:i.keyframes??[],main:!1});return t}function Fr(e,t){return t===Dr(e)?e.keyframes??[]:e.tracks?.find(e=>e.target===t)?.keyframes??[]}function Tr(e,t,i){if(t===Dr(e))return{...e,keyframes:i};const n=[...e.tracks??[]],s=n.findIndex(e=>e.target===t);if(s>=0){const e={...n[s],keyframes:i};i.length||e.path||e.origin?n[s]=e:n.splice(s,1)}else i.length&&n.push({target:t,keyframes:i});const r={...e};return n.length?r.tracks=n:delete r.tracks,r}const Br=(e,t)=>e.target===t?sr(e):`${e.target}/${sr(e)}`;function Ir(e,t){const i=e.indexOf("/");return{target:i>=0?e.slice(0,i):t,...rr(i>=0?e.slice(i+1):e)}}const Zr=(e,t)=>or(Fr(e,t.target),t);function Wr(e){const t=new Map;for(const i of e){const e=t.get(i.target)??[];e.push({lane:i.lane,at:i.at}),t.set(i.target,e)}return t}function Kr(e,t,i,n=!1){const s=t.filter(t=>Zr(e,t)),r=yr(s,i);if(!s.length||0===r&&!n)return{doc:e,selection:s};let a=e;const o=[];for(const[e,t]of Wr(s)){const i=xr(Fr(a,e),t,r,n);a=Tr(a,e,i.keyframes),o.push(...i.selection.map(t=>({...t,target:e})))}return{doc:a,selection:o}}function Ur(e,t){let i=e;for(const[e,n]of Wr(t))i=Tr(i,e,_r(Fr(i,e),n));return i}function Gr(e,t){const i=t.filter(t=>Zr(e,t));if(!i.length)return;const n=Math.min(...i.map(e=>e.at)),s=[];for(const[t,r]of Wr(i)){const i=Sr(Fr(e,t),r),a=Math.min(...r.map(e=>e.at));for(const e of i?.items??[])s.push({...e,dt:e.dt+a-n,target:t})}return{items:s}}const Yr=[{id:"pct1",label:10},{id:"pct5",label:12},{id:"s01",label:9},{id:"fps30",label:11}],Jr=[1,1.5,2,3,4,6,8,10],Xr=e=>Math.min(10,Math.max(1,Math.round(100*e)/100));function Qr(e,t){return t>0?Jr.find(t=>t>e+.001)??10:[...Jr].reverse().find(t=>t<e-.001)??1}const ea=[1,2,2.5,5];function ta(e){const t=10**Math.floor(Math.log10(e));for(const i of[...ea,10])if(i*t>=e-1e-9)return i*t;return 10*t}const ia={linear:[0,0,1,1],ease:[.25,.1,.25,1],"ease-in":[.42,0,1,1],"ease-out":[0,0,.58,1],"ease-in-out":[.42,0,.58,1]};function na(e){if(!e)return;const t=e.trim(),i=ne.find(e=>e.id===t)?.css??t;if(ia[i])return[...ia[i]];const n=i.match(/^cubic-bezier\(\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*,\s*(-?[\d.]+)\s*\)$/);if(!n)return;const s=n.slice(1).map(Number);return s.every(Number.isFinite)?s:void 0}const sa=ne.map(e=>({id:e.id,label:e.label,bezier:na(e.id)})),ra=e=>Math.round(100*e)/100;function aa(e){const t=e=>ra(Math.min(1,Math.max(0,e))),i=e=>ra(Math.min(2,Math.max(-1,e)));return[t(e[0]),i(e[1]),t(e[2]),i(e[3])]}function oa(e){const t=aa(e),i=sa.find(e=>e.bezier.every((e,i)=>Math.abs(e-t[i])<.005));return i?i.id:`cubic-bezier(${t.join(", ")})`}const la=/^color-mix\(in srgb, var\(--mc-anim-c\) (\d+(?:\.\d+)?)%, transparent\)$/;function ca(e){if(!e)return"";const t=e.trim();if(/^var\(\s*--mc-anim-c\s*\)$/.test(t))return"entity";const i=t.match(la);return i?`entity ${i[1]}%`:t}function da(e){const t=e.trim().match(/^entity(?:\s+(\d+(?:\.\d+)?)%)?$/i);return t?void 0===t[1]||Number(t[1])>=100?Fs:`color-mix(in srgb, ${Fs} ${Number(t[1])}%, transparent)`:e.trim()}const pa=e=>`${e.x}px ${e.y}px ${e.blur}px ${e.spread}px ${e.color}`,ha=[{id:"glow",label:349,value:`0px 0px 16px 2px ${Fs}`},{id:"drop",label:273,value:"0px 6px 16px 0px rgba(0, 0, 0, 0.3)"},{id:"lift",label:416,value:"0px 14px 28px -6px rgba(0, 0, 0, 0.35)"},{id:"none",label:568,value:"none"}],ua=[{id:"bright",label:100,value:"brightness(1.3)"},{id:"hue",label:368,value:"hue-rotate(90deg)"},{id:"gray",label:354,value:"grayscale(1)"},{id:"glow",label:349,value:`drop-shadow(0 0 6px ${Fs})`},{id:"none",label:568,value:"none"}],ma=(e,t)=>"none"===e.trim()?"shadow"===t||"filter"===t:void 0!==vt(e,t),ga=["top left","top","top right","left","center","right","bottom left","bottom","bottom right"],fa=[1015,1014,1016,411,126,747,97,96,98],va=(e,t=2)=>String(kr(e,t));function ba(e,t){if(!t)return"";const i=t.transform??{};switch(e){case"x":return void 0===i.x?"":`${va(i.x,1)} px`;case"y":return void 0===i.y?"":`${va(i.y,1)} px`;case"scale":case"scale_x":case"scale_y":{const t=i[e];return void 0===t?"":`${va(100*t,1)}%`}case"rotate":return void 0===i.rotate?"":`${va(i.rotate,1)}°`;case"skew":return`${va(i.skew_x??0,1)}° ${va(i.skew_y??0,1)}°`;case"opacity":return void 0===t.opacity?"":`${va(100*t.opacity,0)}%`;case"blur":return void 0===t.blur?"":`${va(t.blur,1)} px`;case"radius":return void 0===t.radius?"":`${va(t.radius,1)} px`;case"draw":return void 0===t.draw?"":`${va(100*t.draw,0)}%`;default:{const i=t[e];return void 0===i?"":ca(i).startsWith("entity")?as(65):i}}}const ya=e=>{const t=e?ne.find(t=>t.id===e)?.label:void 0;return void 0!==t?(0,te.t)(t):e?e.startsWith("steps")?as(905):as(206):as(213)};var xa=i(8164);function _a(e){const t=e?(0,$e.Rr)(e)[0]:void 0;if(t)return(0,xa.toEdit)(t);const i=String.raw`([-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?)`,n=new RegExp(String.raw`^\s*[Mm]\s*${i}[\s,]*${i}`).exec(e||"");return{anchors:n?[{x:Number(n[1]),y:Number(n[2])}]:[],closed:!1}}const wa=xa.serialize,ka=xa.bounds,$a=xa.reverse,Ma=xa.translate,Sa=new Map;function za(e,t){let i=Sa.get(e);if(i||(i=e?Nn(e,200):[],Sa.size>32&&Sa.clear(),Sa.set(e,i)),!i.length)return;const n=Math.min(1,Math.max(0,Number.isFinite(t)?t:0))*(i.length-1),s=Math.min(i.length-2,Math.floor(n));if(s<0)return i[0];const r=i[s],a=i[s+1],o=n-s;return{t:r.t+(a.t-r.t)*o,x:r.x+(a.x-r.x)*o,y:r.y+(a.y-r.y)*o,angle:r.angle+(a.angle-r.angle)*o}}const Ca=[{id:"circle",label:145},{id:"figure-8",label:321},{id:"wave",label:1076},{id:"bounce",label:99},{id:"zigzag",label:1087},{id:"spiral",label:860}];function Aa(e,t,i,n,s,r){const a=(n-i)/s,o=[],l=r?s:s+1;for(let n=0;n<l;n++){const s=i+n*a,[c,d]=e(s),[p,h]=t(s),u=[p*a/3,h*a/3];o.push({x:c,y:d,in:r||n>0?[c-u[0],d-u[1]]:void 0,out:r||n<l-1?[c+u[0],d+u[1]]:void 0})}return{anchors:o,closed:r}}function ja(e,t=[0,0],i=40){const[n,s]=t,r=i/40,a=2*Math.PI;let o;switch(e){case"circle":{const e=30*r;o=Aa(t=>[n+e*Math.cos(t),s+e*Math.sin(t)],t=>[-e*Math.sin(t),e*Math.cos(t)],0,a,8,!0);break}case"figure-8":{const e=36*r,t=56*r;o=Aa(i=>[n+e*Math.sin(i),s+t*Math.sin(i)*Math.cos(i)],i=>[e*Math.cos(i),t*Math.cos(2*i)],0,a,8,!0);break}case"wave":{const e=80*r,t=20*r,i=2,l=a*i/e;o=Aa(i=>[n-e/2+i,s-t*Math.sin(l*i)],e=>[1,-t*l*Math.cos(l*e)],0,e,4*i,!1);break}case"bounce":{const e=s+20*r,t=[40,25,12].map(e=>e*r),i=[34,26,20].map(e=>e*r);let a=n-40*r;const l=[{x:a,y:e}];t.forEach((t,n)=>{const s=a+i[n],r=[a+i[n]/2,e-2*t];l[l.length-1].out=[a+2/3*(r[0]-a),e+2/3*(r[1]-e)],l.push({x:s,y:e,in:[s+2/3*(r[0]-s),e+2/3*(r[1]-e)]}),a=s}),o={anchors:l,closed:!1};break}case"zigzag":{const e=[],t=6;for(let i=0;i<=t;i++)e.push({x:n-40*r+80*r*i/t,y:s+(i%2?-15:15)*r});o={anchors:e,closed:!1};break}case"spiral":{const e=2.5,t=a*e,i=40*r/t;o=Aa(e=>[n+i*e*Math.cos(e),s+i*e*Math.sin(e)],e=>[i*(Math.cos(e)-e*Math.sin(e)),i*(Math.sin(e)+e*Math.cos(e))],0,t,4*e,!1);break}}return wa(o)}const qa=e=>"particles"===e.subject&&"percent"===e.units?[50,50]:[0,0],Ea=e=>Math.round(100*e)/100,Ha=e=>`${(0,xa.fmtNum)(e[0])} ${(0,xa.fmtNum)(e[1])}`,La=e=>e.length>1&&(0,$e.xg)(e[0][0],e[e.length-1][3])<1e-6;function Va(e,t){return function(e){const t=[];for(const i of e){if(!i.length)continue;const e=La(i);t.push(`M${Ha(i[0][0])}`),i.forEach((n,s)=>{(0,$e.Wv)(n[1],n[0],n[3])<1e-4&&(0,$e.Wv)(n[2],n[0],n[3])<1e-4?e&&s===i.length-1||t.push(`L${Ha(n[3])}`):t.push(`C${Ha(n[1])} ${Ha(n[2])} ${Ha(n[3])}`)}),e&&t.push("Z")}return t.join(" ")}((0,$e.Mj)(e).map(e=>e.map(e=>e.map(t))))}const Oa=(e,t,i)=>Va(e,e=>[e[0]+t,e[1]+i]);function Pa(e){const t=[];for(const i of(0,$e.Mj)(e))i.length&&(t.push([i[0][0][0],i[0][0][1]]),i.forEach((e,n)=>{n===i.length-1&&La(i)||t.push([e[3][0],e[3][1]])}));return t.map(e=>[Ea(e[0]),Ea(e[1])])}function Ra(e,t=12){return(0,$e.Mj)(e).map(e=>{const i=e.length?[e[0][0]]:[];for(const n of e)for(let e=1;e<=t;e++)i.push((0,$e.Mo)(n,e/t));return i})}function Da(e){let t=1/0,i=1/0,n=-1/0,s=-1/0;for(const r of Ra(e,16))for(const e of r)t=Math.min(t,e[0]),i=Math.min(i,e[1]),n=Math.max(n,e[0]),s=Math.max(s,e[1]);return Number.isFinite(t)?{x:t,y:i,w:n-t,h:s-i}:void 0}function Na(e){const t=(e??"").trim().split(/[\s,]+/).map(Number);return 4===t.length&&t.every(Number.isFinite)&&t[2]>0&&t[3]>0?t:[0,0,24,24]}function Fa(e,t){const[i,n,s,r]=Na(e),[a,o,l,c]=Na(t),d=Math.min(l/s,c/r);return{k:d,dx:a+(l-s*d)/2-i*d,dy:o+(c-r*d)/2-n*d}}const Ta=/^(none|transparent)$/i,Ba=e=>e.fill?!Ta.test(e.fill):!e.stroke,Ia=e=>!!e.stroke&&!Ta.test(e.stroke);function Za(e,t){let i=!1;for(let n=0,s=e.length-1;n<e.length;s=n++){const[r,a]=e[n],[o,l]=e[s];a>t[1]!=l>t[1]&&t[0]<(o-r)*(t[1]-a)/(l-a||1e-9)+r&&(i=!i)}return i}const Wa=e=>[...e.filter(e=>"under"===e.layer),...e.filter(e=>"under"!==e.layer)];function Ka(e,t){let i=1/0;for(const n of Ra(e))for(let e=1;e<n.length;e++)i=Math.min(i,(0,$e.Wv)(t,n[e-1],n[e]));return i}function Ua(e,t,i){const n=Wa(e);for(let e=n.length-1;e>=0;e--){const s=n[e],r=Ra(s.d);if(Ba(s)){let e=!1;for(const i of r)Za(i,t)&&(e=!e);if(e)return s.id}const a=(Ia(s)?(s.stroke_width??1)/2:0)+i;if(Ka(s.d,t)<=a)return s.id}}const Ga=/^[a-z0-9][a-z0-9_-]{0,24}$/;function Ya(e,t="shape"){const i=new Set(e.map(e=>"string"==typeof e?e:e.id)),n=Ga.test(t)?t:"shape";let s=1;for(;i.has(`${n}-${s}`);)s++;return`${n}-${s}`}function Ja(e){const t=JSON.stringify(e),i="undefined"!=typeof TextEncoder?(new TextEncoder).encode(t).length:t.length;return i>65536?as(934,{max:Math.round(64),size:Math.ceil(i/1024)}):void 0}const Xa=e=>e.rig?.shapes??[],Qa=e=>[...(e.rig?.parts??[]).map(e=>e.id),...(e.rig?.groups??[]).map(e=>e.id),...Xa(e).map(e=>e.id)];function eo(e,t){const i=Xa(e);if(i.length>=hn||Qa(e).includes(t.id))return;const n=e.rig??{parts:[]};return{...e,rig:{...n,parts:n.parts??[],shapes:[...i,t]}}}function to(e,t,i){if(!e.rig?.shapes)return e;const n=e.rig.shapes.map(e=>{if(e.id!==t)return e;const n={...e,...i};for(const e of Object.keys(n))void 0===n[e]&&delete n[e];return n});return{...e,rig:{...e.rig,shapes:n}}}function io(e,t,i){const n=[...Xa(e)],s=n.findIndex(e=>e.id===t);if(s<0||!e.rig)return e;const[r]=n.splice(s,1);return n.splice(Math.max(0,Math.min(n.length,i)),0,r),{...e,rig:{...e.rig,shapes:n}}}function no(e,t,i){const n=Xa(e),s=n.findIndex(e=>e.id===t);if(s<0||!e.rig)return e;const r="under"===n[s].layer?"under":"over",a=e=>("under"===e.layer?"under":"over")===r,o=[...n],[l]=o.splice(s,1);let c=-1;if("up"===i)c=n.findIndex((e,t)=>t>s&&a(e));else for(let e=s-1;e>=0;e--)if(a(n[e])){c=e;break}if(c>=0)return o.splice(c,0,l),{...e,rig:{...e.rig,shapes:o}};if("over"===r==("up"===i))return e;const d={...l,layer:"over"===r?"under":"over"};if("over"===d.layer){const e=o.findIndex(e=>"under"!==e.layer);o.splice(e<0?s:e,0,d)}else{let e=-1;o.forEach((t,i)=>{"under"===t.layer&&(e=i)}),o.splice(e<0?s:e+1,0,d)}return{...e,rig:{...e.rig,shapes:o}}}function so(e,t){if(!e.rig?.shapes)return e;const i=`shape:${t}`,n={...e,rig:{...e.rig,shapes:e.rig.shapes.filter(e=>e.id!==t)}};return e.tracks&&(n.tracks=e.tracks.filter(e=>e.target!==i)),e.bindings&&(n.bindings=e.bindings.filter(e=>e.target!==i)),n}const ro=(e,t)=>e.tracks?.find(e=>e.target===t);function ao(e,t,i){const n=e.tracks??[],s=n.findIndex(e=>e.target===i);return t?s<0?n.length>=24?void 0:{...e,tracks:[...n,t]}:{...e,tracks:n.map((e,i)=>i===s?t:e)}:s<0?e:{...e,tracks:n.filter((e,t)=>t!==s)}}const oo=(e,t)=>!!ro(e,t)?.keyframes.some(e=>void 0!==e.draw);function lo(e,t,i,n){const s=ro(e,t);if(!i){if(!s?.path)return e;const i={...s};return delete i.path,ao(e,i.keyframes.length?i:void 0,t)}const r=(0,$e.Mj)(i)[0]?.[0]?.[0];return r?ao(e,{...s??{target:t,keyframes:[]},target:t,path:{d:Oa(i,-r[0],-r[1]),...n?{follow_rotation:!0}:{}}},t):e}const co={target:["hide","solo","lock"],part:["hide","solo","lock"],group:["hide","solo","lock"],shape:["hide","solo","lock"],lane:["hide","solo","lock"],emitter:["hide","solo","lock"],children:["hide","solo","lock"],pshape:[],content:[],path:["lock"],subject:["lock"],step:["hide","solo","lock"]},po={hidden:[],solo:[],locked:[],open:[]},ho=["icon","name","state","background"];function uo(e){const t="particles"===e.kind?e.particles?.sim:void 0;if(!t)return[];const i=t.emitters??[];return[t.id??"main",...i.map((e,t)=>e.id??`e${t+1}`)]}function mo(e){const t=[];"keyframes"===e.kind&&t.push([Dr(e),e.keyframes??[]]);for(const i of e.tracks??[])t.push([i.target,i.keyframes]);return t}function go(e,t){return nr(mo(e).filter(([e])=>e===t).flatMap(([,e])=>e))}function fo(e,t,i){return ar(mo(e).filter(([e])=>e===t).flatMap(([,e])=>e),i)}function vo(e){const t=new Map;if("keyframes"===e.kind){for(const e of ho)t.set(`target:${e}`,"targets");for(const i of e.rig?.parts??[])t.set(`part:${i.id}`,"parts");for(const i of e.rig?.groups??[])t.set(`group:${i.id}`,"parts");for(const i of e.rig?.shapes??[])t.set(`shape:${i.id}`,"under"===i.layer?"under":"over");for(const[i,n]of mo(e))for(const e of nr(n))t.set(`lane:${i}|${e}`,"lanes")}const i="particles"===e.kind?e.particles?.sim:void 0;if(i){const n=uo(e),s=[i.children,...(i.emitters??[]).map(e=>e.children)];n.forEach((e,i)=>{t.set(`emitter:${e}`,"emitters"),s[i]&&t.set(`children:${e}`,"emitters")})}else"particles"===e.kind&&e.particles&&t.set("emitter:main","emitters");return"sequence"===e.kind&&(e.steps??[]).forEach((e,i)=>t.set(`step:${i}`,"steps")),t}const bo="parents:";function yo(e,t){const i=vo(e),n=new Set(t.hidden.filter(e=>i.has(e))),s=new Set(t.solo.filter(e=>i.has(e)));if(!s.size)return n;const r=new Set([...s].map(e=>i.get(e))),a=new Map;for(const t of e.rig?.groups??[])for(const e of t.parts)a.has(e)||a.set(e,t.id);for(const[e,t]of i){if(!r.has(t)||s.has(e))continue;const[i,...o]=e.split(":"),l=o.join(":");if("parts"===t){if("group"===i||s.has(`group:${a.get(l)}`))continue}else if("emitters"===t){const t=l;if("children"===i){if(s.has(`emitter:${t}`))continue}else if(s.has(`children:${t}`)&&!n.has(e)){n.add(`${bo}${t}`);continue}}n.add(e)}return n}function xo(e,t){const[i,...n]=t.split(":"),s=n.join(":");if("part"===i){const t=e.rig?.groups?.find(e=>e.parts.includes(s));return t?`group:${t.id}`:void 0}if("children"===i)return`emitter:${s}`;if("lane"===i){const e=t.slice(5,t.lastIndexOf("|"));return/^(part|group|shape):/.test(e)?e:`target:${e}`}}const _o={hide:"hidden",solo:"solo",lock:"locked"},wo=(e,t,i)=>{for(let n=i,s=0;n&&s<4;n=xo(e,n),s++)if(t.locked.includes(n))return!0;return!1},ko={rotate:"rotate",rotate_speed:"rotate",x:"x",y:"y",scale:"scale",opacity:"opacity",draw:"draw",color_mix:"color"};function $o(e,t){return e.map(e=>t.reduce(ir,e)).filter(e=>!Qs(e))}function Mo(e){const t=e=>/^(part|group|shape):/.test(e)?e:`target:${e}`;return"keys"===e.kind?(e.keys??[]).map(e=>"*"===e.lane?t(e.target):`lane:${e.target}|${e.lane}`):(e.targets?.length?e.targets:e.target?[e.target]:[]).map(t)}function So(e,t,i){return t.locked.length>0&&Mo(i).some(i=>wo(e,t,i))}function zo(e,t,i){return Co(e,e=>e===t?i:t<i?e>t&&e<=i?e-1:e:e>=i&&e<t?e+1:e)}function Co(e,t){const i=e=>{let i=!1;const n=[];for(const s of e){const e=/^step:(\d+)$/.exec(s);if(!e){n.push(s);continue}const r=t(Number(e[1]));r!==Number(e[1])&&(i=!0),r>=0&&n.push(`step:${r}`)}return i?n:e},n={hidden:i(e.hidden),solo:i(e.solo),locked:i(e.locked),open:i(e.open)};return n.hidden===e.hidden&&n.solo===e.solo&&n.locked===e.locked&&n.open===e.open?e:n}const Ao=a.AH`
  .lock-banner {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 0 0 8px;
    padding: 6px 8px;
    border: 1px solid var(--mc-divider);
    border-radius: var(--mc-radius-sm, 6px);
    font-size: 0.8125rem;
    color: var(--mc-text);
  }
  .lock-banner ha-icon {
    --mdc-icon-size: 16px;
    flex: none;
  }
  .lock-banner .txt {
    flex: 1;
    min-width: 0;
  }
`;function jo(e,t,i){return a.qy`<div class="lock-banner" role="status"><ha-icon icon="mdi:lock-outline"></ha-icon><span class="txt">${as(430)}</span><button type="button" class="btn btn-text btn-sm unlock" @click=${n=>{const s=function(e,t,i){const n=new Set;for(const s of i)for(let i=s,r=0;i&&r<4;i=xo(e,i),r++)t.locked.includes(i)&&n.add(i);return n.size?{...t,locked:t.locked.filter(e=>!n.has(e))}:t}(e,t,i);n.currentTarget.dispatchEvent(new CustomEvent("layer-view-change",{detail:{view:s,announce:as(1044)},bubbles:!0,composed:!0}))}}>${as(1043)}</button></div>`}const qo={fall:"fall",rise:"rise",drift:"drift",burst:"burst",orbit:"orbit",spiral:"spiral",fountain:"rise",explode:"burst",wave:"drift",vortex:"spiral",zigzag:"fall",rain:"fall",wander:"drift"},Eo=["circle","square","triangle","star","heart","ring","line","spark"],Ho={parents:60,childrenPerParent:8,elements:160,shapes:6,emitters:4,parts:2,stopsPerElement:32,warnBytes:65536,maxBytes:131072,dt:1/60,geometryVariants:4},Lo={aspect:2};function Vo(e){let t=e>>>0;return()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,1|e),e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}}const Oo=(e,t)=>{let i=Math.imul(e>>>0^Math.imul(t,2654435761),2246822507);return i^=i>>>13,i=Math.imul(i,3266489909),(i^i>>>16)>>>0};function Po(e,[t,i]){const n=Math.min(t,i),s=Math.max(t,i),r=e();return s===n?n:n+r*(s-n)}const Ro=Math.PI/180;function Do(e){const t=e.angle*Ro;return{x:-Math.sin(t)*e.strength,y:Math.cos(t)*e.strength}}const No=e=>e*e*(3-2*e),Fo=(e,t,i)=>e+(t-e)*i;function To(e,t,i,n){const s=Math.floor(t),r=Math.floor(i),a=Math.floor(n),o=No(t-s),l=No(i-r),c=No(n-a),d=(t,i,n)=>function(e,t,i,n){let s=e^Math.imul(t,668265261)^Math.imul(i,374761393)^Math.imul(n,2654435761);return s=Math.imul(s^s>>>15,2246822507),s=Math.imul(s^s>>>13,3266489909),((s^s>>>16)>>>0)/4294967296}(e,s+t,r+i,a+n),p=Fo(Fo(d(0,0,0),d(1,0,0),o),Fo(d(0,1,0),d(1,1,0),o),l),h=Fo(Fo(d(0,0,1),d(1,0,1),o),Fo(d(0,1,1),d(1,1,1),o),l);return 2*Fo(p,h,c)-1}const Bo=2*Math.PI,Io=Math.PI/180,Zo=(e,t,i)=>t/2+(e()-.5)*t*(Math.max(0,i)/100),Wo=e=>Math.max(5,e.spread/2),Ko=(e,t)=>{e.x=t.W/2,e.y=t.H/2},Uo=(e,t,i,n)=>{n.x+=3*(t-e.vx),n.y+=3*(i-e.vy)},Go=(e,t)=>{const i=e.x-t.W/2,n=e.y-t.H/2,s=Math.hypot(i,n)||1e-6,r=i/s,a=n/s;return{r:s,ux:r,uy:a,tx:-a*e.dir,ty:r*e.dir}},Yo=(e,t)=>{const i=t*Io;e.vx=Math.sin(i)*e.speed,e.vy=-Math.cos(i)*e.speed},Jo=e=>Math.max(.1,e.lifeMean/4),Xo={persistent:!1,spawn(e,t,i,n){e.x=Zo(t,i.W,i.spread),e.y=-n,e.vx=0,e.vy=e.speed}},Qo={fall:Xo,rise:{persistent:!1,spawn(e,t,i,n){e.x=Zo(t,i.W,i.spread),e.y=i.H+n,e.vx=0,e.vy=-e.speed}},drift:{persistent:!1,spawn(e,t,i,n){e.x=-n,e.y=Zo(t,i.H,i.spread),e.vx=e.speed,e.vy=0}},burst:{persistent:!1,spawn(e,t,i){Ko(e,i),Yo(e,360*t())}},orbit:{persistent:!0,spawn(e,t,i){const n=t()*Bo,s=Wo(i);e.x=i.W/2+Math.cos(n)*s,e.y=i.H/2+Math.sin(n)*s;const r=Go(e,i);e.vx=r.tx*e.speed,e.vy=r.ty*e.speed},accel(e,t,i){const n=Go(e,t),s=2*(Wo(t)-n.r);Uo(e,n.tx*e.speed+n.ux*s,n.ty*e.speed+n.uy*s,i)}},spiral:{persistent:!1,spawn(e,t,i){const n=t()*Bo;e.x=i.W/2+Math.cos(n),e.y=i.H/2+Math.sin(n);const s=Go(e,i);e.vx=(.6*s.ux+s.tx)*e.speed,e.vy=(.6*s.uy+s.ty)*e.speed},accel(e,t,i){const n=Go(e,t);Uo(e,(.6*n.ux+n.tx)*e.speed,(.6*n.uy+n.ty)*e.speed,i)}},fountain:{persistent:!1,spawn(e,t,i,n){e.x=i.W/2+(t()-.5)*i.W*(Math.max(0,i.spread)/100)*.25,e.y=i.H+n,Yo(e,40*(t()-.5))},fall:e=>2*e.vMean/Math.max(.1,e.lifeMean)},explode:{persistent:!1,spawn(e,t,i){Ko(e,i),Yo(e,150*(t()-.5))},fall:e=>1.5*e.vMean/Math.max(.1,e.lifeMean)},wave:{persistent:!1,spawn(e,t,i,n){const s=t()*Bo,r=2*Bo/Math.max(.2,i.lifeMean);e.baseY=Zo(t,i.H,i.spread),e.x=-n,e.y=e.baseY+8*Math.sin(s),e.vx=e.speed,e.vy=8*r*Math.cos(s)},accel(e,t,i){const n=2*Bo/Math.max(.2,t.lifeMean);i.y+=-n*n*(e.y-e.baseY)}},vortex:{persistent:!1,spawn(e,t,i){const n=t()*Bo,s=Math.max(10,i.spread/2);e.x=i.W/2+Math.cos(n)*s,e.y=i.H/2+Math.sin(n)*s;const r=Go(e,i);e.vx=r.tx*e.speed,e.vy=r.ty*e.speed},accel(e,t,i){const n=Go(e,t),s=n.r>2?.4:0;Uo(e,(n.tx-n.ux*s)*e.speed,(n.ty-n.uy*s)*e.speed,i)}},zigzag:{persistent:!1,spawn(e,t,i,n){Xo.spawn(e,t,i,n);const s=Jo(i);e.baseX=e.x,e.vx=24*-e.dir/s},accel(e,t,i){const n=Jo(t),s=Math.floor(e.age/n)%2==0?1:-1;i.x+=s*e.dir*48/(n*n)}},rain:{persistent:!1,align:!0,spawn(e,t,i,n){e.x=t()*i.W*(.2+Math.max(0,i.spread)/100)-.1*i.W,e.y=-n,e.vx=0,e.vy=e.speed}},wander:{persistent:!0,spawn(e,t,i){e.x=Zo(t,i.W,i.spread),e.y=Zo(t,i.H,i.spread),e.baseX=e.x,e.baseY=e.y,Yo(e,360*t())},accel(e,t,i){const n=To(625341585^t.noiseSeed,e.x/20,e.y/20,.4*e.age)*Bo;Uo(e,Math.cos(n)*e.speed+.8*(e.baseX-e.x),Math.sin(n)*e.speed+.8*(e.baseY-e.y),i)}}},el=Ho.dt,tl=2*el,il={builtin:"circle"},nl=e=>({age:e.age,x:e.x,y:e.y,vx:e.vx,vy:e.vy}),sl=([e,t])=>(e+t)/2,rl=(e,t)=>Math.min(Math.max(e,tl),Math.max(tl,Math.min(20,t-tl)));function al(e,t,i){const n=e.sim,s=i.aspect>0?i.aspect:2,r=s>=1?100*s:100,a=s>=1?100:100/s,o=Qo[n.flow]??Qo.fall,l=Oo(n.seed,3),c={W:r,H:a,spread:e.spread,vMean:Math.abs(sl(n.ranges.speed)),lifeMean:rl(sl(n.ranges.lifetime),t),noiseSeed:l},d=function(e,t,i,n){const s=t.content,r="none"!==e.content&&s&&s.w>0&&s.h>0?{x0:s.x/100*i,y0:s.y/100*n,x1:(s.x+s.w)/100*i,y1:(s.y+s.h)/100*n}:void 0;return{floor:e.floor,ceiling:e.ceiling,left:e.left,right:e.right,...r?{content:r}:{}}}(n.colliders,i,r,a),p=((e,t)=>({x:e.x+t.x,y:e.y+t.y}))(Do(n.physics.gravity),{x:0,y:o.fall?.(c)??0});return{spec:e,sim:n,period:t,W:r,H:a,flow:o,ctx:c,physics:n.physics,colliders:d,...d.content?{content:d.content}:{},gravity:p,rest:(h=p,2+2*Math.hypot(h.x,h.y)*el),noiseSeed:l};var h}const ol=(e,t)=>{const i=function(e,t){const i=e();let n=0;for(const e of t)n+=e>0?e:0;if(!(n>0))return 0;let s=0;const r=i*n;for(let e=0;e<t.length;e++)if(s+=t[e]>0?t[e]:0,r<s)return e;for(let e=t.length-1;e>=0;e--)if(t[e]>0)return e;return 0}(e,t.map(e=>e.weight));return t.length?t[i].shape:il},ll=e=>e/2/120*100;function cl(e,t,i){const{sim:n,spec:s,period:r}=e,a=ol(t,n.shapes),o=Po(t,s.size),l=Po(t,n.ranges.speed),c=Po(t,n.ranges.spin),d=t()<.5?-c:c,p=Po(t,n.ranges.delay),h=Po(t,n.ranges.lifetime),u=Po(t,n.ranges.opacity),m=t()<.5?-1:1,g=ll(o),f=e.flow.persistent&&r<=20,v={index:i,x:0,y:0,vx:0,vy:0,age:0,speed:l,dir:m,baseX:0,baseY:0,birth:r>0?(Math.max(0,p)%r+r)%r:0,life:f?r:rl(h,r),spin:d,peak:u,size:o,radius:g,shape:a,...s.colors.length?{color:s.colors[i%s.colors.length]}:{},persistent:f,physics:e.physics,gravity:e.gravity,flow:e.flow};return e.flow.spawn(v,t,e.ctx,g),v}function dl(e,t,i,n){if(e.persistent)return i?.675+.325*Math.cos(t/n*Math.PI*2):1;const s=i?.1*e.life:el;return Math.max(0,Math.min(1,t/s,(e.life-t)/s))}function pl(e,t){let i=t.spin*t.age;return t.flow?.align&&(t.vx||t.vy)&&(i+=180*Math.atan2(-t.vx,t.vy)/Math.PI),{age:t.age,x:t.x,y:t.y,rotate:i,opacity:t.peak*dl(t,t.age,e.spec.fade,e.period),scale:1}}function hl(e,t,i){const n={x:t.gravity.x,y:t.gravity.y},s=function(e,t,i,n){if(!(t.strength>0))return{x:0,y:0};const s=Math.max(1,t.scale),r=.6*n;return{x:To(e,i.x/s,i.y/s,r)*t.strength,y:To(1540483477^e,i.x/s,i.y/s,r+17)*t.strength}}(e.noiseSeed,t.physics.turbulence,t,t.age);n.x+=s.x,n.y+=s.y,t.flow?.accel?.(t,e.ctx,n);const r=((e,t)=>e>0?Math.exp(-e*t):1)(t.physics.drag,i);return t.vx=(t.vx+n.x*i)*r,t.vy=(t.vy+n.y*i)*r,t.x+=t.vx*i,t.y+=t.vy*i,t.age+=i,function(e,t,i,n,s,r,a,o){let l;const c=(t,i,n,s)=>{e.x=n,e.y=s;const c=e.vx*t+e.vy*i;if(c>=0)return;const d=e.vx-c*t,p=e.vy-c*i,h=Math.sqrt(Math.max(0,r));let u=-c*r;u<a&&(u=0),e.vx=d*h+u*t,e.vy=p*h+u*i,-c>=a&&!l&&(l={age:o,x:n,y:s,nx:t,ny:i,speed:-c})};s.floor&&e.y>n-t&&c(0,-1,e.x,n-t),s.ceiling&&e.y<t&&c(0,1,e.x,t),s.left&&e.x<t&&c(1,0,t,e.y),s.right&&e.x>i-t&&c(-1,0,i-t,e.y);const d=s.content;if(d&&e.x>d.x0-t&&e.x<d.x1+t&&e.y>d.y0-t&&e.y<d.y1+t){const i=e.x-(d.x0-t),n=d.x1+t-e.x,s=e.y-(d.y0-t),r=d.y1+t-e.y,a=Math.min(i,n,s,r);a===s?c(0,-1,e.x,d.y0-t):a===r?c(0,1,e.x,d.y1+t):a===i?c(-1,0,d.x0-t,e.y):c(1,0,d.x1+t,e.y)}return l}(t,t.radius,e.W,e.H,e.colliders,t.physics.bounce,e.rest,t.age)}function ul(e,t,i){const n=[pl(e,t)],s=[];let r=void 0!==i&&i<=0?nl(t):void 0;const a=t.x,o=t.y,l=Math.ceil(t.life/el-1e-9);for(let c=0;c<l;c++){const d=Math.min(el,t.life-t.age);if(d<=1e-12)break;const p=hl(e,t,d);c===l-1&&(t.age=t.life),p&&s.push({...p,vx:t.vx,vy:t.vy}),void 0!==i&&!r&&t.age>=i-1e-9&&(r=nl(t));const h=pl(e,t);if(t.persistent){const e=Math.max(0,Math.min(1,(t.age-.85*t.life)/(.15*t.life))),i=e*e*(3-2*e);h.x+=(a-h.x)*i,h.y+=(o-h.y)*i}n.push(h)}const c=n[n.length-1];return{samples:n,hits:s,...r?{at:r}:{},end:{...nl(t),x:c.x,y:c.y}}}const ml=Math.PI/180,gl=e=>e?Math.max(0,Math.min(Ho.childrenPerParent,Math.floor(e.count))):0;function fl(e,t){return"collision"===e.trigger?t.hits[0]:"time"===e.trigger?t.at:t.end}function vl(e,t,i,n,s,r){const a=gl(t),{physics:o,gravity:l}=function(e,t){const i=t.physics??{},n={...e.physics,...i},s=e.gravity.y-Do(e.physics.gravity).y,r=Do(n.gravity);return{physics:n,gravity:{x:r.x,y:r.y+s}}}(e,t),c=Math.hypot(n.vx,n.vy),d=void 0!==n.nx&&void 0!==n.ny?Math.atan2(n.nx,-n.ny):c>1e-9?Math.atan2(n.vx,-n.vy):0,p=Math.max(0,Math.min(360,t.cone))*ml,h=[];for(let c=0;c<a;c++){const a=ol(s,t.shapes),u=Po(s,t.size),m=Po(s,t.ranges.speed),g=Po(s,t.ranges.spin),f=s()<.5?-g:g,v=rl(Po(s,t.ranges.lifetime),e.period),b=Po(s,t.ranges.opacity),y=d+(s()-.5)*p;if(c>=r)continue;const x=t.colors.length?t.colors[c%t.colors.length]:i.color;h.push({index:c,x:n.x,y:n.y,vx:Math.sin(y)*m+n.vx*t.inherit,vy:-Math.cos(y)*m+n.vy*t.inherit,age:0,speed:m,dir:1,baseX:n.x,baseY:n.y,birth:((i.birth+n.age)%e.period+e.period)%e.period,life:v,spin:f,peak:b,size:u,radius:ll(u),shape:a,...void 0!==x?{color:x}:{},persistent:!1,physics:o,gravity:l})}return h}function bl(e,t,i){const n=t.t-e.t,s=n>0?(i.t-e.t)/n:0,r=i=>e[i]+(t[i]-e[i])*s;return Math.max(Math.abs(i.x-r("x")),Math.abs(i.y-r("y")),Math.abs(i.rotate-r("rotate"))/3.6,100*Math.abs(i.opacity-r("opacity")),100*Math.abs(i.scale-r("scale")))}function yl(e){const t=e.length,i=new Float64Array(t);if(!t)return i;i[0]=1/0,i[t-1]=1/0;for(let n=1;n<t-1;n++)e[n].keep&&(i[n]=1/0);const n=[];for(let e=0;e<t;e++)i[e]===1/0&&n.push(e);const s=[];for(let e=0;e+1<n.length;e++)s.push([n[e],n[e+1],1/0]);for(;s.length;){const[t,n,r]=s.pop();if(n-t<2)continue;let a=-1,o=t+1;for(let i=t+1;i<n;i++){const s=bl(e[t],e[n],e[i]);s>a&&(a=s,o=i)}const l=Math.min(a,r);i[o]=l,s.push([t,o,l],[o,n,l])}return i}function xl(e,t,i,n){let s=0;for(let e=0;e<t.length;e++)t[e]>i&&s++;let r=i;if(s>n){const s=Array.from(t).sort((e,t)=>t-e);if(r=Math.max(i,s[n-1]===1/0?1/0:s[n]),r===1/0)return e.filter((e,i)=>t[i]===1/0).slice(0,n)}return e.filter((e,i)=>t[i]>r)}const _l=e=>e.reduce((e,t)=>e+t,0);function wl(e){const t=[e,...(e.sim.emitters??[]).slice(0,Ho.emitters-1).map(t=>((e,t)=>({...e,count:t.count,size:t.size,colors:t.colors,fade:t.fade,spread:t.spread,layer:t.layer??e.layer,sim:{...e.sim,seed:t.seed,flow:t.flow,shapes:t.shapes,ranges:t.ranges,physics:t.physics,children:t.children}}))(e,t))];let i=Ho.parents;const n=t.map(e=>{const t=Math.min(Math.max(0,Math.floor(e.count)),i);return i-=t,t}),s=t.map((e,t)=>n[t]*gl(e.sim.children)),r=Ho.elements-_l(n);let a=s;if(_l(s)>r){const e=_l(n.filter((e,t)=>s[t]));a=s.map((t,i)=>t&&Math.min(t,Math.floor(r*n[i]/e)));let t=r-_l(a);a=a.map((e,i)=>e<s[i]&&t-- >0?e+1:e)}const o="front"!==e.layer,l=t.map((e,t)=>({spec:e,n:n[t],m:a[t],at:0,front:"front"===e.layer,index:t})),c=e=>e.front===o,d=[...l.filter(e=>!c(e)),...l.filter(c)];let p=0;d.forEach(e=>{e.at=p,p+=e.n+e.m});const h=d.findIndex(c);return{plans:d,cut:h<0?d.length:h,pool:p}}const kl=e=>e.cut<e.plans.length?e.plans[e.cut].at:e.pool,$l=Ho,Ml=[.5,1,2,4,8,16,32],Sl=(e,t)=>{const i=10**t,n=Math.round(e*i)/i;return 0===n?0:n},zl=(e,t,i)=>Math.min(i,Math.max(t,e));function Cl(e){const t=Number.isFinite(e.aspect)&&e.aspect>0?e.aspect:2,i=zl(Math.round(4*t)/4,.25,8),n=e.content;if(!n||![n.x,n.y,n.w,n.h].every(Number.isFinite))return{aspect:i};const s=e=>zl(5*Math.round(e/5),0,100);return{aspect:i,content:{x:s(n.x),y:s(n.y),w:s(n.w),h:s(n.h)}}}function Al(e){return`${(e=>Sl(100*e,3))(e.t)}%{translate:${e.x}cqw ${e.y}cqh;rotate:${e.rotate}deg;opacity:${e.opacity}${1!==e.scale?`;scale:${e.scale}`:""}}`}const jl=e=>e.reduce((e,t)=>e+Al(t).length,160);function ql(e,t,i){const n=e.period,s=i.map(e=>({...e,tau:t.birth+e.age}));let r;if(t.persistent?s[s.length-1]={...s[0],tau:t.birth+n}:(s[0].keep=!0,s[s.length-1].keep=!0,s.push({...s[0],tau:t.birth+n,keep:!0})),t.birth<=0)r=s;else{let e=s.findIndex(e=>e.tau>=n);e<1&&(e=1);const t=s[e].tau===n?{...s[e],keep:!0}:((e,t,i)=>{const n=t.tau>e.tau?(i-e.tau)/(t.tau-e.tau):0,s=i=>e[i]+(t[i]-e[i])*n;return{tau:i,age:s("age"),x:s("x"),y:s("y"),rotate:s("rotate"),opacity:s("opacity"),scale:s("scale"),keep:!0}})(s[e-1],s[e],n),i=s.slice(0,e),a=s.slice(s[e].tau===n?e+1:e,-1).map(e=>({...e,tau:e.tau-n}));r=[{...t,tau:0},...a,...i,{...t,tau:n}]}const a=t.persistent?360*Math.round(t.spin*n/360):0,o=r.map(i=>({t:i.tau/n,x:i.x/e.W*100,y:i.y/e.H*100,rotate:t.persistent?a*i.tau/n:i.rotate,opacity:i.opacity,scale:i.scale,...i.keep?{keep:!0}:{}}));return o[0].t=0,o[o.length-1].t=1,o}function El(e){const t=[];return e.forEach((i,n)=>{const s=n===e.length-1?1:Sl(i.t,5),r={t:s,x:Sl(i.x,2),y:Sl(i.y,2),rotate:Sl(i.rotate,1),opacity:Sl(zl(i.opacity,0,1),3),scale:Sl(i.scale,3)},a=t[t.length-1];a&&a.t>=s?(n===e.length-1||i.keep)&&(t[t.length-1]=r):t.push(r)}),t}function Hl(e){const t=e.period>0&&Number.isFinite(e.period)?e.period:1,i=Cl(e.geometry),n=wl(e.spec),s=[],r={elements:0,stops:0,bytes:0,capped:!1,warn:!1};let a=0;n.plans.forEach((e,o)=>{o===n.cut&&(a=s.length);const l=function(e,t,i,n){const s=e.spec,r=s.sim,a=al(s,t,i),o=e.n;let l=Math.floor(s.count)>o;const c=r.children,d=gl(c),p=Vo(r.seed),h=[],u=[];for(let e=0;e<o;e++){const t=cl(a,p,e),i=ul(a,t,"time"===c?.trigger?c.at??0:void 0);u.push(i);const n=ql(a,t,i.samples);h.push({p:t,raw:n,rank:yl(n)})}const m=[];if(c&&d>0){const t=h.map((e,t)=>fl(c,u[t])?t:-1).filter(e=>e>=0),i=e.m,n=t.length?Math.floor(i/t.length):0,s=t.length?i%t.length:0;t.length*d>i&&(l=!0);const o=Vo(Oo(r.seed,2));t.forEach((e,t)=>{const i=Math.min(d,n+(t<s?1:0)),r=fl(c,u[e]);for(const t of vl(a,c,h[e].p,r,o,i)){const i=ql(a,t,ul(a,t).samples);m.push({p:t,raw:i,rank:yl(i),parent:e})}})}let g=d,f=[],v=0;for(;;){const e=[...h,...m.filter(e=>e.p.index<g)];for(const t of Ml){f=[],v=0;const i=new Map;if(e.forEach((e,n)=>{void 0===e.parent&&i.set(e.p.index,n);const s=El(xl(e.raw,e.rank,t,$l.stopsPerElement));v+=jl(s),f.push({slot:n,...void 0!==e.parent?{parent:i.get(e.parent)}:{},shape:{...e.p.shape},size:Sl(e.p.size,2),...void 0!==e.p.color?{color:e.p.color}:{},stops:s})}),v<=n)break;l=!0}if(v<=n||0===g)break;g=Math.floor(g/2)}for(;v>n&&f.length;){const e=f.pop();v-=jl(e.stops),l=!0}const b=f.reduce((e,t)=>e+t.stops.length,0);return{engine:1,period:t,geometry:i,elements:f,stats:{elements:f.length,stops:b,bytes:v,capped:l,warn:v>$l.warnBytes}}}(e,t,i,n.plans[1]?Math.floor($l.maxBytes*(e.n+e.m)/n.pool):$l.maxBytes);l.elements.forEach(t=>s.push({...t,slot:t.slot+e.at,...void 0!==t.parent?{parent:t.parent+e.at}:{}})),r.stops+=l.stats.stops,r.bytes+=l.stats.bytes,r.capped||=l.stats.capped}),r.elements=s.length,r.warn=r.bytes>$l.warnBytes;const o=n.plans[n.cut];return{engine:1,period:t,geometry:i,elements:s,stats:r,...o?{parts:{element:a,slot:o.at,front:o.front}}:{}}}const Ll=(e,t,i)=>`mcc-${e}-${zn(JSON.stringify([t,i]))}`,Vl=(e,t)=>`${e}-g${function(e){const t=e.content;return`${Math.round(4*e.aspect)}${t?`c${t.x}_${t.y}_${t.w}_${t.h}`:""}`}(t)}`;function Ol(e){const t=e.shape,i={x:0,phase:0,k:0,style:""};return"builtin"in t?i.shape=t.builtin:"icon"in t?i.symbol={icon:t.icon}:"emoji"in t&&(i.symbol={text:t.emoji}),i}function Pl(e,t){if(!e.length)return{t,x:0,y:0,rotate:0,scale:1,opacity:0};const i=e.findIndex(e=>e.t>=t);if(i<=0)return{...e[0===i?0:e.length-1],t};const n=e[i-1],s=e[i],r=s.t>n.t?(t-n.t)/(s.t-n.t):0,a=e=>n[e]+(s[e]-n[e])*r;return{t,x:a("x"),y:a("y"),rotate:a("rotate"),scale:a("scale"),opacity:a("opacity")}}function Rl(e,t,i,n,s=e=>e){const r=`.mc-anim-fx[data-fx="${e}"]`,a=`mcp${zn(e)}-`,o=[`${r}{opacity:var(${An(t,"s")},1)}`,`${r}>i{left:0;top:0;width:var(--mcc-sz);height:var(--mcc-sz);margin:calc(var(--mcc-sz)/-2) 0 0 calc(var(--mcc-sz)/-2);color:var(--mcc-pc,var(${An(t,"c")},var(--mc-anim-c)));display:flex;align-items:center;justify-content:center;font-size:var(--mcc-sz);line-height:1;font-style:normal;--mdc-icon-size:var(--mcc-sz);${n?"animation-timing-function:linear":"animation:none"}}`],l=new Map;return i.forEach((e,t)=>{const i=s(t);"svg"in e.shape&&l.set(e.shape.svg,[...l.get(e.shape.svg)??[],i]);const c=n?`animation-name:${a}${i};`:"",d=e.color?vt(e.color,"color"):void 0;var p;o.push(`${r}>i:nth-child(${i+1}){${c}--mcc-sz:${p=e.size,Math.round(100*p)/100||0}px${d?`;--mcc-pc:${d}`:""}}`),n&&o.push(`@keyframes ${a}${i}{${n(t)}}`)}),l.forEach((e,t)=>{const i=et(t).markup,n=i?`-webkit-mask:${In(i)} center/contain no-repeat;mask:${In(i)} center/contain no-repeat`:"border-radius:50%";o.push(`${r}>i:is(${e.map(e=>`:nth-child(${e+1})`).join(",")}){background:currentColor;${n}}`)}),o.join("\n")}function Dl(e,t,i,n,s=0,r=e.elements.length,a=0){const o=e.elements.slice(s,r),l=o.map(e=>n?.[e.slot]??(e=>({shape:e.shape,size:e.size,...void 0!==e.color?{color:e.color}:{}}))(e));return{css:Rl(t,i,l,e=>o[e].stops.map(Al).join(""),n?e=>o[e].slot-a:void 0),slots:(n??l).map(Ol)}}const Nl={circle:{d:"M12 5a7 7 0 1 0 0 14a7 7 0 1 0 0-14z"},square:{d:"M5 5h14v14H5z"},triangle:{d:"M12 4l8 15H4z"},star:{d:"M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7L2 9.2l7.1-.6z"},heart:{d:"M12 20s-7.5-4.6-7.5-10.2A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"},ring:{d:"M12 5.5a6.5 6.5 0 1 0 0 13a6.5 6.5 0 1 0 0-13z",stroke:3},line:{d:"M6 19L18 5",stroke:3},spark:{d:"M12 2l2 8 8 2-8 2-2 8-2-8-8-2 8-2z"}};function Fl(e){const t=Nl[e];return t.stroke?`<path d="${t.d}" fill="none" stroke="currentColor" stroke-width="${t.stroke}" stroke-linecap="round"/>`:`<path d="${t.d}"/>`}const Tl=[".mc-anim-fx>i[data-s]{background:currentColor}",'.mc-anim-fx>i[data-s="circle"]{border-radius:50%}','.mc-anim-fx>i[data-s="square"]{border-radius:0}',...Eo.filter(e=>"circle"!==e&&"square"!==e).map(e=>`.mc-anim-fx>i[data-s="${e}"]{${(e=>{const t=In(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">${Fl(e)}</svg>`);return`-webkit-mask:${t} center/contain no-repeat;mask:${t} center/contain no-repeat`})(e)}}`)].join("\n"),Bl=e=>String(Math.round(100*e)/100||0),Il=e=>String(Math.round(1e3*e)/1e3||0),Zl=e=>e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;");function Wl(e){const t=void 0!==e?vt(e,"color"):void 0;return t&&!/var\(/i.test(t)?t:void 0}const Kl=(e,t)=>`transform:translate(${Bl(e.x)}px,${Bl(e.y)}px) rotate(${Bl(e.rotate)}deg) scale(${Il(e.scale*t)});opacity:${Il(e.opacity)}`,Ul="particles.sim",Gl=[...lt,"fountain","explode","wave","vortex","zigzag","rain","wander"],Yl=["death","collision","time"],Jl=["none","icon","text"],Xl=[0,1e3],Ql=[-3600,3600],ec=[0,6e3],tc=[.01,600],ic=[0,1],nc=[.001,1e3],sc=[-360,360],rc=[0,1e3],ac=[0,20],oc=[0,1e3],lc=[.1,1e3],cc=[0,1],dc=[0,600],pc=[.1,200],hc=[0,360],uc=[0,1],mc={speed:[20,40],spin:[0,0],delay:[0,2],lifetime:[2,2],opacity:[1,1]},gc={gravity:{angle:0,strength:0},drag:0,turbulence:{strength:0,scale:20},bounce:.5},fc={floor:!1,ceiling:!1,left:!1,right:!1,content:"none"},vc=e=>!!e&&"object"==typeof e&&!Array.isArray(e);function bc(e,t,i,n,s,r,a){const o=t[i];if(null==o)return[...r];if(!Array.isArray(o)||2!==o.length||!o.every(e=>"number"==typeof e&&Number.isFinite(e)))return e.err(n,"Must be [min, max]."),[...r];let[l,c]=o;if(l>c&&(a||e.err(n,"Min must not be above max."),[l,c]=[c,l]),l<s[0]||c>s[1]){if(e.err(n,`Must be between ${s[0]} and ${s[1]}.`),!a)return[...r];l=Math.min(s[1],Math.max(s[0],l)),c=Math.min(s[1],Math.max(s[0],c))}return[l,c]}const yc=(e,t,i,n,s,r,a=!1)=>e.num(t,i,n,s[0],s[1],r,a)??r;function xc(e,t,i){if(null==t)return[];const n=e.list(t,i,Ho.shapes),s=[];return n?.forEach((t,n)=>{const r=e.obj(t,`${i}[${n}]`);if(!r)return;const a=function(e,t,i){const n=e.obj(t,i);if(!n)return;const s=["builtin","icon","emoji","svg"].filter(e=>void 0!==n[e]&&""!==n[e]);if(1!==s.length)return e.err(i,"Set one of builtin, icon, emoji or svg.");const r=s[0],a=n[r];if("string"!=typeof a)return e.err(`${i}.${r}`,"Must be text.");if("builtin"===r)return Eo.includes(a)?{builtin:a}:e.err(`${i}.builtin`,`Must be one of: ${Eo.join(", ")}.`);if("icon"===r)return wt.test(a.trim())?{icon:a.trim()}:e.err(`${i}.icon`,"Must be an icon id like mdi:star.");if("emoji"===r){const t=a.trim();return t&&[...t].length<=8&&!/[<>&"'\\{};]/.test(t)?{emoji:t}:e.err(`${i}.emoji`,"Must be up to 8 characters (an emoji or a symbol).")}if(o=a,("undefined"!=typeof TextEncoder?(new TextEncoder).encode(o).length:o.length)>De)return e.err(`${i}.svg`,"The SVG is larger than 32 KB.");var o;if(!/<svg[\s>]/i.test(a))return e.err(`${i}.svg`,"No <svg> element found.");if("undefined"!=typeof DOMParser){const t=et(a);if(t.error)return e.err(`${i}.svg`,t.error)}return{svg:a}}(e,r.shape,`${i}[${n}].shape`),o=e.num(r,"weight",`${i}[${n}].weight`,nc[0],nc[1],1);a&&void 0!==o&&s.push({shape:a,weight:o})}),s}function _c(e,t,i){if(null==t)return[];const n=[];return e.list(t,i,dt)?.forEach((t,s)=>{const r=vt(t,"color");r?n.push(r):e.err(`${i}[${s}]`,"Not a valid colour.")}),n}function wc(e,t,i,n,s){if(null==t)return s?{}:{...n};const r=e.obj(t,i);if(!r)return s?{}:{...n};const a={},o=e=>!s||void 0!==r[e]&&null!==r[e];if(o("gravity")){const t=vc(r.gravity)?r.gravity:e.obj(r.gravity??{},`${i}.gravity`)??{};a.gravity={angle:yc(e,t,"angle",`${i}.gravity.angle`,sc,n.gravity.angle),strength:yc(e,t,"strength",`${i}.gravity.strength`,rc,n.gravity.strength)}}if(o("drag")&&(a.drag=yc(e,r,"drag",`${i}.drag`,ac,n.drag)),o("turbulence")){const t=vc(r.turbulence)?r.turbulence:e.obj(r.turbulence??{},`${i}.turbulence`)??{};a.turbulence={strength:yc(e,t,"strength",`${i}.turbulence.strength`,oc,n.turbulence.strength),scale:yc(e,t,"scale",`${i}.turbulence.scale`,lc,n.turbulence.scale)}}return o("bounce")&&(a.bounce=yc(e,r,"bounce",`${i}.bounce`,cc,n.bounce)),a}function kc(e,t,i){if(null==t)return{...fc};const n=e.obj(t,i);return n?{floor:e.bool(n,"floor",`${i}.floor`,!1),ceiling:e.bool(n,"ceiling",`${i}.ceiling`,!1),left:e.bool(n,"left",`${i}.left`,!1),right:e.bool(n,"right",`${i}.right`,!1),content:e.oneOf(n,"content",`${i}.content`,Jl,"none")??"none"}:{...fc}}function $c(e,t,i,n){const s=e.obj(t,i);if(!s)return;const r=e.errors.length;void 0!==s.children&&null!==s.children&&e.err(`${i}.children`,"Children cannot have children of their own.");const a=e.oneOf(s,"trigger",`${i}.trigger`,Yl);a||void 0!==s.trigger||e.err(`${i}.trigger`,"Required.");const o=vc(s.ranges)?s.ranges:e.obj(s.ranges??{},`${i}.ranges`)??{},l={trigger:a??"death",count:yc(e,s,"count",`${i}.count`,[1,Ho.childrenPerParent],3,!0),shapes:xc(e,s.shapes,`${i}.shapes`),size:bc(e,s,"size",`${i}.size`,pc,[4,6],n),colors:_c(e,s.colors,`${i}.colors`),ranges:{speed:bc(e,o,"speed",`${i}.ranges.speed`,Xl,[20,40],n),lifetime:bc(e,o,"lifetime",`${i}.ranges.lifetime`,tc,[.5,1],n),opacity:bc(e,o,"opacity",`${i}.ranges.opacity`,ic,[1,1],n),spin:bc(e,o,"spin",`${i}.ranges.spin`,Ql,[0,0],n)},cone:yc(e,s,"cone",`${i}.cone`,hc,360),inherit:yc(e,s,"inherit",`${i}.inherit`,uc,0)};"time"===l.trigger?l.at=yc(e,s,"at",`${i}.at`,dc,.5):void 0===s.at||null===s.at||n||e.err(`${i}.at`,"Only for the trigger time.");const c=wc(e,s.physics,`${i}.physics`,gc,!0);return Object.keys(c).length&&(l.physics=c),n&&e.errors.length>r?void 0:l}const Mc=/^[a-z0-9-]{1,16}$/;function Sc(e,t,i,n,s){const r=vc(t.ranges)?t.ranges:e.obj(t.ranges??{},`${i}.ranges`)??{},a=mc;return{seed:yc(e,t,"seed",`${i}.seed`,[0,4294967295],0,!0)>>>0,flow:s,shapes:xc(e,t.shapes,`${i}.shapes`),ranges:{speed:bc(e,r,"speed",`${i}.ranges.speed`,Xl,a.speed,n),spin:bc(e,r,"spin",`${i}.ranges.spin`,Ql,a.spin,n),delay:bc(e,r,"delay",`${i}.ranges.delay`,ec,a.delay,n),lifetime:bc(e,r,"lifetime",`${i}.ranges.lifetime`,tc,a.lifetime,n),opacity:bc(e,r,"opacity",`${i}.ranges.opacity`,ic,a.opacity,n)},physics:wc(e,t.physics,`${i}.physics`,gc,!1)}}function zc(e,t,i,n,s,r){const a="string"==typeof t.id&&Mc.test(t.id)&&!n.has(t.id)?t.id:"";a?n.add(a):(s||null!=t.id)&&e.err(`${i}.id`,"Must be 1-16 of a-z, 0-9 and -, and unique.");const o="string"==typeof t.name?t.name.trim():void 0;return(void 0===o?null!=t.name:o.length>40&&!r)&&e.err(`${i}.name`,"Must be text of at most 40 characters."),{id:a,name:o?.slice(0,40)||void 0}}function Cc(e,t,i){const n="lenient"===t,s=new Ct,r=s.obj(e,Ul);if(!r)return{errors:s.errors};if(1!==r.engine&&(s.err(`${Ul}.engine`,void 0===r.engine?"Required.":"This card plays engine 1; update Magic Card to play this animation."),n))return{errors:s.errors};const a=s.oneOf(r,"flow",`${Ul}.flow`,Gl);if(!a&&(void 0===r.flow&&s.err(`${Ul}.flow`,"Required."),n))return{errors:s.errors};const o={engine:1,mode:s.oneOf(r,"mode",`${Ul}.mode`,["baked","live"],"baked")??"baked",...Sc(s,r,Ul,n,a??"fall"),colliders:kc(s,r.colliders,`${Ul}.colliders`)};if(void 0!==r.children&&null!==r.children){const e=$c(s,r.children,`${Ul}.children`,n);e&&(o.children=e)}if(void 0!==r.emitters&&null!==r.emitters){const e=zc(s,r,Ul,new Set,!1,n),t=function(e,t,i,n,s){const r=`${Ul}.emitters`,a=Ho.emitters-1,o=new Set(n?[n]:[]),l=[];e.list(t,r,i?1/0:a)?.slice(0,a).forEach((t,n)=>{const s=`${r}[${n}]`,a=e.obj(t,s);if(!a)return;const{id:c,name:d}=zc(e,a,s,o,!0,i),p=e.oneOf(a,"layer",`${s}.layer`,["front","back"]),h=e.errors.length,u=e.oneOf(a,"flow",`${s}.flow`,Gl);u||e.err(`${s}.flow`,"Required.");const m={id:c,...d&&{name:d},...p&&{layer:p},count:yc(e,a,"count",`${s}.count`,[1,Ho.parents],10,!0),size:bc(e,a,"size",`${s}.size`,pc,[6,10],i),colors:_c(e,a.colors,`${s}.colors`),fade:e.bool(a,"fade",`${s}.fade`,!0),spread:yc(e,a,"spread",`${s}.spread`,[0,100],100),...Sc(e,a,s,i,u??"fall")},g=e.errors.length===h,f=null==a.children?void 0:$c(e,a.children,`${s}.children`,i);f&&(m.children=f),i&&!g||l.push(m)});let c=s+l.reduce((e,t)=>e+t.count,0)-Ho.parents;if(c>0){e.err(r,`At most ${Ho.parents} particles over all emitters.`);for(let e=l.length;i&&c>0&&e--;){const t=Math.min(c,l[e].count);l[e].count-=t,c-=t}}const d=l.filter(e=>e.count>0),p=new Set(n?[n]:[]);d.forEach(e=>e.id&&!p.has(e.id)?p.add(e.id):e.id="");let h=0;return d.forEach(e=>{if(!e.id){for(;p.has("e"+ ++h););p.add(e.id=`e${h}`)}}),d}(s,r.emitters,n,e.id,i?Math.max(0,Math.floor(i.count)):1);t.length&&Object.assign(o,e.id&&{id:e.id},e.name&&{name:e.name},{emitters:t})}return{sim:o,errors:s.errors}}const Ac=(e,t)=>{const i=e._$AN;if(void 0===i)return!1;for(const e of i)e._$AO?.(t,!1),Ac(e,t);return!0},jc=e=>{let t,i;do{if(void 0===(t=e._$AM))break;i=t._$AN,i.delete(e),e=t}while(0===i?.size)},qc=e=>{for(let t;t=e._$AM;e=t){let i=t._$AN;if(void 0===i)t._$AN=i=new Set;else if(i.has(e))break;i.add(e),Lc(t)}};function Ec(e){void 0!==this._$AN?(jc(this),this._$AM=e,qc(this)):this._$AM=e}function Hc(e,t=!1,i=0){const n=this._$AH,s=this._$AN;if(void 0!==s&&0!==s.size)if(t)if(Array.isArray(n))for(let e=i;e<n.length;e++)Ac(n[e],!1),jc(n[e]);else null!=n&&(Ac(n,!1),jc(n));else Ac(this,e)}const Lc=e=>{e.type==I.OA.CHILD&&(e._$AP??=Hc,e._$AQ??=Ec)};class Vc extends I.WL{constructor(){super(...arguments),this._$AN=void 0}_$AT(e,t,i){super._$AT(e,t,i),qc(this),this.isConnected=e._$AU}_$AO(e,t=!0){e!==this.isConnected&&(this.isConnected=e,e?this.reconnected?.():this.disconnected?.()),t&&(Ac(this,e),jc(this))}setValue(e){if(W(this._$Ct))this._$Ct._$AI(e,this);else{const t=[...this._$Ct._$AH];t[this._$Ci]=e,this._$Ct._$AI(t,this,0)}}disconnected(){}reconnected(){}}let Oc;const Pc=new WeakMap,Rc=new Set,Dc=new WeakMap,Nc=new WeakSet,Fc=new WeakSet,Tc=new WeakSet;function Bc(e,t){for(let i=e;i;i=i.parentNode instanceof ShadowRoot?i.parentNode.host:i.parentNode)if(t?i===t:Tc.has(i))return!0;return!1}function Ic(e,t){const i=t&&(Nc.has(e)||!Bc(e));e.toggleAttribute("offscreen",!i),Pc.get(e)?.(i)}function Zc(e,t=!0,i=!0){const n=function(){if(!Oc&&"undefined"!=typeof IntersectionObserver){Oc=new IntersectionObserver(e=>{for(const t of e)Dc.set(t.target,t.isIntersecting),Ic(t.target,t.isIntersecting)});const[e,t]=[Oc.observe.bind(Oc),Oc.unobserve.bind(Oc)];Oc.observe=t=>{Rc.add(t),e(t)},Oc.unobserve=e=>{Rc.delete(e),Dc.delete(e),t(e)}}return Oc}();return!!n&&(t?Nc.delete(e):Nc.add(e),i?Fc.delete(e):Fc.add(e),n.observe(e),!0)}function Wc(e){Oc?.unobserve(e),e.removeAttribute("offscreen")}(0,I.u$)(class extends Vc{constructor(e){if(super(e),this._counted=!0,e.type!==I.OA.ELEMENT)throw new Error("pauseOffscreen() is an element directive")}render(e){return a.s6}update(e,[t]){const i=!1!==t?.counted;var n;return e.element!==this._el?(this._unwatch(),this._el=e.element,this._counted=i,this.isConnected&&Zc(this._el,!0,i)&&(n=this._el,queueMicrotask(()=>Bc(n)&&Ic(n,!1)))):i!==this._counted&&(this._counted=i,this.isConnected&&Zc(this._el,!0,i)),a.s6}_unwatch(){this._el&&Wc(this._el)}disconnected(){this._unwatch()}reconnected(){this._el&&Zc(this._el,!0,this._counted)}});const Kc=Ho.dt,Uc=Math.ceil(.1/Kc)+1,Gc=e=>Math.round(100*e)/100;function Yc(e,t,i){const n=al(e,t,Lo),s=i?i.n:Math.min(Math.max(0,Math.floor(e.count)),Ho.parents),r=Vo(e.sim.seed),a=[];for(let e=0;e<s;e++){const t=cl(n,r,e);a.push({shape:t.shape,size:Gc(t.size),...void 0!==t.color?{color:t.color}:{}})}const o=e.sim.children,l=gl(o),c=i?i.m:o&&s?Math.min(s*l,Ho.elements-s):0,d=Vo(Oo(e.sim.seed,5));for(let e=0;e<c;e++){const t=ol(d,o.shapes),i=Po(d,o.size),n=o.colors.length?o.colors[e%o.colors.length]:a[Math.floor(e/Math.max(1,l))%s].color;a.push({shape:t,size:Gc(i),...void 0!==n?{color:n}:{}})}return{parents:s,children:c,looks:a}}const Jc=(e,t)=>e.plans.map(e=>Yc(e.spec,t,e));function Xc(e,t,i){const n=1e-6;return t.ny<0&&t.y>=e.H-i-n?"floor":t.ny>0&&t.y<=i+n?"ceiling":t.nx>0&&t.x<=i+n?"left":t.nx<0&&t.x>=e.W-i-n?"right":"content"}const Qc=e=>({age:e.age,x:e.x,y:e.y,vx:e.vx,vy:e.vy});class ed{constructor(e,t,i,n=Yc(e,t)){this.faces=new Set,this.slots=[],this.world=al(e,t,i),this.layout=n,this.rng=Vo(e.sim.seed),this.crng=Vo(Oo(e.sim.seed,2));for(let e=0;e<n.parents;e++){const t=this.spawn(e);this.slots.push({next:t,wait:t.birth,fired:!1})}this.kids=new Array(n.children).fill(void 0)}spawn(e){const t=cl(this.world,this.rng,e);return t.size=this.layout.looks[e].size,t.radius=ll(t.size),t.persistent&&(t.life=1/0),t}emit(e,t,i){e.fired=!0;const n=this.world.sim.children;if(!n)return;const s=[];for(let e=0;e<this.kids.length&&s.length<gl(n);e++)this.kids[e]||s.push(e);vl(this.world,n,t,i,this.crng,s.length).forEach((e,t)=>{e.size=this.layout.looks[this.layout.parents+s[t]].size,e.radius=ll(e.size),this.kids[s[t]]=e})}step(){const e=this.world,t=e.sim.children;this.slots.forEach((i,n)=>{if(!i.p){if(i.wait-=Kc,i.wait>1e-9)return;i.p=i.next,i.fired=!1}const s=i.p,r=hl(e,s,Kc);r&&(this.faces.add(Xc(e,r,s.radius)),"collision"!==t?.trigger||i.fired||this.emit(i,s,{...r,vx:s.vx,vy:s.vy})),"time"===t?.trigger&&!i.fired&&s.age>=(t.at??0)-1e-9&&this.emit(i,s,Qc(s)),s.age>=s.life-1e-9&&("death"!==t?.trigger||i.fired||this.emit(i,s,Qc(s)),i.p=void 0,i.next=this.spawn(n),i.wait=i.next.birth)}),this.kids.forEach((t,i)=>{if(!t)return;const n=hl(e,t,Kc);n&&this.faces.add(Xc(e,n,t.radius)),t.age>=t.life-1e-9&&(this.kids[i]=void 0)})}frame(){const e=this.world,t=t=>{if(!t)return;const i=pl(e,t);return{x:i.x/e.W*100,y:i.y/e.H*100,rotate:i.rotate,opacity:i.opacity,scale:i.scale}};return[...this.slots.map(e=>t(e.p)),...this.kids.map(t)]}}const td=["translate","rotate","scale","opacity","animation"],id=(e,t)=>{const i=10**t;return Math.round(e*i)/i||0};function nd(e,t,i=!1){const n=e.children;for(let e=0;e<n.length;e++){const s=n[e].style;i&&s.setProperty("animation","none");const r=t[e];!r||r.opacity<=0?"0"!==s.getPropertyValue("opacity")&&s.setProperty("opacity","0"):(s.setProperty("translate",`${id(r.x,2)}cqw ${id(r.y,2)}cqh`),s.setProperty("rotate",`${id(r.rotate,1)}deg`),s.setProperty("opacity",String(id(r.opacity,3))),1!==r.scale?s.setProperty("scale",String(id(r.scale,3))):s.removeProperty("scale"))}}function sd(e){for(const t of e.children)for(const e of td)t.style.removeProperty(e)}const rd=new Map;let ad=0,od=0,ld=!1;const cd=()=>"undefined"==typeof document||"hidden"!==document.visibilityState,dd=()=>{for(const e of rd.values())if(e.on)return!0;return!1};function pd(){ad&&"function"==typeof cancelAnimationFrame&&cancelAnimationFrame(ad),ad=0,od=0}function hd(){!ad&&cd()&&dd()&&"function"==typeof requestAnimationFrame&&(ad=requestAnimationFrame(ud))}function ud(e){ad=0;const t=od?Math.min(.1,Math.max(0,(e-od)/1e3)):Kc;od=e;for(const e of[...rd.values()])if(e.el.isConnected){if(e.on){e.acc+=t;for(let t=0;e.acc>=Kc-1e-9&&t<Uc;t++){for(const t of e.sims)t.step();e.acc-=Kc}nd(e.el,e.sims.flatMap(e=>e.frame()),!1)}}else fd(e.el);dd()&&cd()?ad=requestAnimationFrame(ud):od=0}function md(){cd()?hd():pd()}function gd(e,t,i,n){const s=wl(e),r=Jc(s,t);return s.plans.flatMap((e,a)=>a>=s.cut==!!n?[new ed(e.spec,t,i,r[a])]:[])}function fd(e){var t;rd.delete(e)&&(t=e,Pc.delete(t),Wc(t),sd(e),dd()||pd())}const vd=new Map;function bd(e,t,i,n,s,r){const a=wl(t),o=((e,t)=>Jc(e,t).flatMap(e=>e.looks))(a,i),l=t=>{const i=s?Vl(t?n+"o":n,s):`${t?n+"o":n}-g0`,l=((e,t)=>[t.slice(0,kl(e)),t.slice(kl(e))])(a,o)[t],c=r?Dl(r,i,e,o,t?r.parts.element:0,t?void 0:r.parts?.element,t?r.parts.slot:0).css:function(e,t,i){return{css:Rl(t,i,e),slots:e.map(Ol)}}(l,i,e).css;return{name:i,css:c,slots:l.map(Ol)}},c=l(0),d=a.cut<a.plans.length?l(1):void 0,p="front"===t.layer,h=!!s&&!r&&a.plans.some(e=>Math.floor(e.spec.count)>e.n||e.m<e.n*gl(e.spec.sim.children)),u=r?r.stats:{elements:o.length,stops:0,bytes:c.css.length+(d?.css.length??0),capped:h,warn:!1},m=kl(a),g=a.plans.map((e,t)=>({index:e.index,part:t<a.cut?0:1,first:e.at-(t<a.cut?0:m),parents:e.n,children:e.m})).sort((e,t)=>e.index-t.index);return{compiled:{mode:t.sim.mode,...c,front:p,...d?{other:{...d,front:!p}}:{},emitterSlots:g,stats:u},...r?{loop:r}:{},plan:a,still:[]}}function yd(e,t,i,n){const s=Cl(n),r=Ll(e,t,i),a=Vl(r,s);let o=vd.get(r);const l=o?.get(a);if(o&&l)return o.delete(a),o.set(a,l),vd.delete(r),vd.set(r,o),l;const c=bd(e,t,i,r,s,"live"===t.sim.mode?void 0:Hl({spec:t,period:i,geometry:s}));if(!o)for(o=new Map,vd.set(r,o);vd.size>32;)vd.delete(vd.keys().next().value);for(o.set(a,c);o.size>Ho.geometryVariants;)o.delete(o.keys().next().value);return c}const xd=new WeakSet;let _d=!1;var wd;wd=Cc,nt.simValidator=wd;const kd={version:"1.3.0",validateSim:Cc,bake:Hl,bakedCss:Dl,bakedSvg:function(e,t){const i=Number.isFinite(t.width)&&t.width>0?Math.round(t.width):200,n=Number.isFinite(t.height)&&t.height>0?Math.round(t.height):100,s=e.period>0&&Number.isFinite(e.period)?e.period:1,r=`p${zn(JSON.stringify([e.period,e.geometry,e.elements.length,e.stats.bytes]))}`,a=void 0!==t.background?Wl(t.background):void 0,o=new Map,l=`<svg xmlns="http://www.w3.org/2000/svg" width="${i}" height="${n}" viewBox="0 0 ${i} ${n}" fill="currentColor" color="#03a9f4">`,c=a?`<path d="M0 0H${i}V${n}H0z" fill="${Zl(a)}"/>`:"";let d=l.length+c.length+64;const p=[],h=[],u=[],m=e=>({...e,x:e.x/100*i,y:e.y/100*n}),g=e.elements.map((e,t)=>t);return e.parts&&!e.parts.front&&g.push(...g.splice(0,e.parts.element)),g.forEach(t=>{const i=e.elements[t],n=(e=>{const t=JSON.stringify(e);let i=o.get(t);return i||o.set(t,i=function(e){const t=(e,t,i,n,s)=>({markup:`<g transform="translate(${Il(-(t+n/2))} ${Il(-(i+s/2))})">${e}</g>`,grid:Math.max(n,s)||24});if("builtin"in e)return t(Fl(e.builtin),0,0,24,24);if("svg"in e){const i=et(e.svg);if(!i.error){const e=new Set(i.evenodd?.paths??[]),n=new Set(i.evenodd?.accent??[]),s=[...i.paths.map((t,i)=>`<path d="${Zl(t)}"${e.has(i)?' fill-rule="evenodd"':""}/>`),...i.accentPaths.map((e,t)=>`<path d="${Zl(e)}"${n.has(t)?' fill-rule="evenodd"':""}/>`),...i.strokes.map(e=>`<path d="${Zl(e.d)}" fill="none" stroke="currentColor" stroke-width="${Il(e.width)}"${e.cap?` stroke-linecap="${Zl(e.cap)}"`:""}${e.join?` stroke-linejoin="${Zl(e.join)}"`:""}/>`)].join(""),[r,a,o,l]=i.viewBox.split(/[\s,]+/).map(Number);if(s.length<=2048&&[r,a,o,l].every(Number.isFinite)&&o>0&&l>0)return t(s,r,a,o,l)}}return t('<path d="M12 5a7 7 0 1 0 0 14a7 7 0 1 0 0-14z"/>',0,0,24,24)}(e)),i})(i.shape),s=Wl(i.color),a=`<g class="${r}e${t}"${s?` color="${Zl(s)}"`:""}>${n.markup}</g>`;if(d+a.length>31744)return;d+=a.length,p.push(a);const l=i.size/n.grid;h.push(`.${r}e${t}{${Kl(m(Pl(i.stops,.5)),l)}}`);const c=i.stops.map(e=>`${Il(100*e.t)}%{${Kl(m(e),l)}}`).join("");u.push(`.${r} .${r}e${t}{animation-name:${r}a${t}}@keyframes ${r}a${t}{${c}}`)}),[l,`<style>${[`.${r}>g{transform-box:view-box;transform-origin:0 0}`,...h,`@media (prefers-reduced-motion:no-preference){.${r}>g{animation-duration:${Il(s)}s;animation-timing-function:linear;animation-iteration-count:infinite}`,...u,"}"].join("\n")}</style>`,c,`<g class="${r}">`,...p,"</g>","</svg>"].join("\n")},apply:function(e,t){try{const{spec:i,period:n,docId:s}=t;if(!i?.sim)throw new Error("the animation has no particle simulation");t.useCss("mcp-shapes",Tl);const r=function(e,t){const i=e.getBoundingClientRect();if(!(i.width>0&&i.height>0))return;const n={aspect:i.width/i.height};if("none"!==t.spec.sim.colliders.content){const e=t.content?.()?.getBoundingClientRect();e&&e.width>0&&e.height>0&&(n.content={x:(e.left-i.left)/i.width*100,y:(e.top-i.top)/i.height*100,w:e.width/i.width*100,h:e.height/i.height*100})}return Cl(n)}(e,t),a=r??Lo,o=yd(s,i,n,a),l=t.part?1:0;t.mirror?e.style.setProperty("scale","-1 1"):e.style.getPropertyValue("scale")&&e.style.removeProperty("scale");const c=l?o.compiled.other:o.compiled;if(e.getAttribute("data-fx")!==c.name&&(t.useCss(c.name,c.css),e.setAttribute("data-fx",c.name)),t.reducedMotion)return fd(e),nd(e,function(e,t,i,n,s){if(e.still[s])return e.still[s];const r=[],a=e.loop;if(a){const e=a.parts?.element??a.elements.length;a.elements.slice(s?e:0,s?void 0:e).forEach(e=>r[e.slot-(s?a.parts.slot:0)]=Pl(e.stops,.5))}else{const e=gd(t,i,n,s),a=Math.round(Math.min(.5*i,3)/Ho.dt);for(const t of e)for(let e=0;e<a;e++)t.step();r.push(...e.flatMap(e=>e.frame()))}return e.still[s]=r}(o,i,n,a,l),!0),void xd.add(e);xd.delete(e)&&sd(e),"live"===i.sim.mode?function(e,t,i,n,s,r=0){const a=rd.get(e);if(a?.key===s)return;fd(e),ld||"undefined"==typeof document||(document.addEventListener("visibilitychange",md),ld=!0);const o=gd(t,i,n,r),l={el:e,sims:o,key:s,on:!1,acc:0};var c,d;rd.set(e,l),c=e,d=t=>{rd.get(e)===l&&(l.on=t,t?hd():dd()||pd())},Pc.set(c,d),Zc(c,!0,!0)||(l.on=!0,hd())}(e,i,n,a,c.name,l):fd(e)}catch(e){_d||(_d=!0,console.warn("Magic Card: a particle layer could not be set up; it plays its simple version.",e))}},release:function(e){fd(e),xd.delete(e)&&sd(e)}},$d=function(e,t,i,n){return n.aspect>0?yd(e,t,i,n).compiled:bd(e,t,i,Ll(e,t,i)).compiled},Md=new WeakMap;function Sd(e){const t="particles"===e.kind?e.particles:void 0;if(!t?.sim)return;if(Md.has(t))return Md.get(t);let i;try{const n=Cc(t.sim,"lenient").sim;if(n){const s={...t,sim:n},r=$d(e.id,s,e.duration/t.speed,{aspect:0}),a=uo({...e,particles:{...t,sim:n}});r.emitterSlots&&(i={base:r.name.replace(/-g\w+$/,""),emitterSlots:r.emitterSlots,ids:a})}}catch{i=void 0}return Md.set(t,i),i}function zd(){let e=document.activeElement;for(;e?.shadowRoot?.activeElement;)e=e.shadowRoot.activeElement;return e&&e!==document.body?e:null}function Cd(e,t,i){const n="alert"===e.variant;return a.qy`<mc-ui-window
    variant=${e.variant??"sheet"}
    size=${e.size??a.s6}
    heading=${e.heading}
    closeLabel=${as(156)}
    ?movable=${!n}
    ?resizable=${!n}
    ?maximizable=${!n}
    moveLabel=${as(483)}
    resizeLabel=${as(741)}
    maximizeLabel=${as(440)}
    restoreLabel=${as(742)}
    initialFocus=${e.initialFocus??a.s6}
    .dismissible=${e.dismissible??!n}
    @mc-window-close=${t=>{t.stopPropagation(),e.onClose()}}
  >
    ${t}${i?a.qy`<div slot="footer" class="foot">${i}</div>`:a.s6}
  </mc-ui-window>`}const Ad=new WeakMap;function jd(e,t=18){return e.glyph&&y(e.glyph)?b(e.glyph,t):e.icon?a.qy`<ha-icon icon=${e.icon}></ha-icon>`:a.s6}(0,I.u$)(class extends Vc{render(e){return B.s6}update(e,[t]){const i=t!==this.G;return i&&this.rt(void 0),(i||this.lt!==this.ct)&&(this.G=t,this.ht=e.options?.host,this.rt(this.ct=e.element)),B.s6}rt(e){if(void 0!==this.G)if(this.isConnected||(e=void 0),"function"==typeof this.G){const t=this.ht??globalThis;let i=Ad.get(t);void 0===i&&(i=new WeakMap,Ad.set(t,i)),void 0!==i.get(this.G)&&this.G.call(this.ht,void 0),i.set(this.G,e),void 0!==e&&this.G.call(this.ht,e)}else this.G.value=e}get lt(){return"function"==typeof this.G?Ad.get(this.ht??globalThis)?.get(this.G):this.G?.value}disconnected(){this.lt===this.ct&&this.rt(void 0)}reconnected(){this.rt(this.ct)}});const qd="mc-panels:",Ed="mc-panels-hint:",Hd="data-mc-lips",Ld={"card-studio":["layers","inspector"],"anim-studio":["layers","inspector"],"svg-editor":["side","inspector"],"shape-studio":["side","inspector"],"theme-editor":["variables"]},Vd=a.JW`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>`;function Od(){try{return window.localStorage??null}catch{return null}}class Pd{constructor(e,t){this.host=e,this.restoredFrom="none",this.hidden=new Set,this.cols={},this._suspended=!1,this.remembered=null,this.hintDone=!1,this.statusText="",this.frame=0,this.onKeydown=e=>{this.handleKey(e)},this.editor=t.editor,this.panels=t.panels,this.strings=t.strings,this.keys=t.keys??"host",this.fallback=t.fallback,this.direction=new _(e),e.addController(this)}get dir(){return this.direction.direction}hostConnected(){this.host.setAttribute(Hd,""),"host"===this.keys&&this.host.addEventListener("keydown",this.onKeydown,{capture:!0}),this.restore()}hostDisconnected(){this.host.removeAttribute(Hd),this.host.removeEventListener("keydown",this.onKeydown,{capture:!0}),this.frame&&cancelAnimationFrame(this.frame),this.frame=0}restore(){this.remembered=null,this.direction.sync(),this.readMemory(),this.hintDone=this.readFlag(),this.host.requestUpdate()}setPanels(e,t){this.panels=e,this.strings=t,this.direction.sync(),this.host.requestUpdate()}columns(e){const t=new Set([...Object.keys(this.cols),...Object.keys(e)]);let i=!0;for(const n of t)Boolean(this.cols[n])!==Boolean(e[n])&&(i=!1);i||(this.cols={...e},this.host.requestUpdate())}get suspended(){return this._suspended}set suspended(e){e!==this._suspended&&(this._suspended=e,this.host.requestUpdate())}state(e){return!this._suspended&&this.cols[e]&&this.panels.some(t=>t.id===e)?this.hidden.has(e)?"hidden":"shown":"off"}isHidden(e){return"hidden"===this.state(e)}get active(){return!this._suspended&&this.panels.some(e=>this.cols[e.id])}toggle(e){this.remembered=null,this.apply([e],"shown"===this.state(e),"api")}show(e){this.remembered=null,this.apply([e],!1,"api")}hide(e){this.remembered=null,this.apply([e],!0,"api")}toggleAll(){const e=this.panels.map(e=>e.id).filter(e=>"off"!==this.state(e));if(!e.length)return!1;const t=e.filter(e=>!this.hidden.has(e));let i,n;if(t.length)this.remembered=t,i=t,n=!0;else{const t=(this.remembered??[]).filter(t=>e.includes(t));i=t.length?t:e,n=!1,this.remembered=null}return!!this.apply(i,n,"key")&&(this.announce(i,n),!0)}async reveal(e){"hidden"===this.state(e)&&(this.remembered=null,this.apply([e],!1,"reveal"),await this.host.updateComplete)}handleKey(e){if(e.defaultPrevented||!function(e){return(e.ctrlKey||e.metaKey)&&!e.altKey&&!e.shiftKey&&!e.getModifierState?.("AltGraph")&&("\\"===e.key||"Backslash"===e.code)&&!e.repeat&&!e.isComposing}(e))return!1;const t=e.composedPath(),i=t.indexOf(this.host);for(let e=0;e<(i<0?t.length:i);e++){const i=t[e];if(i instanceof Element&&i.hasAttribute(Hd))return!1}return e.preventDefault(),this.toggleAll(),!0}apply(e,t,i){const n=this.panels.map(e=>e.id).filter(i=>e.includes(i)&&"off"!==this.state(i)&&this.hidden.has(i)!==t);if(!n.length)return!1;const s=this.root()?.activeElement,r=t?n.filter(e=>{const t=this.panelEl(e);return!!t&&!!s&&t.contains(s)}):[];for(const e of n)t?this.hidden.add(e):this.hidden.delete(e);return t||this.dismissHint(),this.writeMemory(),this.host.requestUpdate(),r.length&&this.host.updateComplete.then(()=>this.lipEl(r[0])?.focus()),this.host.dispatchEvent(new CustomEvent("mc-panels-change",{detail:{editor:this.editor,hidden:this.panels.map(e=>e.id).filter(e=>this.hidden.has(e)),cause:i}})),!0}announce(e,t){const i=this.panels.filter(t=>e.includes(t.id)).map(e=>e.noun),n=t?this.strings.hidden:this.strings.shown,s=this.strings.locale;let r;try{const e=new Intl.ListFormat(s,{type:"conjunction"}).format(i),t=n.replace("{panels}",()=>e);r=t.charAt(0).toLocaleUpperCase(s)+t.slice(1)}catch{const e=n.replace("{panels}",()=>i.join(", "));r=e.charAt(0).toUpperCase()+e.slice(1)}this.statusText="",this.host.requestUpdate(),this.frame&&cancelAnimationFrame(this.frame),this.frame=requestAnimationFrame(()=>{this.frame=0,this.statusText=r,this.host.requestUpdate()})}allowed(e){const t=new Set(Ld[this.editor]),i=new Set;for(const n of e)"string"==typeof n&&t.has(n)&&i.add(n);return i}readMemory(){let e;this.hidden=new Set,this.restoredFrom="none";try{const t=Od();if(!t)return;e=t.getItem(qd+this.editor)}catch{return}if(null===e){let e;try{e=this.fallback?.()??null}catch{e=null}const t=this.allowed(e??[]);return void(t.size&&(this.hidden=t,this.restoredFrom="fallback",this.writeMemory()))}if("string"!=typeof e||e.length>64)return;const t=this.allowed(e.split(","));t.size&&(this.hidden=t,this.restoredFrom="stored")}writeMemory(){try{const e=Od();if(!e)return;const t=qd+this.editor,i=Ld[this.editor].filter(e=>this.hidden.has(e));i.length?e.setItem(t,i.join(",")):e.removeItem(t)}catch{}}readFlag(){try{return"1"===Od()?.getItem(Ed+this.editor)}catch{return!1}}hintPanel(){if(!this.hintDone&&"none"!==this.restoredFrom)return this.panels.find(e=>"hidden"===this.state(e.id))}dismissHint(){if(!this.hintDone){this.hintDone=!0;try{Od()?.setItem(Ed+this.editor,"1")}catch{}}}closeHint(e){const t=this.root(),i=t?.getElementById(`${e.controls}-hint`),n=!!i&&!!t?.activeElement&&i.contains(t.activeElement);this.dismissHint(),this.host.requestUpdate(),n&&this.lipEl(e.id)?.focus()}onLipKey(e,t){"Escape"===e.key&&(e.preventDefault(),e.stopPropagation(),this.closeHint(t))}hintTemplate(e){const t=this.panels.filter(e=>"hidden"===this.state(e.id)),i=this.strings,n="fallback"===this.restoredFrom?i.hintMigrated:1===t.length?i.hintOne.replace("{noun}",()=>t[0].noun):i.hintMany;return a.qy`<div class="lip-hint" id="${e.controls}-hint" data-side=${e.side} data-dir=${this.dir} @keydown=${t=>{"Escape"===t.key&&(t.preventDefault(),t.stopPropagation(),this.closeHint(e))}}> <p>${n}</p><p class="lip-hint-keys">${i.hintShortcut}</p><button type="button" @click=${()=>this.closeHint(e)}>${i.gotIt}</button></div>`}lip(e){const t=this.panels.find(t=>t.id===e);if(!t)return a.s6;const i=this.state(e);if("off"===i)return a.s6;const n="hidden"===i,s=this.hintPanel()?.id===e;return a.qy`<button type="button" class="lip" data-side=${t.side} data-dir=${this.dir} aria-expanded=${n?"false":"true"} aria-controls=${t.controls} aria-label=${t.name} title=${n?t.showLabel:t.hideLabel} aria-describedby=${(e=>e??B.s6)(s?`${t.controls}-hint`:void 0)} @click=${t=>{t.currentTarget?.focus(),this.remembered=null,this.apply([e],"shown"===this.state(e),"lip")}} @keydown=${s?e=>this.onLipKey(e,t):a.s6} >${Vd}</button>${s?this.hintTemplate(t):a.s6}`}status(){return a.qy`<div class="lip-status" role="status" aria-live="polite" aria-atomic="true">${this.statusText}</div>`}root(){return this.host.renderRoot??this.host.shadowRoot}panelEl(e){const t=this.panels.find(t=>t.id===e);return t?this.root()?.getElementById(t.controls)??null:null}lipEl(e){const t=this.panels.find(t=>t.id===e);if(!t)return null;for(const e of Array.from(this.root()?.querySelectorAll("button[aria-controls]")??[]))if(e.getAttribute("aria-controls")===t.controls)return e;return null}}const Rd={horizontal:["ArrowLeft","ArrowRight","Home","End"],vertical:["ArrowUp","ArrowDown","Home","End"],both:["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"]};class Dd{constructor(e){this.opts=e,this.onKeydown=e=>{if(e.ctrlKey||e.metaKey||e.altKey)return;const t=e.currentTarget,i=Array.from(t.querySelectorAll(this.opts.items)),n=i.indexOf(e.composedPath().find(e=>i.includes(e))),s=function(e,t,i,n="horizontal",s=!0,r=!1){if(!Rd[n].includes(e)||!i.length)return-1;const a=i.length,o=e=>e>=0&&e<a&&!i[e].disabled,l=(e,t)=>{for(let i=1;i<=a;i++){let n=e+t*i;if(s)n=(n+2*a)%a;else if(n<0||n>=a)return e;if(o(n))return n}return e};if("Home"===e)return o(0)?0:l(0,1);if("End"===e)return o(a-1)?a-1:l(a-1,-1);const c="ArrowUp"===e||e===(r?"ArrowRight":"ArrowLeft");return l(t<0?c?0:-1:t,c?-1:1)}(e.key,n,i.map(e=>({disabled:e.hasAttribute("disabled")})),this.opts.orientation,this.opts.wrap,"rtl"===x(t));s<0||(e.preventDefault(),e.stopPropagation(),this.focus(i,s),this.opts.onMove?.(i[s],s))}}focus(e,t){e.forEach((e,i)=>e.setAttribute("tabindex",i===t?"0":"-1")),e[t]?.focus()}}function Nd(e){const t="tablist"===e.role,i=new Dd({items:"[data-val]",orientation:"horizontal",onMove:t=>{const i=t.dataset.val;i!==e.value&&e.onChange(i)}});return a.qy`<div class="seg${e.full?" full":""}" role=${e.role} aria-label=${e.label} @keydown=${i.onKeydown}> ${e.items.map(i=>{const n=i.value===e.value,s=!!i.disabledReason;return a.qy`<button type="button" role=${t?"tab":"radio"} data-val=${i.value} aria-selected=${t?String(n):a.s6} aria-checked=${t?a.s6:String(n)} aria-disabled=${s?"true":a.s6} tabindex=${n?"0":"-1"} @click=${()=>{s||e.onChange(i.value)}} >${jd(i)}${i.label}</button>`})}</div>`}const Fd="{opacity:0!important}",Td=e=>`"${e.replace(/[\\"]/g,"\\$&").replace(/\n/g,"\\a ")}"`,Bd=e=>`.mc-module-wrapper[data-mc-run] [data-mc-part=${Td(e)}]:not(.mc-module-wrapper[data-mc-run] .mc-module-wrapper [data-mc-part])`,Id="data-mc-stage-hide";class Zd{constructor(){this._css={icon:"",card:""},this._sheets={},this._text=new WeakMap}set(e,t){this._css=t,this.attach(e)}attach(e){if(e){this._into(e,"card");for(const t of e.querySelectorAll(".mc-anim-icon"))t.shadowRoot&&this._into(t.shadowRoot,"icon")}}_into(e,t){const i=this._css[t];if("undefined"!=typeof CSSStyleSheet&&"replaceSync"in CSSStyleSheet.prototype&&"undefined"!=typeof ShadowRoot&&"adoptedStyleSheets"in ShadowRoot.prototype){let n=this._sheets[t];return n||(n=new CSSStyleSheet,this._sheets[t]=n,n.replaceSync(i)),this._text.get(n)!==i&&(n.replaceSync(i),this._text.set(n,i)),void(e.adoptedStyleSheets.includes(n)||(e.adoptedStyleSheets=[...e.adoptedStyleSheets,n]))}let n=[...e.children].find(e=>"STYLE"===e.tagName&&e.hasAttribute(Id));n||(n=document.createElement("style"),n.setAttribute(Id,""),e.appendChild(n)),n.textContent!==i&&(n.textContent=i)}}const Wd="light.mc_studio_preview",Kd=e=>(e?.clips?.length??0)>0||(e?.bindings?.length??0)>0,Ud={state:"on",value:.6,attributes:{}},Gd=e=>Math.round(1e3*e)/1e3,Yd=(e,t)=>Gd(e.input.min+(e.input.max-e.input.min)*Math.min(1,Math.max(0,t)));function Jd(e){const t=e?.bindings??[],i=t.find(e=>!e.input.attribute),n=(e?.clips??[]).some(e=>"above"in e.when||"below"in e.when);return{value:t.length>0||n,numericState:!!i||n,...i?{stateRange:[i.input.min,i.input.max]}:{}}}function Xd(e,t){const i={};for(const n of e?.bindings??[])n.input.attribute&&!(n.input.attribute in i)&&(i[n.input.attribute]=Yd(n,t));return i}function Qd(e){const t=new Date(0).toISOString();return{entity_id:Wd,state:e.state??Ud.state,attributes:{friendly_name:as(690),...e.attributes??{}},last_changed:t,last_updated:t,context:{id:"mc-studio-preview",parent_id:null,user_id:null}}}function ep(e){return"state"in e?as(889,{state:e.state}):"state_not"in e?as(888,{state_not:e.state_not}):"entity_on"in e?e.entity_on?as(304):as(303):"above"in e?as(1069,{above:e.above}):as(1071,{below:e.below})}var tp=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const ip=[{id:"light",label:418,icon:"mdi:white-balance-sunny"},{id:"dark",label:212,icon:"mdi:weather-night"}],np=[.25,.5,1,1.5,2],sp=Wd,rp=(e,t)=>!!t||Kd(e);function ap(e,t,i,n,s=1){return i>0&&n>0&&e>0&&t>0?Math.max(.2,Math.min(s,e/i,t/n)):1}const op={light:"--card-background-color:#ffffff;--primary-background-color:#fafafa;--secondary-background-color:#f2f3f5;--primary-text-color:#212121;--secondary-text-color:#5f6368;--divider-color:rgba(0,0,0,.12);--state-icon-color:#44739e;color-scheme:light",dark:"--card-background-color:#1c1c1c;--primary-background-color:#111111;--secondary-background-color:#282a2d;--primary-text-color:#e1e1e1;--secondary-text-color:#9b9b9b;--divider-color:rgba(225,225,225,.12);--state-icon-color:#9fbcd9;color-scheme:dark"};function lp(e){return{states:{},entities:{},language:"en",locale:{language:"en",number_format:"language",time_format:"language"},themes:{themes:{},darkMode:e},callWS:async()=>({}),callService:async()=>{}}}const cp="mc-i18n-wrap";class dp extends a.WF{constructor(){super(...arguments),this.lookup=()=>{},this.tile="icon",this.zoomIcon=!1,this.layerView=po,this.hiddenLayers=0,this.theme="light",this.reduced=!1,this.speed=1,this.playing=!0,this._t=0,this._k=1,this._fh=0,this._wraps=0,this._raf=0,this._last=0,this._lastTimeEvent=0,this._sentTime=-1,this._themeSet=!1,this._sheets=new Zd,this._attachQueued=!1,this._rates=new WeakMap,this._drives=!1,this._onWrap=()=>{this._wraps++},this._canvasOn=!1,this._onCanvasSlot=e=>{this._canvasOn=e.target.assignedElements().length>0},this._loop=()=>{if(!this.isConnected)return;const e=performance.now();if(this.playing&&this._last){const t=this.cycle;this._t=(this._t+(e-this._last)/1e3*this.speed)%t,this._emitTime()}this._last=e,this._raf=requestAnimationFrame(this._loop)}}connectedCallback(){if(super.connectedCallback(),window.addEventListener(cp,this._onWrap),!this._themeSet){this._themeSet=!0;const e=this.hass?.themes?.darkMode;this.theme=e??function(e){const t=/rgba?\((\d+),\s*(\d+),\s*(\d+)/.exec(getComputedStyle(e).color||"");if(!t)return!1;const[i,n,s]=t.slice(1).map(Number);return.2126*i+.7152*n+.0722*s>140}(this)?"dark":"light"}customElements.get("magic-card")||customElements.whenDefined("magic-card").then(()=>this.requestUpdate()),this._poll=setInterval(()=>this._sync(),250),this._loop(),this.hasUpdated&&this._observeFrame()}disconnectedCallback(){super.disconnectedCallback(),window.removeEventListener(cp,this._onWrap),this._ro?.disconnect(),this._ro=void 0,this._mo?.disconnect(),this._mo=this._moRoot=void 0,cancelAnimationFrame(this._raf),this._raf=0,this._poll&&clearInterval(this._poll),this._poll=void 0}get card(){return this._card}get cycle(){return this.doc?function(e,t){if("sequence"===e.kind){const i=Qn(e,{lookup:t}).schedule?.total??0;return i>0?i:1}const i="particles"!==e.kind||e.particles?.preset?1:e.particles?.speed||1;return Math.max(.05,e.duration/i)}(this.doc,this.lookup):1}get scale(){return this._k}togglePlay(){this.playing?this.pause():this.play()}play(){this.playing=!0;for(const e of this._anims())this._rate(e),e.play()}pause(){this.playing=!1;for(const e of this._anims())e.pause()}seek(e){this.playing=!1,this._t=Math.min(this.cycle,Math.max(0,e));for(const e of this._anims())e.pause(),e.currentTime=1e3*this._t;this._emitTime(!0)}_emitTime(e=!1){const t=performance.now(),i=Math.min(1,Math.max(0,this._t/this.cycle));!e&&(t-this._lastTimeEvent<33||i===this._sentTime)||(this._lastTimeEvent=t,this._sentTime=i,this.dispatchEvent(new CustomEvent("stage-time",{detail:{time:i}})))}_observeFrame(){const e=this.shadowRoot?.querySelector(".frame"),t=this.shadowRoot?.querySelector(".area");e&&t&&!this._ro&&"undefined"!=typeof ResizeObserver&&(this._ro=new ResizeObserver(()=>this._fit()),this._ro.observe(e),this._ro.observe(t))}_fit(){const e=this.shadowRoot?.querySelector(".frame"),t=this.shadowRoot?.querySelector(".area");if(!e||!t)return;const i=e.offsetHeight,n=this.zoomIcon?this._iconBox(e):void 0;let s,r;if(n&&t.clientWidth>0&&t.clientHeight>0){const e=function(e,t,i){const n=Math.round(1e3*ap(e-32,t-32,i.width+40,i.height+40,4))/1e3;return{k:n,x:Math.round(e/2-(i.x+i.width/2)*n),y:Math.round(t/2-(i.y+i.height/2)*n)}}(t.clientWidth,t.clientHeight,n);s=e.k,r={x:e.x,y:e.y}}else s=Math.round(1e3*ap(t.clientWidth-32,t.clientHeight-32,e.offsetWidth,i,1))/1e3;s!==this._k&&(this._k=s),i!==this._fh&&(this._fh=i),r?.x===this._off?.x&&r?.y===this._off?.y||(this._off=r),this.isUpdatePending?this.updateComplete.then(()=>this._emitRect()):this._emitRect()}_emitRect(){const e=this.shadowRoot?.querySelector(".frame");e&&this.dispatchEvent(new CustomEvent("stage-rect",{detail:this._rectDetail(e)}))}_rectDetail(e){const t=this._subjectRect(e),i=this._screenRect(e),n=this._iconViewBox();return{width:e.offsetWidth,height:e.offsetHeight,scale:this._k,...t?{subject:t}:{},...n?{viewBox:n}:{},...i?{screen:i}:{}}}_screenRect(e){const t=this.shadowRoot?.querySelector(".area");if(!t)return;const i=t.getBoundingClientRect(),n=e.getBoundingClientRect(),s=e=>Math.round(100*e)/100;return{left:s(n.left-i.left),top:s(n.top-i.top),width:s(n.width),height:s(n.height)}}_iconViewBox(){const e=this._card?.shadowRoot?.querySelector(".mc-anim-icon"),t="MC-SVG-ICON"===e?.tagName?e.shadowRoot?.querySelector("svg")?.getAttribute("viewBox"):null,i=t?.trim().split(/[\s,]+/).map(Number);return i&&4===i.length&&i.every(Number.isFinite)?i:void 0}_subjectRect(e){const t=this._card?.shadowRoot;if(!t||!this.doc)return;const i=this.subjectTarget,n="name"===i||"state"===i||"background"===i?t.querySelector(`[data-mc-part="${i}"]`):null,s=i?"icon"===i||/^(part|group|shape):/.test(i):"path"===this.doc.kind?"icon"===this.doc.path?.subject:"icon"===this.doc.target,r=n??(s?t.querySelector(".mc-anim-icon"):null)??t.querySelector(".mc-module-wrapper");return this._boxOf(r,e)}_iconBox(e){return this._boxOf(this._card?.shadowRoot?.querySelector(".mc-anim-icon")??null,e)}_boxOf(e,t){const i=e?.offsetParent;if(!e||!i||!e.offsetWidth)return;const n=t.getBoundingClientRect(),s=i.getBoundingClientRect(),r=this._k||1;return{x:Math.round((s.left-n.left)/r+i.clientLeft+e.offsetLeft),y:Math.round((s.top-n.top)/r+i.clientTop+e.offsetTop),width:e.offsetWidth,height:e.offsetHeight}}setSpeed(e){this.speed=e;for(const e of this._anims())this._rate(e)}_rate(e){const t=this._rates.get(e),i=t&&e.playbackRate===t.set?t.base:e.playbackRate,n=i*this.speed;e.playbackRate!==n&&(e.playbackRate=n),this._rates.set(e,{base:i,set:e.playbackRate})}_anims(){return function(e){const t=new Set,i=e=>{for(const i of e.getAnimations?.()??[])t.add(i);for(const t of e.querySelectorAll("*"))t.shadowRoot&&i(t.shadowRoot)};return e&&i(e),[...t]}(this._card?.shadowRoot)}_sync(){for(const e of this._anims())this._rate(e),this.playing||"running"!==e.playState||(e.pause(),e.currentTime=1e3*this._t)}_previewHass(){const e=this.hass,t=this._hassFor,i=rp(this.doc,this.preview)?(n=this.preview)?function(e,t){return{state:t.state??e.state,value:t.value??e.value,attributes:t.attributes??e.attributes}}(Ud,n):Ud:void 0;var n;if(t&&t.src===e&&t.theme===this.theme&&t.tile===this.tile&&JSON.stringify(t.sim)===JSON.stringify(i))return t.value;const s="dark"===this.theme,r=e?{...e,themes:{...e.themes??{},darkMode:s}}:lp(s),a=gs(this.tile,r),o=i?function(e,t){const i=e.states??{};return{...e,states:{...i,[Wd]:Qd(t)}}}(a,i):a;return this._hassFor={src:e,theme:this.theme,tile:this.tile,sim:i,value:o},o}willUpdate(e){if(!customElements.get("magic-card")||!this.doc)return;this._card||(this._card=document.createElement("magic-card"));const t=rp(this.doc,this.preview),i=t!==this._drives;if(this._drives=t,e.has("doc")||e.has("tile")||e.has("reduced")||e.has("lookup")||e.has("_wraps")||i||!this._card.shadowRoot)try{this._card.setConfig(Ss(this.doc,this.lookup,{tile:this.tile,still:this.reduced,...t?{entity:sp}:{}}))}catch(e){console.warn("Magic Card studio: preview failed",e)}if(e.has("hass")||e.has("theme")||e.has("preview")||e.has("tile")||e.has("doc")||!this._card.hass){const e=this._previewHass();e!==this._card.hass&&(this._card.hass=e)}}firstUpdated(){this._observeFrame()}_applyHide(){const e=this._card?.shadowRoot;e&&this.doc&&(this._sheets.set(e,((e,t,i)=>{const n=[],s=[],r=yo(e,t);for(const t of r){const r=t.indexOf(":"),a=t.slice(0,r),o=t.slice(r+1);"part"===a?n.push(`[data-p=${Td(o)}]${Fd}`):"group"===a?n.push(`[data-g=${Td(o)}]${Fd}`):"shape"===a?n.push(`[data-s=${Td(o)}]${Fd}`):"emitter"!==a||i||e.particles?.sim?"target"===a&&("background"===o?s.push(".mc-module-wrapper{background:none!important}",`[data-mc-gen-bg]${Fd}`):"element"!==o&&s.push(`${Bd(o)}${Fd}`)):s.push(`.mc-anim-fx${Fd}`)}return i&&s.push(...function(e,t){const i=[];return t.ids.forEach((n,s)=>{const r=t.emitterSlots.find(e=>e.index===s);if(!r)return;const a=`.mc-anim-fx[data-fx^=${Td(`${t.base}${r.part?"o":""}-g`)}]>i`,o=(e,t)=>{t>=e&&i.push(`${a}:nth-child(n+${e}):nth-child(-n+${t})${Fd}`)};e.has(`emitter:${n}`)?o(r.first+1,r.first+r.parents+r.children):(e.has(`${bo}${n}`)&&o(r.first+1,r.first+r.parents),e.has(`children:${n}`)&&o(r.first+r.parents+1,r.first+r.parents+r.children))}),i}(r,i)),{icon:n.join("\n"),card:s.join("\n")}})(this.doc,this.layerView,this.stageParticles)),this._moRoot!==e&&(this._mo?.disconnect(),this._moRoot=e,this._mo=new MutationObserver(()=>{this._attachQueued||(this._attachQueued=!0,queueMicrotask(()=>{this._attachQueued=!1,this._sheets.attach(this._card?.shadowRoot)}))}),this._mo.observe(e,{childList:!0,subtree:!0})))}_showAll(){const e={...this.layerView,hidden:[],solo:[]};this.dispatchEvent(new CustomEvent("layer-view-change",{detail:{view:e,announce:this.layerView.locked.length?as(47):as(46)},bubbles:!0,composed:!0}))}updated(e){(e.has("doc")||e.has("layerView")||e.has("stageParticles")||e.has("tile")||e.has("reduced")||!this._moRoot)&&(this._applyHide(),this._card?.updateComplete?.then(()=>this._applyHide())),e.has("subjectTarget")&&requestAnimationFrame(()=>this._emitRect()),e.has("zoomIcon")&&requestAnimationFrame(()=>this._fit()),(e.has("doc")||e.has("tile")||e.has("reduced")||e.has("preview"))&&this._card?.updateComplete?.then(()=>{this._sync(),requestAnimationFrame(()=>this._fit())})}_pickTile(e){e!==this.tile&&(this.tile=e,this.dispatchEvent(new CustomEvent("stage-tile",{detail:{tile:e},bubbles:!0,composed:!0})))}_seg(e,t,i,n,s){return a.qy`<div class="seg ${s}" role="radiogroup" aria-label=${e} @keydown=${e=>{const s=t.findIndex(e=>e.id===i),r={ArrowRight:(s+1)%t.length,ArrowLeft:(s-1+t.length)%t.length,Home:0,End:t.length-1}[e.key];if(void 0===r)return;e.preventDefault(),n(t[r].id);const a=e.currentTarget;this.updateComplete.then(()=>a.querySelector('[aria-checked="true"]')?.focus())}}>
      ${t.map(e=>{const t=e.id===i;return a.qy`<button
          type="button"
          role="radio"
          aria-checked=${t?"true":"false"}
          tabindex=${t?"0":"-1"}
          title=${as(e.label)}
          @click=${()=>n(e.id)}
        >
          <ha-icon icon=${e.icon}></ha-icon><span class="lbl">${as(e.label)}</span>
        </button>`})}
    </div>`}_missing(){return a.qy`<div class="missing" role="status">
      <ha-icon icon="mdi:card-off-outline"></ha-icon>
      <strong>${as(438)}</strong>
      <p>${as(978)}</p>
    </div>`}render(){const e=this.cycle,t=Math.min(this._t,e),i=!!customElements.get("magic-card"),n=this._k,s=this._off,r=s?"":`width: ${Math.round(360*n)}px; height: ${this._fh?`${Math.round(this._fh*n)}px`:"auto"}`,o=s?`translate(${s.x}px, ${s.y}px) `:"";return a.qy`
      <div class="canvas">
        <div class="dock dock-top">
          ${this.hiddenLayers>0||this.layerView.solo.length>0?a.qy`<div class="hide-chip" role="group" aria-label=${as(409)}>
                <ha-icon icon="mdi:eye-off-outline"></ha-icon>
                <span>${this.hiddenLayers>0?as(692,{count:this.hiddenLayers}):as(849)}</span>
                <button type="button" class="show-all" aria-label=${as(825)} @click=${()=>this._showAll()}>${as(824)}</button>
              </div>`:a.s6}
          <slot name="top"></slot>
        </div>
        <div class="area ${this._canvasOn?"canvas-on":""}">
        <div class="fit ${s?"zoomed":""}" style=${r}>
          <div class="frame" style="${op[this.theme]};width:${360}px;transform:${o}scale(${n})" data-theme=${this.theme}>
            ${i&&this._card?this._card:this._missing()}
            <div class="overlay"><slot name="overlay"></slot></div>
          </div>
        </div>
        <div class="canvas-layer"><slot name="canvas" @slotchange=${this._onCanvasSlot}></slot></div>
        ${this.reduced&&i?a.qy`<p class="note">${as(1084)}</p>`:a.s6}
        ${s?a.qy`<span class="zoom-tag" title=${as(1094)}>${as(378,{percent:Math.round(100*n)})}</span>`:Math.abs(n-1)>.005?a.qy`<span class="zoom-tag" title=${as(977)}>${Math.round(100*n)}%</span>`:a.s6}
        </div>
        <div class="dock dock-bottom"><slot name="bottom"></slot></div>
      </div>
      <div class="transport">
        <button
          type="button"
          class="icon-btn sm play"
          aria-label=${this.playing?as(649):as(666)}
          title=${this.playing?as(649):as(666)}
          ?disabled=${this.reduced||!i}
          @click=${()=>this.togglePlay()}
        >
          <ha-icon icon=${this.playing?"mdi:pause":"mdi:play"}></ha-icon>
        </button>
        <input
          class="scrub"
          type="range"
          min="0"
          max=${e}
          step="0.01"
          aria-label=${as(686)}
          aria-valuetext=${as(1247,{now:t.toFixed(2),total:e.toFixed(2)})}
          .value=${String(t)}
          ?disabled=${this.reduced||!i}
          @input=${e=>this.seek(Number(e.target.value))}
        />
        <span class="time mono" aria-hidden="true">${t.toFixed(2)} / ${e.toFixed(2)} s</span>
        <label class="speed">
          <span class="sr-only">${as(856)}</span>
          <div class="select">
            <select class="input" aria-label=${as(856)} @change=${e=>this.setSpeed(Number(e.target.value))}>
              ${np.map(e=>a.qy`<option value=${e} ?selected=${e===this.speed}>${e}×</option>`)}
            </select>
            <ha-icon icon="mdi:chevron-down"></ha-icon>
          </div>
        </label>
        <span class="view">
          ${this._seg(as(694),hs,this.tile,e=>this._pickTile(e),"tiles")}
          ${this._seg(as(122),ip,this.theme,e=>this.theme=e,"themes")}
          <button
            type="button"
            class="toggle reduced"
            aria-pressed=${this.reduced?"true":"false"}
            aria-label=${as(706)}
            title=${as(696)}
            @click=${()=>this.reduced=!this.reduced}
          >
            <ha-icon icon="mdi:motion-pause-outline"></ha-icon>
          </button>
        </span>
      </div>
    `}}dp.styles=[Cs,As,a.AH`
      :host {
        display: grid;
        grid-template-rows: minmax(0, 1fr) auto;
        min-height: 0;
        min-width: 0;
        overflow: hidden;
      }
      .transport {
        display: flex;
        align-items: center;
        gap: 6px 8px;
        flex-wrap: wrap;
        padding: 6px 12px;
        background: var(--mc-surface);
        border-top: 1px solid var(--mc-divider);
        min-width: 0;
      }
      /* tile, theme and reduced motion: right-aligned, wrapping as one group when the stage is narrow */
      .view {
        display: inline-flex;
        flex-wrap: wrap;
        max-width: 100%;
        align-items: center;
        gap: 8px;
        margin-left: auto;
        margin-inline: auto 0;
        padding-left: 8px;
        padding-inline: 8px 0;
        border-left: 1px solid var(--mc-divider);
        border-inline-width: 1px 0;
        border-inline-style: solid;
        border-inline-color: var(--mc-divider);
      }
      .view .seg {
        flex-wrap: wrap;
      }
      .seg > button {
        gap: 6px;
        min-height: 28px;
        padding: 0 8px;
      }
      .seg > button ha-icon {
        --mdc-icon-size: 16px;
      }
      /* icon-only tiles and themes: the label is for assistive tech, the title for the tooltip */
      .seg .lbl {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip: rect(0 0 0 0);
        white-space: nowrap;
      }
      .toggle {
        display: inline-grid;
        place-items: center;
        width: 34px;
        height: 34px;
        padding: 0;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface);
        color: var(--mc-text-2);
        --mdc-icon-size: 18px;
        transition:
          background-color 0.15s ease-out,
          color 0.15s ease-out;
      }
      .toggle:hover {
        background: var(--mc-surface-2);
        color: var(--mc-text);
      }
      .toggle[aria-pressed='true'] {
        background: var(--mc-accent-tint);
        border-color: transparent;
        color: var(--mc-accent-ink);
      }
      .canvas {
        position: relative;
        display: flex;
        flex-direction: column;
        min-height: 0;
        min-width: 0;
        overflow: hidden;
        background-color: var(--mc-canvas);
        background-image: radial-gradient(var(--mc-canvas-dot) 1px, transparent 1.2px);
        background-size: 16px 16px;
      }
      /* the card's area: what the card is fitted into */
      .area {
        position: relative;
        /* fills a stage of fixed height (the studio); a stage of auto height wraps the card */
        flex: 1 1 auto;
        display: grid;
        place-items: center;
        padding: ${(0,a.iz)(16)}px;
        min-height: 0;
        min-width: 0;
      }
      /* docked stage tools (toolbars, the preview-entity capsule): unscaled, above / below the card, never over it */
      .dock {
        flex: none;
        min-width: 0;
      }
      .dock ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        display: flex !important;
        justify-content: center;
        margin: 8px 12px 0;
      }
      .hide-chip {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin: 8px auto 0;
        padding: 2px 4px 2px 10px;
        width: fit-content;
        max-width: calc(100% - 24px);
        border: 1px solid var(--mc-divider);
        border-radius: 9999px;
        background: var(--mc-surface-2, var(--mc-surface));
        color: var(--mc-text);
        font-size: 0.8125rem;
        --mdc-icon-size: 16px;
      }
      .hide-chip .show-all {
        min-height: 24px;
        padding: 0 10px;
        border: 0;
        border-radius: 9999px;
        background: transparent;
        color: var(--mc-accent, var(--primary-color, #03a9f4));
        font: inherit;
        font-weight: 600;
        cursor: pointer;
      }
      .hide-chip .show-all:hover {
        background: color-mix(in srgb, var(--mc-accent, var(--primary-color, #03a9f4)) 12%, transparent);
      }
      .hide-chip .show-all:focus-visible {
        outline: 2px solid var(--mc-accent, var(--primary-color, #03a9f4));
        outline-offset: 1px;
      }
      .dock-bottom ::slotted(*) {
        margin: 0 12px 8px;
      }
      /* the scaled card's box; the frame inside keeps its natural size and scales from its corner */
      .fit {
        position: relative;
      }
      /* zoomed to the icon: the canvas shows the part of the card around it */
      .fit.zoomed {
        position: absolute;
        inset: 0;
        overflow: hidden;
      }
      .frame {
        position: absolute;
        left: 0; /* physical */
        top: 0;
        transform-origin: 0 0;
        color: var(--primary-text-color);
      }
      /* the path editor's overlay and stage tools: exactly over the preview card */
      .overlay {
        position: absolute;
        inset: 0;
        pointer-events: none;
      }
      .overlay ::slotted(*) {
        position: absolute;
        inset: 0;
        pointer-events: auto;
      }
      /* tools that edit over the card but cannot sit inside its scale: the card area's box, unscaled */
      /* a canvas tool is in the slot: a drag on the area is the tool's, not a page pan or zoom */
      .area.canvas-on {
        touch-action: none;
      }
      .canvas-layer {
        position: absolute;
        inset: 0;
        pointer-events: none;
      }
      .canvas-layer ::slotted(*) {
        position: absolute;
        inset: 0;
        pointer-events: none;
      }
      .frame magic-card {
        display: block;
      }
      .note {
        position: absolute;
        left: 50%; /* physical */
        bottom: 8px;
        transform: translateX(-50%);
        width: max-content;
        max-width: calc(100% - 32px);
        margin: 0;
        padding: 4px 10px;
        border-radius: var(--mc-radius);
        background: var(--mc-surface);
        text-align: center;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .zoom-tag {
        position: absolute;
        right: 8px;
        inset-inline: auto 8px;
        top: 8px;
        padding: 1px 6px;
        border-radius: 6px;
        background: var(--mc-surface);
        border: 1px solid var(--mc-divider);
        font-size: 0.6875rem;
        font-variant-numeric: tabular-nums;
        color: var(--mc-text-2);
        pointer-events: none;
      }
      .missing {
        display: grid;
        justify-items: center;
        gap: 8px;
        padding: 24px;
        text-align: center;
        border: 1px dashed var(--mc-divider);
        border-radius: var(--mc-radius-lg);
        background: var(--mc-surface);
        color: var(--mc-text);
      }
      .missing ha-icon {
        --mdc-icon-size: 32px;
        color: var(--mc-text-2);
      }
      .missing strong {
        font-weight: 500;
      }
      .missing p {
        margin: 0;
        font-size: 0.8125rem;
        color: var(--mc-text-2);
        max-width: 36ch;
      }
      .scrub {
        flex: 1 1 120px;
        min-width: 80px;
        accent-color: var(--mc-accent-fill);
      }
      .time {
        flex: none;
        min-width: 11ch;
        text-align: right;
        text-align: end;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .speed .select {
        width: 76px;
      }
      .speed select.input {
        min-height: 32px;
        padding-top: 2px;
        padding-bottom: 2px;
      }
    `],tp([(0,o.MZ)({attribute:!1})],dp.prototype,"doc",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"lookup",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"hass",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"tile",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"preview",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"subjectTarget",void 0),tp([(0,o.MZ)({type:Boolean})],dp.prototype,"zoomIcon",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"layerView",void 0),tp([(0,o.MZ)({attribute:!1})],dp.prototype,"stageParticles",void 0),tp([(0,o.MZ)({type:Number})],dp.prototype,"hiddenLayers",void 0),tp([(0,o.wk)()],dp.prototype,"theme",void 0),tp([(0,o.wk)()],dp.prototype,"reduced",void 0),tp([(0,o.wk)()],dp.prototype,"speed",void 0),tp([(0,o.wk)()],dp.prototype,"playing",void 0),tp([(0,o.wk)()],dp.prototype,"_t",void 0),tp([(0,o.wk)()],dp.prototype,"_k",void 0),tp([(0,o.wk)()],dp.prototype,"_fh",void 0),tp([(0,o.wk)()],dp.prototype,"_off",void 0),tp([(0,o.wk)()],dp.prototype,"_wraps",void 0),tp([(0,o.wk)()],dp.prototype,"_canvasOn",void 0);var pp=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const hp={"Glow & pulse":"mdi:lightbulb-on-outline",Motion:"mdi:rotate-right",Playful:"mdi:emoticon-happy-outline","Light & colour":"mdi:palette-outline","Rings & sweeps":"mdi:radar",Borders:"mdi:border-outside","Weather & device":"mdi:weather-partly-rainy",Scenes:"mdi:image-filter-hdr",Backgrounds:"mdi:gradient-horizontal",Seasonal:"mdi:pine-tree",Interaction:"mdi:gesture-tap","Fire & heat":"mdi:fire",Cleaning:"mdi:broom",Christmas:"mdi:pine-tree",Halloween:"mdi:halloween",Valentine:"mdi:heart-outline","Home automation":"mdi:home-automation"};let up,mp;const gp=e=>e in ue?(0,te.t)(ue[e]):e,fp=e=>"builtin"===e.kind?e.id:`cat:${e.entry.id}`,vp=e=>"builtin"===e.kind?e.group:e.entry.group,bp=[...he,...["Fire & heat","Cleaning","Christmas","Halloween","Valentine","Home automation","Light & colour"].filter(e=>!he.includes(e))],yp=new Map,xp=new WeakMap;function _p(e){if("catalogue"===e.kind){if(xp.has(e.entry))return xp.get(e.entry);let t;try{t=e.entry.build()}catch{t=void 0}return xp.set(e.entry,t),t}if(yp.has(e.id))return yp.get(e.id);let t=Nt(e.id);return t&&e.tap&&(t={...t,iterations:"infinite"}),yp.set(e.id,t),t}class wp extends a.WF{constructor(){super(...arguments),this.play=!1,this.lookup=()=>{},this._visible="undefined"==typeof IntersectionObserver}connectedCallback(){super.connectedCallback(),"undefined"!=typeof IntersectionObserver&&(this._io=new IntersectionObserver(e=>{const t=e.some(e=>e.isIntersecting);t!==this._visible&&(this._visible=t)}),this._io.observe(this)),customElements.get("magic-card")||customElements.whenDefined("magic-card").then(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this._io?.disconnect(),this._io=void 0,this._card=void 0}willUpdate(e){const t=this.source?_p(this.source):void 0;if(!(this._visible&&t&&this.source&&customElements.get("magic-card")))return void(this._card=void 0);const i=!this._card;if(i&&(this._card=document.createElement("magic-card")),i||e.has("source")||e.has("play")||e.has("lookup"))try{const e=Ss(t,this.lookup,{tile:"card",thumb:!0,as:(n=fp(this.source),`pt-${n.toLowerCase().replace(/[^a-z0-9_-]/g,"-")}`.slice(0,64)),still:!this.play}),i="catalogue"===this.source.kind?this.source.entry.icon:void 0;i&&function(e,t){const i=e.rows??[];for(const e of i)for(const i of e.columns??[])for(const e of i.modules??[])"icon"in e&&(e.icon=t)}(e,i),this._card.setConfig(e)}catch{return void(this._card=void 0)}var n;(i||e.has("hass"))&&(this._card.hass=gs("card",this.hass??lp(!1)))}render(){const e=this.source?hp[vp(this.source)]??"mdi:animation-outline":"mdi:animation-outline";return a.qy`<div class="box">${this._card?a.qy`<div class="scale">${this._card}</div>`:a.qy`<ha-icon icon=${e}></ha-icon>`}</div>`}}wp.styles=[Cs,a.AH`
      :host {
        display: block;
        width: 100%;
        height: 88px;
      }
      .box {
        position: relative;
        width: 100%;
        height: 100%;
        overflow: hidden;
        display: grid;
        place-items: center;
        border-radius: var(--mc-radius);
        background-color: var(--mc-canvas);
        background-image: radial-gradient(var(--mc-canvas-dot) 1px, transparent 1.2px);
        background-size: 8px 8px;
        color: var(--mc-text-2);
        --mdc-icon-size: 24px;
      }
      /* a fixed 200px card scaled to 120px: the type never reflows per tile; 8px of canvas around it for glows and borders */
      .scale {
        position: absolute;
        left: 50%; /* physical */
        top: 50%;
        width: 200px;
        transform: translate(-50%, -50%) scale(0.6);
        pointer-events: none;
      }
      .scale magic-card {
        display: block;
        --ha-card-border-width: 0;
      }
    `],pp([(0,o.MZ)({attribute:!1})],wp.prototype,"source",void 0),pp([(0,o.MZ)({type:Boolean})],wp.prototype,"play",void 0),pp([(0,o.MZ)({attribute:!1})],wp.prototype,"hass",void 0),pp([(0,o.MZ)({attribute:!1})],wp.prototype,"lookup",void 0),pp([(0,o.wk)()],wp.prototype,"_visible",void 0);class kp extends a.WF{constructor(){super(...arguments),this.sources=[],this.query="",this.lookup=()=>{},this.notice="",this._active=new Set,this._previewing=new Set,this._reduced=!1,this._timers=new Map,this._onMq=()=>{this._reduced=!!this._mq?.matches}}connectedCallback(){super.connectedCallback(),this._mq="function"==typeof window.matchMedia?window.matchMedia(as(3)):void 0,this._reduced=!!this._mq?.matches,this._mq?.addEventListener?.("change",this._onMq)}disconnectedCallback(){super.disconnectedCallback(),this._mq?.removeEventListener?.("change",this._onMq),this._mq=void 0;for(const e of this._timers.values())clearTimeout(e);this._timers.clear()}_set(e,t,i){const n=this[e];if(n.has(t)===i)return;const s=new Set(n);i?s.add(t):s.delete(t),this[e]=s}_preview(e,t){clearTimeout(this._timers.get(t)),this._set("_previewing",t,!0),this._timers.set(t,setTimeout(()=>{this._timers.delete(t),this._set("_previewing",t,!1)},function(e){const t="number"==typeof e?.duration?e.duration:2;return Math.min(8e3,Math.max(2500,Math.round(1e3*t)))}(_p(e))))}_pick(e){this.dispatchEvent(new CustomEvent("preset-pick",{detail:{source:e},bubbles:!0,composed:!0}))}_tile(e){const t=fp(e),i=(e=>"builtin"===e.kind?e.name:e.entry.name)(e),n=(e=>"builtin"===e.kind?e.tap||e.heavy:!!e.entry.heavy)(e),s=(e=>"builtin"===e.kind&&e.tap)(e),r=!this._reduced&&(!n||this._active.has(t)||this._previewing.has(t));return a.qy`<li class="pt-cell">
      <button
        type="button"
        class="pt"
        data-preset=${t}
        title=${i}
        aria-description=${s?as(676):a.s6}
        @click=${()=>this._pick(e)}
        @pointerenter=${()=>this._set("_active",t,!0)}
        @pointerleave=${()=>this._set("_active",t,!1)}
        @focus=${()=>this._set("_active",t,!0)}
        @blur=${()=>this._set("_active",t,!1)}
      >
        <mc-preset-thumb aria-hidden="true" .source=${e} .play=${r} .hass=${this.hass} .lookup=${this.lookup}></mc-preset-thumb>
        <span class="nm">${i}</span>
        ${s?a.qy`<span class="chip is-count" aria-hidden="true">${as(919)}</span>`:a.s6}
      </button>
      ${n&&!this._reduced?a.qy`<button type="button" class="pt-play" tabindex="-1" aria-hidden="true" title=${as(690)} @click=${()=>this._preview(e,t)}>
            <ha-icon icon="mdi:play"></ha-icon>
          </button>`:a.s6}
    </li>`}render(){const e=function(e,t){const i=(0,Ft.A)(t).split(/\s+/).filter(Boolean),n=e=>{if(!i.length)return!0;const t=(0,Ft.A)("builtin"===e.kind?`${e.name} ${e.id} ${e.group} ${gp(e.group)}`:`${e.entry.name} ${e.entry.id} ${e.entry.group} ${e.entry.tags.join(" ")}`);return i.every(e=>t.includes(e))},s=new Map;for(const t of e){if(!n(t))continue;const e=vp(t),i=s.get(e);i?i.push(t):s.set(e,[t])}return bp.filter(e=>s.has(e)).map(e=>({group:e,tiles:s.get(e)}))}(this.sources,this.query.trim());return a.qy`
      ${e.length?e.map(e=>a.qy`<section class="pg" role="group" aria-label=${gp(e.group)}>
              <h3>${gp(e.group)} <span class="chip is-count">${e.tiles.length}</span></h3>
              <ul class="grid" role="list">
                ${e.tiles.map(e=>this._tile(e))}
              </ul>
            </section>`):a.qy`<div class="no-results">
            <p>${as(562,{query:this.query})}</p>
            <button type="button" class="btn btn-text btn-sm no-results-clear" @click=${()=>this.dispatchEvent(new CustomEvent("preset-clear-search",{bubbles:!0,composed:!0}))}>
              ${as(147)}
            </button>
          </div>`}
      <p class="notice" role="status" ?hidden=${!this.notice}>${this.notice}</p>
    `}}kp.styles=[Cs,As,a.AH`
      :host {
        display: block;
        max-height: min(64vh, 640px);
        overflow: auto;
        /* sticky group headings never cover the focused tile (WCAG 2.4.11) */
        scroll-padding-top: 32px;
        padding-inline-end: 4px;
      }
      .pg + .pg {
        margin-top: 12px;
      }
      h3 {
        position: sticky;
        top: 0;
        z-index: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0;
        padding: 4px 0 6px;
        background: var(--mc-surface);
        font-size: 0.8125rem;
        font-weight: 500;
        color: var(--mc-text-2);
      }
      .grid {
        list-style: none;
        margin: 0;
        padding: 2px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(136px, 1fr));
        gap: 10px;
      }
      .pt-cell {
        position: relative;
        display: flex;
      }
      .pt {
        width: 100%;
        display: grid;
        align-content: start;
        justify-items: center;
        gap: 6px;
        padding: 8px;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface);
        color: var(--mc-text);
        font: inherit;
        cursor: pointer;
        text-align: center;
      }
      .pt:hover {
        border-color: color-mix(in srgb, var(--mc-accent) 60%, transparent);
      }
      .pt:focus-visible {
        outline: 2px solid var(--mc-accent);
        outline-offset: 2px;
      }
      .nm {
        font-size: 0.8125rem;
        line-height: 1.25;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
      }
      .pt-play {
        position: absolute;
        top: 12px;
        right: 12px;
        inset-inline: auto 12px;
        width: 24px;
        height: 24px;
        display: grid;
        place-items: center;
        padding: 0;
        border-radius: 9999px;
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface);
        color: var(--mc-text);
        cursor: pointer;
        --mdc-icon-size: 16px;
      }
      .pt-play:hover {
        border-color: var(--mc-field-border);
      }
      .no-results {
        display: grid;
        justify-items: center;
        gap: 8px;
        padding: 32px 12px;
        text-align: center;
      }
      .no-results p,
      .notice {
        margin: 0;
        color: var(--mc-text-2);
      }
      .notice {
        margin-top: 12px;
        font-size: 0.8125rem;
      }
    `],pp([(0,o.MZ)({attribute:!1})],kp.prototype,"sources",void 0),pp([(0,o.MZ)()],kp.prototype,"query",void 0),pp([(0,o.MZ)({attribute:!1})],kp.prototype,"hass",void 0),pp([(0,o.MZ)({attribute:!1})],kp.prototype,"lookup",void 0),pp([(0,o.MZ)()],kp.prototype,"notice",void 0),pp([(0,o.wk)()],kp.prototype,"_active",void 0),pp([(0,o.wk)()],kp.prototype,"_previewing",void 0),pp([(0,o.wk)()],kp.prototype,"_reduced",void 0);var $p=i(2231);let Mp,Sp;async function zp(){const e=await i.e(1400).then(()=>i(7695));return Object.values(e).find(Array.isArray)??[]}var Cp=i(1699),Ap=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const jp=e=>e?`mc-anim-draft:${e}`:"mc-anim-draft-new";function qp(e){try{const t=JSON.parse(sessionStorage.getItem(e)??"null");return t&&"object"==typeof t&&"string"==typeof t.id&&"string"==typeof t.name&&ot.includes(t.kind)?t:void 0}catch{return}}function Ep(e,t){try{const i=t?JSON.stringify(t):"";i&&i.length<=65536?sessionStorage.setItem(e,i):sessionStorage.removeItem(e)}catch{}}const Hp=[{value:"normal",label:570},{value:"reverse",label:745},{value:"alternate",label:56},{value:"alternate-reverse",label:57}],Lp={"mc-anim-states-panel":"mdi:state-machine","mc-anim-key-inspector":"mdi:key-variant","mc-anim-part-inspector":"mdi:vector-square","mc-anim-shape-inspector":"mdi:draw","mc-anim-bindings-panel":"mdi:link-variant","mc-anim-targets-layers":"mdi:card-text-outline","mc-anim-parts-layers":"mdi:vector-square","mc-anim-shapes-layers":"mdi:shape-outline","mc-anim-shapes-under-layers":"mdi:shape-outline","mc-anim-particles-layers":"mdi:shimmer","mc-anim-path-layers":"mdi:vector-curve","mc-anim-steps-layers":"mdi:format-list-numbered","mc-anim-part-presets":"mdi:auto-fix"},Vp="mc-anim-parts-layers",Op=new Set(["mc-anim-keyframes-editor","mc-anim-sequence-editor",Vs]),Pp="var(--primary-color, #03a9f4)",Rp=["infinite","1","2","3","5"],Dp=["center","top","bottom","left","right","top left","top right","bottom left","bottom right"],Np={keyframes:541,particles:542,path:543,sequence:544},Fp={keyframes:89,particles:90,path:91,sequence:92},Tp={keyframes:492,particles:379,path:338,sequence:667},Bp=["name","duration","easing","iterations","direction","target","origin"];function Ip(e){const t=e.composedPath()[0];return t instanceof HTMLElement&&(/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)||t.isContentEditable)}const Zp=e=>{const t=e??{},i=Array.isArray(t.errors)?t.errors.filter(e=>e&&"string"==typeof e.message):[];return{message:"string"==typeof t.message&&t.message?t.message:as(770),errors:i}},Wp="mcas-split",Kp="mcas-sections";function Up(){return/Mac|iPhone|iPad/.test(navigator.platform||"")?"⌘\\":"Ctrl+\\"}function Gp(){const e=Up();return[{id:"layers",side:"start",controls:"layers",name:as(410),noun:as(1120),hideLabel:as(365,{noun:as(1120),keys:e}),showLabel:as(827,{noun:as(1120),keys:e})},{id:"inspector",side:"end",controls:"inspector",name:as(389),noun:as(1116),hideLabel:as(365,{noun:as(1116),keys:e}),showLabel:as(827,{noun:as(1116),keys:e})}]}function Yp(e){return{locale:e,hidden:as(1248,{panels:"{panels}"}),shown:as(1249,{panels:"{panels}"}),hintOne:as(990,{noun:"{noun}"}),hintMany:as(850),hintMigrated:as(957),hintShortcut:as(823,{keys:Up()}),gotIt:as(350)}}function Jp(e){try{return localStorage.getItem(e)}catch{return null}}function Xp(e,t){try{void 0===t?localStorage.removeItem(e):localStorage.setItem(e,t)}catch{}}const Qp=e=>Math.min(.8,Math.max(.15,e)),eh=e=>"keyframes"===e.kind||"sequence"===e.kind;function th(e){if(!e)return"none";const t=e.keys?.[0];return`${e.kind}|${"keys"===e.kind?`${t?.target}|${t?.lane}|${1===e.keys?.length?1:"n"}`:e.target??e.tool??""}`}let ih="loading";const nh=(0,te.G)().then(e=>ih=e?"ready":"failed");class sh extends a.WF{constructor(){super(...arguments),this.standalone=!1,this._docs=new Map,this._view="library",this._query="",this._picked=new Set,this._kind="all",this._menu=!1,this._menuClosedAt=0,this._saved=null,this._errors=[],this._saveError="",this._busy=!1,this._status="",this._pseudo=!1,this._presetQuery="",this._catalogueFailed=!1,this._labels=ih,this._customRepeat=!1,this._selection=Ps,this._tile="icon",this._split=function(){const e=Number(Jp(Wp));return null!==Jp(Wp)&&Number.isFinite(e)&&e>0?Qp(e):.4}(),this._lips=new Pd(this,{editor:"anim-studio",keys:"manual",panels:Gp(),strings:Yp("en")}),this._lipLocale="en",this._wasEditing=!1,this._drawerNarrow=!1,this._layersSheet=!1,this._layersWas=!1,this._barInert=!1,this._wrapBack=!1,this._modOnly=!1,this._width=0,this._height=0,this._userSplit=null!==Jp(Wp),this._drawerOpen=!1,this._collapsed=function(){try{const e=JSON.parse(Jp(Kp)??"[]");return new Set(Array.isArray(e)?e.filter(e=>"string"==typeof e):[])}catch{return new Set}}(),this._editorRequested=!1,this._history=new ws(void 0),this._lookup=e=>this._docs.get(e),this._onBeforeUnload=e=>{this._keepDraft(),this.dirty&&(e.preventDefault(),e.returnValue="")},this._taken=e=>this._docs.has(e)||this._doc?.id===e,this._time=0,this._stageScale=1,this._libraryObj={},this._gesture=!1,this._layerViews=new Map,this._emitter={index:0,all:!1},this._onEmitter=e=>{e.stopPropagation();const{index:t,all:i}=e.detail??{};Number.isInteger(t)&&t>=0&&(t!==this._emitter.index||!!i!==this._emitter.all)&&(this._emitter={index:t,all:!!i})},this._onLayerView=e=>{const{view:t,announce:i}=e.detail;e.stopPropagation();const n=this._doc?.id;if(n){if(t!==this._layerViews.get(n)&&t!==this._viewOf(this._doc)){const e=new Map(this._layerViews);e.set(n,t),this._layerViews=e}i&&this._say(i)}},this._onKeydown=e=>{if(e.defaultPrevented||this._dialog)return;const t=e.key.toLowerCase(),i=(e.ctrlKey||e.metaKey)&&!e.altKey;if("editor"!==this._view)"/"!==e.key||i||Ip(e)||(e.preventDefault(),this.shadowRoot?.querySelector(".search input")?.focus());else{if(i&&!e.shiftKey&&("\\"===e.key||"Backslash"===e.code)&&!e.repeat)return e.preventDefault(),void this._toggleBoth();if(i&&"s"===t)return e.preventDefault(),void this.save();if(i&&("z"===t||"y"===t)){if(Ip(e))return;return e.preventDefault(),void("y"===t||e.shiftKey?this.redo():this.undo())}if(" "===e.key&&!i&&!Ip(e)){const t=e.composedPath()[0];if(t instanceof HTMLElement&&/^(BUTTON|A)$/.test(t.tagName))return;return e.preventDefault(),void this._stage()?.togglePlay()}if("Escape"===e.key&&!Ip(e)){if(this._narrow&&this._layersSheet)return e.preventDefault(),void this._closeLayersSheet();if("none"!==this._selection.kind){e.preventDefault();const t=this.shadowRoot?.querySelector(".insp"),i=this.shadowRoot?.activeElement,n=!!t&&!!i&&(t===i||t.contains(i));this._setSelection(Ps),!n&&i||(this._focusSel=".insp")}}}},this._modNow=new Set,this._onFrameDrawer=e=>{this._drawerOpen=e.detail.open},this._onFrameModified=e=>{this._modOnly=e.detail.on},this._onSelection=e=>{e.stopPropagation();const t=e.detail?.selection;var i;(i=t)&&"object"==typeof i&&["none","keys","target","tool"].includes(i.kind)&&this._setSelection(t)},this._onDocChange=e=>{e.stopPropagation();const{doc:t,label:i,transient:n}=e.detail??{};if(!t||!this._doc)return;const s=Ja(t);if(s)n||(this._endGesture(),this._say(as(578,{big:s})),this._doc={...this._doc});else{if(n)this._gesture?this._history.replace(t):(this._gestureBase=this._doc,this._history.push(t)),this._gesture=!0;else if(this._gesture){const e=this._gestureBase;!e||t!==e&&JSON.stringify(t)!==JSON.stringify(e)?this._history.replace(t):this._history.revert(),this._endGesture()}else this._history.push(t,`editor:${i??""}`);this._doc=t,this._check(),this._pruneSelection()}},this._onStageRect=e=>{const{width:t,height:i,subject:n}=e.detail??{};if(!Number.isFinite(t)||!Number.isFinite(i))return;this._stageRect&&this._stageRect.width===t&&this._stageRect.height===i||(this._stageRect={width:t,height:i}),JSON.stringify(n)!==JSON.stringify(this._subjectRect)&&(this._subjectRect=n);const{scale:s,viewBox:r,screen:a}=e.detail??{};Number.isFinite(s)&&s>0&&s!==this._stageScale&&(this._stageScale=s);const o={rect:{width:t,height:i},scale:Number.isFinite(s)&&s>0?s:1,...n?{subject:n}:{},...Array.isArray(r)&&4===r.length?{viewBox:r}:{},...a&&[a.left,a.top,a.width,a.height].every(Number.isFinite)?{screen:{left:a.left,top:a.top,width:a.width,height:a.height}}:{}};JSON.stringify(o)!==JSON.stringify(this._stageInfo)&&(this._stageInfo=o)},this._onPreviewChange=e=>{e.stopPropagation();const t=e.detail;if(!t||"object"!=typeof t)return;const i={...this._preview??{}};"string"==typeof t.state&&(i.state=t.state),"number"==typeof t.value&&Number.isFinite(t.value)&&(i.value=t.value),t.attributes&&"object"==typeof t.attributes&&(i.attributes={...t.attributes}),this._preview=Object.keys(i).length?i:void 0},this._onSeek=e=>{e.stopPropagation();const t=Number(e.detail?.time),i=this._stage();i&&Number.isFinite(t)&&i.seek(Math.min(1,Math.max(0,t))*i.cycle)},this._onSplitDown=e=>{if(0===e.button){e.preventDefault(),this._splitDrag={pointerId:e.pointerId};try{e.currentTarget.setPointerCapture?.(e.pointerId)}catch{}}},this._onSplitMove=e=>{if(!this._splitDrag||e.pointerId!==this._splitDrag.pointerId)return;const t=this._splitAt(e.clientY);void 0!==t&&this._setSplit(t,!1)},this._onSplitUp=e=>{this._splitDrag&&e.pointerId===this._splitDrag.pointerId&&(this._splitDrag=void 0,this._setSplit(this._split,!0))},this._onSplitKey=e=>{const t=e.shiftKey?.1:.05,i={ArrowUp:this._split-t,ArrowDown:this._split+t,Home:0,End:1};void 0!==i[e.key]&&(e.preventDefault(),this._setSplit(i[e.key],!0))},this._closeDialog=()=>{const e=this.shadowRoot?.querySelector("mc-ui-window");e?.open?e.close("action"):this._dialog=void 0}}willUpdate(e){e.has("hass")&&((0,ee.Zc)(this.hass),window.MagicCard?.setLocale?.(this.hass)),this.lang!==cs()&&(this.lang=cs());const t=cs();t!==this._lipLocale&&(this._lipLocale=t,this._lips.setPanels(Gp(),Yp(t)));const i="editor"===this._view&&!!this._doc;if(this._lips.columns({layers:i}),i&&!this._wasEditing&&this._lips.show("layers"),this._wasEditing=i,e.has("library")&&(this._docs=function(e){if(!e||"object"!=typeof e)return new Map;const t=Array.isArray(e)?e:(n=e,Array.isArray(n)?n:n&&"object"==typeof n?Object.entries(n).map(([e,t])=>t&&"object"==typeof t&&!("id"in t)&&ht.test(e)?{id:e,...t}:t):[]),i=new Map;var n;for(const e of t){const t=Ht(e);t.ok&&!i.has(t.doc.id)&&i.set(t.doc.id,t.doc)}return i}(this.library)),(e.has("library")||e.has("_docs"))&&(this._lookup=e=>this._docs.get(e),this._libraryObj=Object.fromEntries(this._docs)),e.has("library")){const e=this._doc&&this._saved?this._docs.get(this._saved.id):void 0;e&&!this.dirty&&JSON.stringify(e)!==JSON.stringify(this._saved)&&(this._saved=e,this._doc=e,this._playable=e,this._history.reset(e))}if(e.has("selectedId")){const e=this.selectedId||void 0;e?this._doc?.id!==e&&(this._wantId=e):("editor"===this._view&&!this.dirty&&this._saved&&this._closeEditor(!1),this._wantId=void 0)}if(this._wantId&&this._docs.has(this._wantId)){const e=this._docs.get(this._wantId);this._wantId=void 0,this.dirty||this._openDoc(e,!1,!1)}}updated(e){this._syncDrawer();const t="editor"===this._view;t!==this.hasAttribute("editing")&&(this.toggleAttribute("editing",t),this.dispatchEvent(new CustomEvent("mc-editor-fullscreen",{detail:{open:t},bubbles:!0,composed:!0})));const i=e.get("_doc"),n=this._layersShown,s=n!==this._layersWas||e.has("_drawerOpen");this._layersWas=n;const r=this._narrow&&n;for(const e of this.shadowRoot?.querySelectorAll(".center > :not(.layers-sheet)")??[])e.toggleAttribute("inert",r);const a=this.shadowRoot?.querySelector(".fr-bar");if(a&&(r||this._barInert)&&a.toggleAttribute("inert",r),this._barInert=r,e.has("_height")||e.has("_width")||s||e.has("_view")||e.has("_doc")&&i?.id!==this._doc?.id?this._autoSplit():e.has("_doc")&&this._autoSplit(!0),e.has("_doc")&&this._doc&&i&&i.id===this._doc.id&&(this._doc.rig?.shapes?.length??0)>(i.rig?.shapes?.length??0)){const e=this._doc.rig?.shapes??[],t=e[e.length-1].id;this._revealShape(t)}if(e.has("_selection")&&th(e.get("_selection"))!==th(this._selection)){const e=this.shadowRoot?.querySelector(".insp");e&&(e.scrollTop=0)}if(this._focusSel){const e=this.shadowRoot?.querySelector(this._focusSel);e&&(e.focus(),e instanceof HTMLInputElement&&e.select()),this._focusSel=void 0}const o=this._menu?this.shadowRoot?.querySelector("mc-ui-menu.new-menu"):void 0;o&&!o.open&&(o.anchor=this.shadowRoot?.querySelector(".new-btn")??void 0,o.show());const l=this.shadowRoot?.querySelector("mc-ui-window");if(l&&!l.open){const e=zd();e?.isConnected&&e!==document.body&&(this._opener=e),l.opener=this._opener,l.show();const t=l.querySelector("mc-anim-icon-start");t&&l.updateComplete.then(()=>setTimeout(()=>t.focusStart?.(),0));const i=l.querySelector("mc-transfer-panel");i&&l.updateComplete.then(()=>i.focusHeading?.())}else if(!l&&e.has("_dialog")&&e.get("_dialog")&&this._opener?.isConnected){const e=zd();e&&e!==document.body||this._opener.focus({preventScroll:!0}),this._opener=void 0}}connectedCallback(){super.connectedCallback(),(Sp??=function(e){let t;return()=>t??=async function(e){if("function"!=typeof FontFace||!document.fonts)return!1;const t=function(){const e=new Set;return document.fonts.forEach(t=>{return e.add(`${i=t.family,i.replace(/^["']|["']$/g,"")}/${t.weight}`);var i}),e}(),i=(await e()).filter(e=>!t.has(`${e.family}/${e.weight}`)).map(e=>new FontFace(e.family,`url(data:font/woff2;base64,${e.data})`,{weight:e.weight,display:"swap"}));await Promise.all(i.map(e=>e.load()));for(const e of i)document.fonts.add(e);return!0}(e).catch(e=>(console.warn("Magic Card: studio fonts not loaded",e),!1)).then(e=>(e||(t=void 0),e))}(zp))(),nh.then(()=>this._labels=ih),this.addEventListener("keydown",this._onKeydown),window.addEventListener("beforeunload",this._onBeforeUnload);const e=this._doc||this._dialog?void 0:qp(jp());e&&(this._dialog={type:"restore",draft:e,isNew:!0}),!this._editorRequested&&window.MagicCard?.loadEditor&&(this._editorRequested=!0,window.MagicCard.loadEditor());for(const e of[...Object.values(Ls).map(e=>e.tag),Vs,...Rs.map(e=>e.tag)])Os(e)||customElements.whenDefined(e).then(()=>this.requestUpdate());"undefined"==typeof ResizeObserver||this._ro||(this._ro=new ResizeObserver(e=>{const t=Math.round(e[0]?.contentRect.width??0),i=Math.round(e[0]?.contentRect.height??0);t&&t!==this._width&&(this._width=t),i&&i!==this._height&&(this._height=i)}),this._ro.observe(this))}disconnectedCallback(){super.disconnectedCallback(),this.removeEventListener("keydown",this._onKeydown),window.removeEventListener("beforeunload",this._onBeforeUnload),this._ro?.disconnect(),this._ro=void 0,this._keepDraft()}_keepDraft(){this._doc&&"restore"!==this._dialog?.type&&Ep(jp(this._saved?.id),this.dirty?this._doc:void 0)}get dirty(){const e=this._doc;if(!e)return!1;const t=this._dirtyFor;if(t&&t.doc===e&&t.saved===this._saved)return t.value;const i=!this._saved||JSON.stringify(e)!==JSON.stringify(this._saved);return this._dirtyFor={doc:e,saved:this._saved,value:i},i}get docs(){return[...this._docs.values()].sort((e,t)=>e.name.localeCompare(t.name))}async _emit(e,t,i=!0){const n={...t};if(this.dispatchEvent(new CustomEvent(e,{detail:n,bubbles:!0,composed:!0})),n.result)return await n.result;if(i&&!this.standalone)throw{message:as(933)}}_store(e){const t=new Map(this._docs);t.set(e.id,e),this._docs=t}_say(e){this._status="",this.updateComplete.then(()=>this._status=e),clearTimeout(this._toastTimer),this._toastTimer=setTimeout(()=>this._status="",4e3)}_stored(e,t){const i=e?.animation??e,n=i?Ht(i):void 0;return n?.ok?n.doc:t}_select(e){this._emit("mc-anim-select",{id:e},!1)}_new(e){this._menu=!1;const t=new Set(this.docs.map(e=>e.name)),i=as(Np[e]);let n=i;for(let e=2;t.has(n);e++)n=`${i} ${e}`;this._guard(()=>this._openDoc(mt(e,ks(n,this._taken),n),!0))}_openIconStart(){this._menu=!1,this._dialog={type:"icon"}}_startIcon(e){e.stopPropagation();const{doc:t,from:i}=e.detail??{};if(!t)return;this._dialog=void 0;const n=new Set(this.docs.map(e=>e.name));let s=t.name;for(let e=2;n.has(s);e++)s=`${t.name} ${e}`;const r={...t,id:ks(t.id,this._taken),name:s};this._guard(()=>{this._openDoc(r,!0);const e=r.rig?.parts[0]?.id;"icon"===i&&e&&(this._selection={kind:"target",target:`part:${e}`,targets:[`part:${e}`]})})}_openPresets(){this._presetQuery="",this._dialog={type:"presets"},this._catalogue||(this._catalogueFailed=!1,(Mp??=i.e(5494).then(()=>i(298)).then(e=>(0,$p.t)("magic-card-preset-catalogue.js",e),e=>{Mp=void 0,console.warn("Magic Card: preset catalogue not loaded",e)}),Mp).then(e=>{e?this._catalogue=e.CATALOGUE:this._catalogueFailed=!0}))}_pickPreset(e){e.stopPropagation();const t=(e.detail??{}).source;if(!t)return;if("builtin"===t.kind)return this._customise(t.id);let i;try{i=structuredClone(t.entry.build())}catch(e){return void this._say(as(1005,{message:Zp(e).message}))}const n={...i,id:ks(Dt(t.entry.id),this._taken)};this._dialog=void 0,this._guard(()=>this._openDoc(n,!0))}_presetSources(){return this._sourcesFor&&this._sourcesFor.catalogue===this._catalogue||(this._sourcesFor={catalogue:this._catalogue,list:[...(up&&mp===(0,te.H)()||(mp=(0,te.H)(),up=pe.map(e=>({kind:"builtin",id:e.id,name:(0,te.t)(e.name),group:e.group,tap:"tap"===e.trigger,heavy:"Seasonal"===e.group||!!e.seasonal}))),up),...(this._catalogue??[]).map(e=>({kind:"catalogue",entry:e}))]}),this._sourcesFor.list}async _clearPresetSearch(){this._presetQuery="",await this.updateComplete,this.shadowRoot?.querySelector("input.preset-search")?.focus()}_customise(e){const t=Nt(e,ks(Dt(e),this._taken));t&&(this._dialog=void 0,this._guard(()=>this._openDoc(t,!0)))}async _duplicate(e){const t={...structuredClone(e),id:ks(`${e.id}-copy`,this._taken),name:$s(e.name,new Set(this.docs.map(e=>e.name)))};try{const e=await this._emit("mc-anim-duplicate",{animation:t});this._store(this._stored(e,t)),this._say(as(280,{name:t.name}))}catch(e){this._say(as(281,{message:Zp(e).message}))}}async _rename(e,t){if(this._renaming!==e.id)return;this._renaming=void 0;const i=t.trim();if(!i||i===e.name)return;const n=Ht({...e,name:i});if(n.ok)try{const e=await this._emit("mc-anim-save",{animation:n.doc});this._store(this._stored(e,n.doc)),this._say(as(730,{clean:i}))}catch(e){this._say(as(731,{message:Zp(e).message}))}else this._say(as(584,{message:ys(n.errors[0].message)}))}_askDelete(e){const t=this.usage?this.usage[e.id]??0:void 0,i=(n=e.id,s=this._docs.values(),[...s].filter(e=>"sequence"===e.kind&&e.id!==n&&Ms(e).includes(n)));var n,s;0!==t||i.length?this._dialog={type:"delete",doc:e,uses:t,sequences:i}:this._delete(e)}async _delete(e){this._dialog=void 0;try{await this._emit("mc-anim-delete",{id:e.id});const t=new Map(this._docs);t.delete(e.id),this._docs=t,this._say(as(235,{name:e.name}))}catch(e){this._say(as(236,{message:Zp(e).message}))}}async _transferChunk(){try{const e=window.MagicCard;if(!e?.loadEditor||!e.loadTransfer||!await e.loadEditor())return;return await e.loadTransfer()}catch{return}}async _openTransfer(e){await this._transferChunk()?this._dialog=e:this._say(as(956))}_export(e){this._openTransfer({type:"export",items:zs(e,this._docs)})}async _onImport(e){e.stopPropagation();const{docs:t,errors:i}=function(e,t){const i=[],n=[];for(const s of e){const e=Ht({...s.data,id:s.id,name:s.name});e.ok?i.length>=Math.max(0,t)?n.push(as(1196,{id:s.id})):i.push(e.doc):n.push(`${s.id}: ${e.errors[0]?ys(e.errors[0].message):as(1129)}`)}return{docs:i,errors:n}}(e.detail.items,200-this._docs.size),n=[...i];let s=0;for(const e of t)try{const t=await this._emit("mc-anim-save",{animation:e});this._store(this._stored(t,e)),s++}catch(t){n.push(`${e.id}: ${Zp(t).message}`)}const r=as(383,{count:s});this._say(n.length?`${r} ${as(581,{list:n.slice(0,4).join("; ")})}`:r),n.length||(this._dialog=void 0)}_guard(e){"editor"===this._view&&this.dirty?this._dialog={type:"discard",then:e}:e()}_openDoc(e,t,i=!0){this._doc=e,this._emitter={index:0,all:!1},this._saved=t?null:e,this._history.reset(e),this._errors=[],this._saveError="",this._customRepeat=!1,this._playable=e,this._endGesture(),this._time=0,this._selection=Ps,this._preview=void 0,this._drawerOpen=!1,this._view="editor",this._focusSel=".back",i&&!t&&this._select(e.id);const n=t?void 0:qp(jp(e.id));n&&JSON.stringify(n)!==JSON.stringify(e)?this._dialog={type:"restore",draft:n,isNew:!1}:n&&Ep(jp(e.id))}_restoreDraft(e,t){this._dialog=void 0,t?this._openDoc(this._taken(e.id)?{...e,id:ks(e.id,this._taken)}:e,!0):this._doc?.id===e.id&&this._apply(e)}_closeEditor(e=!0){const t=!!this._doc;this._view="library",this._doc=void 0,this._selection=Ps,this._preview=void 0,this._saved=null,this._history.reset(void 0),this._errors=[],this._saveError="",e&&t&&this._select(null)}_back(){this._guard(()=>this._closeEditor())}_set(e,t){if(!this._doc)return;const i={...this._doc,...e};for(const[t,n]of Object.entries(e))void 0===n&&delete i[t];this._apply(i,t)}_apply(e,t){this._endGesture(),this._history.push(e,t),this._doc=e,this._check(),this._pruneSelection()}_endGesture(){this._gesture=!1,this._gestureBase=void 0}_viewOf(e){return function(e,t){const i=vo(e),n=e=>!/^(target|part|group|shape|lane|emitter|children|step):/.test(e)||i.has(e)||"target:element"===e,s=e=>e.every(n)?e:e.filter(n),r=s(t.hidden),a=s(t.solo),o=s(t.locked),l=s(t.open);return r===t.hidden&&a===t.solo&&o===t.locked&&l===t.open?t:{hidden:r,solo:a,locked:o,open:l}}(e,this._layerViews.get(e.id)??po)}_previewDoc(e,t){const i=this._previewMemo;if(i&&i.base===e&&i.view===t)return i.out;const n=((e,t)=>{const i=yo(e,t),n=new Map,s=new Set;for(const e of i)if(e.startsWith("lane:")){const t=e.lastIndexOf("|"),i=e.slice(5,t);n.set(i,[...n.get(i)??[],e.slice(t+1)])}else e.startsWith("step:")&&s.add(Number(e.slice(5)));if(!n.size&&!s.size)return e;const r={...e};return s.size&&(r.steps=(e.steps??[]).filter((e,t)=>!s.has(t))),n.size&&(e.keyframes&&n.has(Dr(e))&&(r.keyframes=$o(e.keyframes,n.get(Dr(e)))),e.tracks&&(r.tracks=e.tracks.flatMap(e=>{const t=n.get(e.target);if(!t)return[e];const i=$o(e.keyframes,t);return i.length||e.path?[{...e,keyframes:i}]:[]})),e.bindings&&(r.bindings=e.bindings.filter(e=>!n.get(e.target)?.some(t=>ko[e.property]===t)))),r})(e,t);return this._previewMemo={base:e,view:t,out:n},n}_check(){const e=this._doc?Ht(this._doc):void 0;this._errors=e&&!e.ok?e.errors:[],e?.ok&&(this._playable=e.doc)}undo(){this._endGesture();const e=this._history.undo();e&&(this._doc=e,this._check(),this._pruneSelection())}redo(){this._endGesture();const e=this._history.redo();e&&(this._doc=e,this._check(),this._pruneSelection())}_pruneSelection(){const e=this._doc,t=this._selection;if(!e||"none"===t.kind)return;const i=t=>{const i=/^(part|group|shape):(.+)$/.exec(t);if(!i)return!0;const n="part"===i[1]?e.rig?.parts:"group"===i[1]?e.rig?.groups:e.rig?.shapes;return!!n?.some(e=>e.id===i[2])};if("tool"===t.kind)return void(t.target&&!i(t.target)&&(this._selection={kind:"tool",tool:t.tool}));if("keys"===t.kind){const i=(t.keys??[]).filter(t=>Zr(e,{target:t.target,lane:t.lane,at:t.at}));if(i.length===(t.keys??[]).length)return;if(!i.length)return void(this._selection=Ps);const n=[...new Set(i.map(e=>e.target))];return void(this._selection={kind:"keys",keys:i,targets:n,target:t.target&&n.includes(t.target)?t.target:i[i.length-1].target})}const n=(t.targets??(t.target?[t.target]:[])).filter(i);n.length?n.length===(t.targets?.length??1)&&t.target&&i(t.target)||(this._selection={kind:"target",target:t.target&&i(t.target)?t.target:n[0],targets:n}):this._selection=Ps}async save(){if(!this._doc||this._busy)return!1;const e=Ht(this._doc);if(!e.ok)return this._errors=e.errors,this._saveError=as(331),!1;this._busy=!0,this._saveError="";const t=JSON.stringify(this._doc);try{const i=await this._emit("mc-anim-save",{animation:e.doc}),n=this._stored(i,e.doc),s=!this._saved;this._store(n),this._saved=n,Ep(jp(n.id)),s&&Ep(jp());const r=JSON.stringify(this._doc);return r===t&&JSON.stringify(n)!==r?this._apply(n):this._check(),this._say(as(769,{name:n.name})),s&&this._select(n.id),!0}catch(e){const t=Zp(e);return this._errors=t.errors,this._saveError=t.message,!1}finally{this._busy=!1}}_pseudoSwitch(){return a.qy`<button
      type="button"
      class="btn ${this._pseudo?"btn-primary":"btn-secondary"} btn-sm pseudo-switch"
      role="switch"
      aria-checked=${this._pseudo?"true":"false"}
      @click=${()=>{this._togglePseudo()}}
    >
      <ha-icon icon="mdi:format-textdirection-r-to-l"></ha-icon>${as(700)}
    </button>`}async _togglePseudo(){const e=!this._pseudo;await async function(e,t){let s=null;if(e)try{s=(await i.e(8278).then(()=>i(419))).pseudoWrap}catch{return!1}(0,Cp.iC)(s);for(const i of t)i&&(e?i.setAttribute("dir","rtl"):i.removeAttribute("dir"));return window.dispatchEvent(new Event(n)),!0}(e,[this,this._stage()])&&(this._pseudo=e)}_stage(){return this.shadowRoot?.querySelector("mcas-stage")??null}_renderNewMenu(){const e=[...ot.map(e=>({id:`kind:${e}`,label:as(Fp[e]),sub:as(Tp[e]),icon:_s[e]})),{id:"preset",label:as(209),icon:"mdi:auto-fix",separatorBefore:!0},{id:"icon",label:as(373),icon:"mdi:motion-play-outline"}];return a.qy`<mc-ui-menu
      class="new-menu"
      .items=${e}
      label=${as(539)}
      .align=${"end"}
      @mc-menu-pick=${e=>{e.stopPropagation();const t=e.detail.id;this._menu=!1,this._opener=this.shadowRoot?.querySelector(".new-btn")??void 0,"preset"===t?this._openPresets():"icon"===t?this._openIconStart():this._new(t.slice(5))}}
      @mc-menu-close=${e=>{e.stopPropagation(),"outside"===e.detail.reason&&(this._menuClosedAt=Date.now()),this._menu=!1}}
    ></mc-ui-menu>`}_toggleNewMenu(){this._menu?(this.shadowRoot?.querySelector("mc-ui-menu.new-menu")?.close("escape"),this._menu=!1):Date.now()-this._menuClosedAt>400&&(this._menu=!0)}_renderNewButton(){return a.qy`<div class="menu-anchor">
      <button
        type="button"
        class="btn btn-primary new-btn"
        aria-haspopup="menu"
        aria-expanded=${this._menu?"true":"false"}
        @click=${()=>this._toggleNewMenu()}
      >
        <ha-icon icon="mdi:plus"></ha-icon>${as(539)}<ha-icon class="chev" icon="mdi:chevron-down"></ha-icon>
      </button>
      ${this._menu?this._renderNewMenu():a.s6}
    </div>`}_usedBy(e){if(!this.usage)return a.s6;const t=this.usage[e]??0;return a.qy`<span class="used ${t?"":"none"}">${t?as(1065,{count:t}):as(586)}</span>`}_pick(e,t){const i=new Set(this._picked);t?i.add(e):i.delete(e),this._picked=i}_renderRow(e){const t=this._renaming===e.id,i=t=>{this._rename(e,t.target.value)};return a.qy`
      <li class="lib-row${this._picked.has(e.id)?" selected":""}" data-id=${e.id}>
        <input
          type="checkbox"
          class="check"
          aria-label=${as(790,{name:e.name})}
          .checked=${this._picked.has(e.id)}
          @change=${t=>this._pick(e.id,t.target.checked)}
        />
        <mcas-thumb .doc=${e} .lookup=${this._lookup} .hass=${this.hass}></mcas-thumb>
        ${t?a.qy`<div class="name-cell">
                <input
                  class="input rename"
                  aria-label=${as(534,{name:e.name})}
                  maxlength="80"
                  .value=${e.name}
                  @keydown=${t=>{"Enter"===t.key&&i(t),"Escape"===t.key&&(t.preventDefault(),t.stopPropagation(),this._renaming=void 0,this._focusSel=`.lib-row[data-id="${e.id}"] .rename-btn`)}}
                  @blur=${i}
                />
              </div>`:a.qy`<button type="button" class="open name-cell" @click=${()=>this._guard(()=>this._openDoc(e,!1))}>
                <span class="nm">${e.name}</span>
                <span class="id mono">${as(1104,{id:e.id})}</span>
              </button>`}
        <span class="chip kind"><ha-icon icon=${_s[e.kind]}></ha-icon>${as(xs[e.kind])}</span>
        ${this._usedBy(e.id)}
        <span class="acts">
          <button type="button" class="icon-btn xs" title=${as(275)} aria-label=${as(279,{name:e.name})} @click=${()=>this._duplicate(e)}>
            <ha-icon icon="mdi:content-copy"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn xs rename-btn"
            title=${as(725)}
            aria-label=${as(728,{name:e.name})}
            @click=${()=>{this._renaming=e.id,this._focusSel=".rename"}}
          >
            <ha-icon icon="mdi:rename-outline"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn xs"
            title=${as(311)}
            aria-label=${as(314,{name:e.name})}
            @click=${()=>this._export([e])}
          >
            <ha-icon icon="mdi:export-variant"></ha-icon>
          </button>
          <button type="button" class="icon-btn xs danger" title=${as(219)} aria-label=${as(234,{name:e.name})} @click=${()=>this._askDelete(e)}>
            <ha-icon icon="mdi:delete-outline"></ha-icon>
          </button>
        </span>
      </li>
    `}_renderEmpty(){return a.qy`<div class="empty lib-empty">
      <ha-icon icon="mdi:animation-play-outline"></ha-icon>
      <strong>${as(553)}</strong>
      <p>${as(109)}</p>
    </div>`}_renderLibrary(){const e=this.docs,t=[{id:"all",label:as(44)},...ot.map(e=>({id:e,label:as(xs[e])}))],i=function(e,t){const i=t.toLowerCase().split(/\s+/).filter(Boolean);return i.length?e.filter(e=>{const t=(0,Ft.A)(`${e.name} ${e.id} ${e.kind} ${as(xs[e.kind])}`);return i.every(e=>t.includes(e))}):e}(e,this._query).filter(e=>"all"===this._kind||e.kind===this._kind),n=e.filter(e=>this._picked.has(e.id)),s=e.length?function(e){return a.qy`<div class="field"><div class="field-head"><label for=${e.id}>${e.label}</label> ${e.onReset?a.qy`<button type="button" class="icon-btn sm field-reset" aria-label=${e.resetLabel??""} title=${e.resetLabel??""} @click=${e.onReset}>${jd({icon:"mdi:restore"})}</button>`:a.s6}</div>${e.control} ${e.error?a.qy`<p class="help error" id=${t=e.id,`${t}-error`} role="alert">${e.error}</p>`:e.help?a.qy`<p class="help" id=${(e=>`${e}-help`)(e.id)}>${e.help}</p>`:a.s6}</div>`;var t}({id:"lib-search",label:as(777),control:a.qy`<div class="with-icon search">
            <ha-icon icon="mdi:magnify"></ha-icon>
            <input
              id="lib-search"
              class="input"
              type="search"
              aria-keyshortcuts="/"
              .value=${U(this._query)}
              @input=${e=>this._query=e.target.value}
            />
          </div>`}):a.s6;return this._frameHost(a.qy`
      <header class="fr-bar" slot="top">
        <strong class="doc-name">${as(532)}</strong>
        <span class="spacer"></span>
        <div class="grp bar">
          <button type="button" class="btn btn-secondary btn-sm" ?disabled=${!i.length} @click=${()=>this._export(n.length?n:i)}>
            <ha-icon icon="mdi:export-variant"></ha-icon>${n.length?as(315,{n:n.length}):as(312)}
          </button>
          ${this._renderNewButton()}
          <button type="button" class="btn btn-secondary btn-sm" @click=${()=>{this._openTransfer({type:"import"})}}>
            <ha-icon icon="mdi:import"></ha-icon>${as(380)}
          </button>
          ${this._drawerToggle()}
        </div>
      </header>
      <main class="lib" slot="stage">
        <div class="lib-inner">
          ${s}
          ${e.length?a.qy`<div role="status" aria-live="polite" class="help">${as(1221,{n:i.length})}</div>
                  ${i.length?a.qy`<ul class="lib-list" aria-label=${as(532)}>
                          ${i.map(e=>this._renderRow(e))}
                        </ul>`:a.qy`<p class="no-results">${this._query?as(551,{query:this._query}):as(552)}</p>`}`:this._renderEmpty()}
        </div>
      </main>
      <div class="insp" id="inspector" slot="drawer" tabindex="-1">
        <div class="kinds">${Nd({role:"radiogroup",label:as(400),value:this._kind,items:t.map(e=>({value:e.id,label:e.label})),onChange:e=>this._kind=e})}</div>
      </div>
    `,as(532),!1)}_fieldErrors(e){const t=this._errors.filter(t=>t.path===e);return t.length?a.qy`${t.map(t=>a.qy`<p class="help error" id="err-${e}">${ys(t.message)}</p>`)}`:a.s6}_resetButton(e,t){if(!this._modNow.has(e))return a.s6;const i=as(740,{field:t});return a.qy`<button type="button" class="icon-btn reset-field" aria-label=${i} title=${i} @click=${()=>this._resetField(e)}>
      <ha-icon icon="mdi:restore"></ha-icon>
    </button>`}_resetField(e){const t=this._doc;if(!t)return;const i=mt(t.kind,t.id);"iterations"===e&&(this._customRepeat=!1);const n="direction"===e?{direction:void 0}:{[e]:i[e]};this._set(n,e),this._focusSel=`.field [id="${"iterations"===e?"f-repeat":"direction"===e?"f-dir":`f-${e}`}"], .target [aria-checked="true"]`}_field(e,t,i,n,s){return a.qy`<div class="field">
      <div class="field-head"><label for=${t}>${e}</label>${n?this._resetButton(n,e):a.s6}</div>
      ${i} ${s?a.qy`<p class="help">${s}</p>`:a.s6} ${n?this._fieldErrors(n):a.s6}
    </div>`}_selectEl(e,t,i,n){return a.qy`<div class="select">
      <select class="input" id=${e} @change=${e=>n(e.target.value)}>
        ${i.map(e=>a.qy`<option value=${e.value} ?selected=${e.value===t}>${e.label}</option>`)}
      </select>
      <ha-icon icon="mdi:chevron-down"></ha-icon>
    </div>`}get _narrow(){return this._width>0&&this._width<1024}_frame(){return this.shadowRoot?.querySelector(s)??null}_toggleDrawer(e){const t=this._frame();t&&(t.drawerOpen?t.closeDrawer("user"):t.openDrawer(e??zd(),"user"))}_toggleBoth(){const e=this._frame();e&&(this._narrow?this._toggleDrawer():this._lips.isHidden("layers")||!e.drawerOpen?(this._lips.show("layers"),e.openDrawer(null,"user")):(this._layersHasFocus()&&(this._focusSel=".layers-toggle"),this._lips.hide("layers"),e.closeDrawer("user")))}_layersHasFocus(){return!!this.shadowRoot?.querySelector("#layers")?.matches(":focus-within")}_syncDrawer(){const e="editor"===this._view&&this._doc?this._frame():null;if(!e)return void(this._drawerFrame=void 0);const t=this._narrow;e!==this._drawerFrame?(this._drawerFrame=e,this._drawerNarrow=t,t||e.openDrawer(null,"user"),this._drawerOpen=e.drawerOpen):t!==this._drawerNarrow&&(this._drawerNarrow=t,t?e.closeDrawer("stage"):e.openDrawer(null,"user"))}get _layersShown(){return this._narrow?this._layersSheet:!this._lips.isHidden("layers")}_toggleLayers(){this._narrow?this._layersSheet?this._closeLayersSheet():(this._layersSheet=!0,this.updateComplete.then(()=>this.shadowRoot?.querySelector(".layers-close")?.focus())):this._lips.toggle("layers")}_sheetTab(e){"Tab"===e.key&&e.shiftKey&&e.composedPath()[0]?.classList?.contains("layers-close")&&(this._wrapBack=!0,this.shadowRoot?.querySelector(".sheet-end")?.focus())}_sheetEnd(){this._wrapBack?this._wrapBack=!1:this.shadowRoot?.querySelector(".layers-close")?.focus()}_closeLayersSheet(){this._layersSheet=!1,this.updateComplete.then(()=>this.shadowRoot?.querySelector(".layers-toggle")?.focus())}_setSelection(e){this._selection=e,"none"===e.kind||this._narrow&&"keys"!==e.kind||this._frame()?.openDrawer(null,"selection")}_toggleSection(e){const t=new Set(this._collapsed);t.has(e)?t.delete(e):t.add(e),this._collapsed=t,Xp(Kp,JSON.stringify([...t]))}_section(e,t,i,n,s={}){const r=s.errors||!this._collapsed.has(e);return a.qy`<section class="sec ${s.cls??""}" data-sec=${e}>
      ${function(e){const t=4===e.level,i=jd(e,18);if(!e.collapsible){const n=a.qy`${i}${t?a.qy`<h4>${e.title}</h4>`:a.qy`<h3>${e.title}</h3>`}`;return a.qy`<div class="group-head">${n}</div>`}const n=a.qy`<button type="button" class="sector-btn" aria-expanded=${String(!!e.expanded)} @click=${()=>e.onToggle?.()}> ${i}<span class="nm">${e.title}</span><span class="chev">${b("chevronDown",20)}</span> </button>`;return t?a.qy`<h4 class="sector-head">${n}</h4>`:a.qy`<h3 class="sector-head">${n}</h3>`}({title:t,icon:i,collapsible:!0,expanded:r,onToggle:()=>this._toggleSection(e)})}
      ${s.errors?a.qy`<span class="sec-err" role="img" aria-label=${as(359)}></span>`:a.s6}
      <div class="sec-body" id="secb-${e}" ?hidden=${!r}>${r?n:a.s6}</div>
    </section>`}_hasErrors(e){return this._errors.some(t=>e.includes(t.path))}_renderErrors(){const e=this._errors.filter(e=>!Bp.includes(e.path));return this._saveError||e.length?a.qy`<div class="errors" role="alert">
          ${this._saveError?a.qy`<strong>${this._saveError}</strong>`:a.s6}
          ${e.length?a.qy`<ul>
                  ${e.map(e=>a.qy`<li><span class="mono">${e.path||"animation"}</span> ${ys(e.message)}</li>`)}
                </ul>`:a.s6}
        </div>`:a.s6}_modified(e,t=!0){const i=mt(e.kind,e.id),n=new Set;if(e.name!==i.name&&n.add("name"),e.duration!==i.duration&&n.add("duration"),e.easing!==i.easing&&n.add("easing"),e.iterations!==i.iterations&&n.add("iterations"),(e.direction??"normal")!==(i.direction??"normal")&&n.add("direction"),e.target!==i.target&&n.add("target"),e.origin!==i.origin&&n.add("origin"),!t)return n;const s=e=>JSON.stringify({...e,name:"",duration:0,easing:"",iterations:0,direction:void 0,target:"element",origin:""});return s(e)!==s(i)&&n.add("content"),n}_renderForm(e){this._modNow=this._modified(e,!1);const t=this._modOnly?this._modNow:void 0,i=(...e)=>!t||e.some(e=>t.has(e)),n=ne.map(e=>({value:e.id,label:(0,te.t)(e.label)}));ne.some(t=>t.id===e.easing)||n.push({value:e.easing,label:e.easing});const s=String(e.iterations),r=this._customRepeat||!Rp.includes(s),o=[...Rp.map(e=>({value:e,label:"infinite"===e?as(387):e})),{value:"custom",label:as(204)}],l="keyframes"===e.kind||"sequence"===e.kind,c=this._field(as(533),"f-name",a.qy`<input
        class="input"
        id="f-name"
        maxlength="80"
        .value=${U(e.name)}
        aria-invalid=${this._errors.some(e=>"name"===e.path)?"true":"false"}
        @input=${e=>this._set({name:e.target.value},"name")}
      />`,"name",a.qy`${as(124)} <span class="mono ref">${as(1104,{id:e.id})}</span>`),d=a.qy`
      ${"sequence"===e.kind?t?a.s6:a.qy`<p class="help">${as(19)}</p>`:i("duration")?this._field(as(282),"f-duration",a.qy`<div class="suffix">
                <input
                  class="input"
                  id="f-duration"
                  type="number"
                  inputmode="decimal"
                  min="0.05"
                  max="600"
                  step="any"
                  .value=${U(String(e.duration))}
                  @input=${e=>{const t=e.target.value;""!==t&&Number.isFinite(Number(t))&&this._set({duration:Number(t)},"duration")}}
                />
                <span aria-hidden="true">s</span>
              </div>`,"duration"):a.s6}
      <div class="two">
        ${i("easing")?this._field(as(285),"f-easing",this._selectEl("f-easing",e.easing,n,e=>this._set({easing:e},"easing")),"easing"):a.s6}
        ${i("iterations")?this._field(as(732),"f-repeat",this._selectEl("f-repeat",r?"custom":s,o,t=>{if("custom"===t)return this._customRepeat=!0,void("infinite"===e.iterations&&this._set({iterations:10},"iterations"));this._customRepeat=!1,this._set({iterations:"infinite"===t?"infinite":Number(t)},"iterations")}),"iterations"):a.s6}
      </div>
      ${r&&i("iterations")?this._field(as(733),"f-count",a.qy`<input
                class="input"
                id="f-count"
                type="number"
                min="1"
                step="1"
                .value=${U("number"==typeof e.iterations?String(e.iterations):"")}
                @input=${e=>{const t=Number(e.target.value);Number.isFinite(t)&&t>0&&this._set({iterations:t},"count")}}
              />`):a.s6}
      ${i("direction")?this._field(as(239),"f-dir",this._selectEl("f-dir",e.direction??"normal",(p=Hp,p.map(e=>({...e,label:as(e.label)}))),e=>this._set({direction:"normal"===e?void 0:e},"direction")),"direction"):a.s6}
    `;var p;const h=["name",..."sequence"===e.kind?[]:["duration"],"easing","iterations","direction",...l?["target"]:[],..."keyframes"===e.kind?["origin"]:[]],u=h.filter(e=>this._modNow.has(e)).length;return a.qy`
      ${t&&u?a.qy`<p class="help mod-count" role="status">${as(1220,{modified:u,total:h.length})}</p>`:a.s6}
      ${i("name")?this._section("anim",as(64),_s[e.kind],c,{errors:this._hasErrors(["name"])}):a.s6}
      ${i("duration","easing","iterations","direction")?this._section("timing",as(1010),"mdi:timer-outline",d,{errors:this._hasErrors(["duration","easing","iterations","direction"])}):a.s6}
      ${l&&i("target","origin")?this._section("moves",as(1079),"mdi:cursor-move",this._renderMoves(e,t),{errors:this._hasErrors(["target","origin"])}):a.s6}
    `}_renderMoves(e,t){const i=Dp.map(e=>({value:e,label:ga.includes(e)?as(fa[ga.indexOf(e)]):e.charAt(0).toUpperCase()+e.slice(1)}));Dp.includes(e.origin)||i.push({value:e.origin,label:e.origin});const n="icon"===e.target?"icon":"element";return a.qy`
      ${t&&!t.has("target")?a.s6:a.qy`<div class="field">
        <div class="field-head"><span class="lbl" id="l-target">${as(920)}</span>${this._resetButton("target",as(920))}</div>
        <div class="seg full target" role="radiogroup" aria-labelledby="l-target" @keydown=${e=>{["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Home","End"].includes(e.key)&&(e.preventDefault(),this._set({target:"icon"===n?"element":"icon"},"target"),this._focusSel='.target [aria-checked="true"]')}}>
          ${["element","icon"].map(e=>{const t=e===n;return a.qy`<button
              type="button"
              role="radio"
              aria-checked=${t?"true":"false"}
              tabindex=${t?"0":"-1"}
              @click=${()=>this._set({target:e},"target")}
            >
              ${as("element"===e?291:370)}
            </button>`})}
        </div>
        <p class="help">${as(374)}</p>
        ${this._fieldErrors("target")}
      </div>`}
      ${"keyframes"!==e.kind||t&&!t.has("origin")?a.s6:this._field(as(615),"f-origin",this._selectEl("f-origin",e.origin,i,e=>this._set({origin:e},"origin")),"origin",as(971))}
    `}_editorEl(e,t,i={}){const n=(e=>({_$litStatic$:e,r:G}))(e);return i.panel?Q`<${n}
        class=${i.cls??"panel"}
        slot=${i.slot??a.s6}
        .doc=${t}
        .hass=${this.hass}
        .library=${this._libraryObj}
        .time=${Op.has(e)?this._time:0}
        .disabled=${this._busy||!!i.inspector&&So(t,this._viewOf(t),this._selection)}
        .selection=${this._selection}
        .tile=${this._tile}
        .stage=${this._stageInfo}
        .layerView=${this._viewOf(t)}
        .density=${this._width>0&&this._width<1e3?"compact":"full"}
        .emitter=${this._emitter.index}
        .all=${this._emitter.all}
        .stageRect=${i.stageRect}
        .subjectRect=${i.subjectRect}
        .entityColor=${Pp}
        @doc-change=${this._onDocChange}
        @seek=${this._onSeek}
        @selection-change=${this._onSelection}
      ></${n}>`:Q`<${n}
      class=${i.cls??"kind-editor"}
      slot=${i.slot??a.s6}
      .doc=${t}
      .hass=${this.hass}
      .library=${this._libraryObj}
      .time=${Op.has(e)?this._time:0}
      .disabled=${this._busy||e===Vs&&this._viewOf(t).locked.includes("path")}
      .studioSelection=${this._selection}
      .layerView=${this._viewOf(t)}
      .emitter=${this._emitter.index}
      .all=${this._emitter.all}
      .tile=${this._tile}
      .stage=${this._stageInfo}
      .stageRect=${i.stageRect}
      .subjectRect=${i.subjectRect}
      .entityColor=${Pp}
      @doc-change=${this._onDocChange}
      @seek=${this._onSeek}
      @selection-change=${this._onSelection}
    ></${n}>`}_panels(e,t,i={}){return Ns(e,t,this._selection).filter(e=>Os(e.tag)).map(e=>this._editorEl(e.tag,t,{cls:`panel panel-${e.place}`,panel:!0,...i,..."stage-tool"===e.place&&e.dock&&"overlay"!==e.dock?{slot:e.dock}:{}}))}_renderKindSlot(e){const t=Ls[e.kind],i=Os(t.tag)?this._editorEl(t.tag,e):a.qy`<p class="help">${as(426,{kind:as(t.title).toLowerCase()})}</p>`;return"inspector"===t.place?a.qy`<div class="kind-slot place-inspector" data-kind=${e.kind}>${this._section(`kind-${e.kind}`,as(t.title),_s[e.kind],i)}</div>`:a.qy`<section class="kind-slot place-panel" aria-label=${as(t.title)} data-kind=${e.kind}>${i} ${this._panels("timeline",e)}</section>`}_setSplit(e,t){this._split=this._clampSplitPx(Qp(Math.round(1e3*e)/1e3)),this._userSplit=!0,t&&Xp(Wp,String(this._split))}_clampSplitPx(e){const t=this.shadowRoot?.querySelector(".center")?.getBoundingClientRect().height??0;if(t<=0)return e;const i=Math.min(.45,160/t);return Math.round(1e3*Math.min(1-i,Math.max(i,e)))/1e3}_splitAt(e){const t=this.shadowRoot?.querySelector(".center")?.getBoundingClientRect();if(t&&!(t.height<=0))return(e-t.top)/t.height}_resetSplit(){Xp(Wp,void 0),this._userSplit=!1,this._split=.4,this._autoSplit()}_autoSplit(e=!1){const t=this._doc;if(this._userSplit||!t||"editor"!==this._view||"panel"!==Ls[t.kind].place)return;const i=this.shadowRoot?.querySelector(".center"),n=i?.getBoundingClientRect().height??0;if(n<=0)return;const s=this.shadowRoot?.querySelector(".kind-slot.place-panel .kind-editor"),r=s?.getBoundingClientRect().width||i?.getBoundingClientRect().width||0,a=function(e,t,i=!1){const n=Nr(e).filter(e=>e.main||e.keyframes.length),s=n.reduce((e,t)=>e+nr(t.keyframes).length,0),r=Math.max(0,...n.map(e=>ar(e.keyframes,"*").length)),a=i?187+49*r+(r?0:44):146+41*n.length+35*s+(s?0:44),o=Math.max(160,Math.min(.6*t,a));return Math.round(1e3*Qp((t-9-o)/t))/1e3}(t,n,r>0&&r<480);(e?a<this._split-.002:Math.abs(a-this._split)>.002)&&(this._split=a)}async _revealShape(e){await this.updateComplete;const t=this.shadowRoot?.querySelector("nav.layers"),i=[...t?.querySelectorAll("mc-anim-shapes-layers, mc-anim-shapes-under-layers")??[]];await Promise.all(i.map(e=>e.updateComplete));const n=i.find(t=>t.shadowRoot?.querySelector(`li[data-id="${e}"]`))??i[0],s=n?.shadowRoot?.querySelector(`li[data-id="${e}"]`);s?.scrollIntoView?.({block:"nearest"})}_layerTargets(e){const t=["element","icon"];for(const i of e.tracks??[])t.includes(i.target)||t.push(i.target);return t}_renderLayerList(e){if("particles"===e.kind)return a.qy`<p class="help layers-note">${as(636)}</p>`;const t=hs.find(e=>e.id===this._tile),i=this._selection;return a.qy`<ul class="layer-list" role="list">
      ${this._layerTargets(e).map(n=>{const s=!("target"!==i.kind&&"keys"!==i.kind||i.target!==n&&!i.targets?.includes(n)),r=!!t&&"element"!==n&&!t.targets.includes(n),o=Pr(e,n),l=(t=>t===e.target&&"keyframes"===e.kind?e.keyframes?.length??0:e.tracks?.find(e=>e.target===t)?.keyframes.length??0)(n),c=n===e.target,d=c&&r?as(1202,{label:o,tile:as(t.label).toLowerCase()}):c?as(1201,{label:o}):r?as(1210,{label:o,tile:as(t.label).toLowerCase()}):o;return a.qy`<li>
          <button
            type="button"
            class="layer ${r?"off":""}"
            data-target=${n}
            aria-pressed=${s?"true":"false"}
            title=${d}
            @click=${e=>this._pickLayer(n,e.ctrlKey||e.metaKey||e.shiftKey)}
          >
            <ha-icon icon=${Rr(n)}></ha-icon>
            <span class="layer-name">${o}</span> ${c&&eh(e)?a.qy`<span class="chip is-accent layer-main">${as(496)}</span>`:a.s6}
            ${l?a.qy`<span class="layer-count" title=${as(1163,{count:l})}>${l}</span>`:a.s6}
          </button>
        </li>`})}
    </ul>`}_pickLayer(e,t){const i=this._selection,n="target"===i.kind||"keys"===i.kind?i.targets??(i.target?[i.target]:[]):[];if(!t){const t=1===n.length&&n[0]===e&&"target"===i.kind;return void this._setSelection(t?Ps:{kind:"target",target:e,targets:[e]})}const s=n.includes(e),r=s?n.filter(t=>t!==e):[...n,e];r.length?this._setSelection({kind:"target",target:s?i.target&&r.includes(i.target)?i.target:r[0]:e,targets:r}):this._setSelection(Ps)}_renderLayers(e){const t=Ns("layers",e,this._selection).filter(e=>Os(e.tag)).map(t=>a.qy`<section class="layer-group" data-panel=${t.tag} aria-label=${as(t.title)} tabindex="-1">
          <h3 class="layer-head">${as(t.title)}</h3>
          ${this._editorEl(t.tag,e,{cls:"panel panel-layers",panel:!0})}
        </section>`),i=this._narrow;return a.qy`<nav class="layers" id="layers" aria-label=${as(410)} ?inert=${!i&&this._lips.isHidden("layers")} data-lip=${this._lips.state("layers")} data-dir=${this._lips.dir}>
      <div class="layers-head">
        <h2>${as(408)}</h2>
        ${i?a.qy`<button type="button" class="icon-btn layers-close" aria-label=${as(158)} title=${as(158)} @click=${()=>this._closeLayersSheet()}>
          <ha-icon icon="mdi:close"></ha-icon>
        </button>`:a.s6}
      </div>
      <div class="layers-body">${t.length?a.qy`${t}<p class="help layers-help">${as(366)}</p>`:this._renderLayerList(e)}</div>
    </nav>`}_selectionWhat(e){const t=this._selection,i=t.keys?.length??0;return"keys"===t.kind?`${as(1163,{count:i})}${t.target?` · ${Pr(e,t.target)}`:""}`:"target"===t.kind&&t.target?(t.targets?.length??0)>1?as(1177,{count:t.targets.length}):Pr(e,t.target):"tool"===t.kind?as(1013,{tool:t.tool??""}):""}_renderContext(e){const t=this._selectionWhat(e);return a.qy`<div class="ctx">
      <button type="button" class="btn btn-text btn-sm ctx-back" title=${as(66)} @click=${()=>this._setSelection(Ps)}>
        <ha-icon icon="mdi:arrow-left"></ha-icon>${as(64)}
      </button>
      <span class="ctx-what">${t}</span>
    </div>`}_renderFallback(e){const t=this._selection;if("target"===t.kind&&("element"===t.target||"icon"===t.target)&&eh(e)){const i=t.target===e.target;return this._section("target",Pr(e,t.target),Rr(t.target),a.qy`<p class="help">
            ${i?"icon"===t.target?as(938):as(939):"icon"===e.target?as(937):as(936)}
          </p>
          ${i?a.s6:a.qy`<button
                  type="button"
                  class="btn btn-secondary btn-sm make-main"
                  @click=${()=>this._set({target:t.target},"target")}
                >
                  <ha-icon icon="mdi:target"></ha-icon>${"icon"===t.target?as(479):as(478)}
                </button>`}
          ${"keyframes"===e.kind&&i?this._renderMoves(e):a.s6}`)}const i=t.keys?.length??0;return a.qy`<p class="help ctx-note">${"keys"===t.kind?as(1167,{count:i}):as(595)}</p>`}_renderInspector(e){const t=this._selection,i="inspector"===Ls[e.kind].place?this._renderKindSlot(e):a.s6;if("none"===t.kind){const n=!this._modOnly||this._modified(e).has("content"),s=n?Ns("inspector",e,t).filter(e=>Os(e.tag)).map(t=>this._section(`panel-${t.tag}`,as(t.title),Lp[t.tag]??"mdi:puzzle-outline",this._editorEl(t.tag,e,{cls:"panel panel-inspector",panel:!0}))):[];return a.qy`${this._renderErrors()} ${n?i:a.s6} ${this._renderForm(e)} ${s}`}const n=Ns("inspector",e,t).filter(e=>Os(e.tag)).map(t=>this._section(`panel-${t.tag}`,as(t.title),Lp[t.tag]??"mdi:puzzle-outline",this._editorEl(t.tag,e,{cls:"panel panel-inspector",panel:!0,inspector:!0}))),s=this._viewOf(e),r=So(e,s,t)?jo(e,s,Mo(t)):a.s6,o="target"!==t.kind||"element"!==t.target&&"icon"!==t.target||!eh(e)?a.s6:this._renderFallback(e),l="target"===t.kind&&"icon"===t.target&&"keyframes"===e.kind&&!e.rig?.parts?.length&&Os(Vp)?this._section("split-icon",as(375),Lp[Vp],this._editorEl(Vp,e,{cls:"panel panel-inspector",panel:!0})):a.s6,c=n.length?n:o===a.s6&&l===a.s6?this._renderFallback(e):a.s6;return a.qy`${r} ${this._renderContext(e)} ${this._renderErrors()} ${o} ${l} ${c}`}_zoomIcon(e){const t=this._selection;return"keyframes"===e.kind&&("tool"===t.kind||("target"===t.kind||"keys"===t.kind)&&!!t.target&&/^(part|group|shape):/.test(t.target))}_frameStrings(){const e=cs();return this._strings?.language!==e&&(this._strings={language:e,value:{pin:as(393),modifiedOnly:as(448),noneModified:as(554),close:as(157),drawer:as(388),zoom:as(1089)}}),this._strings.value}get _scheme(){const e=this.hass?.themes;return e?.darkMode?"dark":"light"}_measure(){const e=this._stageRect,t=this._stageScale>0?this._stageScale:1,i="none"!==this._selection.kind?this._subjectRect:void 0,n=i&&[i.x,i.y,i.width,i.height].every(Number.isFinite)?{x:i.x/t,y:i.y/t,width:i.width/t,height:i.height/t}:null;return{width:e?.width||400,height:e?.height||240,grid:20,selection:n,zoom:t}}_drawerToggle(){const e=this._narrow,t=as(e?807:388);return a.qy`<button
      type="button"
      class="icon-btn insp-toggle"
      aria-controls="inspector"
      aria-expanded=${this._drawerOpen?"true":"false"}
      aria-haspopup=${e?"dialog":a.s6}
      aria-label=${t}
      title=${t}
      @click=${e=>this._toggleDrawer(e.currentTarget)}
    >
      <ha-icon icon="mdi:tune-variant"></ha-icon>
    </button>`}_frameHost(e,t,i=!0){return a.qy`<mc-ui-studio-frame
      class=${this._narrow?"narrow":""}
      studio="anim-studio"
      fixed-drawer
      .scheme=${this._scheme}
      .strings=${this._frameStrings()}
      .selectionLabel=${t}
      .measure=${i?this._measure():null}
      .rulers=${i}
      @selection-change=${this._onSelection}
      @mc-frame-drawer=${this._onFrameDrawer}
      @mc-frame-modified=${this._onFrameModified}
      @preview-change=${this._onPreviewChange}
      @layer-view-change=${this._onLayerView}
      @emitter-change=${this._onEmitter}
      >${e}</mc-ui-studio-frame
    >`}_renderEditor(e){const t=this.dirty,i="panel"===Ls[e.kind].place,n=this._viewOf(e),s=this._playable??e,r=function(e,t){const i=yo(e,t);let n=0;for(const t of i){if(t.startsWith(bo))continue;const s=xo(e,t);s&&i.has(s)||n++}return n}(s,n),o=this._layersShown,l=e.name.trim()||as(1047),c=this._selectionWhat(e),d=c?`${l} · ${c}`:l,p=this._modOnly&&"none"===this._selection.kind&&!this._modified(e).size&&!this._saveError&&!this._errors.length;return this._frameHost(a.qy`
      <header class="fr-bar" slot="top">
        <div class="grp">
          <button type="button" class="btn btn-secondary btn-sm back" @click=${()=>this._back()}><ha-icon icon="mdi:arrow-left"></ha-icon>${as(414)}</button>
          <span class="vr" aria-hidden="true"></span>
          <button
            type="button"
            class="icon-btn layers-toggle"
            aria-controls="layers"
            aria-expanded=${o?"true":"false"}
            aria-label=${as(408)}
            title=${as(408)}
            @click=${()=>this._toggleLayers()}
          >
            <ha-icon icon="mdi:layers-outline"></ha-icon>
          </button>
          <div class="title">
            <strong class="doc-name">${l}</strong>
            <span class="chip kind"><ha-icon icon=${_s[e.kind]}></ha-icon>${as(xs[e.kind])}</span>
            ${this._saved?t?a.qy`<span class="chip is-warn">${as(1045)}</span>`:a.s6:a.qy`<span class="chip is-accent">${as(538)}</span>`}
          </div>
        </div>
        <span class="spacer"></span>
        <div class="grp">
          ${this._pseudoSwitch()}
          <button
            type="button"
            class="icon-btn"
            aria-label=${as(1036)}
            title=${as(1036)}
            ?disabled=${!this._history.canUndo()}
            @click=${()=>this.undo()}
          >
            <ha-icon icon="mdi:undo"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn"
            aria-label=${as(704)}
            title=${as(704)}
            ?disabled=${!this._history.canRedo()}
            @click=${()=>this.redo()}
          >
            <ha-icon icon="mdi:redo"></ha-icon>
          </button>
          ${this._drawerToggle()}
          <button
            type="button"
            class="btn btn-primary btn-sm save"
            ?disabled=${this._busy||!t&&!!this._saved}
            title=${as(765)}
            @click=${()=>this.save()}
          >
            <ha-icon icon=${this._busy?"mdi:progress-upload":"mdi:content-save-outline"}></ha-icon>${this._busy?as(771):as(764)}
          </button>
        </div>
      </header>
      <output class="zoom-read" slot="zoom">${new Intl.NumberFormat(cs(),{style:"percent",maximumFractionDigits:0}).format(this._stageScale>0?this._stageScale:1)}</output>
      ${o&&!this._narrow?a.qy`<div class="fr-start" slot="start">${this._renderLayers(e)}</div>`:a.s6}
      <div class="center ${i?"with-panel":""}" slot="stage" style="--split: ${this._split}${this._narrow?`;max-inline-size: calc(${this._width}px - 2 * var(--bp-s-6))`:""}">
        ${o&&this._narrow?a.qy`<div class="layers-sheet" @keydown=${e=>this._sheetTab(e)}>${this._renderLayers(e)}<span class="sheet-end" tabindex="0" @focus=${()=>this._sheetEnd()}></span></div>`:a.s6}
        <mcas-stage
          dir=${this._pseudo?"rtl":a.s6}
          .doc=${this._previewDoc(s,n)}
          .layerView=${n}
          .hiddenLayers=${r}
          .stageParticles=${r?Sd(s):void 0}
          .lookup=${this._lookup}
          .hass=${this.hass}
          .tile=${this._tile}
          .preview=${this._preview}
          .subjectTarget=${"keyframes"===e.kind&&"none"!==this._selection.kind?this._selection.target:void 0}
          .zoomIcon=${this._zoomIcon(e)}
          @pointerdown=${()=>this._frame()?.stageWork()}
          @stage-tile=${e=>this._tile=e.detail.tile}
          @stage-time=${e=>this._time=e.detail.time}
          @stage-rect=${this._onStageRect}
        >
          ${"path"===e.kind&&Os(Vs)?this._editorEl(Vs,e,{slot:"canvas",stageRect:this._stageRect,subjectRect:this._subjectRect}):a.s6}
          ${this._panels("stage-tool",e,{slot:"overlay",stageRect:this._stageRect,subjectRect:this._subjectRect})}
        </mcas-stage>
        ${i?a.qy`<div
                  class="splitter"
                  role="separator"
                  tabindex="0"
                  aria-orientation="horizontal"
                  aria-label=${as(872)}
                  aria-valuemin="15"
                  aria-valuemax="80"
                  aria-valuenow=${Math.round(100*this._split)}
                  title=${as(255)}
                  @pointerdown=${this._onSplitDown}
                  @pointermove=${this._onSplitMove}
                  @pointerup=${this._onSplitUp}
                  @pointercancel=${this._onSplitUp}
                  @keydown=${this._onSplitKey}
                  @dblclick=${()=>this._resetSplit()}
                ></div>
                ${this._renderKindSlot(e)}`:a.s6}
      </div>
      ${p?a.s6:a.qy`<div class="insp" id="inspector" slot="drawer" tabindex="-1">${this._renderInspector(e)}</div>`}
    `,d)}_renderDialog(){const e=this._dialog;if(!e)return a.s6;const t=()=>{this._dialog===e&&(this._dialog=void 0)};switch(e.type){case"delete":{const{doc:i,uses:n,sequences:s}=e,r=[];return void 0===n?r.push(as(123)):n&&r.push(as(390,{count:n})),s.length&&r.push(as(801,{names:s.map(e=>e.name).join(", ")})),Cd({heading:as(220,{name:i.name}),variant:"alert",initialFocus:"dlg-safe",onClose:t},a.qy`<div class="dlg">${r.map(e=>a.qy`<p>${e}</p>`)}</div>`,a.qy`<button type="button" class="btn btn-secondary btn-sm" id="dlg-safe" @click=${this._closeDialog}>${as(114)}</button>
            <button type="button" class="btn btn-danger btn-sm confirm-delete" @click=${()=>this._delete(i)}>
              <ha-icon icon="mdi:delete-outline"></ha-icon>${as(219)}
            </button>`)}case"discard":return Cd({heading:as(768),variant:"alert",initialFocus:"dlg-safe",onClose:t},a.qy`<div class="dlg"><p>${as(0,{name:this._doc?.name||as(993)})}</p></div>`,a.qy`<button type="button" class="btn btn-secondary btn-sm" id="dlg-safe" @click=${this._closeDialog}>${as(392)}</button>
            <button
              type="button"
              class="btn btn-secondary btn-sm discard"
              @click=${()=>{this._dialog=void 0,Ep(jp(this._saved?.id)),this._saved=this._doc??null,e.then()}}
            >
              ${as(240)}
            </button>
            <button
              type="button"
              class="btn btn-primary btn-sm"
              @click=${async()=>{this._dialog=void 0,await this.save()&&e.then()}}
            >
              ${as(764)}
            </button>`);case"restore":return Cd({heading:as(744),variant:"alert",initialFocus:"restore-draft",onClose:t},a.qy`<div class="dlg">
            <p>${e.isNew?as(964,{name:e.draft.name}):as(1,{name:e.draft.name})}</p>
          </div>`,a.qy`<button
              type="button"
              class="btn btn-secondary btn-sm discard-draft"
              @click=${()=>{this._dialog=void 0,Ep(jp(e.isNew?void 0:e.draft.id))}}
            >
              ${as(240)}
            </button>
            <button type="button" class="btn btn-primary btn-sm restore-draft" id="restore-draft" @click=${()=>this._restoreDraft(e.draft,e.isNew)}>
              ${as(743)}
            </button>`);case"export":case"import":return Cd({heading:"export"===e.type?as(313):as(382),size:"l",dismissible:!1,onClose:t},a.qy`<mc-transfer-panel
            host="animation-studio"
            .mode=${e.type}
            .exportItems=${"export"===e.type?{kind:"animation",items:e.items}:void 0}
            .taken=${(e,t)=>this._taken(t)}
            @mc-transfer-import=${e=>{this._onImport(e)}}
            @mc-transfer-close=${this._closeDialog}
          ></mc-transfer-panel>`);case"icon":return Cd({heading:as(372),size:"l",onClose:t},a.qy`<div class="dlg">
            ${Os("mc-anim-icon-start")?a.qy`<mc-anim-icon-start class="icon-start" .hass=${this.hass} .lookup=${this._lookup} @icon-start=${e=>this._startIcon(e)}></mc-anim-icon-start>`:a.qy`<p class="help">${as(427)}</p>`}
          </div>`,a.qy`<button type="button" class="btn btn-secondary btn-sm" @click=${this._closeDialog}>${as(114)}</button>`);case"presets":return Cd({heading:as(208),size:"xl",initialFocus:"preset-search",onClose:t},a.qy`<div class="dlg">
            <p class="help">${as(976)}</p>
            <div class="with-icon">
              <ha-icon icon="mdi:magnify"></ha-icon>
              <input
                class="input preset-search"
                id="preset-search"
                type="search"
                placeholder=${as(779)}
                aria-label=${as(779)}
                .value=${U(this._presetQuery)}
                @input=${e=>this._presetQuery=e.target.value}
              />
            </div>
            <mc-preset-grid
              class="preset-list"
              .sources=${this._presetSources()}
              .query=${this._presetQuery}
              .hass=${this.hass}
              .lookup=${this._lookup}
              .notice=${this._catalogueFailed?as(449):""}
              @preset-pick=${e=>this._pickPreset(e)}
              @preset-clear-search=${()=>{this._clearPresetSearch()}}
            ></mc-preset-grid>
          </div>`,a.qy`<button type="button" class="btn btn-secondary btn-sm" @click=${this._closeDialog}>${as(114)}</button>`)}}render(){if("ready"!==this._labels)return a.qy`<div class="shell" role="status">${"failed"===this._labels?"The studio texts (magic-card-i18n-labels.js) could not be loaded. Reload the page.":a.s6}</div>`;const e="editor"===this._view?this._doc:void 0;return a.qy`
      <div class="shell" data-view=${e?"editor":"library"}>${e?this._renderEditor(e):this._renderLibrary()}</div>
      ${this._renderDialog()}
      <div class="sr-only" role="status" aria-live="polite">${this._status}</div>
      ${this._lips.status()}
      ${this._status?a.qy`<div class="toast" aria-hidden="true">${this._status}</div>`:a.s6}
    `}}sh.styles=[...Hs,Ao],Ap([(0,o.MZ)({attribute:!1})],sh.prototype,"hass",void 0),Ap([(0,o.MZ)({attribute:!1})],sh.prototype,"library",void 0),Ap([(0,o.MZ)({attribute:!1})],sh.prototype,"selectedId",void 0),Ap([(0,o.MZ)({attribute:!1})],sh.prototype,"usage",void 0),Ap([(0,o.MZ)({type:Boolean})],sh.prototype,"standalone",void 0),Ap([(0,o.wk)()],sh.prototype,"_docs",void 0),Ap([(0,o.wk)()],sh.prototype,"_view",void 0),Ap([(0,o.wk)()],sh.prototype,"_query",void 0),Ap([(0,o.wk)()],sh.prototype,"_picked",void 0),Ap([(0,o.wk)()],sh.prototype,"_kind",void 0),Ap([(0,o.wk)()],sh.prototype,"_menu",void 0),Ap([(0,o.wk)()],sh.prototype,"_renaming",void 0),Ap([(0,o.wk)()],sh.prototype,"_dialog",void 0),Ap([(0,o.wk)()],sh.prototype,"_doc",void 0),Ap([(0,o.wk)()],sh.prototype,"_saved",void 0),Ap([(0,o.wk)()],sh.prototype,"_errors",void 0),Ap([(0,o.wk)()],sh.prototype,"_saveError",void 0),Ap([(0,o.wk)()],sh.prototype,"_busy",void 0),Ap([(0,o.wk)()],sh.prototype,"_status",void 0),Ap([(0,o.wk)()],sh.prototype,"_pseudo",void 0),Ap([(0,o.wk)()],sh.prototype,"_presetQuery",void 0),Ap([(0,o.wk)()],sh.prototype,"_catalogue",void 0),Ap([(0,o.wk)()],sh.prototype,"_catalogueFailed",void 0),Ap([(0,o.wk)()],sh.prototype,"_labels",void 0),Ap([(0,o.wk)()],sh.prototype,"_customRepeat",void 0),Ap([(0,o.wk)()],sh.prototype,"_selection",void 0),Ap([(0,o.wk)()],sh.prototype,"_tile",void 0),Ap([(0,o.wk)()],sh.prototype,"_split",void 0),Ap([(0,o.wk)()],sh.prototype,"_layersSheet",void 0),Ap([(0,o.wk)()],sh.prototype,"_modOnly",void 0),Ap([(0,o.wk)()],sh.prototype,"_width",void 0),Ap([(0,o.wk)()],sh.prototype,"_height",void 0),Ap([(0,o.wk)()],sh.prototype,"_drawerOpen",void 0),Ap([(0,o.wk)()],sh.prototype,"_collapsed",void 0),Ap([(0,o.wk)()],sh.prototype,"_time",void 0),Ap([(0,o.wk)()],sh.prototype,"_stageRect",void 0),Ap([(0,o.wk)()],sh.prototype,"_stageScale",void 0),Ap([(0,o.wk)()],sh.prototype,"_subjectRect",void 0),Ap([(0,o.wk)()],sh.prototype,"_stageInfo",void 0),Ap([(0,o.wk)()],sh.prototype,"_preview",void 0),Ap([(0,o.wk)()],sh.prototype,"_layerViews",void 0),Ap([(0,o.wk)()],sh.prototype,"_emitter",void 0),Ap([(0,o.wk)()],sh.prototype,"_playable",void 0);var rh=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class ah extends a.WF{constructor(){super(...arguments),this.lookup=()=>{},this._visible="undefined"==typeof IntersectionObserver}connectedCallback(){super.connectedCallback(),"undefined"!=typeof IntersectionObserver&&(this._io=new IntersectionObserver(e=>{const t=e.some(e=>e.isIntersecting);t!==this._visible&&(this._visible=t)}),this._io.observe(this)),customElements.get("magic-card")||customElements.whenDefined("magic-card").then(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this._io?.disconnect(),this._io=void 0}willUpdate(e){if(!this._visible||!this.doc||!customElements.get("magic-card"))return void(this._card=void 0);const t=!this._card;if(t&&(this._card=document.createElement("magic-card")),t||e.has("doc")||e.has("lookup"))try{this._card.setConfig(Ss(this.doc,this.lookup,{tile:"icon",thumb:!0,as:this.doc.id}))}catch{return void(this._card=void 0)}(t||e.has("hass"))&&(this._card.hass=this.hass??lp(!1))}render(){const e=this.doc?_s[this.doc.kind]:"mdi:animation-outline";return a.qy`<div class="box" aria-hidden="true">
      ${this._card?a.qy`<div class="scale">${this._card}</div>`:a.qy`<ha-icon icon=${e}></ha-icon>`}
    </div>`}}ah.styles=[Cs,a.AH`
      :host {
        display: block;
        width: 64px;
        height: 40px;
        flex: none;
      }
      .box {
        position: relative;
        width: 100%;
        height: 100%;
        overflow: hidden;
        display: grid;
        place-items: center;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background-color: var(--mc-canvas);
        background-image: radial-gradient(var(--mc-canvas-dot) 1px, transparent 1.2px);
        background-size: 8px 8px;
        color: var(--mc-text-2);
        --mdc-icon-size: 22px;
      }
      .scale {
        position: absolute;
        left: 50%; /* physical */
        top: 50%;
        width: 176px;
        transform: translate(-50%, -50%) scale(0.36);
        pointer-events: none;
      }
      .scale magic-card {
        display: block;
        --ha-card-border-width: 0;
      }
    `],rh([(0,o.MZ)({attribute:!1})],ah.prototype,"doc",void 0),rh([(0,o.MZ)({attribute:!1})],ah.prototype,"lookup",void 0),rh([(0,o.MZ)({attribute:!1})],ah.prototype,"hass",void 0),rh([(0,o.wk)()],ah.prototype,"_visible",void 0);const oh=(0,a.iz)(":is(.mc-field, .mc-act-field, .mc-cond-field) :is(input, select, textarea):not([type='checkbox']):not([type='color']):not([type='range']):not([type='radio'])"),lh=a.AH`.mc-tab-content{display:grid;gap:16px}.mc-field{display:grid;gap:6px;min-width:0}.mc-field-label,.mc-field>label,.mc-input-label{display:flex;align-items:center;gap:8px;min-height:24px;font-size:.8125rem;font-weight:500;color:var(--mc-text);text-transform:none;letter-spacing:normal}.mc-field-hint,.mc-mode-help{font-size:.75rem;font-style:normal;color:var(--mc-text-2)} ${oh},.mc-input-field.mc-input-field{width:100%;min-height:40px;margin:0;padding:8px 12px;border:1px solid var(--mc-field-border);border-radius:var(--mc-radius);background:var(--mc-surface);color:var(--mc-text);font:inherit;font-size:.875rem;line-height:1.4;outline:none;box-shadow:none;transition:border-color .15s ease-out,box-shadow .15s ease-out}${oh}::placeholder,.mc-input-field.mc-input-field::placeholder{color:var(--mc-text-2);opacity:1}${oh}:hover,.mc-input-field.mc-input-field:hover{border-color:var(--mc-text-2)}${oh}:focus,.mc-input-field.mc-input-field:focus{outline:none;border-color:var(--mc-focus);box-shadow:0 0 0 1px var(--mc-focus)}${oh}:disabled{background:var(--mc-surface-2);color:var(--mc-text-2);cursor:not-allowed}${oh}.mono{font-family:var(--mc-mono);font-size:.8125rem} ${oh}:is(select):not([multiple]):not([size]){appearance:none;-webkit-appearance:none;padding-right:36px;padding-inline:12px 36px;cursor:pointer}${oh}:is(select):not(.input):not([multiple]):not([size]){background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath fill='%238b919a' d='M7.41 8.58 12 13.17l4.59-4.59L18 10l-6 6-6-6 1.41-1.42Z'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;background-size:18px 18px}:host([dir='rtl']) ${oh}:is(select):not(.input):not([multiple]):not([size]),[dir='rtl'] ${oh}:is(select):not(.input):not([multiple]):not([size]){background-position:left 10px center} ${oh}:is(textarea){resize:vertical;min-height:88px;line-height:1.5;font-family:var(--mc-mono);font-size:.8125rem} .mc-section{display:grid;gap:16px}.mc-section + .mc-section{padding-top:20px;border-top:1px solid var(--mc-divider)}.mc-section-header{display:flex;align-items:center;gap:8px;margin:0;padding:0;border:0;font-size:.875rem;font-weight:500;color:var(--mc-text)} .mc-btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:40px;padding:0 16px;border-radius:var(--mc-radius);border:1px solid transparent;font-size:.875rem;font-weight:500;white-space:nowrap;filter:none;transform:none;transition:background-color .15s ease-out,border-color .15s ease-out,box-shadow .15s ease-out;--mdc-icon-size:18px}.mc-btn-primary{background:var(--mc-accent-fill);border-color:transparent;color:var(--mc-on-accent)}.mc-btn-primary:hover{filter:none;box-shadow:inset 0 0 0 999px rgba(255,255,255,.1)}.mc-btn-primary:active{box-shadow:inset 0 0 0 999px rgba(0,0,0,.1)}.mc-btn-secondary{background:var(--mc-surface);border:1px solid var(--mc-field-border);color:var(--mc-text)}.mc-btn-secondary:hover{background:var(--mc-surface-2)}.mc-btn-small{min-height:32px;padding:0 12px;font-size:.8125rem}.mc-btn-icon{display:inline-grid;place-items:center;width:32px;height:32px;flex:none;padding:0;border:0;border-radius:var(--mc-radius);background:transparent;color:var(--mc-text-2);--mdc-icon-size:18px}.mc-btn-icon:hover:not(:disabled){background:var(--mc-surface-2);color:var(--mc-text)}:is(.mc-btn,.mc-btn-primary,.mc-btn-secondary,.mc-btn-icon):active{opacity:1;transform:none}:is(.mc-btn,.mc-btn-primary,.mc-btn-secondary,.mc-btn-icon):disabled{opacity:.45;cursor:not-allowed;box-shadow:none}:is(.mc-btn,.mc-btn-primary,.mc-btn-secondary,.mc-btn-icon):focus-visible{outline:2px solid var(--mc-focus);outline-offset:2px} .mc-conditions-list{display:grid;gap:12px;margin:0}.mc-condition-item{position:relative;border:1px solid var(--mc-divider);border-radius:var(--mc-radius-lg);padding:12px;display:grid;gap:12px} .mc-tabs-header{display:flex;width:100%;align-items:stretch;gap:2px;padding:3px;margin:0;background:var(--mc-surface-2);border:1px solid var(--mc-divider);border-radius:10px;max-width:100%;overflow-x:auto;scrollbar-width:none}.mc-tab-button{flex:1 0 auto;display:inline-flex;align-items:center;justify-content:center;gap:6px;min-height:32px;padding:0 10px;border:0;border-radius:7px;background:transparent;white-space:nowrap;font-size:.8125rem;font-weight:500;color:var(--mc-text-2);box-shadow:none;transition:background-color .15s ease-out,color .15s ease-out;--mdc-icon-size:18px}.mc-tab-button:hover{color:var(--mc-text);background:color-mix(in srgb,var(--mc-surface) 55%,transparent)}.mc-tab-button.active,.mc-tab-button[aria-selected='true']{background:var(--mc-surface);color:var(--mc-accent-ink);box-shadow:0 0 0 1px var(--mc-divider),0 1px 2px rgba(0,0,0,.08)}.mc-tab-button:focus-visible{outline:2px solid var(--mc-focus);outline-offset:-2px}`,ch=a.AH`:host([dir='rtl']) .gl[data-dir='mirror']{transform:scaleX(-1)}:host .mono,:host textarea.mono,:host input.mono,:host code,:host pre{direction:ltr;unicode-bidi:isolate}`,dh=[Cs,As,lh,a.AH`:host .seg>button:is([aria-checked=true],[aria-selected=true],[aria-pressed=true]){font-weight:700;box-shadow:inset 0 -3px 0 var(--mc-accent-ink)}`,ch];var ph=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const hh=168,uh=140,mh=e=>14+e*uh,gh=e=>14+(1.5-e)/2*uh,fh=(e,t=mh,i=gh)=>`M${t(0)} ${i(0)} C${t(e[0])} ${i(e[1])} ${t(e[2])} ${i(e[3])} ${t(1)} ${i(1)}`,vh={"ease-in-out":386};let bh=class extends a.WF{constructor(){super(...arguments),this.inherited="ease",this.disabled=!1,this.label="",this._textError=""}willUpdate(e){e.has("value")&&(this._textError="")}get _bezier(){return this._drag?.bezier??na(this.value||this.inherited)}_emit(e,t=!1){this.dispatchEvent(new CustomEvent("easing-change",{bubbles:!0,composed:!0,detail:t?{value:e,transient:t}:{value:e}}))}_fromPointer(e){const t=this.renderRoot.querySelector(".plot").getBoundingClientRect(),i=t.width/hh||1;return[((e.clientX-t.left)/i-14)/uh,1.5-((e.clientY-t.top)/i-14)/uh*2]}_down(e,t){if(this.disabled||0!==e.button)return;const i=this._bezier??[0,0,1,1];e.preventDefault(),e.currentTarget.focus(),e.currentTarget.setPointerCapture?.(e.pointerId),this._drag={handle:t,bezier:[...i]}}_move(e){if(!this._drag)return;const[t,i]=this._fromPointer(e),n=[...this._drag.bezier];n[2*this._drag.handle]=t,n[2*this._drag.handle+1]=i,this._drag={...this._drag,bezier:aa(n)},this._emit(oa(this._drag.bezier),!0)}_up(){if(!this._drag)return;const e=oa(this._drag.bezier);this._drag=void 0,this._emit(e)}_key(e,t){const i={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]}[e.key];if(!i||this.disabled)return;e.preventDefault(),e.stopPropagation();const n=e.shiftKey?.1:.01,s=[...this._bezier??[0,0,1,1]];s[2*t]+=i[0]*n,s[2*t+1]+=i[1]*n,this._emit(oa(aa(s)))}_num(e,t){const i=Number(t),n=[...this._bezier??[0,0,1,1]];""!==t.trim()&&Number.isFinite(i)?(n[e]=i,this._emit(oa(aa(n)))):this.requestUpdate()}_text(e){const t=e.value.trim();if(!t)return void(this.value&&this._emit(void 0));if(t===(this.value??""))return;if(!$t(t))return void(this._textError=as(1053));this._textError="";const i=na(t);this._emit(i&&t.startsWith("cubic-bezier")?oa(i):t)}render(){const e=this._bezier,t=this._drag?oa(this._drag.bezier):this.value,i=sa.map(e=>e.id),n=t?i.includes(t)?t:"custom":"",s=t?na(t)?`cubic-bezier(${na(t).join(",")})`:t:e?`cubic-bezier(${e.join(",")})`:"linear";return a.qy`
      <div class="presets" role="radiogroup" aria-label=${as(1208,{label:this.label||as(285)})}>
        ${[{id:"",label:as(213),bezier:na(this.inherited)},...sa.map(e=>({...e,label:(0,te.t)(e.label)}))].map(e=>a.qy`<button
            type="button"
            class="preset"
            role="radio"
            data-easing=${e.id||"default"}
            aria-checked=${n===e.id?"true":"false"}
            title=${e.id?e.label:as(935,{easingLabel:ya(this.inherited).toLowerCase()})}
            ?disabled=${this.disabled}
            @click=${()=>this._emit(e.id||void 0)}
          >
            ${function(e){return a.qy`<svg class="glyph" viewBox="0 0 ${22} ${22}" aria-hidden="true">
    ${e?a.JW`<path d=${fh(e,e=>3+16*e,e=>19-16*e*.82-2)}></path>`:a.JW`<path d="M3 ${17} H${19}" stroke-dasharray="2 2.5"></path>`}
  </svg>`}(e.bezier)}<span>${void 0!==vh[e.id]?as(vh[e.id]):e.label}</span>
          </button>`)}
      </div>
      <div class="wrap">
        <div class="body">
          <div
            class="plot"
            aria-disabled=${this.disabled?"true":"false"}
            @pointermove=${this._move}
            @pointerup=${this._up}
            @pointercancel=${this._up}
            @lostpointercapture=${this._up}
          >
            <svg viewBox="0 0 ${hh} ${hh}" aria-hidden="true">
              <g class="grid">
                <rect x=${mh(0)} y=${gh(1)} width=${uh} height=${gh(0)-gh(1)} rx="2"></rect>
                ${[.25,.5,.75].map(e=>a.JW`<line x1=${mh(e)} x2=${mh(e)} y1=${gh(1)} y2=${gh(0)}></line><line x1=${mh(0)} x2=${mh(1)} y1=${gh(e)} y2=${gh(e)}></line>`)}
              </g>
              <path class="diag" d="M${mh(0)} ${gh(0)} L${mh(1)} ${gh(1)}"></path>
              ${e?a.JW`<line class="arm" x1=${mh(0)} y1=${gh(0)} x2=${mh(e[0])} y2=${gh(e[1])}></line>
                  <line class="arm" x1=${mh(1)} y1=${gh(1)} x2=${mh(e[2])} y2=${gh(e[3])}></line>
                  <path class="curve" d=${fh(e)}></path>`:a.s6}
              <circle class="end" cx=${mh(0)} cy=${gh(0)} r="3.5"></circle>
              <circle class="end" cx=${mh(1)} cy=${gh(1)} r="3.5"></circle>
            </svg>
            ${e?[0,1].map(t=>a.qy`<button
                    type="button"
                    class="knob ${this._drag?.handle===t?"dragging":""}"
                    data-handle=${t}
                    style="left: ${mh(e[2*t])/hh*100}%; top: ${gh(e[2*t+1])/hh*100}%"
                    role="slider"
                    aria-label=${as(0===t?882:299)}
                    aria-valuemin="-1"
                    aria-valuemax="2"
                    aria-valuenow=${e[2*t+1]}
                    aria-valuetext=${`x ${e[2*t]}, y ${e[2*t+1]}`}
                    ?disabled=${this.disabled}
                    @pointerdown=${e=>this._down(e,t)}
                    @keydown=${e=>this._key(e,t)}
                  ></button>`):a.qy`<p class="steps-note">${t?.startsWith("steps")?as(906):""}</p>`}
          </div>
          <div class="nums">
            ${["x1","y1","x2","y2"].map((t,i)=>a.qy`<div class="num">
                <label for=${`bz-${t}`}>${t.toUpperCase()}</label>
                <input
                  class="input mono"
                  id=${`bz-${t}`}
                  type="number"
                  step="0.01"
                  min=${i%2?-1:0}
                  max=${i%2?2:1}
                  inputmode="decimal"
                  .value=${e?String(e[i]):""}
                  ?disabled=${this.disabled||!e}
                  @change=${e=>this._num(i,e.target.value)}
                />
              </div>`)}
            <div class="num text">
              <label for="bz-text">${as(287)}</label>
              <input
                class="input mono"
                id="bz-text"
                type="text"
                spellcheck="false"
                autocomplete="off"
                placeholder=${as(214,{inherited:this.inherited})}
                aria-invalid=${this._textError?"true":"false"}
                aria-describedby=${this._textError?"bz-err":a.s6}
                .value=${t??""}
                ?disabled=${this.disabled}
                @change=${e=>this._text(e.target)}
                @keydown=${e=>"Enter"===e.key&&this._text(e.target)}
              />
              ${this._textError?a.qy`<p class="help error" id="bz-err">${this._textError}</p>`:a.s6}
            </div>
            <div class="preview" aria-hidden="true" style="--ease: ${s}"><i></i></div>
          </div>
        </div>
      </div>
    `}};bh.styles=[dh,a.AH`
      :host {
        display: grid;
        gap: 12px;
        min-width: 0;
      }
      .presets {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(80px, 1fr));
        gap: 6px;
      }
      .preset {
        display: flex;
        align-items: center;
        gap: 5px;
        min-height: 32px;
        padding: 0 6px;
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius);
        background: var(--mc-surface);
        color: var(--mc-text-2);
        font-size: 0.75rem;
        font-weight: 500;
        text-align: start;
        min-width: 0;
        transition: border-color 0.15s ease-out, background-color 0.15s ease-out, color 0.15s ease-out;
      }
      .preset span {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .preset:hover {
        border-color: var(--mc-field-border);
        color: var(--mc-text);
      }
      .preset[aria-checked='true'] {
        border-color: color-mix(in srgb, var(--mc-accent) 55%, transparent);
        background: var(--mc-accent-tint);
        color: var(--mc-accent-ink);
      }
      .glyph {
        width: 18px;
        height: 18px;
        flex: none;
        fill: none;
        stroke: currentColor;
        stroke-width: 1.6;
        stroke-linecap: round;
      }
      .body {
        display: grid;
        grid-template-columns: ${hh}px minmax(0, 1fr);
        gap: 12px;
        align-items: start;
      }
      @container (max-width: 340px) {
        .body {
          grid-template-columns: minmax(0, 1fr);
        }
        .plot {
          width: 100%;
          max-width: 260px;
          justify-self: center;
        }
        .nums {
          width: 100%;
        }
      }
      .wrap {
        container-type: inline-size;
      }
      .plot {
        position: relative;
        width: ${hh}px;
        aspect-ratio: 1;
        border-radius: var(--mc-radius);
        background: var(--mc-surface-2);
        border: 1px solid var(--mc-divider);
        direction: ltr; /* x is time, y is progress */
        touch-action: none;
        user-select: none;
      }
      .plot svg {
        display: block;
        width: 100%;
        height: 100%;
        overflow: visible;
      }
      .grid line {
        stroke: var(--mc-divider);
        stroke-width: 1;
      }
      .grid rect {
        fill: var(--mc-surface);
        stroke: var(--mc-divider);
      }
      .diag {
        stroke: var(--mc-field-border);
        stroke-dasharray: 3 3;
        fill: none;
      }
      .arm {
        stroke: var(--mc-text-2);
        stroke-width: 1.25;
      }
      .curve {
        fill: none;
        stroke: var(--mc-text);
        stroke-width: 2.5;
        stroke-linecap: round;
      }
      .end {
        fill: var(--mc-text-2);
      }
      .knob {
        position: absolute;
        width: 32px;
        height: 32px;
        margin: -16px 0 0 -16px;
        padding: 0;
        border: 0;
        border-radius: 50%;
        background: transparent;
        cursor: grab;
        touch-action: none;
      }
      .knob::before {
        content: '';
        position: absolute;
        inset: 9px;
        border-radius: 50%;
        background: var(--mc-surface);
        border: 2.5px solid var(--mc-text);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        transition: transform 0.15s ease-out, border-color 0.15s ease-out, background-color 0.15s ease-out;
      }
      .knob:hover::before,
      .knob.dragging::before {
        transform: scale(1.15);
      }
      .knob:focus-visible {
        outline: none;
      }
      .knob:focus-visible::before,
      .knob.dragging::before {
        border-color: var(--mc-accent);
        background: var(--mc-accent-fill);
      }
      .knob.dragging {
        cursor: grabbing;
      }
      .plot[aria-disabled='true'] {
        opacity: 0.55;
      }
      .steps-note {
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        padding: 16px;
        text-align: center;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .nums {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px;
      }
      .num {
        display: grid;
        gap: 4px;
        min-width: 0;
      }
      .num label {
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .num .input {
        min-height: 32px;
        padding: 4px 8px;
      }
      .text {
        grid-column: 1 / -1;
      }
      .preview {
        grid-column: 1 / -1;
        position: relative;
        height: 24px;
        border-radius: 9999px;
        background: var(--mc-surface-2);
        direction: ltr; /* the run goes from start to end of time */
        overflow: hidden;
      }
      .preview i {
        position: absolute;
        top: 4px;
        left: 4px; /* physical */
        width: 16px;
        height: 16px;
        border-radius: 50%;
        background: var(--mc-text-2);
        animation: mc-ease-run 1.6s var(--ease, ease) infinite alternate;
      }
      @keyframes mc-ease-run {
        to {
          left: calc(100% - 20px); /* physical */
        }
      }
      @media (prefers-reduced-motion: reduce) {
        .preview i {
          animation: none;
        }
      }
    `],ph([(0,o.MZ)({type:String})],bh.prototype,"value",void 0),ph([(0,o.MZ)({type:String})],bh.prototype,"inherited",void 0),ph([(0,o.MZ)({type:Boolean})],bh.prototype,"disabled",void 0),ph([(0,o.MZ)({type:String})],bh.prototype,"label",void 0),ph([(0,o.wk)()],bh.prototype,"_drag",void 0),ph([(0,o.wk)()],bh.prototype,"_textError",void 0),bh=ph([(0,o.EM)("mc-anim-bezier-editor")],bh);var yh=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const xh=(e,t,i,n)=>e<t||e>i?as(519,{min:t,max:i,unit:n}):void 0,_h=(e,t)=>({...e,transform:{...e.transform??{},...t}}),wh=e=>void 0===e?void 0:Math.round(1e5*e)/1e3,kh=e=>{return t=e,Math.round(10*t)/10+"%";var t},$h={x:[{key:"x",label:1085,unit:"px",get:e=>e.transform?.x,set:(e,t)=>xh(t,-1e4,1e4,"px")??_h(e,{x:t})}],y:[{key:"y",label:1086,unit:"px",get:e=>e.transform?.y,set:(e,t)=>xh(t,-1e4,1e4,"px")??_h(e,{y:t})}],scale:[{key:"scale",label:772,unit:"%",get:e=>wh(e.transform?.scale),set:(e,t)=>xh(t,0,1e4,"%")??_h(e,{scale:t/100})}],scale_x:[{key:"scale_x",label:773,unit:"%",get:e=>wh(e.transform?.scale_x),set:(e,t)=>xh(t,-1e4,1e4,"%")??_h(e,{scale_x:t/100})}],scale_y:[{key:"scale_y",label:774,unit:"%",get:e=>wh(e.transform?.scale_y),set:(e,t)=>xh(t,-1e4,1e4,"%")??_h(e,{scale_y:t/100})}],rotate:[{key:"rotate",label:60,unit:"deg",get:e=>e.transform?.rotate,set:(e,t)=>xh(t,-36e3,36e3,"deg")??_h(e,{rotate:t})}],skew:[{key:"skew_x",label:835,unit:"deg",get:e=>e.transform?.skew_x??0,set:(e,t)=>xh(t,-89,89,"deg")??_h(e,{skew_x:t})},{key:"skew_y",label:836,unit:"deg",get:e=>e.transform?.skew_y??0,set:(e,t)=>xh(t,-89,89,"deg")??_h(e,{skew_y:t})}],opacity:[{key:"opacity",label:608,unit:"%",get:e=>wh(e.opacity),set:(e,t)=>xh(t,0,100,"%")??{...e,opacity:Math.round(10*t)/1e3}}],blur:[{key:"blur",label:94,unit:"px",get:e=>e.blur,set:(e,t)=>xh(t,0,200,"px")??{...e,blur:t}}],radius:[{key:"radius",label:701,unit:"px",get:e=>e.radius,set:(e,t)=>xh(t,0,1e3,"px")??{...e,radius:t}}],draw:[{key:"draw",label:268,unit:"%",get:e=>wh(e.draw),set:(e,t)=>xh(t,0,100,"%")??{...e,draw:Math.round(10*t)/1e3}}]},Mh=[{id:"z",label:333},{id:"y",label:335,axis:[0,1,0]},{id:"x",label:334,axis:[1,0,0]}];let Sh=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.entityColor="var(--primary-color, #03a9f4)",this._errors={}}willUpdate(e){e.has("doc")&&(this._draft=void 0),e.has("selection")&&(this._errors={})}get _view(){return this._draft??this.doc}get _keys(){const e=this._view;return e&&"keys"===this.selection?.kind?(this.selection.keys??[]).map(e=>({target:e.target,lane:e.lane,at:e.at})).filter(t=>Zr(e,t)):[]}_emit(e,t,i=!1){this.disabled||(this._draft=i?e:void 0,this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:i?{doc:e,label:t,transient:!0}:{doc:e,label:t}})))}_select(e){const t=this._view?Dr(this._view):"element",i=e.length?{kind:"keys",target:e[e.length-1].target,targets:[...new Set(e.map(e=>e.target))],keys:e.map(e=>({target:e.target,lane:e.lane,at:e.at,id:Br(e,t)}))}:{kind:"none"};this.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:i}}))}_editTrack(e,t){const i=this.doc;return Tr(i,e,t(Fr(i,e)))}_setFragment(e,t,i,n,s){this.doc&&this._emit(this._editTrack(e,e=>function(e,t,i,n){let s=!1;const r=e.map(e=>{if(e.at!==i||!Xs(e,t))return e;s=!0;const r=tr(ir(e,t),n);return e.easings?{...r,easings:e.easings}:r});return s?r:hr(mr(e,i,n))}(e,t,i,n)),s)}_ownEasing(e){const t=Fr(this._view,e.target);return"*"===e.lane?cr(t,e.at):dr(t,e.lane,e.at)}_setEasing(e,t,i){if(!this.doc)return;let n=this.doc;for(const i of e){const e=Fr(n,i.target);n=Tr(n,i.target,"*"===i.lane?Mr(e,i.at,t):pr(e,i.lane,i.at,t))}this._emit(n,"Change easing",i)}_delete(e){this.doc&&e.length&&(this._emit(Ur(this.doc,e),"Delete "+(1===e.length?"keyframe":"keyframes")),this._select([]))}_copy(e){const t=this.doc?Gr(this.doc,e):void 0;t&&Er(t)}_moveTo(e,t){if(!this.doc)return;const i=Kr(this.doc,[e],t-e.at);this._emit(i.doc,"Move keyframe"),this._select(i.selection)}render(){const e=this._keys;return this._view&&e.length?(this._last=a.qy`<section class="insp" aria-label=${as(395)}>${e.length>1?this._renderMany(e):this._renderOne(e[0])}</section>`,this._last):"keys"===this.selection?.kind&&this.selection.keys?.length&&this._last?this._last:a.qy``}_easingEditor(e,t,i,n){return a.qy`<mc-anim-bezier-editor
      .value=${n}
      .inherited=${t}
      ?disabled=${this.disabled||i}
      @easing-change=${t=>this._setEasing(e,t.detail.value,!!t.detail.transient)}
    ></mc-anim-bezier-editor>`}_renderMany(e){const t=this._view,i=[...new Set(e.map(e=>e.at))].sort((e,t)=>e-t),n=[...new Set(e.map(e=>e.target))],s=new Set(e.map(e=>this._ownEasing(e)??"")),r=1===s.size&&[...s][0]||void 0,o=new Set(e.map(e=>e.lane)),l=n.length>1?as(1177,{count:n.length}):Pr(t,n[0]);return a.qy`
      <div class="insp-head">
        <span class="tile"><ha-icon icon="mdi:selection-multiple"></ha-icon></span>
        <div class="insp-title">
          <b>${as(1163,{count:e.length})}</b>
          <span>${as(1270,{where:l,from:kh(i[0]),to:kh(i[i.length-1])})}</span>
        </div>
      </div>
      <p class="note">${as(248)}</p>
      <div class="foot-actions">
        <button type="button" class="btn btn-text btn-sm" data-act="copy" @click=${()=>this._copy(e)}>
          <ha-icon icon="mdi:content-copy"></ha-icon>${as(184)}
        </button>
        <button type="button" class="btn btn-text btn-sm danger-text" data-act="delete" @click=${()=>this._delete(e)}>
          <ha-icon icon="mdi:delete-outline"></ha-icon>${as(1180,{count:e.length})}
        </button>
      </div>
      <div class="sub">
        <div class="sub-head"><ha-icon icon="mdi:chart-bell-curve-cumulative"></ha-icon><span class="grow">${as(286)}</span></div>
        ${s.size>1?a.qy`<p class="note">${as(981)}</p>`:a.s6}
        ${o.size>1||!o.has("*")?a.qy`<p class="note">${as(699)}</p>`:a.s6}
        ${this._easingEditor(e,t.easing,!1,r)}
      </div>
    `}_renderOne(e){const t=this._view,i=Fr(t,e.target),n="*"===e.lane?nr(i.filter(t=>t.at===e.at)):[e.lane],s="*"===e.lane?void 0:Zs[e.lane],r="*"===e.lane?[]:nr(i.filter(t=>t.at===e.at)).filter(t=>t!==e.lane),o=ar(i,e.lane).every(t=>t<=e.at),l=(t.duration*e.at/100).toFixed(2),c=(t.tracks?.length??0)>0||e.target!==Dr(t)?Pr(t,e.target):"";return a.qy`
      <div class="insp-head">
        <span class="tile"><ha-icon icon=${s?.icon??Rr(e.target)}></ha-icon></span>
        <div class="insp-title">
          <b>${as(s?s.label:394)}</b>
          <span>${c?as(1267,{target:c,at:kh(e.at),secs:l}):as(74,{at:kh(e.at),secs:l})}</span>
        </div>
        <button
          type="button"
          class="icon-btn sm danger"
          data-act="delete"
          aria-label=${as(225)}
          title=${as(225)}
          @click=${()=>this._delete([e])}
        >
          <ha-icon icon="mdi:delete-outline"></ha-icon>
        </button>
      </div>
      <div class="field">
        <div class="field-head"><label for="kf-at">${as(685)}</label></div>
        <div class="at-field">
          <mc-unit-field
            inputId="kf-at"
            .label=${as(685)}
            .value=${`${e.at}%`}
            .units=${["%"]}
            noCustom
            ?disabled=${this.disabled}
            @value-changed=${t=>this._onAt(t,e)}
          ></mc-unit-field>
          <span class="secs">${l} s</span>
        </div>
        ${this._errors.at?a.qy`<p class="help error">${this._errors.at}</p>`:a.s6}
      </div>
      ${n.length?n.map(t=>this._renderLaneFields(e.target,t,e.at,"*"===e.lane)):a.qy`<p class="note">${as(1001)}</p>`}
      ${r.length?a.qy`<div class="field">
              <div class="field-head"><span class="lbl">${as(51,{at:kh(e.at)})}</span></div>
              <div class="chips">
                ${r.map(t=>a.qy`<button type="button" class="chip" data-lane=${t} @click=${()=>this._select([{target:e.target,lane:t,at:e.at}])}>
                      <ha-icon icon=${Zs[t].icon}></ha-icon>${Ks(t)}
                    </button>`)}
                <button type="button" class="chip" data-lane="*" @click=${()=>this._select([{target:e.target,lane:"*",at:e.at}])}>
                  <ha-icon icon="mdi:key-variant"></ha-icon>${as(1082)}
                </button>
              </div>
            </div>`:a.s6}
      ${this._renderEasing(e,i,o)}
    `}_renderEasing(e,t,i){const n=this._view,s=cr(t,e.at);if("*"===e.lane)return a.qy`<div class="sub" data-easing="keyframe">
        <div class="sub-head"><ha-icon icon="mdi:chart-bell-curve-cumulative"></ha-icon><span class="grow">${as(286)}</span></div>
        ${i?a.qy`<p class="note">${as(1e3)}</p>`:a.s6}
        ${this._easingEditor([e],n.easing,i,s)}
      </div>`;const r=e.lane,o=Ys(r).filter(e=>e!==r),l=o.length?ds(o.map(e=>Ks(e))):"";return a.qy`<div class="sub" data-easing="lane">
      <div class="sub-head">
        <ha-icon icon="mdi:chart-bell-curve-cumulative"></ha-icon><span class="grow">${as(1205,{label:Ks(r)})}</span>
      </div>
      ${i?a.qy`<p class="note">${as(999)}</p>`:a.qy`<p class="note">
              ${as(s?607:606)}${l?` ${as(1222,{names:l})}`:""}
            </p>`}
      ${this._easingEditor([e],s??n.easing,i,dr(t,r,e.at))}
      ${Xs(t.find(t=>t.at===e.at)??{at:0},r)?a.qy`<div class="ease-of">
              <button type="button" class="btn btn-text btn-sm" data-act="whole" @click=${()=>this._select([{target:e.target,lane:"*",at:e.at}])}>
                <ha-icon icon="mdi:key-variant"></ha-icon>${as(288)}
              </button>
            </div>`:a.s6}
    </div>`}_onAt(e,t){e.stopPropagation();const i=parseFloat(String(e.detail.value));if(!Number.isFinite(i)||i<0||i>100)return this._errors={...this._errors,at:as(518)},void e.target.revert?.();this._errors={...this._errors,at:""},i!==t.at&&this._moveTo(t,Math.round(100*i)/100)}_renderLaneFields(e,t,i,n){const s=Zs[t],r=lr(Fr(this._view,e),t,i),o=this._laneBody(e,t,i,r,n);return n?a.qy`<div class="sub" data-lane=${t}>
      <div class="sub-head">
        <ha-icon icon=${s.icon}></ha-icon><span class="grow">${as(s.label)}</span>
        <button
          type="button"
          class="icon-btn sm danger"
          aria-label=${as(724,{name:as(s.label).toLowerCase()})}
          title=${as(717)}
          @click=${()=>this._emit(this._editTrack(e,e=>_r(e,[{lane:t,at:i}])),`Remove ${t}`)}
        >
          <ha-icon icon="mdi:close"></ha-icon>
        </button>
      </div>
      ${o}
    </div>`:a.qy`<div class="fields" data-lane=${t}>${o}</div>`}_laneBody(e,t,i,n,s=!1){const r=$h[t];return r?a.qy`
        <div class="pair">${r.map(a=>this._numField(e,t,i,n,a,s&&1===r.length))}</div>
        ${"rotate"===t?this._axisField(e,i,n):a.s6}
      `:"color"===t||"background"===t||"stroke"===t?this._colorField(e,t,i,n):"shadow"===t?this._shadowField(e,i,n):this._filterField(e,i,n)}_numField(e,t,i,n,s,r=!1){const o=s.get(n),l=`kf-${t}-${s.key}`,c=this._errors[l];return a.qy`<div class="field">
      ${r?a.s6:a.qy`<div class="field-head"><label for=${l}>${as(s.label)}</label></div>`}
      <mc-unit-field
        .inputId=${l}
        .label=${as(s.label)}
        .value=${void 0===o?"":`${o}${s.unit}`}
        .units=${[s.unit]}
        noCustom
        ?disabled=${this.disabled}
        @value-changed=${n=>{n.stopPropagation();const r=n.target,a=parseFloat(String(n.detail.value));if(!Number.isFinite(a))return void r.revert?.();const o=s.set(lr(Fr(this._view,e),t,i),a);if("string"==typeof o)return this._errors={...this._errors,[l]:o},void r.revert?.();this._errors={...this._errors,[l]:""},this._setFragment(e,t,i,o,`Change ${t}`)}}
      ></mc-unit-field>
      ${c?a.qy`<p class="help error">${c}</p>`:a.s6}
    </div>`}_axisField(e,t,i){const n=i.transform?.axis,s=n?Mh.find(e=>e.axis&&e.axis.every((e,t)=>e===n[t]))?.id??"custom":"z";return a.qy`<div class="field">
      <div class="field-head"><label for="kf-axis">${as(1025)}</label></div>
      <div class="select">
        <select
          class="input"
          id="kf-axis"
          ?disabled=${this.disabled}
          @change=${i=>{const n=Mh.find(e=>e.id===i.target.value);if(!n)return;const s={...lr(Fr(this._view,e),"rotate",t).transform??{}};n.axis?s.axis=[...n.axis]:delete s.axis,this._setFragment(e,"rotate",t,{transform:s},"Change turn axis")}}
        >
          ${Mh.map(e=>a.qy`<option value=${e.id} ?selected=${s===e.id}>${as(e.label)}</option>`)}
          ${"custom"===s?a.qy`<option value="custom" selected>${as(205,{axis:n.join(", ")})}</option>`:a.s6}
        </select>
        <ha-icon icon="mdi:chevron-down"></ha-icon>
      </div>
    </div>`}_colorField(e,t,i,n){const s=`kf-${t}`,r=n[t],o=as("color"===t?922:"stroke"===t?912:78),l="background"===t?"background":"color";return a.qy`<div class="field">
      <div class="field-head"><span class="lbl">${o}</span></div>
      <mc-color-picker
        .value=${ca(r)}
        .label=${o}
        allowEntity
        .entityColor=${this.entityColor}
        @value-changed=${n=>{n.stopPropagation();let a=da(String(n.detail.value??""));if(!a){if(!ca(r).startsWith("entity"))return;a="var(--primary-color)"}ma(a,l)?(this._errors={...this._errors,[s]:""},a!==r&&this._setFragment(e,t,i,{[t]:a},`Change ${o.toLowerCase()}`)):this._errors={...this._errors,[s]:as("color"===l?574:1052)}}}
      ></mc-color-picker>
      ${this._errors[s]?a.qy`<p class="help error">${this._errors[s]}</p>`:a.qy`<p class="help">${as(945)}</p>`}
    </div>`}_shadowField(e,t,i){const n=i.shadow??"",s=function(e){if(!e)return;const t=e.trim().match(/^(-?\d*\.?\d+)(?:px)?\s+(-?\d*\.?\d+)(?:px)?(?:\s+(\d*\.?\d+)(?:px)?)?(?:\s+(-?\d*\.?\d+)(?:px)?)?\s+(.+)$/);return t&&!/,(?![^(]*\))/.test(t[5])?{x:Number(t[1]),y:Number(t[2]),blur:Number(t[3]??0),spread:Number(t[4]??0),color:t[5].trim()}:void 0}(n),r=this._errors["kf-shadow"],o=i=>{ma(i,"shadow")?(this._errors={...this._errors,"kf-shadow":""},i!==n&&this._setFragment(e,"shadow",t,{shadow:i},"Change shadow")):this._errors={...this._errors,"kf-shadow":as(576)}},l=(e,t)=>a.qy`<div class="field">
        <div class="field-head"><label for=${`kf-sh-${e}`}>${t}</label></div>
        <mc-unit-field
          .inputId=${`kf-sh-${e}`}
          .label=${as(812,{name:t.toLowerCase()})}
          .value=${`${s[e]}px`}
          .units=${["px"]}
          noCustom
          compact
          @value-changed=${t=>{t.stopPropagation();const i=parseFloat(String(t.detail.value));if(!Number.isFinite(i)||"blur"===e&&i<0)return t.target.revert?.();o(pa({...s,[e]:i}))}}
        ></mc-unit-field>
      </div>`;return a.qy`
      <div class="chips" role="group" aria-label=${as(811)}>
        ${ha.map(e=>a.qy`<button type="button" class="chip" aria-pressed=${n===e.value?"true":"false"} @click=${()=>o(e.value)}>${as(e.label)}</button>`)}
      </div>
      ${s?a.qy`<div class="quad">${l("x","X")} ${l("y","Y")} ${l("blur",as(94))} ${l("spread",as(868))}</div>
              <div class="field">
                <div class="field-head"><span class="lbl">${as(810)}</span></div>
                <mc-color-picker
                  .value=${ca(s.color)}
                  .label=${as(810)}
                  allowEntity
                  .entityColor=${this.entityColor}
                  @value-changed=${e=>{e.stopPropagation();const t=da(String(e.detail.value??""))||"rgba(0, 0, 0, 0.3)";o(pa({...s,color:t}))}}
                ></mc-color-picker>
              </div>`:a.qy`<div class="field">
              <div class="field-head"><label for="kf-shadow">${as(808)}</label></div>
              <input
                class="input mono"
                id="kf-shadow"
                type="text"
                spellcheck="false"
                .value=${n}
                @change=${e=>o(e.target.value.trim())}
              />
            </div>`}
      ${r?a.qy`<p class="help error">${r}</p>`:a.s6}
    `}_filterField(e,t,i){const n=i.filter??"",s=this._errors["kf-filter"],r=i=>{ma(i,"filter")?(this._errors={...this._errors,"kf-filter":""},i!==n&&this._setFragment(e,"filter",t,{filter:i},"Change filter")):this._errors={...this._errors,"kf-filter":as(1058)}};return a.qy`
      <div class="chips" role="group" aria-label=${as(325)}>
        ${ua.map(e=>a.qy`<button type="button" class="chip" aria-pressed=${n===e.value?"true":"false"} @click=${()=>r(e.value)}>${as(e.label)}</button>`)}
      </div>
      <div class="field">
        <div class="field-head"><label for="kf-filter">${as(324)}</label></div>
        <input
          class="input mono"
          id="kf-filter"
          type="text"
          spellcheck="false"
          autocomplete="off"
          aria-invalid=${s?"true":"false"}
          .value=${n}
          @change=${e=>r(e.target.value.trim())}
        />
        ${s?a.qy`<p class="help error">${s}</p>`:a.qy`<p class="help">${as(95)}</p>`}
      </div>
    `}};Sh.styles=[dh,a.AH`
      :host {
        display: block;
        min-width: 0;
      }
      :host([disabled]) .insp {
        opacity: 0.6;
        pointer-events: none;
      }
      .insp {
        display: grid;
        gap: 16px;
        align-content: start;
        min-width: 0;
        padding: 16px 0;
      }
      .insp-head {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
      }
      .tile {
        display: grid;
        place-items: center;
        width: 36px;
        height: 36px;
        flex: none;
        border-radius: var(--mc-radius);
        background: var(--mc-accent-tint);
        color: var(--mc-accent-ink);
        --mdc-icon-size: 20px;
      }
      .insp-title {
        flex: 1;
        min-width: 0;
      }
      .insp-title b {
        display: block;
        font-size: 1rem;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .insp-title span {
        display: block;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .fields {
        display: grid;
        gap: 12px;
      }
      .pair {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 120px), 1fr));
        gap: 12px;
      }
      .quad {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }
      .sub {
        display: grid;
        gap: 10px;
        padding-top: 12px;
        border-top: 1px solid var(--mc-divider);
      }
      .sub-head {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 28px;
        font-size: 0.875rem;
        font-weight: 500;
      }
      .sub-head ha-icon {
        --mdc-icon-size: 16px;
        color: var(--mc-text-2);
      }
      .sub-head .grow {
        flex: 1;
      }
      .chips {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      .chip[aria-pressed='true'] {
        color: var(--mc-accent-ink);
        border-color: color-mix(in srgb, var(--mc-accent) 45%, transparent);
        background: var(--mc-accent-tint);
      }
      .at-field {
        display: grid;
        grid-template-columns: minmax(0, 1fr) auto;
        align-items: center;
        gap: 10px;
      }
      .at-field .secs {
        font-family: var(--mc-mono);
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .note {
        margin: 0;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .ease-of {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 4px 8px;
      }
      .danger-text {
        color: var(--mc-error-ink);
      }
      .danger-text:hover {
        background: color-mix(in srgb, var(--error-color, #db4437) 10%, transparent);
      }
      .foot-actions {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        justify-content: space-between;
      }
    `],yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"doc",void 0),yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"hass",void 0),yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"library",void 0),yh([(0,o.MZ)({type:Number})],Sh.prototype,"time",void 0),yh([(0,o.MZ)({type:Boolean,reflect:!0})],Sh.prototype,"disabled",void 0),yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"selection",void 0),yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"tile",void 0),yh([(0,o.MZ)({attribute:!1})],Sh.prototype,"stage",void 0),yh([(0,o.MZ)({type:String})],Sh.prototype,"entityColor",void 0),yh([(0,o.wk)()],Sh.prototype,"_errors",void 0),yh([(0,o.wk)()],Sh.prototype,"_draft",void 0),Sh=yh([(0,o.EM)("mc-anim-key-inspector")],Sh),Ds({tag:"mc-anim-key-inspector",place:"inspector",when:(e,t)=>"keyframes"===e.kind&&"keys"===t.kind&&!!t.keys?.length,title:394,order:0});var zh=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Ch=e=>Math.round(10*e)/10,Ah=e=>`${Ch(e)}%`;let jh=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.onionSkin=!1,this.layout="auto",this.entityColor="var(--primary-color, #03a9f4)",this._keys=[],this._width=0,this._viewW=0,this._menuOpen=!1,this._status="",this._zoom=1,this._unit="pct",this._snap=!0,this._grid="pct1",this._collapsed=new Set,this._laneFocus=new Map,this._selFrame=0,this._menuClosedAt=0,this._onTouchMove=e=>{"band"===this._drag?.kind&&"touch"===this._drag.pointerType&&e.preventDefault()},this._pxCache=0,this._onPointerMove=e=>{const t=this._hold;t&&e.pointerId===t.pointerId&&Math.hypot(e.clientX-t.x,e.clientY-t.y)>8&&this._cancelHold();const i=this._drag;if(!i||e.pointerId!==i.pointerId)return;if("seek"===i.kind)return void this._seek(this._atFromX(e.clientX));if("band"===i.kind){const t=this.renderRoot.querySelector(".lanes").getBoundingClientRect(),n=e.clientX-t.left,s=e.clientY-t.top;if(!i.moved&&Math.hypot(n-i.x0,s-i.y0)<3)return;i.moved=!0,this._band={x0:i.x0,y0:i.y0,x1:n,y1:s};const r=this._main,a=i.baseSel??[];return void this._select([...a,...this._keysInBand(i.centres).filter(e=>!a.some(t=>Br(t,r)===Br(e,r)))],!0)}const n=e.clientX-i.x0;if(!i.moved&&Math.abs(n)<3)return;i.moved=!0;const s=this._pxCache||this._pxPerPct(),r=this._snapAt(i.grab.at+n/s,e.shiftKey,i.duplicate?[]:i.sel,i.snaps,s);if(i.lastTarget===r)return;i.lastTarget=r;const a=Kr(i.base,i.sel,r-i.grab.at,i.duplicate),o=i.sel.length;i.label=i.duplicate?as(278,{count:o}):as(484,{count:o}),this._draft=a.doc,this._select(a.selection,!0);const l=a.selection[i.sel.findIndex(e=>Br(e,this._main)===Br(i.grab,this._main))];l&&this._laneFocus.set(`${l.target}|${l.lane}`,l.at),(a.doc!==i.base||i.emitted)&&(i.emitted=!0,this._emit(this._draft,i.label,!0),this._selFrame||(this._selFrame=requestAnimationFrame(()=>{this._selFrame=0,"keys"===this._drag?.kind&&this._emitSelection()})))},this._onPointerUp=e=>{const t=this._hold;if(t&&e.pointerId===t.pointerId)return this._cancelHold(),void("pointerup"!==e.type||t.additive||(this._lastTarget=t.target,this._select([])));const i=this._drag;if(i&&e.pointerId===i.pointerId){if(this._drag=void 0,this._pxCache=0,cancelAnimationFrame(this._selFrame),this._selFrame=0,"band"===i.kind)return this._band=void 0,void(i.moved||i.additive?this._emitSelection():(i.target&&(this._lastTarget=i.target),this._select([])));if("keys"===i.kind){if(i.moved&&this._draft&&i.emitted){const e=this._draft,t=this._keys.find(e=>e.target===i.grab.target&&e.lane===i.grab.lane);return t&&(this._pendingFocus=Br(t,this._main)),this._emit(e,i.label??as(468)),this._emitSelection(),this._draft=e,void(this.doc===e&&(this._draft=void 0))}this._draft=void 0,!i.additive&&i.wasSelected&&this._select([i.clickKey])}}},this._onWheel=e=>{!e.ctrlKey&&!e.metaKey||this._narrow||(e.preventDefault(),this._setZoom(this._zoom*Math.exp(.002*-e.deltaY),e.clientX))}}get onion(){const e=ar(this._kfsOf(this._active),"*"),t=100*this.time;return{prev:[...e].reverse().find(e=>e<t-.001),next:e.find(e=>e>t+.001)}}get selection(){return this._keys.map(e=>Br(e,this._main))}set selection(e){this._select(e.map(e=>Ir(e,this._main)))}get zoom(){return this._zoom}set zoom(e){this._zoom=Xr(e)}connectedCallback(){var e;super.connectedCallback(),"undefined"!=typeof ResizeObserver&&(this._ro=new ResizeObserver(e=>{const t=Math.round(e[0]?.contentRect.width??0);t&&t!==this._width&&(this._width=t)}),this._ro.observe(this)),this._unsubClip=(e=()=>this.requestUpdate(),jr.add(e),()=>jr.delete(e)),this.addEventListener("touchmove",this._onTouchMove,{passive:!1})}disconnectedCallback(){super.disconnectedCallback(),this._ro?.disconnect(),this._ro=void 0,this._bodyRo?.disconnect(),this._bodyRo=void 0,this._unsubClip?.(),this.removeEventListener("touchmove",this._onTouchMove),this._cancelHold(),cancelAnimationFrame(this._selFrame)}get _view(){return this._draft??this.doc}get _main(){return this._view?Dr(this._view):"element"}_kfsOf(e){return this._view?Fr(this._view,e):[]}get _narrow(){return"narrow"===this.layout||"auto"===this.layout&&this._width>0&&this._width<480}get _active(){const e=this.studioSelection;return(!e||"target"!==e.kind&&"keys"!==e.kind?void 0:e.target)??this._keys[this._keys.length-1]?.target??this._lastTarget??this._main}_groups(){const e=this._view;if(!e)return[];const t=Nr(e),i=this.studioSelection,n=new Set([...i?.targets??[],...i?.target?[i.target]:[],...this._keys.map(e=>e.target)]),s=t.filter(e=>e.main||e.keyframes.length||n.has(e.target));for(const e of n)s.some(t=>t.target===e)||s.push({target:e,keyframes:[],main:!1});return s}_rows(){const e=[];for(const t of this._groups())if(e.push({target:t.target,lane:"*"}),!this._narrow&&!this._collapsed.has(t.target))for(const i of nr(t.keyframes))e.push({target:t.target,lane:i});return e}willUpdate(e){if(e.has("doc")){this._drag||(this._draft=void 0);const e=this._view,t=e?this._keys.filter(t=>Zr(e,t)):[];t.length!==this._keys.length&&this._select(t)}e.has("studioSelection")&&this._adopt()}_adopt(){const e=this.studioSelection,t=this._view;if(e&&t)if("keys"===e.kind&&e.keys){const i=e.keys.map(e=>({target:e.target,lane:e.lane,at:e.at})).filter(e=>Zr(t,e)),n=this._main;i.map(e=>Br(e,n)).join()!==this.selection.join()&&(this._keys=i)}else this._keys.length&&(this._keys=[])}updated(){const e=this._menuOpen?this.renderRoot.querySelector("mc-ui-menu.add-menu"):null;if(e&&!e.open&&(e.anchor=this.renderRoot.querySelector(".add-btn")??void 0,e.show()),this._pendingFocus){const e=this.renderRoot.querySelector(`.key[data-key="${CSS.escape(this._pendingFocus)}"]`);this._pendingFocus=void 0,e?.focus()}const t=this.renderRoot.querySelector(".tl-body");if(t&&!this._bodyRo&&"undefined"!=typeof ResizeObserver&&(this._bodyRo=new ResizeObserver(()=>{const e=this.renderRoot.querySelector(".tl-body")?.clientWidth??0;e&&e!==this._viewW&&(this._viewW=e)}),this._bodyRo.observe(t)),this._zoomAnchor&&t){const{at:e,clientX:i}=this._zoomAnchor;this._zoomAnchor=void 0;const n=this._trackRect();n&&(t.scrollLeft+=n.left+12+e/100*(n.width-24)-i)}}_emit(e,t,i=!1){this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:i?{doc:e,label:t,transient:!0}:{doc:e,label:t}}))}_select(e,t=!1){const i=this._main,n=new Set,s=e.filter(e=>{const t=Br(e,i);return!n.has(t)&&(n.add(t),!0)}),r=s.map(e=>Br(e,i)).join()!==this.selection.join();this._keys=s,s.length&&(this._lastTarget=s[s.length-1].target),r&&!t&&this._emitSelection()}_emitSelection(){const e=this._main,t=this._keys,i=[...new Set(t.map(e=>e.target))],n=t.length?{kind:"keys",target:t[t.length-1].target,targets:i,keys:t.map(t=>({target:t.target,lane:t.lane,at:t.at,id:Br(t,e)}))}:{kind:"none"};!t.length&&this.studioSelection&&"keys"!==this.studioSelection.kind||this.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:n}}))}_isLocked(e){const t=this.layerView,i=this.doc;return!(!i||!t?.locked.length)&&("*"!==e.lane?wo(i,t,`lane:${e.target}|${e.lane}`):wo(i,t,/^(part|group|shape):/.test(e.target)?e.target:`target:${e.target}`)||go(i,e.target).some(n=>wo(i,t,`lane:${e.target}|${n}`)))}_refuseLocked(e){const t=e.find(e=>this._isLocked(e));if(!t||!this._view)return!1;const i=Pr(this._view,t.target);return this._announce(as(1229,{name:"*"===t.lane?i:`${i} ${Zs[t.lane]?Ks(t.lane).toLowerCase():t.lane}`})),!0}_commit(e,t,i){this.doc&&!this.disabled&&(this._emit(e,t),i&&this._select(i))}_seek(e){const t=Math.min(1,Math.max(0,e/100));this.dispatchEvent(new CustomEvent("seek",{bubbles:!0,composed:!0,detail:{time:t}}))}_announce(e){this._status="",this.updateComplete.then(()=>this._status=e)}_isSel(e){return this._keys.some(t=>t.target===e.target&&t.lane===e.lane&&t.at===e.at)}_trackRect(){return this.renderRoot.querySelector(".track, .ruler-track")?.getBoundingClientRect()}_atFromX(e){const t=this._trackRect();return!t||t.width<=24?0:(e-t.left-12)/(t.width-24)*100}_pxPerPct(){const e=this._trackRect();return e&&e.width>24?(e.width-24)/100:6}_snapTargets(e=[]){const t=this._main,i=new Set(e.map(e=>Br(e,t))),n=new Set([100*this.time]);for(const e of this._groups())for(const s of["*",...nr(e.keyframes)])for(const r of ar(e.keyframes,s))i.has(Br({target:e.target,lane:s,at:r},t))||n.add(r);return[...n]}_snapAt(e,t,i=[],n=this._snapTargets(i),s=this._pxPerPct()){return function(e,t){const i=e=>Math.min(100,Math.max(0,e));if(t.free)return i(Math.round(10*e)/10);let n;for(const i of t.targets??[])Math.abs(i-e)<=(t.threshold??0)&&(void 0===n||Math.abs(i-e)<Math.abs(n-e))&&(n=i);if(void 0!==n)return i(n);const s=function(e,t){const i=t>0?t:1;switch(e){case"pct5":return 5;case"s01":return.1/i*100;case"fps30":return 1/30/i*100;default:return 1}}(t.grid,t.duration);return i(Math.round(Math.round(e/s)*s*100)/100)}(e,{free:t||!this._snap,grid:this._grid,duration:this._view?.duration??1,targets:n,threshold:6/s})}_range(e,t){const i=this._rows(),n=i.findIndex(t=>t.target===e.target&&t.lane===e.lane),s=i.findIndex(e=>e.target===t.target&&e.lane===t.lane);if(n<0||s<0)return[t];const[r,a]=[Math.min(e.at,t.at),Math.max(e.at,t.at)],o=[];for(const e of i.slice(Math.min(n,s),Math.max(n,s)+1))for(const t of ar(this._kfsOf(e.target),e.lane))t>=r&&t<=a&&o.push({target:e.target,lane:e.lane,at:t});return o}_onKeyDown(e,t){if(this.disabled||0!==e.button||!this.doc)return;e.preventDefault(),e.stopPropagation(),e.currentTarget.focus();const i=this._isSel(t),n=e.ctrlKey||e.metaKey;if(e.shiftKey&&this._anchor)this._select(n?[...this._keys,...this._range(this._anchor,t)]:this._range(this._anchor,t));else if(n){if(this._select(i?this._keys.filter(e=>Br(e,this._main)!==Br(t,this._main)):[...this._keys,t]),i)return}else i||this._select([t]),this._anchor=t;this._laneFocus.set(`${t.target}|${t.lane}`,t.at),this._refuseLocked(this._keys)||(this._drag={kind:"keys",pointerId:e.pointerId,x0:e.clientX,y0:e.clientY,moved:!1,base:this.doc,grab:t,sel:[...this._keys],duplicate:e.altKey,clickKey:t,wasSelected:i,additive:e.shiftKey||n,snaps:this._snapTargets(e.altKey?[]:this._keys)},this._pxCache=this._pxPerPct(),this._capture(e))}_cancelHold(){this._hold&&clearTimeout(this._hold.timer),this._hold=void 0}_onTrackDown(e,t){if(this.disabled||0!==e.button)return;const i=e.shiftKey||e.ctrlKey||e.metaKey;if("touch"===e.pointerType){this._cancelHold();const{pointerId:n,clientX:s,clientY:r}=e;return void(this._hold={pointerId:n,x:s,y:r,target:t,additive:i,timer:setTimeout(()=>{this._hold=void 0,this._startBand(n,s,r,t,i,"touch")},400)})}this._startBand(e.pointerId,e.clientX,e.clientY,t,i,e.pointerType)}_startBand(e,t,i,n,s,r){const a=this.renderRoot.querySelector(".lanes");if(!a)return;const o=a.getBoundingClientRect(),l=this._main,c=[...this.renderRoot.querySelectorAll(".lanes .key")].map(e=>{const t=e.getBoundingClientRect();return{key:Ir(e.dataset.key,l),x:t.left+t.width/2-o.left,y:t.top+t.height/2-o.top}});this._drag={kind:"band",pointerId:e,x0:t-o.left,y0:i-o.top,moved:!1,baseSel:s?[...this._keys]:[],additive:s,target:n,pointerType:r,centres:c};try{a.setPointerCapture?.(e)}catch{}}_capture(e){const t=this.renderRoot.querySelector(".lanes");try{(t??e.currentTarget).setPointerCapture?.(e.pointerId)}catch{}}_keysInBand(e=[]){const t=this._band;if(!t)return[];const[i,n]=[Math.min(t.x0,t.x1),Math.max(t.x0,t.x1)],[s,r]=[Math.min(t.y0,t.y1),Math.max(t.y0,t.y1)];return e.filter(e=>e.x>=i&&e.x<=n&&e.y>=s&&e.y<=r).map(e=>e.key)}_onRulerDown(e){if(0===e.button){e.preventDefault(),this._drag={kind:"seek",pointerId:e.pointerId,x0:e.clientX,y0:e.clientY,moved:!1};try{e.currentTarget.setPointerCapture?.(e.pointerId)}catch{}this._seek(this._atFromX(e.clientX))}}_onRulerKey(e){const t=100*this.time,i=e.shiftKey?10:1,n={ArrowLeft:t-i,ArrowDown:t-i,ArrowRight:t+i,ArrowUp:t+i,Home:0,End:100,PageUp:t+10,PageDown:t-10};e.key in n&&(e.preventDefault(),this._seek(Ch(n[e.key])))}_jump(e){const t=this.onion,i=e<0?t.prev:t.next;void 0!==i&&this._seek(i)}_setZoom(e,t){const i=Xr(e);if(i===this._zoom)return;const n=this._trackRect(),s=void 0!==t?this._atFromX(t):100*this.time,r=t??(n?n.left+12+s/100*(n.width-24):0);this._zoomAnchor={at:s,clientX:r},this._zoom=i}_onKeyKeydown(e,t){if(this.disabled||!this._view)return;const i=e.ctrlKey||e.metaKey,n=this._main;if(!("ArrowLeft"!==e.key&&"ArrowRight"!==e.key||e.altKey||i)){e.preventDefault(),this._isSel(t)||this._select([t]);const i=this._keys;if(this._refuseLocked(i))return;const s=Kr(this._view,i,("ArrowLeft"===e.key?-1:1)*(e.shiftKey?10:1));if(s.doc===this._view)return;const r=i.findIndex(e=>Br(e,n)===Br(t,n)),a=s.selection[r]??s.selection[0];return a&&(this._pendingFocus=Br(a,n),this._laneFocus.set(`${a.target}|${a.lane}`,a.at)),void this._commit(s.doc,"Move "+(1===i.length?"keyframe":"keyframes"),s.selection)}if("ArrowLeft"===e.key||"ArrowRight"===e.key||"Home"===e.key||"End"===e.key){e.preventDefault();const i=ar(this._kfsOf(t.target),t.lane),n=i.indexOf(t.at),s="Home"===e.key?0:"End"===e.key?i.length-1:n+("ArrowLeft"===e.key?-1:1);return void(s>=0&&s<i.length&&this._focusKey({target:t.target,lane:t.lane,at:i[s]},e.shiftKey))}if("ArrowUp"===e.key||"ArrowDown"===e.key){e.preventDefault();const i=this._rows(),n=i.findIndex(e=>e.target===t.target&&e.lane===t.lane)+("ArrowUp"===e.key?-1:1);if(n<0||n>=i.length)return;const s=ar(this._kfsOf(i[n].target),i[n].lane),r=s.reduce((e,i)=>Math.abs(i-t.at)<Math.abs(e-t.at)?i:e,s[0]);return void(void 0!==r&&this._focusKey({...i[n],at:r},e.shiftKey))}if("Delete"===e.key||"Backspace"===e.key)return e.preventDefault(),this._isSel(t)||this._select([t]),void this._delete();if(" "===e.key||"Enter"===e.key){e.preventDefault();const s=e.shiftKey||i;this._select(s?this._isSel(t)?this._keys.filter(e=>Br(e,n)!==Br(t,n)):[...this._keys,t]:[t]),s||(this._anchor=t)}}_onTimelineKeydown(e){if(this.disabled)return;const t=e.ctrlKey||e.metaKey,i=e.composedPath()[0]?.tagName;if("INPUT"===i||"TEXTAREA"===i||"SELECT"===i)return;const n=e.key.toLowerCase();if(t&&"c"===n)e.preventDefault(),this._copy();else if(t&&"v"===n)e.preventDefault(),this._paste();else if(t&&"a"===n){e.preventDefault();const t=[];for(const e of this._rows())for(const i of ar(this._kfsOf(e.target),e.lane))this._narrow&&"*"!==e.lane||t.push({...e,at:i});this._select(t)}else!t||"="!==n&&"+"!==n&&"-"!==n?"Escape"===e.key&&this._keys.length&&(e.preventDefault(),e.stopPropagation(),this._select([])):(e.preventDefault(),this._setZoom(Qr(this._zoom,"-"===n?-1:1)))}_focusKey(e,t=!1){this._select(t&&!this._isSel(e)?[...this._keys,e]:t?this._keys:[e]),t||(this._anchor=e),this._laneFocus.set(`${e.target}|${e.lane}`,e.at),this._pendingFocus=Br(e,this._main),this.requestUpdate()}_add(e,t,i){const n=this._view;if(!this.doc||!n||this.disabled)return;if(this._refuseLocked([{target:e,lane:t}]))return;const s=Ch(Math.min(100,Math.max(0,i))),r=Fr(n,e),a="*"===t?function(e,t,i){const n=ur(t);let s=e;for(const t of nr(e))s=mr(s,n,$r(e,t,n,i));return e.some(e=>e.at===n)||s!==e||(s=[...e,{at:n}]),{keyframes:hr(s),selection:[{lane:"*",at:n}]}}(r,s,n.easing):function(e,t,i,n){const s=ur(i),r=$r(e,t,s,n)??Zs[t].def;return{keyframes:hr(mr(e,s,r)),selection:[{lane:t,at:s}]}}(r,t,s,n.easing),o=a.selection.map(t=>({...t,target:e}));this._pendingFocus=Br(o[0],this._main),this._laneFocus.set(`${e}|${t}`,o[0].at),this._anchor=o[0],this._collapsed.delete(e),this._commit(Tr(n,e,a.keyframes),"*"===t?as(29):as(40,{lane:Ks(t).toLowerCase()}),o)}_onTrackDblClick(e,t,i){e.target.closest(".key")||this._add(t,i,this._snapAt(this._atFromX(e.clientX),e.shiftKey))}_addLane(e){this._menuOpen=!1,this._add(this._active,e,100*this.time)}_delete(){const e=this._keys.length,t=this._view;e&&t&&!this._refuseLocked(this._keys)&&(this._commit(Ur(t,this._keys),"Delete "+(1===e?"keyframe":"keyframes"),[]),this._announce(as(1165,{count:e})))}_copy(){const e=this._view,t=e?Gr(e,this._keys):void 0;t&&(Er(t),this._announce(as(1164,{count:t.items.length})))}_paste(){const e=qr(),t=this._view;if(!e||!t||!this.doc)return;const i=new Set(e.items.map(e=>e.target??this._main)),n=1===new Set(this._keys.map(e=>`${e.target}|${e.lane}`)).size&&"*"!==this._keys[0].lane?this._keys[0]:void 0,s=i.size>1?{}:n?{target:n.target,lane:n.lane}:{target:this._active},r=function(e,t,i,n={}){const s=Dr(e),r=new Set(t.items.map(e=>e.lane)),a=!n.lane||1!==r.size||r.has("*")||r.has(n.lane)?void 0:{from:[...r][0],to:n.lane},o=new Map;let l=0;for(const e of t.items){const t=n.target??e.target??s;let i=e;if(a){const t=Vr(a.from,a.to,e.frag);if(!t){l++;continue}i={...e,lane:a.to,frag:t,easings:e.easings?.[a.from]?{[a.to]:e.easings[a.from]}:void 0}}if("*"!==i.lane&&!Us(t).some(e=>e.id===i.lane)){l++;continue}if("*"===i.lane&&!Ws(t)&&(void 0!==i.frag.draw||void 0!==i.frag.stroke)){const e={...i.frag};delete e.draw,delete e.stroke,i={...i,frag:e}}const r=o.get(t)??[];r.push(i),o.set(t,r)}let c=e;const d=[];for(const[e,t]of o){const n=Cr(Fr(c,e),{items:t},i);c=Tr(c,e,n.keyframes),d.push(...n.selection.map(t=>({...t,target:e})))}return{doc:c,selection:d,skipped:l}}(t,e,Ch(100*this.time),s);if(!r.selection.length)return void this._announce(as(592));if(this._refuseLocked(r.selection))return;this._commit(r.doc,"Paste "+(1===r.selection.length?"keyframe":"keyframes"),r.selection);const a=r.skipped?as(13,{skipped:r.skipped}):"";this._announce(as(1166,{count:r.selection.length,at:Ah(100*this.time),skipped:a}))}_selectLane(e,t,i){const n=ar(this._kfsOf(e),t).map(i=>({target:e,lane:t,at:i}));this._lastTarget=e,this._select(i?[...this._keys.filter(i=>!(i.target===e&&i.lane===t)),...n]:n)}_toggleGroup(e){const t=new Set(this._collapsed);t.has(e)?t.delete(e):t.add(e),this._collapsed=t}render(){if(!this._view)return a.qy``;const e=this._narrow;return a.qy`
      <div class="shell" @keydown=${this._onTimelineKeydown}>
        ${this._renderBar(e)} ${e?this._renderNarrow():this._renderTimeline()}
        <div class="sr-only" role="status" aria-live="polite">${this._status}</div>
      </div>
    `}_renderAddMenu(e,t,i){const n=e.map((t,i)=>({id:t.id,label:as(t.label),icon:t.icon,separatorBefore:i>0&&e[i-1].group!==t.group}));return a.qy`<mc-ui-menu
      class="add-menu"
      .items=${n}
      label=${as(33,{target:Pr(this._view,t),at:Ah(i)})}
      @mc-menu-pick=${e=>{e.stopPropagation(),this._addLane(e.detail.id)}}
      @mc-menu-close=${e=>{e.stopPropagation(),"outside"===e.detail.reason&&(this._menuClosedAt=Date.now()),this._menuOpen=!1}}
    ></mc-ui-menu>`}_renderBar(e){const t=100*this.time,i=(this._view.duration*this.time).toFixed(2),n=this.onion,s=this._active,r=new Set(nr(this._kfsOf(s))),o=Us(s).filter(e=>!r.has(e.id)),l=qr();return a.qy`
      <div class="bar">
        <div class="readout" role="group" aria-label=${as(674)}>
          <button
            type="button"
            class="icon-btn sm"
            aria-label=${as(697)}
            title=${as(697)}
            ?disabled=${void 0===n.prev}
            @click=${()=>this._jump(-1)}
          >
            <ha-icon icon="mdi:skip-previous"></ha-icon>
          </button>
          <span class="now">${Ah(t)} <small>${i} s</small></span>
          <button
            type="button"
            class="icon-btn sm"
            aria-label=${as(546)}
            title=${as(546)}
            ?disabled=${void 0===n.next}
            @click=${()=>this._jump(1)}
          >
            <ha-icon icon="mdi:skip-next"></ha-icon>
          </button>
        </div>
        <button
          type="button"
          class="btn btn-secondary btn-sm add-btn"
          aria-haspopup="menu"
          aria-expanded=${this._menuOpen?"true":"false"}
          title=${as(23,{target:Pr(this._view,s)})}
          ?disabled=${this.disabled||!o.length}
          @click=${()=>{this._menuOpen?this._menuOpen=!1:Date.now()-this._menuClosedAt>400&&(this._menuOpen=!0)}}
        >
          <ha-icon icon="mdi:plus"></ha-icon><span class="lbl">${as(e?698:32)}</span>
        </button>
        ${this._menuOpen?this._renderAddMenu(o,s,t):a.s6}
        <span class="spacer"></span>
        <div class="tools" role="toolbar" aria-label=${as(397)}>
          <button
            type="button"
            class="icon-btn sm"
            data-act="copy"
            aria-label=${as(188)}
            title=${as(185)}
            ?disabled=${!this._keys.length}
            @click=${this._copy}
          >
            <ha-icon icon="mdi:content-copy"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn sm"
            data-act="paste"
            aria-label=${as(642)}
            title=${l?as(641,{target:Pr(this._view,s)}):as(189)}
            ?disabled=${!l||this.disabled}
            @click=${this._paste}
          >
            <ha-icon icon="mdi:content-paste"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn sm danger"
            data-act="delete"
            aria-label=${as(226)}
            title=${as(221)}
            ?disabled=${!this._keys.length||this.disabled}
            @click=${this._delete}
          >
            <ha-icon icon="mdi:delete-outline"></ha-icon>
          </button>
          <span class="sep" aria-hidden="true"></span>
          <button
            type="button"
            class="icon-btn sm"
            data-act="onion"
            aria-pressed=${this.onionSkin?"true":"false"}
            aria-label=${as(602)}
            title=${as(603)}
            @click=${()=>this.onionSkin=!this.onionSkin}
          >
            <ha-icon icon="mdi:layers-triple-outline"></ha-icon>
          </button>
        </div>
      </div>
    `}_renderRuler(){const e=Math.min(1,Math.max(0,this.time)),t=this.onionSkin?this.onion:{},i=this._narrow,n=this._pxPerPct(),s=function(e,t,i){const n=t>0?t:1,s=64/(e>0?e:6),r=e=>String(Math.round(1e3*e)/1e3);let a,o;"s"===i?(a=ta(s/100*n)/n*100,o=e=>`${r(e/100*n)} s`):(a=Math.min(50,ta(s)),o=e=>`${r(e)}%`);const l=Math.abs(a/ta(a/5)-5)<.01?5:4,c=a/l,d=[],p=[];for(let e=0;e*c<=100.000001&&e<2e3;e++){const t=Math.round(e*c*1e3)/1e3;e%l===0?d.push(t):p.push(t)}return{major:d,minor:p,label:o}}(i?Math.min(n,2.5):n,this._view.duration,this._unit),r=s.major.filter(t=>Math.abs(t-100*e)*n>34);return a.qy`
      <div class="ruler">
        <div class="ruler-head">${i?"":"s"===this._unit?as(782):as(211)}</div>
        <div
          class="ruler-track"
          role="slider"
          tabindex="0"
          aria-label=${as(674)}
          aria-valuemin="0"
          aria-valuemax="100"
          aria-valuenow=${Ch(100*e)}
          aria-valuetext=${as(1254,{pct:Ah(100*e),seconds:(this._view.duration*e).toFixed(2)})}
          @pointerdown=${this._onRulerDown}
          @pointermove=${this._onPointerMove}
          @pointerup=${this._onPointerUp}
          @pointercancel=${this._onPointerUp}
          @keydown=${this._onRulerKey}
        >
          ${s.minor.map(e=>a.qy`<i class="tick" style="--at: ${e/100}"></i>`)}
          ${s.major.map(e=>a.qy`<i class="tick major" style="--at: ${e/100}"></i>`)}
          ${r.map(e=>a.qy`<span class="tick-label ${0===e?"first":e>=99.999?"last":""}" style="--at: ${e/100}">${s.label(e)}</span>`)}
          ${void 0!==t.prev?a.qy`<i class="ghost" style="--at: ${t.prev/100}"></i>`:a.s6}
          ${void 0!==t.next?a.qy`<i class="ghost" style="--at: ${t.next/100}"></i>`:a.s6}
          <span class="ph-tag" style="--t: ${e}">${"s"===this._unit?`${(this._view.duration*e).toFixed(2)} s`:Ah(100*e)}</span>
        </div>
      </div>
    `}_overlays(){const e=Math.min(1,Math.max(0,this.time)),t=this.onionSkin?this.onion:{},i=t.prev??(void 0!==t.next?100*e:void 0),n=t.next??(void 0!==t.prev?100*e:void 0);return a.qy`
      ${this.onionSkin&&void 0!==i&&void 0!==n?a.qy`<div class="onion-band" style="--a: ${i/100}; --b: ${n/100}" aria-hidden="true"></div>`:a.s6}
      <div class="ph-line" style="--t: ${e}" aria-hidden="true"></div>
    `}_laneTab(e,t,i){const n=this._laneFocus.get(`${e}|${t}`);return void 0!==n&&i.includes(n)?n:this._keys.find(n=>n.target===e&&n.lane===t&&i.includes(n.at))?.at??i[0]}_renderKeys(e,t,i){const n=e.keyframes,s=e.target,r=this._main,o=this._laneTab(s,t,i),l=this.onionSkin&&s===this._active?this.onion:{},c=s===r&&1===this._groups().length?"":`${Pr(this._view,s)} `,d="*"===t?c?as(1265,{target:c.trim()}):as(1117):c?as(1266,{target:c.trim(),lane:Ks(t).toLowerCase()}):as(1211,{lane:Ks(t).toLowerCase()}),p=d.charAt(0).toUpperCase()+d.slice(1),h=i.slice(0,-1).map((e,r)=>{const o=i[r+1],l=this._isSel({target:s,lane:t,at:e})&&this._isSel({target:s,lane:t,at:o});if("*"!==t)return a.qy`<i class="span ${l?"sel":""} ${dr(n,t,e)?"own":""}" style="--a: ${e/100}; --b: ${o/100}"></i>`;const c=na(cr(n,e)??this._view.easing),d=c?`M0 20 C${100*c[0]} ${20-16*c[1]} ${100*c[2]} ${20-16*c[3]} 100 4`:"M0 20 L100 4";return a.qy`<i class="span ${l?"sel":""}" style="--a: ${e/100}; --b: ${o/100}">
        <svg viewBox="0 0 100 24" preserveAspectRatio="none" aria-hidden="true">
          ${a.JW`<path class="area" d="${d} L100 24 L0 24 Z"></path><path d=${d}></path>`}
        </svg>
      </i>`});return[...h,...i.map(e=>{const i={target:s,lane:t,at:e},c=this._isSel(i),d="*"===t?this._kfLanesText(n,e):ba(t,lr(n,t,e)),h=this._isLocked(i);return a.qy`<button
        type="button"
        class="key ${c?"sel":""} ${h?"locked":""} ${e===l.prev||e===l.next?"onion":""} ${"keys"===this._drag?.kind&&c?"dragging":""}"
        style="--at: ${e/100}"
        data-key=${Br(i,r)}
        data-lane=${t}
        data-target=${s}
        data-at=${e}
        role="slider"
        tabindex=${e===o?"0":"-1"}
        aria-label=${p}
        aria-valuemin="0"
        aria-valuemax="100"
        aria-valuenow=${e}
        aria-valuetext=${[Ah(e),d,c?as(1136):"",h?as(1124):""].filter(Boolean).join(", ")}
        aria-describedby="kf-help"
        title=${d?as(1204,{label:p,at:Ah(e),value:d}):as(1203,{label:p,at:Ah(e)})}
        @pointerdown=${e=>this._onKeyDown(e,i)}
        @keydown=${e=>this._onKeyKeydown(e,i)}
        @focus=${()=>this._laneFocus.set(`${s}|${t}`,e)}
        @dblclick=${e=>e.stopPropagation()}
      ></button>`})]}_kfLanesText(e,t){return nr(e.filter(e=>e.at===t)).map(e=>Ks(e)).join(", ")}_renderGroupHead(e,t){const i=ar(e.keyframes,"*"),n=Pr(this._view,e.target),s=!this._collapsed.has(e.target),r=e.target===this._active&&!t;return a.qy`
      <div
        class="row lane summary ${r?"target-active":""} ${this._keys.some(t=>t.target===e.target&&"*"===t.lane)?"active":""}"
        data-lane="*"
        data-target=${e.target}
        role="group"
        aria-label=${as(1232,{name:n})}
      >
        <div class="head">
          <button
            type="button"
            class="icon-btn sm collapse"
            aria-expanded=${s?"true":"false"}
            aria-label=${as(s?163:309,{name:n})}
            title=${as(s?162:308)}
            @click=${()=>this._toggleGroup(e.target)}
          >
            <ha-icon icon="mdi:chevron-down"></ha-icon>
          </button>
          <button
            type="button"
            class="lane-name"
            title=${as(788,{name:n.toLowerCase()})}
            @click=${t=>this._selectLane(e.target,"*",t.shiftKey||t.ctrlKey||t.metaKey)}
          >
            <ha-icon icon=${Rr(e.target)}></ha-icon>
            <span class="nm">${n}</span>
          </button>
          <button
            type="button"
            class="icon-btn sm lane-add"
            aria-label=${as(25,{name:n.toLowerCase()})}
            title=${as(22)}
            ?disabled=${this.disabled}
            @click=${()=>this._add(e.target,"*",100*this.time)}
          >
            <ha-icon icon="mdi:plus"></ha-icon>
          </button>
        </div>
        <div
          class="track"
          @pointerdown=${t=>this._onTrackDown(t,e.target)}
          @dblclick=${t=>this._onTrackDblClick(t,e.target,"*")}
        >
          ${this._renderKeys(e,"*",i)}
        </div>
      </div>
    `}_renderLane(e,t){const i=e.keyframes,n=ar(i,t),s=Zs[t],r=ba(s.id,$r(i,s.id,100*this.time,this._view.easing)),o=this._keys.some(i=>i.target===e.target&&i.lane===t);return a.qy`
      <div class="row lane sub ${o?"active":""}" data-lane=${t} data-target=${e.target} role="group" aria-label=${as(1207,{label:as(s.label)})}>
        <div class="head">
          <button
            type="button"
            class="lane-name"
            title=${as(788,{name:as(s.label).toLowerCase()})}
            @click=${i=>this._selectLane(e.target,t,i.shiftKey||i.ctrlKey||i.metaKey)}
          >
            <ha-icon icon=${s.icon}></ha-icon>
            <span class="nm">${as(s.label)}</span>
            ${r?this._laneValue(i,s.id,r):a.s6}
          </button>
          <button
            type="button"
            class="icon-btn sm lane-add"
            aria-label=${as(41,{name:as(s.label).toLowerCase()})}
            title=${as(22)}
            ?disabled=${this.disabled}
            @click=${()=>this._add(e.target,t,100*this.time)}
          >
            <ha-icon icon="mdi:plus"></ha-icon>
          </button>
        </div>
        <div
          class="track"
          @pointerdown=${t=>this._onTrackDown(t,e.target)}
          @dblclick=${i=>this._onTrackDblClick(i,e.target,t)}
        >
          ${this._renderKeys(e,t,n)}
        </div>
      </div>
    `}_laneValue(e,t,i){const n=$r(e,t,100*this.time,this._view.easing)??{},s=(e,t="")=>a.qy`<span class="val" title=${as(73,{text:i})}><i class="sw" style="background: ${e};${t}"></i></span>`,r=e=>e.replace(/var\(--mc-anim-c\)/g,this.entityColor);return"color"===t&&n.color?s(r(n.color)):"background"===t&&n.background?s(r(n.background)):"stroke"===t&&n.stroke?s(r(n.stroke)):"shadow"===t&&n.shadow?s("var(--mc-surface)",`box-shadow: ${"none"===n.shadow?"none":r(n.shadow).replace(/(\d+(?:\.\d+)?)px/g,(e,t)=>`${Math.min(4,Number(t)/4)}px`)}`):"filter"===t&&n.filter?a.qy`<span class="val" title=${as(72,{filter:n.filter})}>${n.filter.match(/^[a-z-]+/)?.[0]??n.filter}</span>`:a.qy`<span class="val" title=${as(73,{text:i})}>${i}</span>`}_trackWidth(){if(this._zoom<=1||!this._viewW)return;const e=this._narrow?44:216;return`${Math.round(Math.max(100,this._viewW-e)*this._zoom)}px`}_renderTimeline(){const e=this._groups(),t=1===e.length,i=[];for(const n of e){if(i.push(this._renderGroupHead(n,t)),this._collapsed.has(n.target))continue;const e=nr(n.keyframes);for(const t of e)i.push(this._renderLane(n,t));e.length||n.main||i.push(a.qy`<div class="empty-group">${as(559)}</div>`)}const n=this._band,s=this._trackWidth(),r=e.every(e=>!nr(e.keyframes).length);return a.qy`
      <div class="tl" role="group" aria-label=${as(396)}>
        <div class="tl-body" @wheel=${this._onWheel}>
          <div class="tl-content" style=${s?`--tw: ${s}`:a.s6}>
            ${this._renderRuler()}
            <div class="lanes" @pointermove=${this._onPointerMove} @pointerup=${this._onPointerUp} @pointercancel=${this._onPointerUp}>
              ${i}
              ${n?a.qy`<div
                      class="band"
                      style="left: ${Math.min(n.x0,n.x1)}px; top: ${Math.min(n.y0,n.y1)}px; width: ${Math.abs(n.x1-n.x0)}px; height: ${Math.abs(n.y1-n.y0)}px"
                    ></div>`:a.s6}
            </div>
            ${r?a.qy`<div class="empty-lanes"><ha-icon icon="mdi:information-outline"></ha-icon>${as(563)}</div>`:a.s6}
            ${this._overlays()}
          </div>
        </div>
        ${this._renderFoot()}
        <span class="sr-only" id="kf-help">
          ${as(253)}
        </span>
      </div>
    `}_renderFoot(){const e=this._zoom;return a.qy`<div class="tl-foot" role="toolbar" aria-label=${as(1008)}>
      <button
        type="button"
        class="icon-btn sm"
        data-act="snap"
        aria-pressed=${this._snap?"true":"false"}
        aria-label=${as(846)}
        title=${as(845)}
        @click=${()=>this._snap=!this._snap}
      >
        <ha-icon icon="mdi:magnet"></ha-icon>
      </button>
      <label class="grid-select">
        <span class="sr-only">${as(844)}</span>
        <div class="select">
          <select
            class="input"
            data-act="grid"
            aria-label=${as(844)}
            ?disabled=${!this._snap}
            @change=${e=>this._grid=e.target.value}
          >
            ${Yr.map(e=>a.qy`<option value=${e.id} ?selected=${e.id===this._grid}>${as(e.label)}</option>`)}
          </select>
          <ha-icon icon="mdi:chevron-down"></ha-icon>
        </div>
      </label>
      <button
        type="button"
        class="unit-btn"
        data-act="units"
        aria-label=${"s"===this._unit?as(758):as(757)}
        title=${as(756)}
        @click=${()=>this._unit="s"===this._unit?"pct":"s"}
      >
        ${"s"===this._unit?"s":"%"}
      </button>
      <span class="spacer"></span>
      <button
        type="button"
        class="icon-btn sm"
        data-act="zoom-out"
        aria-label=${as(1092)}
        title=${as(1093)}
        ?disabled=${e<=1}
        @click=${()=>this._setZoom(Qr(e,-1))}
      >
        <ha-icon icon="mdi:magnify-minus-outline"></ha-icon>
      </button>
      <span class="zoom-pct" aria-live="polite" title=${as(197)}>${Math.round(100*e)}%</span>
      <button
        type="button"
        class="icon-btn sm"
        data-act="zoom-in"
        aria-label=${as(1090)}
        title=${as(1091)}
        ?disabled=${e>=10}
        @click=${()=>this._setZoom(Qr(e,1))}
      >
        <ha-icon icon="mdi:magnify-plus-outline"></ha-icon>
      </button>
      <button
        type="button"
        class="icon-btn sm"
        data-act="zoom-fit"
        aria-label=${as(329)}
        title=${as(330)}
        ?disabled=${e<=1}
        @click=${()=>this._setZoom(1)}
      >
        <ha-icon icon="mdi:arrow-expand-horizontal"></ha-icon>
      </button>
    </div>`}_renderNarrow(){const e=this._active,t=this._kfsOf(e),i={target:e,keyframes:t,main:e===this._main},n=ar(t,"*");return a.qy`
      <div class="tl narrow" role="group" aria-label=${as(396)}>
        <div class="tl-body">
          <div class="tl-content">
            ${this._renderRuler()}
            <div class="lanes" @pointermove=${this._onPointerMove} @pointerup=${this._onPointerUp} @pointercancel=${this._onPointerUp}>
              ${this._renderGroupHead(i,!0)}
            </div>
            ${this._overlays()}
          </div>
          <ul class="kf-list" aria-label=${as(398)}>
            ${n.map(i=>{const n={target:e,lane:"*",at:i},s=this._isSel(n),r=this._kfLanesText(t,i),o=cr(t,i),l=nr(t.filter(e=>e.at===i)).map(e=>ba(e,lr(t,e,i))).filter(Boolean).join(" · ");return a.qy`<li>
                <button
                  type="button"
                  class="kf-row"
                  data-at=${i}
                  aria-pressed=${s?"true":"false"}
                  @click=${t=>{const r=t.shiftKey||t.ctrlKey||t.metaKey;this._select(r?s?this._keys.filter(t=>!(t.target===e&&"*"===t.lane&&t.at===i)):[...this._keys,n]:[n])}}
                >
                  <span class="at">${Ah(i)}</span>
                  <span class="props">${r||as(297)}${l?a.qy`<small>${l}</small>`:a.s6}</span>
                  <span class="ease">${ya(o)}</span>
                </button>
              </li>`})}
          </ul>
        </div>
        <span class="sr-only" id="kf-help">${as(70)}</span>
      </div>
    `}};jh.styles=[dh,a.AH`
      :host {
        display: block;
        min-width: 0;
        height: 100%;
        container: kf / inline-size;
        --head: ${(0,a.iz)(216)}px;
        --row: 34px;
        --inset: 12px;
        --key-ink: var(--mc-text-2);
        --grid-line: color-mix(in srgb, var(--mc-text) 7%, transparent);
        --grid-major: color-mix(in srgb, var(--mc-text) 12%, transparent);
        --ph: var(--mc-accent);
      }
      :host([disabled]) .tl {
        opacity: 0.6;
        pointer-events: none;
      }
      .shell {
        display: grid;
        grid-template-rows: auto minmax(0, 1fr);
        gap: 8px;
        min-width: 0;
        height: 100%;
        min-height: 0;
      }
      /* ── toolbar ── */
      .bar {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
        min-width: 0;
      }
      .readout {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        padding: 2px;
        border: 1px solid var(--mc-divider);
        border-radius: 10px;
        background: var(--mc-surface-2);
      }
      .readout .now {
        display: inline-flex;
        align-items: baseline;
        gap: 6px;
        min-width: 104px;
        justify-content: center;
        padding: 0 4px;
        font-family: var(--mc-mono);
        font-size: 0.8125rem;
        font-variant-numeric: tabular-nums;
        color: var(--mc-text);
      }
      .readout .now small {
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .spacer {
        flex: 1;
      }
      .tools {
        display: inline-flex;
        align-items: center;
        gap: 2px;
      }
      .sep {
        width: 1px;
        height: 20px;
        margin: 0 4px;
        background: var(--mc-divider);
      }
      .icon-btn[aria-pressed='true'] {
        background: var(--mc-accent-tint);
        color: var(--mc-accent-ink);
      }
      .add-btn ha-icon {
        --mdc-icon-size: 18px;
      }
      /* ── timeline ── */
      .tl {
        position: relative;
        display: grid;
        grid-template-rows: minmax(0, 1fr) auto;
        min-width: 0;
        min-height: 0;
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius-lg);
        background: var(--mc-surface);
        direction: ltr; /* time runs left to right */
        overflow: hidden;
        user-select: none;
        -webkit-user-select: none;
      }
      /* the scroll area: lanes scroll vertically, zoomed tracks sideways; heads and ruler stay */
      .tl-body {
        position: relative;
        min-height: 0;
        overflow: auto;
        overscroll-behavior: contain;
      }
      .tl-content {
        position: relative;
        min-width: 100%;
        width: max-content;
      }
      .tl.narrow {
        --head: ${(0,a.iz)(44)}px;
      }
      .tl.narrow .lane-name .nm,
      .tl.narrow .lane-name .val,
      .tl.narrow .collapse {
        display: none;
      }
      .row,
      .ruler {
        display: grid;
        grid-template-columns: var(--head) var(--tw, minmax(0, 1fr));
      }
      .row {
        min-height: var(--row);
      }
      .ruler {
        position: sticky;
        top: 0;
        z-index: 6;
        height: 36px;
        border-bottom: 1px solid var(--mc-divider);
        background: var(--mc-surface-2);
      }
      .ruler-head {
        position: sticky;
        left: 0; /* physical */
        z-index: 2;
        display: flex;
        align-items: center;
        gap: 6px;
        padding: 0 8px 0 12px;
        font-size: 0.75rem;
        font-weight: 500;
        color: var(--mc-text-2);
        background: var(--mc-surface-2);
        border-right: 1px solid var(--mc-divider); /* physical */
      }
      .ruler-track {
        position: relative;
        cursor: ew-resize;
        touch-action: none;
        overflow: hidden;
      }
      .ruler-track:focus-visible {
        outline-offset: -2px;
      }
      .tick {
        position: absolute;
        bottom: 0;
        width: 1px;
        height: 5px;
        background: var(--mc-field-border);
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--at)); /* physical */
      }
      .tick.major {
        height: 9px;
        background: var(--mc-text-2);
      }
      .tick-label {
        position: absolute;
        top: 5px;
        transform: translateX(-50%);
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--at)); /* physical */
        font-size: 0.6875rem;
        font-variant-numeric: tabular-nums;
        color: var(--mc-text-2);
        pointer-events: none;
        white-space: nowrap;
      }
      .tick-label.first {
        transform: translateX(-2px);
      }
      .tick-label.last {
        transform: translateX(calc(-100% + 2px));
      }
      .ph-tag {
        position: absolute;
        top: 3px;
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--t)); /* physical */
        transform: translateX(-50%);
        z-index: 4;
        padding: 2px 6px;
        border-radius: 6px;
        background: var(--mc-accent-fill);
        color: var(--mc-on-accent);
        font-size: 0.6875rem;
        font-weight: 500;
        font-variant-numeric: tabular-nums;
        pointer-events: none;
        white-space: nowrap;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
      }
      .ph-tag::after {
        content: '';
        position: absolute;
        left: 50%; /* physical */
        bottom: -4px;
        width: 8px;
        height: 8px;
        margin-left: -4px; /* physical */
        background: inherit;
        transform: rotate(45deg);
        border-radius: 1px;
        z-index: -1;
      }
      .ph-line {
        position: absolute;
        top: 36px;
        bottom: 0;
        width: 2px;
        margin-left: -1px; /* physical */
        left: calc(var(--head) + var(--inset) + (100% - var(--head) - 2 * var(--inset)) * var(--t)); /* physical */
        background: var(--ph);
        z-index: 3;
        pointer-events: none;
      }
      .onion-band {
        position: absolute;
        top: 36px;
        bottom: 0;
        left: calc(var(--head) + var(--inset) + (100% - var(--head) - 2 * var(--inset)) * var(--a)); /* physical */
        width: calc((100% - var(--head) - 2 * var(--inset)) * (var(--b) - var(--a)));
        background: repeating-linear-gradient(135deg, color-mix(in srgb, var(--mc-text) 5%, transparent) 0 6px, transparent 6px 12px);
        border-left: 1px dashed var(--mc-field-border); /* physical */
        border-right: 1px dashed var(--mc-field-border); /* physical */
        pointer-events: none;
        z-index: 0;
      }
      .ghost {
        position: absolute;
        bottom: 4px;
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--at)); /* physical */
        width: 10px;
        height: 10px;
        margin-left: -5px; /* physical */
        border: 1.5px dashed var(--mc-text-2);
        border-radius: 2px;
        transform: rotate(45deg);
        pointer-events: none;
      }
      .lanes {
        position: relative;
        touch-action: pan-x pan-y;
      }
      .lane {
        border-top: 1px solid var(--mc-divider);
      }
      .lane.summary {
        min-height: 40px;
        background: color-mix(in srgb, var(--mc-surface-2) 45%, var(--mc-surface));
      }
      .lanes > .lane.summary:first-child {
        border-top: 0;
      }
      .head {
        position: sticky;
        left: 0; /* physical */
        z-index: 4;
        display: flex;
        align-items: center;
        gap: 2px;
        min-width: 0;
        padding: 0 2px 0 4px;
        background: var(--mc-surface);
        border-right: 1px solid var(--mc-divider); /* physical */
      }
      .lane.summary .head {
        background: color-mix(in srgb, var(--mc-surface-2) 45%, var(--mc-surface));
      }
      .lane.sub .head {
        padding-left: 20px; /* physical */
      }
      .lane.active .head {
        background: var(--mc-surface-2);
      }
      .collapse {
        flex: none;
      }
      .collapse ha-icon {
        transition: transform 0.15s ease-out;
      }
      .collapse[aria-expanded='false'] ha-icon {
        transform: rotate(-90deg);
      }
      .lane-name {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 8px;
        min-width: 0;
        min-height: 32px;
        padding: 0 6px;
        border: 0;
        border-radius: 6px;
        background: transparent;
        text-align: start;
        font-size: 0.8125rem;
        font-weight: 500;
        color: var(--mc-text);
      }
      .lane.sub .lane-name {
        font-weight: 400;
      }
      .lane-name:hover {
        background: var(--mc-surface-2);
      }
      .lane-name ha-icon {
        --mdc-icon-size: 16px;
        color: var(--mc-text-2);
        flex: none;
      }
      .lane.target-active .lane-name ha-icon {
        color: var(--mc-accent-ink);
      }
      .lane-name .nm {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .lane-name .val {
        flex: none;
        max-width: 64px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-family: var(--mc-mono);
        font-size: 0.6875rem;
        font-weight: 400;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .val .sw {
        display: inline-block;
        width: 14px;
        height: 14px;
        vertical-align: middle;
        border-radius: 4px;
        border: 1px solid var(--mc-field-border);
      }
      .head .icon-btn.sm {
        width: 28px;
        height: 28px;
        --mdc-icon-size: 16px;
      }
      .track {
        position: relative;
        min-width: 0;
        cursor: crosshair;
        background-image: linear-gradient(to right, var(--grid-major) 1px, transparent 1px), linear-gradient(to right, var(--grid-line) 1px, transparent 1px);
        background-size:
          calc((100% - 2 * var(--inset)) / 4) 100%,
          calc((100% - 2 * var(--inset)) / 20) 100%;
        background-position:
          var(--inset) 0,
          var(--inset) 0;
        background-repeat: repeat-x;
        background-clip: content-box;
        padding: 0 var(--inset);
        touch-action: pan-x pan-y;
      }
      .span {
        position: absolute;
        top: 50%;
        height: 2px;
        margin-top: -1px;
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--a)); /* physical */
        width: calc((100% - 2 * var(--inset)) * (var(--b) - var(--a)));
        background: color-mix(in srgb, var(--mc-text-2) 45%, transparent);
        border-radius: 1px;
        pointer-events: none;
      }
      /* a lane segment with its own easing */
      .span.own {
        height: 3px;
        margin-top: -1.5px;
        background: repeating-linear-gradient(90deg, var(--mc-text-2) 0 4px, transparent 4px 7px);
      }
      .lane.summary .span {
        height: 24px;
        margin-top: -12px;
        background: none;
      }
      .span svg {
        display: block;
        width: 100%;
        height: 100%;
        overflow: visible;
      }
      .span path {
        fill: none;
        stroke: color-mix(in srgb, var(--mc-text-2) 60%, transparent);
        stroke-width: 1.5;
        vector-effect: non-scaling-stroke;
      }
      .span .area {
        fill: color-mix(in srgb, var(--mc-text-2) 8%, transparent);
        stroke: none;
      }
      .span.sel path {
        stroke: var(--mc-accent);
      }
      .span.sel {
        background: color-mix(in srgb, var(--mc-accent) 55%, transparent);
      }
      .lane.summary .span.sel {
        background: none;
      }
      .key.locked {
        opacity: 0.55;
        cursor: not-allowed;
      }
      .key {
        position: absolute;
        top: 50%;
        left: calc(var(--inset) + (100% - 2 * var(--inset)) * var(--at)); /* physical */
        width: 24px;
        height: 32px;
        margin: -16px 0 0 -12px;
        padding: 0;
        border: 0;
        background: transparent;
        cursor: grab;
        z-index: 2;
        touch-action: none;
      }
      .key::before {
        content: '';
        position: absolute;
        left: 50%; /* physical */
        top: 50%;
        width: 11px;
        height: 11px;
        margin: -5.5px 0 0 -5.5px;
        border-radius: 2px;
        transform: rotate(45deg);
        background: var(--key-ink);
        box-shadow: 0 0 0 2px var(--mc-surface);
        transition:
          transform 0.15s ease-out,
          background-color 0.15s ease-out,
          box-shadow 0.15s ease-out;
      }
      .lane.summary .key::before {
        width: 13px;
        height: 13px;
        margin: -6.5px 0 0 -6.5px;
        background: var(--mc-surface);
        box-shadow:
          inset 0 0 0 2px var(--mc-text),
          0 0 0 2px var(--mc-surface);
      }
      .key:hover::before {
        transform: rotate(45deg) scale(1.2);
      }
      .key.sel::before {
        background: var(--mc-accent-fill);
        box-shadow:
          0 0 0 2px var(--mc-surface),
          0 0 0 4px color-mix(in srgb, var(--mc-accent) 45%, transparent);
      }
      .lane.summary .key.sel::before {
        background: var(--mc-accent-fill);
        box-shadow:
          inset 0 0 0 2px var(--mc-accent-fill),
          0 0 0 2px var(--mc-surface),
          0 0 0 4px color-mix(in srgb, var(--mc-accent) 45%, transparent);
      }
      .key.onion::after {
        content: '';
        position: absolute;
        left: 50%; /* physical */
        top: 50%;
        width: 19px;
        height: 19px;
        margin: -9.5px 0 0 -9.5px;
        border: 1.5px dashed var(--mc-text-2);
        border-radius: 4px;
        transform: rotate(45deg);
        pointer-events: none;
      }
      .key:focus-visible {
        outline: none;
      }
      .key:focus-visible::before {
        box-shadow:
          0 0 0 2px var(--mc-surface),
          0 0 0 4px var(--mc-accent);
      }
      .key.dragging {
        cursor: grabbing;
      }
      .band {
        position: absolute;
        z-index: 5;
        border: 1px solid var(--mc-accent);
        background: var(--mc-accent-tint);
        border-radius: 2px;
        pointer-events: none;
      }
      .empty-lanes,
      .empty-group {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 16px;
        border-top: 1px solid var(--mc-divider);
        font-size: 0.8125rem;
        color: var(--mc-text-2);
      }
      .empty-group {
        position: sticky;
        left: 0; /* physical */
        width: max-content;
        max-width: 100cqw;
        padding-left: 24px; /* physical */
        border-top: 0;
        font-size: 0.75rem;
      }
      /* ── footer: snapping, ruler unit, zoom ── */
      .tl-foot {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 4px 6px;
        padding: 4px 8px;
        border-top: 1px solid var(--mc-divider);
        background: color-mix(in srgb, var(--mc-surface-2) 55%, var(--mc-surface));
      }
      .tl-foot .icon-btn.sm {
        width: 30px;
        height: 30px;
        --mdc-icon-size: 17px;
      }
      .grid-select {
        width: 92px;
      }
      .grid-select select.input {
        min-height: 30px;
        padding-top: 2px;
        padding-bottom: 2px;
        font-size: 0.8125rem;
      }
      .unit-btn {
        min-width: 34px;
        height: 30px;
        padding: 0 8px;
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius);
        background: var(--mc-surface);
        color: var(--mc-text);
        font-size: 0.75rem;
        font-weight: 500;
        font-variant-numeric: tabular-nums;
      }
      .unit-btn:hover {
        background: var(--mc-surface-2);
      }
      .zoom-pct {
        min-width: 44px;
        text-align: center;
        font-size: 0.75rem;
        font-variant-numeric: tabular-nums;
        color: var(--mc-text-2);
      }
      kbd {
        display: inline-block;
        min-width: 18px;
        padding: 1px 5px;
        border: 1px solid var(--mc-divider);
        border-bottom-width: 2px;
        border-radius: 4px;
        background: var(--mc-surface);
        font-family: var(--mc-mono);
        font-size: 0.6875rem;
        line-height: 1.4;
        color: var(--mc-text);
        text-align: center;
      }
      /* ── narrow: keyframe list ── */
      .kf-list {
        display: grid;
        gap: 0;
        margin: 0;
        padding: 0;
        list-style: none;
        border-top: 1px solid var(--mc-divider);
      }
      .kf-row {
        display: grid;
        grid-template-columns: 56px minmax(0, 1fr) auto;
        align-items: center;
        gap: 10px;
        width: 100%;
        min-height: 48px;
        padding: 6px 12px;
        border: 0;
        border-top: 1px solid var(--mc-divider);
        background: transparent;
        text-align: start;
      }
      .kf-list li:first-child .kf-row {
        border-top: 0;
      }
      .kf-row:hover {
        background: var(--mc-surface-2);
      }
      .kf-row[aria-pressed='true'] {
        background: var(--mc-accent-tint);
      }
      .kf-row[aria-pressed='true'] .at {
        color: var(--mc-accent-ink);
      }
      .kf-row:focus-visible {
        outline-offset: -2px;
      }
      .kf-row .at {
        font-family: var(--mc-mono);
        font-size: 0.8125rem;
        font-weight: 500;
        font-variant-numeric: tabular-nums;
      }
      .kf-row .props {
        min-width: 0;
        font-size: 0.8125rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .kf-row .props small {
        display: block;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .kf-row .ease {
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      @container kf (max-width: 560px) {
        .readout .now {
          min-width: 88px;
        }
        .add-btn .lbl {
          display: none;
        }
      }
    `],zh([(0,o.MZ)({attribute:!1})],jh.prototype,"doc",void 0),zh([(0,o.MZ)({attribute:!1})],jh.prototype,"hass",void 0),zh([(0,o.MZ)({attribute:!1})],jh.prototype,"library",void 0),zh([(0,o.MZ)({type:Number})],jh.prototype,"time",void 0),zh([(0,o.MZ)({type:Boolean,reflect:!0})],jh.prototype,"disabled",void 0),zh([(0,o.MZ)({attribute:!1})],jh.prototype,"layerView",void 0),zh([(0,o.MZ)({type:Boolean,reflect:!0,attribute:"onion-skin"})],jh.prototype,"onionSkin",void 0),zh([(0,o.MZ)({type:String})],jh.prototype,"layout",void 0),zh([(0,o.MZ)({type:String})],jh.prototype,"entityColor",void 0),zh([(0,o.MZ)({attribute:!1})],jh.prototype,"studioSelection",void 0),zh([(0,o.wk)()],jh.prototype,"_keys",void 0),zh([(0,o.wk)()],jh.prototype,"_draft",void 0),zh([(0,o.wk)()],jh.prototype,"_band",void 0),zh([(0,o.wk)()],jh.prototype,"_width",void 0),zh([(0,o.wk)()],jh.prototype,"_viewW",void 0),zh([(0,o.wk)()],jh.prototype,"_menuOpen",void 0),zh([(0,o.wk)()],jh.prototype,"_status",void 0),zh([(0,o.wk)()],jh.prototype,"_zoom",void 0),zh([(0,o.wk)()],jh.prototype,"_unit",void 0),zh([(0,o.wk)()],jh.prototype,"_snap",void 0),zh([(0,o.wk)()],jh.prototype,"_grid",void 0),zh([(0,o.wk)()],jh.prototype,"_collapsed",void 0),zh([(0,o.wk)()],jh.prototype,"_lastTarget",void 0),jh=zh([(0,o.EM)("mc-anim-keyframes-editor")],jh);const qh={...fe,...be,...xe},Eh={"steam-rise":"bottom:-12px;width:18px;height:18px;margin-left:-9px;border-radius:50%;background:$c;filter:blur(5px);",bubbles:"bottom:-10px;width:8px;height:8px;margin-left:-4px;border-radius:50%;border:1.5px solid $c;background:color-mix(in srgb,$c 22%,transparent);","bubbles|:nth-child(even)":"width:5px;height:5px;","snow-fall":"top:-8px;width:5px;height:5px;border-radius:50%;background:$c;","rain-fall":"top:-18px;width:2px;height:14px;border-radius:1px;background:linear-gradient(transparent,$c);","liquid-wave":"left:-50%;top:calc(100% - $i * 1%);width:200%;aspect-ratio:1;border-radius:42%;background:color-mix(in srgb,$c 50%,transparent);opacity:1;","liquid-wave|:nth-child(2)":"top:calc(100% - $i * .9%);border-radius:38%;background:$c;animation-direction:reverse;","storm-flash":"inset:0;background:color-mix(in srgb,$c 35%,rgba(255,255,255,.55));","shine-sweep":"top:0;bottom:0;left:0;width:45%;opacity:1;background:linear-gradient(100deg,transparent 0%,color-mix(in srgb,var(--mca-shine-sweep-c,#fff) calc($i * 1%),transparent) 50%,transparent 100%);",...ye,"holographic-shimmer":"left:0;top:0;width:400%;height:100%;opacity:calc($i / 100);background:linear-gradient(115deg,transparent 20%,color-mix(in srgb,$c 55%,#ff80ab) 35%,color-mix(in srgb,$c 55%,#80d8ff) 50%,color-mix(in srgb,$c 55%,#ccff90) 65%,transparent 80%) 0 0 / 50% 100% repeat-x;",scanline:"left:0;top:0;width:100%;height:14%;opacity:calc($i / 100);background:linear-gradient(transparent,color-mix(in srgb,$c 45%,transparent) 70%,$c 96%,transparent);",twinkle:"top:calc(8% + var(--mc-anim-phase) * 80%);width:10px;height:10px;margin:-5px 0 0 -5px;background:$c;clip-path:polygon(50% 0,62% 38%,100% 50%,62% 62%,50% 100%,38% 62%,0 50%,38% 38%);",spotlight:"left:50%;top:50%;width:70cqmin;aspect-ratio:1;margin:-35cqmin 0 0 -35cqmin;opacity:calc($i / 100);border-radius:50%;background:radial-gradient(circle,$c,transparent 65%);","color-cycle-bg":"left:0;top:0;width:100%;height:100%;opacity:calc($i / 100);background:$c;",aurora:"left:-25%;top:calc(-10% + var(--mc-anim-k) * 40%);width:150%;height:55%;background:radial-gradient(ellipse 30% 50% at 32% 50%,$c,color-mix(in srgb,$c 45%,transparent) 45%,transparent),radial-gradient(ellipse 30% 50% at 62% 50%,color-mix(in srgb,$c 50%,#00e5ff),color-mix(in srgb,color-mix(in srgb,$c 50%,#00e5ff) 45%,transparent) 45%,transparent);","aurora|:nth-child(2)":"animation-duration:calc(var(--mc-fx-dur) * 1.4);animation-direction:reverse;background:radial-gradient(ellipse 30% 50% at 37% 50%,color-mix(in srgb,$c 50%,#76ff03),color-mix(in srgb,color-mix(in srgb,$c 50%,#76ff03) 45%,transparent) 45%,transparent),radial-gradient(ellipse 30% 50% at 68% 50%,$c,color-mix(in srgb,$c 45%,transparent) 45%,transparent);","aurora|:nth-child(3)":"animation-duration:calc(var(--mc-fx-dur) * .8);background:radial-gradient(ellipse 38% 50% at 42% 50%,color-mix(in srgb,$c 50%,#e040fb),color-mix(in srgb,color-mix(in srgb,$c 50%,#e040fb) 45%,transparent) 45%,transparent);","lava-lamp":"bottom:-12%;width:calc(14cqmin + var(--mc-anim-phase) * 16cqmin);aspect-ratio:1;margin-left:-10cqmin;border-radius:50%;background:radial-gradient(circle at 35% 35%,color-mix(in srgb,$c 55%,#fff),$c 70%);filter:blur(2px);","plasma-gradient":"left:50%;top:50%;width:160cqmax;aspect-ratio:1;margin:-80cqmax 0 0 -80cqmax;opacity:calc($i / 100);background:radial-gradient(circle at 30% 30%,$c,color-mix(in srgb,$c 55%,transparent) 22%,color-mix(in srgb,$c 15%,transparent) 38%,transparent 52%),radial-gradient(circle at 70% 40%,color-mix(in srgb,$c 40%,#ff4081),color-mix(in srgb,color-mix(in srgb,$c 40%,#ff4081) 55%,transparent) 22%,color-mix(in srgb,color-mix(in srgb,$c 40%,#ff4081) 15%,transparent) 38%,transparent 52%),radial-gradient(circle at 45% 75%,color-mix(in srgb,$c 40%,#00e5ff),color-mix(in srgb,color-mix(in srgb,$c 40%,#00e5ff) 55%,transparent) 22%,color-mix(in srgb,color-mix(in srgb,$c 40%,#00e5ff) 15%,transparent) 38%,transparent 52%);","gradient-flow":"left:0;top:0;width:300%;height:100%;opacity:calc($i / 100);background:linear-gradient(110deg,$c,color-mix(in srgb,$c 40%,#ff4081),color-mix(in srgb,$c 40%,#00e5ff),$c);",starfield:"top:calc(6% + var(--mc-anim-phase) * 86%);width:3px;height:3px;margin:-1.5px 0 0 -1.5px;border-radius:50%;background:$c;box-shadow:0 0 4px 1px color-mix(in srgb,$c 60%,transparent);","starfield|:nth-child(3n)":"width:2px;height:2px;","meteor-shower":"top:calc(-10% + var(--mc-anim-phase) * 30%);left:calc(30% + var(--mc-anim-x) * .8);width:22%;height:2px;rotate:-45deg;transform-origin:0 50%;border-radius:2px;background:linear-gradient(90deg,$c,transparent);",bokeh:"top:calc(10% + var(--mc-anim-phase) * 75%);width:calc(10cqmin + var(--mc-anim-k) * 18cqmin);aspect-ratio:1;margin:-10cqmin 0 0 -10cqmin;border-radius:50%;filter:blur(1px);background:radial-gradient(circle,color-mix(in srgb,$c 70%,transparent),color-mix(in srgb,$c 25%,transparent) 60%,transparent 72%);","matrix-rain":"top:0;width:2px;height:calc(20% + var(--mc-anim-phase) * 25%);border-radius:1px;background:linear-gradient(transparent,color-mix(in srgb,$c 60%,transparent) 70%,$c);","matrix-rain|:nth-child(odd)":"width:3px;background:repeating-linear-gradient(transparent 0 3px,$c 3px 6px);-webkit-mask:linear-gradient(transparent,#000);mask:linear-gradient(transparent,#000);",smoke:"bottom:-20px;width:26px;height:26px;margin-left:-13px;border-radius:50%;background:color-mix(in srgb,$c 70%,#9e9e9e);filter:blur(8px);","clouds-drift":"left:-40%;top:calc(5% + var(--mc-anim-phase) * 55%);width:38%;aspect-ratio:2.4;filter:blur(1.5px);background:radial-gradient(ellipse 35% 45% at 30% 60%,$c 60%,transparent 62%),radial-gradient(ellipse 30% 55% at 55% 45%,$c 60%,transparent 62%),radial-gradient(ellipse 28% 40% at 75% 62%,$c 60%,transparent 62%);","water-ripple":"top:calc(25% + var(--mc-anim-phase) * 50%);width:60cqmin;aspect-ratio:2.2;margin:-13.6cqmin 0 0 -30cqmin;border:2px solid $c;border-radius:50%;box-sizing:border-box;box-shadow:0 0 0 3px color-mix(in srgb,$c 25%,transparent);",fireworks:"left:50%;top:45%;width:4px;height:4px;margin:-2px 0 0 -2px;border-radius:50%;background:$c;box-shadow:0 0 6px 1px $c;animation-delay:var(--mc-fx-delay,0s);","fireworks|:nth-child(even)":"background:color-mix(in srgb,$c 50%,#ffeb3b);box-shadow:0 0 6px 1px color-mix(in srgb,$c 50%,#ffeb3b);","tap-ripple":"left:var(--mc-tap-x,50%);top:var(--mc-tap-y,50%);width:290cqmax;aspect-ratio:1;margin:-145cqmax 0 0 -145cqmax;border-radius:50%;background:radial-gradient(circle,$c 0,color-mix(in srgb,$c 55%,transparent) 40%,transparent 70%);"};function Hh(e,t,i=!1){const n=ge(t),s=`var(--mca-${t}-c, var(--mc-anim-c))`;return e.replace(/\$i/g,`var(--mca-${t}-i, ${n?.defaults.intensity??1})`).replace(/\$c/g,i?`color-mix(in srgb, ${s} calc(var(--mca-${t}-s, 1) * 100%), transparent)`:s)}const Lh=a.AH`[data-mc-anim],[data-mc-anim-fx]{--mc-anim-c:var(--mc-anim-color,var(--mc-design-color,var(--primary-color,#03a9f4)))}[data-mc-anim~='module']{animation:var(--mc-anim-m);transform-origin:var(--mc-anim-om,center)} [data-mc-anim~='icon'] .mc-anim-icon{display:inline-block;animation:var(--mc-anim-i);transform-origin:var(--mc-anim-oi,center)} [data-mc-anim~='label'] [data-mc-part='name']{display:inline-block;animation:var(--mc-anim-n);transform-origin:var(--mc-anim-on,center)} [data-mc-anim~='icon']:not(:has(.mc-anim-icon)){animation:var(--mc-anim-mi);transform-origin:var(--mc-anim-om,var(--mc-anim-oi,center))} [data-mc-anim-fx]{position:relative;isolation:isolate}.mc-anim-fx{position:absolute;inset:0;z-index:-1;overflow:hidden;pointer-events:none;border-radius:inherit;container-type:size}.mc-anim-fx[data-front]{z-index:auto}.mc-anim-fx>i{position:absolute;display:block;left:var(--mc-anim-x,50%);opacity:0;will-change:translate,scale,rotate,opacity;animation:var(--mc-fx-anim);animation-delay:calc(var(--mc-fx-delay,0s) - var(--mc-anim-phase,0) * var(--mc-fx-dur,1s))} [data-mc-tap][data-mc-tapped]{animation:var(--mc-anim-m,none),var(--mc-anim-t);transform-origin:var(--mc-anim-om,center)} .mc-anim-fx[data-tap]:not([data-tapped]),.mc-anim-ring[data-tap]:not([data-tapped]){display:none}`,Vh=a.AH`@media (prefers-reduced-motion:reduce){[data-mc-anim],[data-mc-anim] .mc-anim-icon,[data-mc-anim~='label'] [data-mc-part='name'],[data-mc-tap],.mc-anim-fx>i{animation:none !important}.mc-anim-fx:not([data-p]),.mc-anim-ring{display:none}}`,Oh=(0,a.iz)(Lh.cssText+[...Object.entries(qh).map(([e,t])=>`@keyframes mc-anim-${e} {${Hh(t,e.replace(/-icon$/,""),!0)}\n}`),...pe.filter(e=>void 0!==e.particles).map(e=>`.mc-anim-fx[data-fx="${e.id}"] {\n  opacity: var(--mca-${e.id}-s, 1);\n}`),...Object.entries({"conic-border-spin":"padding:calc($i * 1px);box-sizing:border-box;background:color-mix(in srgb,$c 18%,transparent);-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0);"}).map(([e,t])=>`.mc-anim-fx[data-fx="${e}"] {${Hh(t,e)}\n}`),...Object.entries(Eh).map(([e,t])=>{const[i,n=""]=e.split("|");return`.mc-anim-fx[data-fx="${i}"] > i${n} {${Hh(t,i)}\n}`})].join("\n")+Vh.cssText),Ph=new Set(["off","unavailable","unknown","idle","standby"]),Rh=new Set(["alarm_control_panel","alert","automation","binary_sensor","calendar","camera","climate","cover","device_tracker","fan","group","humidifier","input_boolean","lawn_mower","light","lock","media_player","person","plant","remote","schedule","script","siren","sun","switch","timer","update","vacuum","valve","water_heater"]);function Dh(e){if(!e)return!1;const t=e.entity_id.split(".")[0],i=e.state;if(Ph.has(i))return!1;switch(t){case"alarm_control_panel":return"disarmed"!==i;case"cover":case"valve":return"closed"!==i;case"device_tracker":case"person":return"not_home"!==i;case"lock":return"locked"!==i;case"vacuum":return!["docked","paused","returning"].includes(i);case"lawn_mower":return["mowing","error"].includes(i);case"plant":return"problem"===i;case"timer":return"active"===i;case"camera":return"streaming"===i;case"sun":return"above_horizon"===i;default:return!0}}function Nh(e,t){if(!e||!Object.prototype.hasOwnProperty.call(e,t))return;const i=e[t];if(!Array.isArray(i))return;const n=[i[0],i[1],i[2]];return"hs_color"===t&&n.slice(0,2).every(Number.isFinite)?function(e,t){const i=Math.max(0,Math.min(100,t))/100,n=t=>{const n=(t+e/60)%6;return 1-i*Math.max(0,Math.min(n,4-n,1))};return[n(5),n(3),n(1)].map(e=>Math.round(255*e))}((n[0]%360+360)%360,n[1]):n.every(Number.isFinite)?n.map(e=>Math.max(0,Math.min(255,Math.round(e)))):void 0}const Fh=/^entity(?:\s+(\d+(?:\.\d+)?)%)?$/;function Th(e){if("string"!=typeof e)return;const t=e.trim().match(Fh);return t?{opacity:void 0===t[1]?100:Math.min(100,Number(t[1]))}:void 0}function Bh(e){return void 0!==Th(e)}function Ih(e){const t=Th(e);if(!t)return;const i="var(--mc-entity-color, currentColor)";return t.opacity>=100?i:`color-mix(in srgb, ${i} ${t.opacity}%, transparent)`}const Zh=e=>e.replace(/_/g,"-"),Wh={margin:["top","right","bottom","left"].map(e=>({key:`margin_${e}`,cssProperty:`margin-${e}`})),padding:["top","right","bottom","left"].map(e=>({key:`padding_${e}`,cssProperty:`padding-${e}`})),border_radius:["top_left","top_right","bottom_right","bottom_left"].map(e=>({key:`border_${e}_radius`,cssProperty:`border-${e.replace("_","-")}-radius`}))},Kh="margin:p padding:p width:p height:p min_width:p min_height:p max_width:p max_height:p box_sizing border border_top border_right border_bottom border_left border_width:p border_style border_color:c border_radius:p outline outline_width:p outline_style outline_color:c outline_offset:p box_shadow position top:p right:p bottom:p left:p inset:p display visibility opacity z_index overflow overflow_x overflow_y float clear cursor pointer_events font_family font_size:p font_weight font_style font_variant color:c text_align text_decoration text_transform text_indent:p text_overflow text_shadow line_height letter_spacing:p word_spacing:p white_space word_break overflow_wrap background background_color:c background_image:i background_position background_size background_repeat background_attachment background_clip background_origin backdrop_filter flex_direction flex_wrap justify_content align_items align_content gap:p row_gap:p column_gap:p flex flex_grow flex_shrink flex_basis:p align_self order grid_template_columns grid_template_rows grid_template_areas grid_auto_columns grid_auto_rows grid_auto_flow grid_column grid_row grid_area transition transition_property transition_duration:s transition_timing_function transition_delay:s transform transform_origin animation_name animation_duration:s animation_timing_function animation_delay:s animation_iteration_count animation_direction animation_fill_mode animation_play_state filter list_style list_style_type list_style_position list_style_image border_collapse border_spacing:p table_layout caption_side".split(" ").map(e=>{const[t,i=""]=e.split(":");return{key:t,flag:i}}),Uh=[...Kh.filter(e=>"c"===e.flag).map(e=>e.key),"icon_color","icon_background","label_color","state_color"];new Set(Kh.filter(e=>"i"===e.flag).map(e=>e.key)),Object.fromEntries(Kh.filter(e=>"p"===e.flag||"s"===e.flag).flatMap(e=>{const t="s"===e.flag?"s":"px";return[[e.key,t],...(Wh[e.key]||[]).map(e=>[e.key,t])]})),new Map;const Gh=e=>"string"==typeof e&&""!==e.trim()?e.trim():void 0;function Yh(e){if("number"==typeof e&&Number.isFinite(e)&&e>=0)return+e.toFixed(3)+"s";const t=Gh(e);if(!t)return;const i=t.length<=64?/^(?:\d+(?:\.\d+)?|\.\d+)(m?s)?$/.exec(t):null;return i?i[1]?t:+(+t).toFixed(3)+"s":void 0}const Jh=new Set(["rgb","rgba","hsl","hsla","hwb","lab","lch","oklab","oklch","color","color-mix","var","light-dark","calc","min","max","clamp"]);function Xh(e){const t=Gh(e);if(!t||t.length>256||!/^[#\w\s(),.%+*/-]+$/.test(t)||t.includes("/*")||t.includes("*/"))return;let i=0;for(const e of t)if("("===e)i++;else if(")"===e&&--i<0)return;if(0!==i)return;const n=t.match(/\(/g)?.length??0,s=[...t.matchAll(/([a-z-]+)\s*\(/gi)];return s.length!==n||s.some(e=>!Jh.has(e[1].toLowerCase()))?void 0:t}const Qh=/^(\d+(?:\.\d+)?|\.\d+)(%)?$/;new Map([["blur",/^(\d+(?:\.\d+)?|\.\d+)(px|em|rem)?$/],["hue-rotate",/^(-?(?:\d+(?:\.\d+)?|\.\d+))(deg|grad|rad|turn)$/],...["brightness","contrast","grayscale","invert","opacity","saturate","sepia"].map(e=>[e,Qh])]),new Map,new Map,new Map([["left",["2/1/4/2",3]],["right",["2/4/4/5",2]],["above",["1/2/2/4",1]],["below",["4/2/5/4",0]]]),new Set(["start","center","end"]),function(){const e={};for(const{key:t}of Kh){e[t]=Zh(t);for(const i of Wh[t]||[])e[i.key]=i.cssProperty}}();const eu=/(?<![\w-])entity(?: \d+(?:\.\d+)?%)?(?![\w-])/g;function tu(e){const t="string"==typeof e&&e.length<=256?e.replace(eu,e=>Ih(e)??e):e;return t===e?void 0:t}function iu(e,t,i){const n=Gh(e.trigger_entity);switch(n&&(t=i?.[n]),e.trigger){case"entity_on":return Dh(t);case"state":{const i=(e.state||"").trim();return!!i&&!!t&&t.state===i}default:return!0}}new Set(["border","border_top","border_right","border_bottom","border_left","border_width","border_style","border_color","box_shadow"]),new Set(["none","hidden","solid","dashed","dotted","double","groove","ridge","inset","outset"]);const nu={snowy:"snow","snowy-rainy":"snow",rainy:"rain",pouring:"rain",hail:"rain",lightning:"storm","lightning-rainy":"storm",sunny:"sun","clear-night":"night",cloudy:"clouds",partlycloudy:"clouds",fog:"fog",windy:"wind","windy-variant":"wind"},su=new Map,ru=new Set;const au=new Map,ou={slow:1.6,normal:1,fast:.6},lu=["normal","reverse","alternate","alternate-reverse"],cu=e=>e.endsWith("ms")?parseFloat(e)/1e3:parseFloat(e);function du(e){const t=Gh(e);if(!t)return;const i=ne.find(e=>e.id===t);return i?i.css:/^cubic-bezier\(\s*-?[\d.]+\s*(,\s*-?[\d.]+\s*){3}\)$/.test(t)||/^steps\(\s*\d+\s*(,\s*(start|end|jump-start|jump-end|jump-none|jump-both)\s*)?\)$/.test(t)?t:void 0}function pu(e){if("infinite"===e)return"infinite";const t="string"==typeof e?Number(e):e;return"number"==typeof t&&Number.isFinite(t)&&t>0?String(+t.toFixed(2)):void 0}function hu(e,t){const i="string"==typeof t?Number(t):t;return"number"==typeof i&&Number.isFinite(i)?Math.min(e.intensity.max,Math.max(e.intensity.min,i)):e.defaults.intensity}function uu(e){const t="string"==typeof e&&""!==e.trim()?Number(e):e;return"number"==typeof t&&Number.isFinite(t)?Math.min(100,Math.max(0,t)):void 0}const mu=(e,t)=>t&&"icon"===e.target,gu=(e,t)=>!e.target&&!!t?.channels.includes("rotate"),fu=(e,t)=>t&&"label"===e.target;function vu(e,t,i,n){if("weather"===e.seasonal){const e=Gh(t.trigger_entity),r=e?.startsWith("weather.")?n?.[e]:i;return r?.entity_id?.startsWith("weather.")&&(s=r.state)?nu[s]:void 0}var s;if("daynight"===e.seasonal){const e=n?.["sun.sun"],t=e?.attributes?.elevation;return function(e,t){if("below_horizon"===e||"above_horizon"===e)return"number"==typeof t&&Number.isFinite(t)&&Math.abs(t)<=6?"dusk":"below_horizon"===e?"night":void 0}(e?.state,"number"==typeof t?t:"string"==typeof t&&""!==t.trim()?Number(t):void 0)}return e.seasonal}const bu=.618034;function yu(e){return Array.from({length:e},(t,i)=>{const n=60/e*(i*bu%1-.5);return{x:+Math.min(96,Math.max(4,(i+.5)/e*100+n)).toFixed(1),phase:+(i*bu%1).toFixed(3),k:e>1?+(i/e).toFixed(3):0}})}function xu(e,t,i={}){e=function(e){if(!e)return e;const t=e;let i;for(const e of Uh){const n=tu(t[e]);n&&((i??={...t})[e]=n)}return Array.isArray(t.animations)&&t.animations.some(e=>Bh(e?.color))&&((i??={...t}).animations=t.animations.map(e=>Bh(e?.color)?{...e,color:Ih(e.color)}:e)),i??e}(e);const n=!1!==i.allowIcon,s={m:[],i:[],mi:[],t:[],n:[]},r=[],a={},o=[],l=[],c=[],d={need:!1,p:!1};for(let p of function(e){if(!e)return[];if(Array.isArray(e.animations))return e.animations.filter(e=>!!e&&"object"==typeof e&&!!Gh(e.preset)).map((e,t)=>Gh(e.id)?e:{...e,id:`anim-${t}`});const t=Gh(e.animation_preset);if(!t)return[];const i=ge(t),n={id:"legacy",preset:t};if(e.animation_target&&(n.target=e.animation_target),e.animation_trigger&&(n.trigger=e.animation_trigger),e.animation_state&&(n.state=e.animation_state),e.animation_color&&(n.color=e.animation_color),!i)return[n];const s=function(e){if(e.seasonal)return{intensity:e.defaults.intensity};const{duration:t,delay:i,easing:n,iterations:s,direction:r,intensity:a}=e.defaults;return{duration:t,delay:i,easing:n,iterations:s,direction:r,intensity:a,...ie(e)?{strength:100}:{}}}(i),r=ou[e.animation_speed||"normal"]??1;return[{...n,...s,duration:+(cu(s.duration)*r).toFixed(3)+"s"}]}(e)){const e=!!i.spinIcon&&!rt(p.preset);if(rt(p.preset)){const e=i.custom?.(at(p.preset));if(!e||!iu(p,t,i.states))continue;const h=_u(e,p,{lists:s,vars:r,origins:a,fx:o,seq:l,v2:c,allowIcon:n,runtime:d,custom:i.custom,stateObj:t,states:i.states});if(!h)continue;p=h}const h=ge(p.preset);if(!h||!iu(p,t,i.states))continue;const u=h.defaults,m=Yh(p.duration)??u.duration,g=Yh(p.delay)??u.delay,f="tap"===p.trigger;let v=pu(p.iterations)??pu(u.iterations);f&&"infinite"===v&&(v="1");const b=`${du(p.easing)??du(u.easing)} ${g} ${v} ${lu.includes(p.direction)?p.direction:u.direction}`,y=`${m} ${b}`,x=[`--mca-${h.id}-i: ${hu(h,p.intensity)}`],_=Xh(p.color);_&&x.push(`--mca-${h.id}-c: ${_}`);const w=ie(h)?uu(p.strength):void 0;if(void 0!==w&&100!==w&&x.push(`--mca-${h.id}-s: ${+(w/100).toFixed(3)}`),h.seasonal){const e=vu(h,p,t,i.states);if(!e)continue;o.push({preset:h.id,front:!1,style:void 0!==w&&100!==w?"opacity: "+ +(w/100).toFixed(3):"",particles:[],seasonal:{scenes:[e],intensity:hu(h,p.intensity)/100,decorations:!1!==p.decorations}});continue}if(h.ring){o.push({preset:h.id,front:!0,style:x.join("; "),particles:[],...f?{tap:f}:{},ring:wu(h,p,m,b,w)});continue}if(void 0!==h.particles){const e="count"===h.particles?Math.min(12,Math.round(hu(h,p.intensity))):h.particles;o.push({preset:h.id,front:!!h.front,style:[`--mc-fx-anim: mc-anim-${h.id} ${y}`,`--mc-fx-dur: ${m}`,`--mc-fx-delay: ${g}`,...x].join("; "),particles:yu(Math.max(1,e)),...f?{tap:f}:{}});continue}if(r.push(...x),f){s.t.push(`mc-anim-${h.id} ${y}`),h.origin&&!a.m&&(a.m=h.origin);continue}if(fu(p,n)){s.n.push(`mc-anim-${h.id} ${y}`),h.origin&&!a.n&&(a.n=h.origin);continue}const k=mu(p,n)||e&&gu(p,h);s.mi.push(`mc-anim-${h.id} ${y}`),k?(s.i.push(`mc-anim-${h.id}${h.iconKeyframes?"-icon":""} ${y}`),h.origin&&!a.i&&(a.i=h.origin)):(s.m.push(`mc-anim-${h.id} ${y}`),h.origin&&!a.m&&(a.m=h.origin))}if(!(s.mi.length||s.n.length||s.t.length||o.length||l.length||d.need))return;const p=[];s.m.length&&p.push(`--mc-anim-m: ${s.m.join(", ")}`),s.t.length&&p.push(`--mc-anim-t: ${s.t.join(", ")}`),s.i.length&&p.push(`--mc-anim-i: ${s.i.join(", ")}`,`--mc-anim-mi: ${s.mi.join(", ")}`),s.n.length&&p.push(`--mc-anim-n: ${s.n.join(", ")}`),a.m&&p.push(`--mc-anim-om: ${a.m}`),a.i&&p.push(`--mc-anim-oi: ${a.i}`),a.n&&p.push(`--mc-anim-on: ${a.n}`),p.push(...function(e){const t=new Map;for(const i of e){const e=i.slice(0,i.indexOf(":"));t.delete(e),t.set(e,i)}return[...t.values()]}(r));const h=Xh(e?.color)??Xh(function(e){if(!e)return;const t=e.entity_id.split(".")[0];if(!Rh.has(t))return;if(!Dh(e))return`var(--state-${t}-inactive-color, var(--state-inactive-color, var(--disabled-text-color)))`;const i=function(e){const t=Nh(e,"rgb_color")||Nh(e,"hs_color");return t?`rgb(${t.join(", ")})`:void 0}(e.attributes||{});return i||`var(--state-${t}-${e.state.replace(/[^a-z0-9_-]/gi,"_")}-color, var(--state-${t}-active-color, var(--state-active-color, var(--primary-color))))`}(t));h&&p.push(`--mc-anim-color: ${h}`);const u=[s.m.length?"module":"",s.i.length?"icon":"",s.n.length?"label":""].filter(Boolean).join(" ");return{...u?{targets:u}:{},style:p.join("; "),fx:o,...s.t.length?{tap:!0}:{},...l.length?{seq:l.join(" ")}:{},...d.need?{needsRuntime:!0}:{},...d.p?{needsParticles:!0}:{},...c.length?{v2:c,run:[...new Set(c.map(e=>e.run))].join(" ")}:{}}}function _u(e,t,i){const n=Qn(e,{lookup:i.custom}),s=pu(e.iterations)??"infinite",r="tap"===t.trigger,a=Yh(t.duration)??`${e.duration}s`,o=Yh(t.delay)??"0s";let l=pu(t.iterations)??s;r&&"infinite"===l&&(l="1");const c=lu.includes(t.direction)?t.direction:e.direction??"normal",d=`${du(t.easing)??du(e.easing)??"ease"} ${o} ${l} ${c}`,p=fu(t,i.allowIcon),h=i.allowIcon&&("icon"===t.target||!t.target&&"icon"===n.motion?.target);let u;if(it(e)&&(i.runtime.need=!0,n.v2)){const s="string"==typeof t.entity&&t.entity?t.entity:void 0,r=s?i.states?.[s]:i.stateObj,o=s??i.stateObj?.entity_id,l=n.name||Cn(e),c={};u=c.clip?.animation,i.v2.push({run:l,docId:e.id,v2:u?{...n.v2,tracks:[]}:n.v2,timing:`${a} ${d}`,icon:h,...o?{entityId:o}:{},...r?{stateObj:r}:{},hints:c})}if(u){if("none"===u)return;const n={...t,preset:u,target:h?"icon":t.target};for(const e of["duration","delay","easing","iterations","direction"])delete n[e];if(!rt(u))return n;const s=i.custom?.(at(u));return s&&s!==e?_u(s,n,i):void 0}if(n.preset)return{...t,preset:n.preset.id,intensity:t.intensity??n.preset.intensity,duration:t.duration??`${e.duration}s`,easing:t.easing??e.easing,iterations:t.iterations??("infinite"===s?"infinite":Number(s)),direction:t.direction??e.direction};if(n.schedule){const e=n.schedule,s=Yh(t.duration),r=s&&e.total>0?cu(s)/e.total:1,a="number"==typeof t.iterations&&t.iterations>0?Math.round(t.iterations):void 0;return void(e.steps.length&&i.seq.push(function(e){const t=`s${zn(JSON.stringify(e))}`;return au.set(t,e),au.size>64&&au.delete(au.keys().next().value),t}({...e,delay:cu(o),scale:r,...a?{cycles:a}:{},...p?{target:"label"}:{}})))}const m=[],g="number"==typeof t.intensity&&Number.isFinite(t.intensity)?t.intensity:void 0;void 0!==g&&100!==g&&m.push(`${An(e.id,"i")}: ${+(g/100).toFixed(3)}`);const f=Xh(t.color);f&&m.push(`${An(e.id,"c")}: ${f}`);const v=uu(t.strength);if(void 0!==v&&100!==v&&m.push(`${An(e.id,"s")}: ${+(v/100).toFixed(3)}`),b=e.id,y=n.name,x=n.css,y&&x&&su.get(b)?.name!==y&&(su.set(b,{name:y,css:x}),function(){const e=[...su.values()].map(e=>e.css).join("\n");for(const t of ru)t.isConnected?t.textContent=e:ru.delete(t)}()),n.layer){(n.sim||n.needsParticles)&&(i.runtime.p=!0);const e=+(cu(a)/n.layer.speed).toFixed(3)+"s";for(const[t,s,a]of[[n.name,n.layer,n.sim],...n.split?[[n.split.name,n.split.layer,n.split.sim]]:[]])i.fx.push({preset:t,front:s.front,style:[`--mc-fx-anim: ${t} ${e} ${d}`,`--mc-fx-dur: ${e}`,`--mc-fx-delay: ${o}`,...m].join("; "),particles:s.particles,...s.symbol?{symbol:s.symbol}:{},sim:a,...r?{tap:r}:{}});return}var b,y,x;if(!n.motion)return;const _=[n.name,...n.lanes??[]].map(e=>`${e} ${a} ${d}`).join(", "),w="center"!==n.motion.origin?n.motion.origin:void 0;return i.vars.push(...m),r?(i.lists.t.push(_),void(w&&!i.origins.m&&(i.origins.m=w))):p?(i.lists.n.push(_),void(w&&!i.origins.n&&(i.origins.n=w))):(i.lists.mi.push(_),void(h?(i.lists.i.push(_),w&&!i.origins.i&&(i.origins.i=w)):(i.lists.m.push(_),w&&!i.origins.m&&(i.origins.m=w))))}function wu(e,t,i,n,s){return{mode:"animated",fill:1,animation:e.ring,color:Xh(t.color)??"var(--mc-anim-c)",width:hu(e,t.intensity),linecap:"dashes"===e.ring?"butt":"round",glow:0,position:"inside",start:"top",direction:"cw",length:25,speed:i,transition:"1s",timing:n,...void 0!==s&&100!==s?{opacity:+(s/100).toFixed(3)}:{}}}const ku=["❤️","💖","⭐","✨","❄️","💧","🔥","🍂","🌸","🎉","🎈","🫧","☁️","⚡","🌙","🦋"],$u={icon:{icon:"mdi:star"},emoji:{emoji:"✨"},svg:{svg:'<svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7L2 9.2l7.1-.6z"/></svg>'}},Mu=/^[a-z0-9_-]+:[a-z0-9_-]+$/i;function Su(e){const t=e.trim();return t?[...t].length>8?as(1063):/[<>&"'\\{};]/.test(t)?"These characters are not allowed: < > & \" ' \\ { } ;":void 0:as(301)}function zu(e){if(!e.trim())return as(644);if(!/<svg[\s>]/i.test(e))return as(547);const t=et(e);return t.error?ys(t.error):t.paths.length||t.strokes.length||t.accentPaths.length?void 0:as(926)}const Cu=Ih("entity"),Au=/^color-mix\(in srgb, var\(--mc-entity-color, currentColor\) (\d+(?:\.\d+)?)%, transparent\)$/;function ju(e){const t=e.trim();if(t)return Th(t)?Ih(t):vt(t,"color")}function qu(e){if(e===Cu)return"entity";const t=Au.exec(e);return t?`entity ${t[1]}%`:e}const Eu=(e,t,i)=>Math.min(i,Math.max(t,e)),Hu=(e,t)=>+(Math.round(e/t)*t).toFixed(4),Lu={count:{min:1,max:ct,step:1},speed:{min:.1,max:10,step:.1},size:{min:1,max:200,step:1},spin:{min:-3600,max:3600,step:15},spread:{min:0,max:100,step:5},gravity:{min:-1,max:1,step:.1}};function Vu(e,t){const i="number"==typeof t?t:"string"==typeof t&&""!==t.trim()?parseFloat(t):NaN;if(!Number.isFinite(i))return;const n=Lu[e],s=Eu(i,n.min,n.max);return"count"===e?Math.round(s):"gravity"===e||"speed"===e?Hu(s,.01):+s.toFixed(2)}function Ou(e,t){const i={...e.particles??ut,...t};for(const e of Object.keys(i))void 0===i[e]&&delete i[e];return{...e,particles:i}}const Pu=e=>e.particles?.preset?ge(e.particles.preset):void 0;function Ru(e){return e.ring?as(750):e.seasonal?as(781):"count"===e.particles?as(631):as(775)}const Du={"snow-fall":{direction:"fall",size:[4,8],colors:["#ffffff"],spin:0},"rain-fall":{direction:"fall",size:[2,4],speed:2,colors:["#90caf9"],gravity:.6,fade:!1},bubbles:{direction:"rise",size:[6,14],colors:[]},"steam-rise":{direction:"rise",size:[10,18],spread:60},confetti:{direction:"fall",size:[5,9],spin:360,colors:["#ef4444","#eab308","#22c55e","#3b82f6","#ec4899"]},"falling-leaves":{direction:"fall",shape:{icon:"mdi:leaf"},size:[10,16],spin:180,colors:["#f97316","#eab308","#a16207"]},fireflies:{direction:"drift",size:[3,6],colors:["#fde047"]},twinkle:{direction:"drift",shape:{emoji:"✨"},size:[8,14],layer:"front",speed:.5},"orbit-dots":{direction:"orbit",size:[6,8],spread:70,fade:!1},starfield:{direction:"fall",size:[2,4],colors:["#ffffff"],speed:1.5},"meteor-shower":{direction:"fall",size:[3,5],gravity:.6,colors:["#ffffff"]},bokeh:{direction:"drift",size:[16,32],speed:.4},smoke:{direction:"rise",size:[16,28],spread:70,speed:.6},"clouds-drift":{direction:"drift",shape:{icon:"mdi:cloud"},size:[24,40],colors:["#ffffff"],speed:.3},fireworks:{direction:"burst",size:[4,6],spread:80,colors:["#ef4444","#eab308","#3b82f6"]},"ripple-rings":{direction:"burst",size:[8,12],spread:90},"water-ripple":{direction:"burst",size:[8,12],spread:90},"wind-lines":{direction:"drift",size:[3,5],speed:1.5},drip:{direction:"fall",size:[4,7],gravity:.8,colors:["#4fc3f7"]}},Nu=["fall","rise","drift","burst","orbit","spiral","fountain","explode","wave","vortex","zigzag","rain","wander"],Fu={fall:319,rise:751,drift:270,burst:110,orbit:614,spiral:860,fountain:343,explode:310,wave:1076,vortex:916,zigzag:1087,rain:702,wander:328},Tu=new Set(lt),Bu=new Set(["burst","orbit","spiral","explode","vortex"]),Iu=[{id:"circle",label:145},{id:"square",label:871},{id:"triangle",label:1021},{id:"star",label:876},{id:"heart",label:360},{id:"ring",label:749},{id:"line",label:910},{id:"spark",label:852},{id:"icon",label:370,icon:"mdi:star-outline"},{id:"emoji",label:295,icon:"mdi:emoticon-outline"},{id:"svg",label:760,icon:"mdi:svg"}],Zu=new Set(Eo),Wu=e=>Zu.has(e),Ku=e=>{return"builtin"in e?e.builtin:(t=e)?"icon"in t?"icon":"emoji"in t?"emoji":"svg":"dot";var t},Uu=e=>{const t=Iu.find(t=>t.id===Ku(e));return as(t?t.label:813)},Gu=Math.min(4,Ho.shapes),Yu=200,Ju={pspeed:{min:0,max:500,step:5},spin:{min:-3600,max:3600,step:15},delay:{min:0,max:60,step:.1},lifetime:{min:.1,max:60,step:.1},opacity:{min:0,max:100,step:5},seed:{min:0,max:4294967295,step:1},weight:{min:1,max:10,step:1},childCount:{min:1,max:Ho.childrenPerParent,step:1},childSize:{min:1,max:200,step:1},childLife:{min:.1,max:10,step:.1},angle:{min:0,max:359,step:1},wind:{min:-60,max:60,step:5},unit:{min:0,max:1,step:.05}},Xu=new Set(["seed","weight","childCount","childSize","angle","opacity","spin","wind"]);function Qu(e,t){let i="number"==typeof t?t:"string"==typeof t&&""!==t.trim()?parseFloat(t):NaN;if(!Number.isFinite(i))return;"angle"===e&&(i=(Math.round(i)%360+360)%360);const n=Ju[e],s=Eu(i,n.min,n.max);return Xu.has(e)?Math.round(s):Hu(s,.01)}const em=e=>e[0]>e[1]?[e[1],e[0]]:[e[0],e[1]],tm=e=>e.duration/(e.particles?.speed||1);function im(e,t=Math.random){for(let i=0;i<8;i++){const i=Math.floor(4294967296*t())>>>0;if(i!==e)return i}return(e??0)+1>>>0}const nm=e=>+e.toFixed(2);function sm(e,t){const i=e.particles??ut,n=tm(e),s=nm((Bu.has(i.direction)?Math.max(10,i.spread):100)/n),r=nm(i.spin/n);return{engine:1,mode:"baked",seed:t>>>0,flow:i.direction,shapes:i.shape?[{shape:i.shape,weight:1}]:[],ranges:{speed:[s,s],spin:[r,r],delay:[0,nm(n)],lifetime:[nm(n),nm(n)],opacity:[1,1]},physics:{gravity:{angle:i.gravity<0?180:0,strength:nm(Math.abs(i.gravity)*Yu)},drag:0,turbulence:{strength:0,scale:25},bounce:.5},colliders:{floor:!1,ceiling:!1,left:!1,right:!1,content:"none"}}}const rm=(e,t)=>e.particles?.sim??sm(e,t),am=e=>!!e.particles?.sim;function om(e){const t=e.strength/Yu*Math.cos(e.angle*Math.PI/180);return Eu(Math.round(100*t)/100,-1,1)||0}function lm(e,t){const i=t.shapes.find(e=>!("builtin"in e.shape))?.shape,n=Eu(Math.round(t.ranges.spin[1]*tm(e)),Lu.spin.min,Lu.spin.max),s=Ou(e,{sim:t,direction:qo[t.flow],gravity:om(t.physics.gravity),spin:n});return i?s.particles.shape=i:delete s.particles.shape,s}const cm=(e,t,i)=>lm(e,i(rm(e,t))),dm=e=>e.shapes.length?e.shapes:[{shape:{builtin:"circle"},weight:1}];function pm(e,t){if(!am(e)){const t=e.particles?.spin??0;return[t,t]}const i=tm(e);return[Math.round(t.ranges.spin[0]*i),Math.round(t.ranges.spin[1]*i)]}function hm(e,t,i,n){const s=nm(Eu(n,0,1));return!am(e)&&(0===i||180===i&&s>0)?Ou(e,{gravity:180===i?-s:s}):cm(e,t,e=>({...e,physics:{...e.physics,gravity:{angle:i,strength:nm(s*Yu)}}}))}const um=(e,t,i)=>cm(e,t,e=>({...e,seed:im(e.seed,i)}));function mm(e,t){const i=e.reduce((e,t)=>e+t.weight,0);return i>0?5*Math.round((e[t]?.weight??0)/i*20):0}function gm(e){const t=new Set(e.map(e=>Ku(e.shape)));return{builtin:["star","heart","circle","spark","square","triangle","ring","line"].find(e=>!t.has(e))??"circle"}}const fm=e=>e.floor||e.ceiling||e.left||e.right||"none"!==e.content;function vm(e){return{trigger:fm(e.colliders)?"collision":"death",count:6,shapes:[{shape:{builtin:"spark"},weight:1}],size:[2,4],colors:[],ranges:{speed:[30,60],lifetime:[.6,.6],opacity:[1,1],spin:[0,0]},cone:360,inherit:.2}}const bm=[{angle:0,name:1105,icon:"mdi:arrow-down"},{angle:45,name:1106,icon:"mdi:arrow-bottom-left"},{angle:90,name:1121,icon:"mdi:arrow-left"},{angle:135,name:1153,icon:"mdi:arrow-top-left"},{angle:180,name:1152,icon:"mdi:arrow-up"},{angle:225,name:1154,icon:"mdi:arrow-top-right"},{angle:270,name:1135,icon:"mdi:arrow-right"},{angle:315,name:1107,icon:"mdi:arrow-bottom-right"}],ym=e=>{const t=bm.find(t=>t.angle===e);return t?as(t.name):as(1099,{angle:e})},xm=e=>String(+e.toFixed(2)),_m=(e,t="")=>e[0]===e[1]?`${xm(e[0])}${t}`:as(1193,{from:xm(e[0]),to:xm(e[1]),unit:t}),wm=[{id:"floor",label:336},{id:"ceiling",label:125},{id:"left",label:412},{id:"right",label:748},{id:"content",label:180}],km=(e,t)=>"content"===t?"none"!==e.content:e[t];let $m;const Mm=()=>$m;function Sm(e,t=0){const i="particles"===e.kind?e.particles:void 0;if(i&&!i.preset)return{...i,sim:i.sim??sm(e,t)}}const zm=e=>1+(e.particles?.sim?.emitters?.length??0);function Cm(e){return(e.particles?.count??ut.count)+(e.particles?.sim?.emitters??[]).reduce((e,t)=>e+t.count,0)}const Am=e=>Math.max(0,Ho.parents-Cm(e)),jm=e=>zm(e)<Ho.emitters&&Am(e)>=1,qm=(e,t)=>e.layer??t;function Em(e,t){const i=e.particles??ut,n=rm(e,t);return[{id:n.id??"",...void 0!==n.name?{name:n.name}:{},layer:i.layer,seed:n.seed,count:i.count,size:[i.size[0],i.size[1]],colors:[...i.colors],fade:i.fade,spread:i.spread,flow:n.flow,shapes:n.shapes,ranges:n.ranges,physics:n.physics,...n.children?{children:n.children}:{}},...(n.emitters??[]).map(e=>({...e,layer:qm(e,i.layer)}))]}function Hm(e,t,i){const n=rm(e,t),[s,...r]=i,a={...n,seed:s.seed,flow:s.flow,shapes:s.shapes,ranges:s.ranges,physics:s.physics};if(s.children?a.children=s.children:delete a.children,delete a.id,delete a.name,delete a.emitters,i.length>1){const e=new Set,t=i.map(t=>t.id&&!e.has(t.id)?(e.add(t.id),t.id):"").map(t=>{if(t)return t;let i=1;for(;e.has(`e${i}`);)i++;return e.add(`e${i}`),`e${i}`});a.id=t[0],s.name&&(a.name=s.name),a.emitters=r.map((e,i)=>{const{layer:n,name:r,...a}=e;return{...a,id:t[i+1],...r?{name:r}:{},...n!==s.layer?{layer:n}:{}}})}return lm(Ou(e,{count:s.count,size:s.size,colors:s.colors,fade:s.fade,spread:s.spread,layer:s.layer}),a)}const Lm=(e,t)=>Number.isInteger(t)&&t>=0&&t<zm(e);function Vm(e,t,i,n){if(!Lm(e,i)||zm(e)<2)return e;const s=(e=>e.trim().slice(0,40).trim())(n),r=e.particles.sim;if((0===i?r.name:r.emitters[i-1].name)===(s||void 0))return e;const a=Em(e,t);return s?a[i].name=s:delete a[i].name,Hm(e,t,a)}function Om(e,t){const i=e.particles??ut;return t<=0?i.layer:qm(i.sim?.emitters?.[t-1]??{},i.layer)}function Pm(e,t,i){if(i<=0||i>=zm(e))return e;const n=Em(e,t)[i],s={...rm(e,t),seed:n.seed,flow:n.flow,shapes:n.shapes,ranges:n.ranges,physics:n.physics};return delete s.id,delete s.name,delete s.emitters,delete s.children,n.children&&(s.children=n.children),lm(Ou(e,{count:n.count,size:n.size,colors:n.colors,fade:n.fade,spread:n.spread,layer:n.layer}),s)}function Rm(e,t,i,n){const s=Pm(e,t,i);if(s===e)return n(e);const r=n(s);if(r===s)return e;const a=r.particles,o=a.sim,l=e.particles.sim,c=l.emitters.map((t,n)=>{if(n!==i-1)return t;const s={...t};return delete s.children,{...s,seed:o.seed,flow:o.flow,shapes:o.shapes,ranges:o.ranges,physics:o.physics,count:Math.max(1,Math.min(a.count,t.count+Am(e))),size:a.size,colors:a.colors,fade:a.fade,spread:a.spread,...o.children?{children:o.children}:{}}});return Ou(e,{speed:a.speed,sim:{...l,mode:o.mode,colliders:o.colliders,emitters:c}})}function Dm(e,t,i){const n=Em(e,t),s=n[i];if(s?.name)return s.name;if(n.length<2)return as(633);const r=/^e(\d+)$/.exec(s?.id??""),a=r?Number(r[1]):i+1;return a>1?as(639,{n:a}):as(633)}class Nm extends I.WL{constructor(e){if(super(e),this.it=B.s6,e.type!==I.OA.CHILD)throw Error(this.constructor.directiveName+"() can only be used in child bindings")}render(e){if(e===B.s6||null==e)return this._t=void 0,this.it=e;if(e===B.c0)return e;if("string"!=typeof e)throw Error(this.constructor.directiveName+"() called with a non-string value");if(e===this.it)return this._t;this.it=e;const t=[e];return t.raw=t,this._t={_$litType$:this.constructor.resultType,strings:t,values:[]}}}Nm.directiveName="unsafeHTML",Nm.resultType=1,(0,I.u$)(Nm);class Fm extends Nm{}Fm.directiveName="unsafeSVG",Fm.resultType=2;const Tm=(0,I.u$)(Fm),Bm=Object.freeze({kind:"svg",extensions:Object.freeze([".svg"]),mimeTypes:Object.freeze(["image/svg+xml"])}),Im=Object.freeze({types:Object.freeze([Object.freeze({...Bm,maxBytes:32768})])});Object.freeze({types:Object.freeze([Object.freeze({...Bm,maxBytes:8388608})])});const Zm=1048576,Wm=["path","circle","ellipse","rect","line","polyline","polygon"],Km=/^(none|transparent)$/i,Um=/^(currentcolor|inherit|black|#0{3}|#0{6})$/i,Gm=e=>Object.is(e,-0)?"-0":String(e),Ym=e=>e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),Jm=/^(#[0-9a-f]{3,8}|[a-z]+|(rgb|rgba|hsl|hsla|hwb|lab|lch|oklab|oklch)\([\d\s.,%/+-]*\))$/i,Xm=/^(butt|round|square)$/,Qm=/^(miter|round|bevel|arcs|miter-clip)$/;function eg(e){if(!e)return;const t=e.trim();return/^entity\b/i.test(t)||/var\(/i.test(t)||/^currentcolor$/i.test(t)?"currentColor":Jm.test(t)?t:"currentColor"}function tg(e){const t=Ba(e)?eg(e.fill)??"currentColor":"none";let i=` id="${Ym(e.id)}" class="shape" d="${Ym(e.d)}" fill="${Ym(t)}"`;return Ia(e)&&(i+=` stroke="${Ym(eg(e.stroke)??"currentColor")}" stroke-width="${e.stroke_width??1}"`,e.linecap&&(i+=` stroke-linecap="${e.linecap}"`),i+=' stroke-linejoin="round"'),`<path${i}/>`}function ig(e,t){const i=et(/^\s*<svg[\s>]/i.test(e)?e:`<svg viewBox="${t}">${e}</svg>`);return i.error?"":i.markup.replace(/^<svg[^>]*>/,"").replace(/<\/svg>$/,"")}function ng(e){const t=e.accent?"mc-accent":"";if(!e.stroke)return e.evenodd?{cls:t,attrs:' fill="currentColor" fill-rule="evenodd"',key:`e${t}`}:{cls:t,attrs:' fill="currentColor"',key:`f${t}`};let i=` fill="none" stroke="currentColor" stroke-width="${+e.stroke.width.toFixed(3)}"`;return e.stroke.cap&&Xm.test(e.stroke.cap)&&(i+=` stroke-linecap="${e.stroke.cap}"`),e.stroke.join&&Qm.test(e.stroke.join)&&(i+=` stroke-linejoin="${e.stroke.join}"`),{cls:t,attrs:i,key:`s${t}${i}`}}function sg(e,t,i){const n=new Map;for(const t of e){const e=ng(t),i=n.get(e.key)??{paint:e,d:[]};i.d.push(t.d),n.set(e.key,i)}const s=t?` id="${Ym(t)}"`:"",r=[...n.values()],a=(e,t)=>{const n=[t?i:"",e.paint.cls].filter(Boolean).join(" ");return`<path${t?s:""}${n?` class="${n}"`:""} d="${Ym(e.d.join(" "))}"${e.paint.attrs}/>`};return 1===r.length?a(r[0],!0):`<g${s} class="${i}">${r.map(e=>a(e,!1)).join("")}</g>`}const rg={not_svg:"No <svg> element found.",empty:"The SVG has no shapes to draw.",too_detailed:"A shape in the SVG is too detailed (over 8192 characters of path data).",too_many:"The SVG has too many shapes; at most {room} fit."};function ag(e){const t=Da(e);return!t||function(e){let t=0;for(const i of Ra(e)){let e=0;for(let t=0,n=i.length-1;t<i.length;n=t++)e+=(i[n][0]+i[t][0])*(i[n][1]-i[t][1]);t+=Math.abs(e)/2}return t}(e)<.001*Math.max(t.w,t.h)}function og(e){if(void 0===e)return;const t=e.trim();return/^(none|transparent)$/i.test(t)?"none":vt(t,"color")&&!/url\(/i.test(t)?t:"currentColor"}function lg(e){return e?.svg?Na(et(e.svg).viewBox).join(" "):"0 0 24 24"}var cg=i(2637);function dg(e){const t=/^(part|group|shape):([a-z0-9][a-z0-9_-]{0,31})$/.exec(e);if(t)return`[data-${"part"===t[1]?"p":"group"===t[1]?"g":"s"}="${t[2]}"]`}const pg=e=>e.css.includes("stroke-dashoffset");function hg(e){const t=new Map;for(const i of e.css.matchAll(/(-?[\d.]+)% \{([^}]*)\}/g)){const e=/stroke-dashoffset: (-?[\d.]+)/.exec(i[2]);e&&t.set(Number(i[1]),Number(e[1])<=.001?1:0)}const i=[...t].sort((e,t)=>e[0]-t[0]),n=[];return i.forEach(([e,t],s)=>{const r=i[s-1];r&&r[1]!==t&&n.push([+(r[0]+(e-r[0])*(t?.75:.25)).toFixed(2),0]),n.push([e,t])}),n}function ug(e){const t=hg(e);if(!t.length)return"";const i=t.map(([e,t])=>`  ${e}% { fill-opacity: ${t}; }`);return`@keyframes ${e.name}-fill {\n${i.join("\n")}\n}`}function mg(e){const t=hg(e);if(!t.length)return"";const i=t.map(([e,t])=>`  ${e}% { stroke-opacity: ${1-t}; }`);return`@keyframes ${e.name}-outline {\n${i.join("\n")}\n}`}const gg=[".rig { color: var(--mc-rig-paint, var(--icon-primary-color, currentColor)); }",".rig .primary { fill: var(--mc-rig-fill, currentColor); }",".rig .outlines { stroke-opacity: 0; }",".rig [data-p], .rig [data-g], .rig [data-s] { transform-box: view-box; }",".rig .drawn { stroke-dasharray: 1; stroke-linecap: round; stroke-linejoin: round; }",".rig .outlines .drawn { stroke-linecap: butt; stroke-dasharray: 0.999 2; }","@media (prefers-reduced-motion: reduce) { .rig, .rig * { animation: none !important; } }"].join("\n");function fg(e,t,i={}){const n=[gg];if(i.still)return n.join("\n");const s=i.timing||"1s ease 0s infinite normal",r=new Set([...t.parts.map(e=>`part:${e.id}`),...(t.groups??[]).map(e=>`group:${e.id}`),...(t.shapes??[]).map(e=>`shape:${e.id}`)]);for(const t of e){const e=dg(t.target);if(!e||!r.has(t.target)||!t.css)continue;const i=[t.name,...t.lanes??[]];n.push(t.css);const a=e=>`${e} ${s}`;if(pg(t)){const s=ug(t);s&&(n.push(s,mg(t)),i.push(`${t.name}-fill`),n.push(`.rig ${e} .outlines { animation: ${a(`${t.name}-outline`)}; }`)),n.push(`.rig ${e} { stroke: currentColor; }`,`.rig ${e} .primary, .rig ${e} .secondary { stroke: none; }`)}t.origin&&n.push(`.rig ${e} { transform-origin: ${t.origin} !important; }`),n.push(`.rig ${e} { animation: ${i.map(a).join(", ")}; }`)}return n.join("\n")}const vg=e=>String(+e.toFixed(3)),bg=e=>[e[0]+e[2]/2,e[1]+e[3]/2],yg=e=>`transform-origin: ${vg(e[0])}px ${vg(e[1])}px`,xg=e=>(0,$e.Mj)(e).map(e=>(0,$e.ER)([e])),_g=new Map;function wg(e,t){const i=`${t}|${e}`;let n=_g.get(i);if(void 0===n){const s=et(`<svg viewBox="${t}">${e}</svg>`);n=s.error?null:{markup:s.markup.replace(/^<svg[^>]*>/,"").replace(/<\/svg>$/,""),box:(0,cg.Zg)([...s.paths,...s.accentPaths,...s.strokes.map(e=>e.d)].map(cg.hd)),outlines:[...s.paths,...s.accentPaths,...s.strokes.map(e=>e.d)].flatMap(xg)},_g.size>100&&_g.clear(),_g.set(i,n)}return n??void 0}function kg(e,t,i="0 0 24 24"){return e.svg?wg(e.svg,i)?.box:(0,cg.Zg)((e.from??[]).map(e=>t[e]?.bbox).filter(e=>!!e))}function $g(e,t,i="0 0 24 24"){const n=new Map,s=new Map;for(const r of e.parts){const e=kg(r,t,i);e&&s.set(r.id,e);const a=r.origin??(e?bg(e):void 0);a&&n.set(`part:${r.id}`,a)}for(const t of e.groups??[]){const e=(0,cg.Zg)(t.parts.map(e=>s.get(e)).filter(e=>!!e)),i=t.origin??(e?bg(e):void 0);i&&n.set(`group:${t.id}`,i)}for(const t of e.shapes??[])n.set(`shape:${t.id}`,t.origin??bg((0,cg.hd)(t.d)));return n}const Mg=e=>{if(!e)return;const t=/^entity(?:\s+(\d+(?:\.\d+)?)%)?$/.exec(e.trim());if(t){const e=void 0===t[1]?100:Math.min(100,Number(t[1]));return e>=100?"var(--mc-entity-color, currentColor)":`color-mix(in srgb, var(--mc-entity-color, currentColor) ${e}%, transparent)`}return vt(e,"color")},Sg=e=>Object.entries(e).filter(([,e])=>void 0!==e&&!1!==e&&""!==e).map(([e,t])=>` ${e}="${(e=>String(e).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;"))(t)}"`).join("");new WeakMap,new Map,new Map,new WeakMap;const zg=/^(#[0-9a-f]{3,8}|[a-z]+|(rgb|rgba|hsl|hsla|hwb|lab|lch|oklab|oklch)\([\d\s.,%/+-]*\))$/i;function Cg(e){if(!e)return;const t=e.trim();return/^entity\b/i.test(t)||/var\(/i.test(t)||/^currentcolor$/i.test(t)?"currentColor":zg.test(t)?t:"currentColor"}const Ag=e=>e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),jg=e=>String(+e.toFixed(4)),qg=e=>"undefined"!=typeof TextEncoder?(new TextEncoder).encode(e).length:e.length;function Eg(e,t){const i=(e??"center").trim().split(/\s+/),n=(e,i)=>{const n=t[2+i],s=t[i];if(!e||"center"===e)return s+n/2;if("left"===e||"top"===e)return s;if("right"===e||"bottom"===e)return s+n;const r=parseFloat(e);return Number.isFinite(r)?e.endsWith("%")?s+n*r/100:s+r:s+n/2};let[s,r]=i;return"top"!==s&&"bottom"!==s&&("left"!==r&&"right"!==r||"center"!==s)||([s,r]=[r,s]),[n(s,0),n(r??"center",1)]}const Hg={linear:[0,0,1,1],ease:[.25,.1,.25,1],"ease-in":[.42,0,1,1],"ease-out":[0,0,.58,1],"ease-in-out":[.42,0,.58,1]};function Lg(e){const t=(ne.find(t=>t.id===e)?.css??e??"ease").trim();if(/^steps\(/.test(t))return"steps";if(Hg[t])return Hg[t];const i=/^cubic-bezier\(([^)]*)\)$/.exec(t);if(i){const e=i[1].split(",").map(e=>Math.min(1,Math.max(0,Number(e))));if(4===e.length&&e.every(Number.isFinite))return e}return Hg.ease}const Vg={translate:"x",rotate:"rotate",scale:"scale",skewX:"skew",skewY:"skew",opacity:"opacity",color:"color",stroke:"stroke",draw:"draw"};function Og(e,t){const i=e.transform;switch(t){case"translate":return!i||void 0===i.x&&void 0===i.y?void 0:[i.x??0,i.y??0];case"rotate":return void 0!==i?.rotate?[i.rotate]:void 0;case"scale":if(!i||void 0===i.scale&&void 0===i.scale_x&&void 0===i.scale_y)return;return[(i.scale??1)*(i.scale_x??1),(i.scale??1)*(i.scale_y??1)];case"skewX":return!i||void 0===i.skew_x&&void 0===i.skew_y?void 0:[i.skew_x??0];case"skewY":return!i||void 0===i.skew_x&&void 0===i.skew_y?void 0:[i.skew_y??0];case"opacity":return void 0!==e.opacity?[e.opacity]:void 0;case"color":return e.color?Cg(e.color)??"currentColor":void 0;case"stroke":return e.stroke?Cg(e.stroke)??"currentColor":void 0;case"draw":return void 0!==e.draw?[1-e.draw]:void 0}}const Pg=e=>"string"==typeof e?e:e.map(jg).join(" ");function Rg(e){const t=e.easings.map(Lg),i=` keyTimes="${e.times.map(jg).join(";")}"`;return t.some(e=>"steps"===e)?` calcMode="discrete"${i}`:` calcMode="spline"${i} keySplines="${t.map(e=>e.map(jg).join(" ")).join(";")}"`}const Dg=e=>` dur="${jg(e)}s" repeatCount="indefinite" begin="0s"`;function Ng(e,t,i,n){return`<animateTransform attributeName="transform" type="${e}" additive="sum" values="${t.values.map(e=>n(e)).join(";")}"${Rg(t)}${Dg(i)}/>`}function Fg(e,t,i){return`<animate attributeName="${e}" values="${t.values.map(Pg).join(";")}"${Rg(t)}${Dg(i)}/>`}function Tg(e,t,i,n,s){const r=[],a=t=>function(e,t,i){const n=e.filter(e=>void 0!==Og(e,t));if(!n.length)return;const s=[],r=[],a=[],o=(e,t,i)=>{const n=Math.min(1,Math.max(0,e/100));if(s.length&&n<=s[s.length-1])return r[r.length-1]=t,void(a[a.length-1]=i);s.push(n),r.push(t),a.push(i)};n[0].at>0&&o(0,Og(n[0],t),"linear");for(const e of n)o(e.at,Og(e,t),e.easings?.[Vg[t]]??e.easing??i);return s[s.length-1]<1&&o(100,r[r.length-1],"linear"),1===s.length&&(s.push(1),r.push(r[0]),a.push("linear")),a.pop(),{times:s,values:r,easings:a}}(e,t,n),o=a("translate"),l=[a("rotate"),a("scale"),a("skewX"),a("skewY")],c=l.some(Boolean),[d,p]=c?t:[0,0];if(s){const e=Nn(s.d,32);if(e.length){const t={times:e.map(e=>e.t),values:e.map(e=>[e.x,e.y]),easings:e.slice(1).map(()=>"linear")};r.push(Ng("translate",t,i,e=>`${jg(e[0])} ${jg(e[1])}`))}}o?r.push(Ng("translate",o,i,e=>`${jg(e[0]+d)} ${jg(e[1]+p)}`)):c&&r.push(Ng("translate",{times:[0,1],values:[[d,p],[d,p]],easings:["linear"]},i,e=>`${jg(e[0])} ${jg(e[1])}`));const[h,u,m,g]=l;h&&r.push(Ng("rotate",h,i,e=>jg(e[0]))),u&&r.push(Ng("scale",u,i,e=>`${jg(e[0])} ${jg(e[1])}`)),m&&r.push(Ng("skewX",m,i,e=>jg(e[0]))),g&&r.push(Ng("skewY",g,i,e=>jg(e[0]))),c&&r.push(Ng("translate",{times:[0,1],values:[[-d,-p],[-d,-p]],easings:["linear"]},i,e=>`${jg(e[0])} ${jg(e[1])}`));const f=a("opacity");f&&r.push(Fg("opacity",f,i));const v=a("color");v&&r.push(Fg("color",v,i));const b=a("stroke");b&&r.push(Fg("stroke",b,i));const y=a("draw");if(y){r.push(Fg("stroke-dashoffset",y,i));const e=function(e){const t=e.times.map((t,i)=>[t,e.values[i][0]<=.001?1:0]),i=[],n=[];return t.forEach(([e,s],r)=>{const a=t[r-1];if(a&&a[1]!==s){const t=a[0]+(e-a[0])*(s?.75:.25);t>i[i.length-1]&&(i.push(t),n.push([0]))}(!i.length||e>i[i.length-1])&&(i.push(e),n.push([s]))}),{times:i,values:n,easings:i.slice(1).map(()=>"linear")}}(y);r.push(Fg("fill-opacity",e,i)),r.push(Fg("stroke-opacity",{...e,values:e.values.map(e=>[1-e[0]])},i))}return r.join("")}function Bg(e,t,i){const n=/^(part|group|shape):(.+)$/.exec(t);if(!n||!i)return e;const s="part"===n[1]?"data-p":"group"===n[1]?"data-g":"data-s",r=new RegExp(`(<(g|path) ${s}="${n[2]}"[^>]*>)`);return e.replace(r,e=>`${e}${i}`)}function Ig(e,t){const i=function(e,t){const i=/^(part|group|shape):(.+)$/.exec(t);if(!i)return;const n="part"===i[1]?"data-p":"group"===i[1]?"data-g":"data-s",s=new RegExp(`<(g|path) ${n}="${i[2]}"[^>]*>`).exec(e);if(!s)return;if("path"===s[1])return[s.index,e.indexOf("</path>",s.index)+7];const r=/<g\b[^>]*>|<\/g>/g;r.lastIndex=s.index+s[0].length;let a=1;for(let t=r.exec(e);t;t=r.exec(e))if(a+="</g>"===t[0]?-1:1,!a)return[s.index,t.index+4]}(e,t);if(!i)return e;const n=e.slice(i[0],i[1]).replace(/ class="(primary|secondary)"/g,' class="$1" stroke="none"');return e.slice(0,i[0])+n+e.slice(i[1])}function Zg(e){const t=e=>{const t={...e};return delete t.at,delete t.easing,delete t.easings,JSON.stringify(t)};return e.every(i=>t(i)===t(e[0]))}const Wg=new Set(["name","state","background"]);const Kg=new Set(["svg","g","path","title","style","animate","animatetransform"]);var Ug=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Gg=e=>as(1260,{size:(e/1024).toFixed(e<10240?1:0)}),Yg=e=>(new TextEncoder).encode(e).length;function Jg(e,t,i="image/svg+xml"){const n=URL.createObjectURL(new Blob([e],{type:i})),s=document.createElement("a");s.href=n,s.download=t,s.rel="noopener",document.body.appendChild(s),s.click(),s.remove(),setTimeout(()=>URL.revokeObjectURL(n),1e3)}async function Xg(e){const t=await async function(e,t){const i=function(e,t){const i=e.name.lastIndexOf("."),n=e.name.slice(i<0?e.name.length:i).toLowerCase(),s=t.types.find(e=>e.extensions.includes(n))??t.types.find(t=>t.mimeTypes.includes(e.type))??(t.other&&{kind:"other",...t.other});return s?e.size>s.maxBytes?{code:"too_large",maxBytes:s.maxBytes}:s:{code:"wrong_type"}}(e,t);if("code"in i)return{ok:!1,...i};try{return{ok:!0,text:await e.text(),kind:i.kind,bytes:e.size,name:e.name}}catch{return{ok:!1,code:"unreadable"}}}(e,Im);return t.ok?{text:t.text}:{error:"too_large"===t.code?as(928):"wrong_type"===t.code?as(142):as(947)}}let Qg=class extends a.WF{constructor(){super(...arguments),this.pieces=[],this.viewBox="0 0 24 24",this.disabled=!1,this._open=!1,this._mode="export",this._format="still",this._smil=!0,this._color="",this._text="",this._fileName="",this._status="",this._error="",this._over=!1,this._textSeq=0}openExport(e=!1){this._mode="export",this._format=e||this._isParticles?"animated":"still",this._manual=void 0,this._status="",this._error="",this._show()}openImport(e="",t=""){this._mode="import",this._text="",this._take(e),this._fileName=t,this._status="",this._error="",this._show()}close(){const e=this.renderRoot.querySelector("mc-ui-window");e?.open?e.close("action"):this._open=!1}get open(){return this._open}get _isParticles(){return"particles"===this.doc?.kind}get exportText(){return this._export().text}_export(){const e=this._exportMemo;if(e&&e.doc===this.doc&&e.pieces===this.pieces&&e.viewBox===this.viewBox)return e;const t=this.doc?.rig??{parts:[]},i=function(e,t,i={}){const n=i.viewBox??lg(e),s=new Map(t.map(e=>[e.index,e])),r=new Set,a=[],o=Wa(e.shapes??[]);for(const e of o)"under"===e.layer&&a.push(tg(e));const l=[];for(const t of e.parts??[])if(t.svg){const e=ig(t.svg,n);e&&l.push(`<g id="${Ym(t.id)}" class="part" fill="currentColor">${e}</g>`)}else if(t.from?.length){const e=t.from.map(e=>(r.add(e),s.get(e))).filter(e=>!!e);e.length&&l.push(sg(e,t.id,"part"))}const c=t.filter(e=>!r.has(e.index));c.length&&a.push(sg(c,void 0,"base")),a.push(...l);for(const e of o)"under"!==e.layer&&a.push(tg(e));return`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${Ym(n)}">\n${a.map(e=>`  ${e}`).join("\n")}\n</svg>`}(t,this.pieces,{viewBox:t.svg?void 0:this.viewBox}),n=(a=r=i,("undefined"!=typeof TextEncoder?(new TextEncoder).encode(a).length:a.length)>De?"The SVG is larger than 32 KB.":/<path|<g/.test(r)?et(r).error:"Nothing to save yet: draw a shape or use an icon."),s=n?"":et(i).markup;var r,a;return this._exportMemo={doc:this.doc,pieces:this.pieces,viewBox:this.viewBox,text:i,error:n,clean:s},this._exportMemo}_animated(){const e=this._animMemo;if(e&&e.doc===this.doc&&e.pieces===this.pieces&&e.viewBox===this.viewBox&&e.smil===this._smil&&e.color===this._color)return e;const t=this.doc?this._isParticles?function(e){const t=$m;if(!t)return{svg:"",warnings:[as(967)]};const i=Sm(e);if(!i)return{svg:"",warnings:[as(181)]};const n=t.bake({spec:i,period:tm(e),geometry:Lo}),s=[];return"live"===i.sim.mode&&s.push(as(422)),n.elements.some(e=>"icon"in e.shape||"emoji"in e.shape)&&s.push(as(371)),n.stats.capped&&s.push(as(961)),{svg:t.bakedSvg(n,{width:200,height:Math.round(200/Lo.aspect)}),warnings:s}}(this.doc):function(e,t,i={}){const n=[],s=Ht(e,{v2:"lenient"});if(!s.ok)return{svg:"",warnings:[as(932,{message:s.errors[0]?.message??as(1151)})]};const r=s.doc;if("keyframes"!==r.kind)return{svg:"",warnings:[as(605)]};r.clips?.length&&n.push(as(895)),r.bindings?.length&&n.push(as(1073)),"infinite"!==r.iterations&&n.push(as(949)),r.tracks?.some(e=>Wg.has(e.target))&&n.push(as(1019));const a=!1!==i.smil;a&&r.direction&&"normal"!==r.direction&&n.push(as(925)),a&&[...r.keyframes??[],...(r.tracks??[]).flatMap(e=>e.keyframes)].some(e=>e.transform?.axis)&&n.push("3D turns play flat in the SMIL fallback.");const o=t.viewBox||"0 0 24 24",l=function(e){const[t,i,n,s]=e.split(/[\s,]+/).map(Number);return[t,i,n,s].every(Number.isFinite)&&n>0&&s>0?[t,i,n,s]:[0,0,24,24]}(o),c=(0,cg.WP)(t),d=r.rig??{parts:[]},p=rs(r),h=function(e){return new Set(e.filter(e=>dg(e.target)&&pg(e)).map(e=>e.target))}(p);let u=function(e,t,i={}){const n=i.viewBox??"0 0 24 24",s=function(e){const[t,i,n,s]=e.split(/[\s,]+/).map(Number);return[t,i,n,s].every(Number.isFinite)&&n>0&&s>0?[t,i,n,s]:[0,0,24,24]}(n),r=i.drawn??new Set,a=$g(e,t,n),o=vg(s[2]/24*1.2),l=new Set(e.parts.flatMap(e=>e.from??[])),c=new Map;for(const t of e.groups??[])for(const e of t.parts)c.has(e)||c.set(e,t.id);const d=(e,t=!1)=>e.stroke?(t?xg(e.d):[e.d]).map(i=>`<path${Sg({class:t&&"drawn",d:i,fill:"none",stroke:"currentColor","stroke-width":vg(e.stroke.width),"stroke-linecap":e.stroke.cap,"stroke-linejoin":e.stroke.join,pathLength:t&&"1"})}></path>`).join(""):`<path${Sg({class:e.secondary?"secondary":"primary",d:e.d,"fill-rule":e.evenodd&&"evenodd"})}></path>`,p=e=>e.length?`<g class="outlines">${e.map(e=>`<path${Sg({class:"drawn",d:e,fill:"none",pathLength:"1","stroke-width":o})}></path>`).join("")}</g>`:"";let h=!1;const u=(e,i)=>{const s=i||r.has(`part:${e.id}`),o=a.get(`part:${e.id}`),l=`<g${Sg({"data-p":e.id,style:o&&yg(o)})}>`;if(e.svg){const t=wg(e.svg,n);return t?(h=!0,`${l}${t.markup}${s?p(t.outlines):""}</g>`):""}const c=(e.from??[]).map(e=>t[e]).filter(e=>!!e);if(!c.length)return"";h=!0;const u=c.filter(e=>!e.stroke);return`${l}${c.map(e=>d(e,s)).join("")}${s?p(u.flatMap(e=>xg(e.d))):""}</g>`},m=new Set;let g="";for(const t of e.parts){const i=c.get(t.id);if(!i){g+=u(t,!1);continue}if(m.has(i))continue;m.add(i);const n=r.has(`group:${i}`),s=e.parts.filter(e=>c.get(e.id)===i).map(e=>u(e,n)).join(""),o=a.get(`group:${i}`);g+=`<g${Sg({"data-g":i,style:o&&yg(o)})}>${s}</g>`}const f=e.shapes??[],v=e=>f.filter(t=>t.layer===e).map(e=>function(e,t,i){const n=Mg(e.fill)??(e.stroke?"none":"currentColor"),s=Mg(e.stroke),r=[`fill: ${n}`,s?`stroke: ${s}`:"",t?yg(t):""].filter(Boolean).join("; ");return`<path${Sg({"data-s":e.id,class:i&&"drawn",d:e.d,pathLength:i&&"1","stroke-width":e.stroke_width??(i||s?1:void 0),"stroke-linecap":e.linecap,style:r})}></path>`}(e,a.get(`shape:${e.id}`),r.has(`shape:${e.id}`))).join("");if(!h&&!f.length)return;const b=t.filter(e=>!l.has(e.index)).map(e=>d(e)).join("");return`<g class="rig">${v("under")}${b}${g}${v("over")}</g>`}(d,c,{viewBox:o,drawn:h});if(u||(u=`<g class="rig">${c.map(e=>`<path class="${e.secondary?"secondary":"primary"}" d="${Ag(e.d)}"${e.evenodd?' fill-rule="evenodd"':""}></path>`).join("")}</g>`),!c.length&&!d.shapes?.length)return{svg:"",warnings:[...n,as(952)]};const m=r.duration,g=`${jg(m)}s ${jn(r.easing)} 0s infinite ${r.direction??"normal"}`,f=i.color?vt(i.color,"color"):void 0;i.color&&!f&&n.push(as(941));const v=f?Cg(f)??"currentColor":void 0,b=`mc-a-${zn(`${u}|${JSON.stringify(r)}|${a}|${f??""}`)}`,y=Cn(r),x=qn(r.id),_=r.origin||"center",w=[],k=(e,t,i,n)=>{if(Zg(i))return;const s=Pn(t,i,x);w.push(s.css,`.${b} .mc-css .${e} { transform-box: view-box; transform-origin: ${n??_}; animation: ${[t,...s.lanes].map(e=>`${e} ${g}`).join(", ")}; }`)},$=r.tracks?.find(e=>"element"===e.target),M=r.tracks?.find(e=>"icon"===e.target);k("mc-el",`${y}-el`,r.keyframes??[]),k("mc-et",`${y}-et`,$?.keyframes??[],$?.origin),k("mc-it",`${y}-it`,M?.keyframes??[],M?.origin);const S=[`.${b} { --mc-anim-c: ${f??"currentColor"};${f?` color: ${f};`:""} }`,...a?[`.${b} .mc-css { visibility: visible; }`,`.${b} .mc-smil { display: none; }`]:[],(C=fg(p,d,{timing:g}),C.replace(/(^|[\s,{])\.rig\b/g,`$1.${b} .mc-css .rig`)),...w,...w.length?[`@media (prefers-reduced-motion: reduce) { .${b} .mc-el, .${b} .mc-et, .${b} .mc-it { animation: none !important; } }`]:[]].join("\n"),z=[];var C,A;if(z.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${Ag(l.join(" "))}" class="mc-anim ${b}"${v?` color="${Ag(v)}"`:""}>`),z.push(`<title>${Ag(r.name)}</title>`),z.push(`<style>\n${S}\n</style>`),z.push(`<g class="mc-css"${a?' visibility="hidden"':""}>${A=u,`<g class="mc-el"><g class="mc-et"><g class="mc-it">${A}</g></g></g>`}</g>`),a){let e=u.replace(/ style="([^"]*)"/g,(e,t)=>t.split(";").map(e=>e.trim()).filter(Boolean).map(e=>{const[t,...i]=e.split(":"),n=t.trim(),s=i.join(":").trim();return"fill"===n||"stroke"===n?` ${n}="${Ag("none"===s?"none":Cg(s)??"currentColor")}"`:""}).join("")).replace(/ class="drawn"/g,' class="drawn" stroke-dasharray="1" stroke-linecap="round" stroke-linejoin="round"').replace(/<g class="outlines">[\s\S]*?<\/g>/g,e=>e.replace(/stroke-linecap="round"/g,'stroke-linecap="butt"').replace(/stroke-dasharray="1"/g,'stroke-dasharray="0.999 2"')).replace(/<g class="outlines">/g,'<g class="outlines" stroke="currentColor">').replace(/<g class="rig">/,'<g class="rig" fill="currentColor">');const t=$g(d,c,o),i=[0,0,l[2],l[3]];for(const n of r.tracks??[])/^(part|group|shape):/.test(n.target)&&(h.has(n.target)&&(e=Ig(e,n.target)),e=Bg(e,n.target,Tg(n.keyframes,n.origin?Eg(n.origin,i):t.get(n.target)??Eg("center",l),m,r.easing,n.path)));const n=Eg(_,l),s=(e,t,i)=>{const n=e&&!Zg(e)?Tg(e,t,m,r.easing):"";return n?`<g>${n}${i}</g>`:i};e=s(M?.keyframes,M?.origin?Eg(M.origin,l):n,e),e=s($?.keyframes,$?.origin?Eg($.origin,l):n,e),e=s(r.keyframes,n,e),z.push(`<g class="mc-smil">${e}</g>`)}z.push("</svg>");const j=z.join("\n");return qg(j)>262144&&n.push(as(948,{size:Math.round(qg(j)/1024)})),{svg:j,warnings:n}}(this.doc,function(e,t="0 0 24 24"){const i=e=>!(!e.accent&&!e.secondary),n=e.filter(e=>!e.stroke&&!i(e)),s=e.filter(e=>!e.stroke&&i(e)),r=e.filter(e=>e.stroke),a=e=>e.map((e,t)=>e.evenodd?t:-1).filter(e=>e>=0),o={paths:a(n),accent:a(s)};return{paths:n.map(e=>e.d),viewBox:t,...s.length?{secondary:s.map(e=>e.d)}:{},...r.length?{strokes:r.map(e=>({d:e.d,width:e.stroke.width,...e.stroke.cap?{cap:e.stroke.cap}:{},...e.stroke.join?{join:e.stroke.join}:{},...i(e)?{accent:!0}:{}}))}:{},...o.paths.length||o.accent.length?{evenodd:o}:{}}}(this.pieces,this.viewBox),{smil:this._smil,...this._color?{color:this._color}:{}}):{svg:"",warnings:[]},i=t.svg?function(e){if(/<script|<foreignobject|<iframe|<image|<use|<!entity|<!doctype/i.test(e))return as(177);if(/\son[a-z]+\s*=/i.test(e))return as(178);if(/\shref\s*=|xlink:/i.test(e))return as(176);if(/url\(\s*['"]?(?!#)/i.test(e)||/@import|javascript:|expression\s*\(/i.test(e))return as(179);for(const t of e.matchAll(/<([a-zA-Z][\w-]*)/g))if(!Kg.has(t[1].toLowerCase()))return as(1037,{element:t[1]});let t=e.replace(/<style>[\s\S]*?<\/style>/g,"").replace(/<animate(Transform)?\b[^>]*\/>/g,"");qg(t)>De&&t.includes('<g class="mc-smil">')&&(t=`${t.slice(0,t.indexOf('<g class="mc-smil">'))}</svg>`);const i=et(t);return i.error?i.error:i.paths.length||i.strokes.length||i.accentPaths.length?void 0:as(591)}(t.svg):t.warnings[0]??as(594),n=t.svg?t.warnings:t.warnings.slice(1),s="function"==typeof getComputedStyle?getComputedStyle(this).getPropertyValue("--state-icon-color").trim():"",r=/^(#[0-9a-f]{3,8}|rgba?\([\d\s.,%]+\))$/i.test(s)?s:"#44739e",a=this._color?t.svg:t.svg.replace('class="mc-anim ',`color="${r}" class="mc-anim `),o=t.svg&&!i?`data:image/svg+xml;charset=utf-8,${encodeURIComponent(a)}`:"";return this._animMemo={doc:this.doc,pieces:this.pieces,viewBox:this.viewBox,smil:this._smil,color:this._color,text:t.svg,warnings:n,error:i,url:o},this._animMemo}_ready(){return this._cssLoad??=(async()=>{let e;try{const t=await Promise.race([i.e(9417).then(()=>i(8844)),new Promise(t=>{e=setTimeout(t,1e4,void 0)})]);return t?"2026.11.03-beta.2"!==t.BUILD?void console.warn("Magic Card was updated, reload the page (magic-card-svg-css.js)"):t.resolveCss:void console.warn("Magic Card: magic-card-svg-css.js did not load")}catch{return void console.warn("Magic Card: magic-card-svg-css.js did not load")}finally{clearTimeout(e)}})().then(e=>{this._css=e})}_take(e){const t=++this._textSeq,i=()=>{t===this._textSeq&&(this._text=e)};if(!e)return i(),Promise.resolve();const n=this._ready().then(i);return this._taking=n,n}async getUpdateComplete(){return await this._taking,super.getUpdateComplete()}_sourceError(){return this._srcMemo?.text!==this._text&&(this._srcMemo={text:this._text,error:et(this._text,{css:this._css}).error}),this._srcMemo.error}async _copy(e,t,i){const n=await async function(e,t){try{if(navigator.clipboard?.writeText)return await navigator.clipboard.writeText(e),!0}catch{}try{const i=document.createElement("textarea");i.value=e,i.setAttribute("readonly",""),i.style.cssText="position:fixed;left:-9999px;top:0;opacity:0",(t??document.body).appendChild(i),i.select();const n=document.execCommand("copy");return i.remove(),n}catch{return!1}}(e,this.renderRoot.querySelector("mc-ui-window"));n?(this._manual=void 0,this._status=i):(this._manual={label:t,text:e},this._status=as(187))}async _show(){const e=zd()??void 0;this._open=!0,await this.updateComplete;const t=this.renderRoot.querySelector("mc-ui-window");t&&!t.open&&(t.opener=e,t.show())}updated(e){if(e.has("_manual")&&this._manual){const e=this.renderRoot.querySelector("textarea.manual");e?.focus(),e?.select()}if(e.has("_status")&&this._status){const e=this._status;setTimeout(()=>{this._status===e&&(this._status="")},2500)}}_emit(e,t){this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:e,label:t}}))}_imported(){if(!this._text||!this.doc)return;const e=this._importMemo;if(e&&e.text===this._text&&e.doc===this.doc&&e.viewBox===this.viewBox)return e.r;const t=hn-(this.doc.rig?.shapes?.length??0),i=function(e,t,i=[],n=48,s){const r=et(e,{css:s});if(r.error)return{error:r.error};const a=Fa(r.viewBox,t),o=function(e,t){const i="undefined"==typeof DOMParser?void 0:(new DOMParser).parseFromString(e,"image/svg+xml").documentElement;if(!i||"svg"!==i.localName)return{ok:!1,error:"not_svg"};const n=Math.min(t.maxShapes??1e4,1e4),s=Math.min(t.maxPathChars??Zm,Zm),r={transforms:!1,colours:!1,opacity:!1,mergedGroups:!1},a=[],o=[];let l,c=0;const d=e=>(void 0!==t.paint?.(e)||Km.test(e)||Um.test(e)||(r.colours=!0),e),p=(e,t)=>{const i=t=>e.getAttribute(t)?.trim(),n={...t},s=i("fill");void 0!==s&&(n.fill=d(s));const a=i("stroke");void 0!==a&&(n.stroke=d(a));const o=parseFloat(i("stroke-width")??"");Number.isFinite(o)&&o>=0&&(n.width=o);const l=i("stroke-linecap");"butt"!==l&&"round"!==l&&"square"!==l||(n.cap=l);const c=i("stroke-linejoin");"miter"!==c&&"round"!==c&&"bevel"!==c||(n.join=c);const p=i("fill-rule");"evenodd"!==p&&"nonzero"!==p||(n.evenodd="evenodd"===p),(i("class")??"").split(/\s+/).includes("mc-accent")&&(n.accent=!0),(i("opacity")||i("fill-opacity")||i("stroke-opacity"))&&(r.opacity=!0);const h=parseFloat(i("opacity")??"");return Number.isFinite(h)&&(n.opacity=(n.opacity??1)*Math.min(Math.max(h,0),1)),n},h=(e,i,d,u,m)=>{const g=e.localName.toLowerCase(),f=Wm.find(e=>e===g);if(l||!f&&"g"!==g&&"svg"!==g)return;const v=e.getAttribute("transform");v&&(r.transforms=!0);const b=v?Oe(i,Pe(v)):i,y=p(e,d);if("g"===g){let i=u,n=m;if(t.keepGroups)if(m<4){const t=e.getAttribute("id");o.push({...void 0===u?{}:{parent:u},...t?{id:t}:{}}),i=o.length-1,n++}else r.mergedGroups=!0;for(const t of e.children)h(t,b,y,i,n);return}if(!f)return;const x=Re(e,g);if(!x)return;if(a.length>=n)return void(l="too_many");const _=function(e,t){const i=e=>`${Gm(t[0]*e[0]+t[2]*e[1]+t[4])} ${Gm(t[1]*e[0]+t[3]*e[1]+t[5])}`;return(0,$e.Rr)(e).map(e=>`M${i(e.start)}${e.segs.map(e=>e.c1&&e.c2?`C${i(e.c1)} ${i(e.c2)} ${i(e.to)}`:`L${i(e.to)}`).join("")}${e.closed?"Z":""}`).join("")}(x,b);if(!_)return;if(c+=_.length,c>s)return void(l="too_detailed");const w=e.getAttribute("id"),k={from:f,d:_,fill:y.fill,stroke:y.stroke,strokeWidth:y.width*Math.sqrt(Math.abs(b[0]*b[3]-b[1]*b[2])),cap:y.cap,join:y.join,evenodd:y.evenodd,opacity:y.opacity,accent:y.accent,group:u,...w?{id:w}:{}};a.push(t.each?t.each(e,k):k)},u=Pe(i.getAttribute("transform"));i.getAttribute("transform")&&(r.transforms=!0);const m=t.matrix?Oe(t.matrix,u):u,g=p(i,{width:1,accent:!1});for(const e of i.children)h(e,m,g,void 0,0);return l?{ok:!1,error:l}:a.length?{ok:!0,shapes:a,groups:o,viewBox:t.viewBox,notes:r}:{ok:!1,error:"empty"}}(r.markup,{viewBox:t,keepGroups:!1,maxShapes:n,maxPathChars:Math.min(n*pt,Zm),matrix:[a.k,0,0,a.k,a.dx,a.dy]});if(!o.ok)return{error:rg[o.error].replace("{room}",String(n))};const l=new Set(i),c=[];for(const e of o.shapes){const t=Va(e.d,e=>e);if(t.length>pt)return{error:rg.too_detailed};if(!t)continue;const i=e.id??"",n=un.test(i)&&!l.has(i)?i:Ya([...l],"shape");l.add(n);const s={id:n,name:i&&un.test(i)?i:`Shape ${c.length+1}`,d:t,layer:"over"},r="line"===e.from?"none":og(e.fill)??"currentColor",o=og(e.stroke),d=e.strokeWidth??1;o&&"none"!==o?(s.stroke=o,s.stroke_width=Math.round(1e3*d)/1e3,"round"!==e.cap&&"butt"!==e.cap&&"square"!==e.cap||(s.linecap=e.cap),"none"!==r&&(s.fill=r)):"none"===r||ag(t)?(s.stroke="currentColor",s.stroke_width=Math.round(1e3*Math.max(a.k,.05))/1e3):s.fill=r,c.push(s)}return c}(this._text,this.viewBox,Qa(this.doc),t,this._css);return this._importMemo={text:this._text,doc:this.doc,viewBox:this.viewBox,r:i},i}async _pick(e){const t=e.target,i=t.files?.[0];t.value="",i&&await this._takeFile(i)}async _takeFile(e){const t=await Xg(e);if("error"in t)return this._error=ys(t.error),void this._take("");this._error="",this._fileName=e.name,await this._take(t.text)}_drop(e){e.preventDefault(),this._over=!1;const t=e.dataTransfer?.files?.[0];t&&this._takeFile(t)}_addShapes(e){if(!this.doc)return;let t=this.doc;for(const i of e)t=t&&eo(t,i);if(!t)return void(this._error=as(1259,{shapes:hn}));const i=Ja(t);i?this._error=i:(this._emit(t,as(1185,{count:e.length})),this.close())}_useAsIcon(){if(!this.doc)return;const e=function(e,t,i,n){const s=et(t,{css:n});if(s.error)return{error:s.error};const r=e.rig??{parts:[]},a=Na(i??lg(r)).join(" "),o=Na(s.viewBox).join(" "),l=Fa(a,o),c=a===o,d=e=>{return e.origin?{...e,origin:(t=e.origin,t&&!c?[Math.round(100*(t[0]*l.k+l.dx))/100,Math.round(100*(t[1]*l.k+l.dy))/100]:t)}:e;var t},p=e=>String(Math.round(1e4*e)/1e4),h=(r.parts??[]).filter(e=>!e.from).map(e=>d(c||!e.svg?e:{...e,svg:`<g transform="matrix(${p(l.k)} 0 0 ${p(l.k)} ${p(l.dx)} ${p(l.dy)})">${e.svg}</g>`})),u=r.shapes?.map(e=>c?e:d({...e,d:Va(e.d,e=>[e[0]*l.k+l.dx,e[1]*l.k+l.dy]),...void 0!==e.stroke_width?{stroke_width:Math.round(e.stroke_width*l.k*1e3)/1e3}:{}})),m=new Set(h.map(e=>e.id)),g=(r.groups??[]).map(e=>d({...e,parts:e.parts.filter(e=>m.has(e))})).filter(e=>e.parts.length),f=new Set([...(r.parts??[]).filter(e=>!m.has(e.id)).map(e=>`part:${e.id}`),...(r.groups??[]).filter(e=>!g.some(t=>t.id===e.id)).map(e=>`group:${e.id}`)]),v={...r,svg:s.markup,parts:h,...r.groups?{groups:g}:{},...u?{shapes:u}:{}};delete v.icon;const b={...e,rig:v};return e.tracks&&(b.tracks=e.tracks.filter(e=>!f.has(e.target)).map(e=>e.path&&!c&&/^(part|group|shape):/.test(e.target)?{...e,path:{...e.path,d:Va(e.path.d,e=>[e[0]*l.k,e[1]*l.k])}}:e)),e.bindings&&(b.bindings=e.bindings.filter(e=>!f.has(e.target))),b}(this.doc,this._text,this.viewBox,this._css);if("error"in e)return void(this._error=ys(e.error));const t=Ja(e);t?this._error=t:(this._emit(e,"Use SVG as icon"),this.close())}_shapesPreview(e,t){return a.qy`<svg viewBox=${t} aria-hidden="true">
      ${Wa(e).map(e=>a.JW`<path d=${e.d} fill=${Ba(e)?e.fill&&!/^entity|var\(/.test(e.fill)?e.fill:"currentColor":"none"}
            stroke=${Ia(e)?/^entity|var\(/.test(e.stroke)?"currentColor":e.stroke:"none"}
            stroke-width=${e.stroke_width??1} stroke-linecap=${e.linecap??"butt"} stroke-linejoin="round"></path>`)}
    </svg>`}_renderFormat(){const e=[["still",as(370),"mdi:image-outline"],["animated",as(62),"mdi:motion-play-outline"]];return a.qy`<div class="format">${Nd({role:"radiogroup",label:as(1080),full:!0,value:this._format,items:e.map(([e,t,i])=>({value:e,label:t,icon:i})),onChange:e=>{this._format=e,this._status="",this._manual=void 0}})}</div>`}_renderManual(){return this._manual?a.qy`<div class="field">
          <div class="field-head"><label for="svg-manual">${this._manual.label}</label></div>
          <textarea id="svg-manual" class="code manual" readonly .value=${this._manual.text} @focus=${e=>e.target.select()}></textarea>
        </div>`:a.s6}_renderAnimated(){const{text:e,warnings:t,error:i,url:n}=this._animated(),s=Yg(e);return a.qy`
      <div class="body">
        ${this._isParticles?a.s6:this._renderFormat()}
        <div class="top">
          <div class="preview">${n?a.qy`<img class="anim" src=${n} alt="" />`:a.qy`<ha-icon icon="mdi:image-off-outline"></ha-icon>`}</div>
          <div class="facts">
            <span>${this._isParticles?as(17):as(16)}</span>
            <span class="muted">${Gg(s)}${s>262144?as(4):""}</span>
            ${this._isParticles?a.qy`<span class="muted">${as(107)}</span>`:a.qy`<span class="muted">${as(108)}</span>
            <div class="color-row">
              <label class="check">
                <input type="color" class="color" .value=${this._color||"#03a9f4"} @input=${e=>this._color=e.target.value} />
                ${this._color?a.qy`${as(166)} <span class="mono">${this._color}</span>`:as(172)}
              </label>
              ${this._color?a.qy`<button type="button" class="btn btn-text btn-sm color-reset" @click=${()=>this._color=""}>${as(1057)}</button>`:a.qy`<span class="muted">${as(88)}</span>`}
            </div>
            <label class="check">
              <input type="checkbox" class="smil" .checked=${this._smil} @change=${e=>this._smil=e.target.checked} />
              ${as(759)}
            </label>
            `}
            ${t.length?a.qy`<ul class="warn">${t.map(e=>a.qy`<li>${e}</li>`)}</ul>`:a.s6}
            ${i?a.qy`<p class="error" role="alert">${i}</p>`:a.s6}
          </div>
        </div>
        <div class="field">
          <div class="field-head"><label for="svg-anim-code">${as(62)}</label></div>
          <textarea id="svg-anim-code" class="code" readonly .value=${e}></textarea>
        </div>
        ${this._renderManual()}
      </div>
      <div slot="footer" class="foot">
        <p class="status grow" role="status" aria-live="polite">${this._status}</p>
        <button type="button" class="btn btn-secondary copy" ?disabled=${!!i} @click=${()=>this._copy(e,as(763),as(63))}>
          <ha-icon icon="mdi:content-copy"></ha-icon>${as(186)}
        </button>
        <button
          type="button"
          class="btn btn-primary download"
          ?disabled=${!!i}
          @click=${()=>{Jg(e,`${(this.doc?.name??""??"").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||"icon"}-animated.svg`),this._status=as(246)}}
        >
          <ha-icon icon="mdi:tray-arrow-down"></ha-icon>${as(245)}
        </button>
      </div>
    `}_renderExport(){if("animated"===this._format)return this._renderAnimated();const{text:e,error:t,clean:i}=this._export(),n=Yg(e),s=this.doc?.rig?.parts?.length??0,r=this.doc?.rig?.shapes?.length??0,o=Math.min(100,n/De*100);return a.qy`
      <div class="body">
        ${this._renderFormat()}
        <div class="top">
          <div class="preview">${i?Tm(i):a.qy`<ha-icon icon="mdi:image-off-outline"></ha-icon>`}</div>
          <div class="facts">
            <span>${this.pieces.length?as(1251,{parts:s,shapes:r}):as(1252,{parts:s,shapes:r})}</span>
            <span class="muted">${as(1197,{kb:Gg(n)})}</span>
            <div class="meter ${n>De?"over":""}" role="meter" aria-label=${as(832)} aria-valuemin="0" aria-valuemax=${De} aria-valuenow=${n}>
              <i style="width:${o}%"></i>
            </div>
            <span class="muted">${as(951)}</span>
            ${t?a.qy`<p class="error" role="alert">${t}</p>`:a.s6}
          </div>
        </div>
        <div class="field">
          <div class="field-head"><label for="svg-code">SVG</label></div>
          <textarea id="svg-code" class="code" readonly .value=${e}></textarea>
        </div>
        ${this._manual?a.qy`<div class="field">
              <div class="field-head"><label for="svg-manual">${this._manual.label}</label></div>
              <textarea id="svg-manual" class="code manual" readonly .value=${this._manual.text} @focus=${e=>e.target.select()}></textarea>
            </div>`:a.s6}
      </div>
      <div slot="footer" class="foot">
        <p class="status grow" role="status" aria-live="polite">${this._status}</p>
        <button type="button" class="btn btn-secondary copy" ?disabled=${!!t} @click=${()=>this._copy(e,as(763),as(761))}>
          <ha-icon icon="mdi:content-copy"></ha-icon>${as(186)}
        </button>
        <button type="button" class="btn btn-secondary download" ?disabled=${!!t} @click=${()=>{Jg(e,`${(this.doc?.name??""??"").toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").slice(0,60)||"icon"}.svg`),this._status=as(246)}}>
          <ha-icon icon="mdi:tray-arrow-down"></ha-icon>${as(245)}
        </button>
        <button
          type="button"
          class="btn btn-primary use"
          ?disabled=${!!t}
          title=${as(183)}
          @click=${()=>this._copy(`icon: svg\nsvg: |\n${e.replace(/\r\n?/g,"\n").trim().split("\n").map(e=>`  ${e}`).join("\n")}\n`,as(118),as(117))}
        >
          <ha-icon icon="mdi:card-text-outline"></ha-icon>${as(1059)}
        </button>
      </div>
    `}_renderImport(){const e=this._imported(),t=e&&!("error"in e)?e:void 0,i=this._error||(e&&"error"in e?ys(e.error):"");return a.qy`
      <div class="body">
        ${this._text?a.qy`<div class="top">
              <div class="preview">${t?this._shapesPreview(t,this.viewBox):a.qy`<ha-icon icon="mdi:image-off-outline"></ha-icon>`}</div>
              <div class="facts">
                <span>${this._fileName||"SVG"}</span>
                ${t?a.qy`<span class="muted">${as(1174,{count:t.length})}</span>`:a.s6}
                <span class="muted">${as(38)}</span>
                ${i?a.qy`<p class="error" role="alert">${i}</p>`:a.s6}
              </div>
            </div>`:a.qy`<div
              class="drop ${this._over?"over":""}"
              @dragover=${e=>{e.preventDefault(),this._over=!0}}
              @dragleave=${()=>this._over=!1}
              @drop=${e=>this._drop(e)}
            >
              <ha-icon icon="mdi:file-upload-outline"></ha-icon>
              <span>${as(272)}</span>
              <label class="btn btn-secondary">
                ${as(144)}
                <input type="file" accept=".svg,image/svg+xml" class="sr-only" @change=${e=>this._pick(e)} />
              </label>
              ${i?a.qy`<p class="error" role="alert">${i}</p>`:a.s6}
            </div>`}
      </div>
      <div slot="footer" class="foot">
        ${this._text?a.qy`<button type="button" class="btn btn-text again" @click=${()=>{this._take("")}}>${as(143)}</button><span class="grow"></span>`:a.qy`<span class="grow"></span>`}
        <button type="button" class="btn btn-secondary use-icon" ?disabled=${!this._text||!!this._sourceError()} @click=${()=>this._useAsIcon()}>
          <ha-icon icon="mdi:star-four-points-outline"></ha-icon>${as(1055)}
        </button>
        <button type="button" class="btn btn-primary add" ?disabled=${!t} @click=${()=>t&&this._addShapes(t)}>
          <ha-icon icon="mdi:shape-plus-outline"></ha-icon>${as(26)}
        </button>
      </div>
    `}render(){return this._open?Cd({heading:"import"===this._mode?as(381):this._isParticles?as(62):as(767),size:"m",onClose:()=>{this._open=!1,this._status=""}},"export"===this._mode?this._renderExport():this._renderImport()):a.s6}};Qg.styles=[dh,a.AH`
      :host {
        display: contents;
      }
      /* the window brings the frame, header and footer row; what is slotted in is a grid */
      .body {
        display: grid;
        gap: 16px;
        min-width: 0;
      }
      .foot {
        display: contents;
      }
      .foot .grow {
        flex: 1;
      }
      .top {
        display: grid;
        grid-template-columns: 120px minmax(0, 1fr);
        gap: 16px;
        align-items: start;
      }
      .preview {
        width: 120px;
        height: 120px;
        box-sizing: border-box;
        border-radius: 12px;
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        display: grid;
        place-items: center;
        color: var(--state-icon-color, #44739e);
        background-color: color-mix(in srgb, var(--primary-text-color, #212121) 4%, var(--card-background-color, #fff));
        background-image: radial-gradient(color-mix(in srgb, var(--primary-text-color, #212121) 14%, transparent) 1px, transparent 1px);
        background-size: 12px 12px;
      }
      .preview img.anim {
        width: 88px;
        height: 88px;
      }
      .check {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        min-height: 32px;
        font-size: 0.875rem;
        cursor: pointer;
      }
      .color-row {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px 12px;
      }
      .color-row .muted {
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
      }
      .check input[type='color'] {
        width: 28px;
        height: 28px;
        padding: 0;
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        border-radius: 6px;
        background: none;
      }
      .check input {
        width: 18px;
        height: 18px;
        margin: 0;
        accent-color: var(--primary-color, #03a9f4);
      }
      .warn {
        margin: 0;
        padding-inline-start: 18px;
        font-size: 0.8125rem;
        color: color-mix(in srgb, var(--warning-color, #ff9800) 65%, var(--primary-text-color, #212121));
      }
      .preview svg {
        width: 88px;
        height: 88px;
        overflow: visible;
      }
      .facts {
        display: grid;
        gap: 6px;
        font-size: 0.875rem;
      }
      .facts .muted {
        color: var(--secondary-text-color, #5f6368);
        font-size: 0.8125rem;
      }
      .meter {
        height: 6px;
        border-radius: 3px;
        background: var(--secondary-background-color, #f2f3f5);
        overflow: hidden;
      }
      .meter i {
        display: block;
        height: 100%;
        background: color-mix(in srgb, var(--primary-color, #03a9f4) 70%, #000);
      }
      .meter.over i {
        background: var(--error-color, #db4437);
      }
      textarea.code {
        width: 100%;
        box-sizing: border-box;
        min-height: 120px;
        max-height: 200px;
        resize: vertical;
        font: 0.8125rem/1.5 'Roboto Mono', ui-monospace, SFMono-Regular, Consolas, monospace;
        padding: 8px 12px;
        border-radius: 8px;
        border: 1px solid color-mix(in srgb, var(--primary-text-color, #212121) 40%, transparent);
        background: var(--card-background-color, #fff);
        color: inherit;
      }
      .status {
        min-height: 1.2em;
        margin: 0;
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
        align-self: center;
      }
      .error {
        margin: 0;
        color: color-mix(in srgb, var(--error-color, #db4437) 80%, var(--primary-text-color, #212121));
        font-size: 0.8125rem;
      }
      .drop {
        display: grid;
        place-items: center;
        gap: 8px;
        min-height: 140px;
        padding: 16px;
        border: 1px dashed var(--divider-color, rgba(0, 0, 0, 0.24));
        border-radius: 12px;
        text-align: center;
        color: var(--secondary-text-color, #5f6368);
        font-size: 0.875rem;
      }
      .drop.over {
        border-color: var(--primary-color, #03a9f4);
        background: color-mix(in srgb, var(--primary-color, #03a9f4) 8%, transparent);
      }
      .drop ha-icon {
        --mdc-icon-size: 32px;
      }
    `],Ug([(0,o.MZ)({attribute:!1})],Qg.prototype,"doc",void 0),Ug([(0,o.MZ)({attribute:!1})],Qg.prototype,"pieces",void 0),Ug([(0,o.MZ)({type:String})],Qg.prototype,"viewBox",void 0),Ug([(0,o.MZ)({type:Boolean})],Qg.prototype,"disabled",void 0),Ug([(0,o.wk)()],Qg.prototype,"_open",void 0),Ug([(0,o.wk)()],Qg.prototype,"_mode",void 0),Ug([(0,o.wk)()],Qg.prototype,"_format",void 0),Ug([(0,o.wk)()],Qg.prototype,"_smil",void 0),Ug([(0,o.wk)()],Qg.prototype,"_color",void 0),Ug([(0,o.wk)()],Qg.prototype,"_text",void 0),Ug([(0,o.wk)()],Qg.prototype,"_fileName",void 0),Ug([(0,o.wk)()],Qg.prototype,"_status",void 0),Ug([(0,o.wk)()],Qg.prototype,"_error",void 0),Ug([(0,o.wk)()],Qg.prototype,"_over",void 0),Ug([(0,o.wk)()],Qg.prototype,"_manual",void 0),Qg=Ug([(0,o.EM)("mc-anim-svg-dialog")],Qg);var ef=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const tf={circle:a.JW`<circle cx="12" cy="12" r="7"></circle>`,square:a.JW`<rect x="5" y="5" width="14" height="14" rx="1.5"></rect>`,triangle:a.JW`<path d="M12 4l8 15H4z"></path>`,star:a.JW`<path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.7-6.2 3.7 1.6-7L2 9.2l7.1-.6z"></path>`,heart:a.JW`<path d="M12 20s-7.5-4.6-7.5-10.2A4.2 4.2 0 0 1 12 7.3a4.2 4.2 0 0 1 7.5 2.5C19.5 15.4 12 20 12 20z"></path>`,ring:a.JW`<circle cx="12" cy="12" r="6.5" fill="none" stroke="currentColor" stroke-width="3"></circle>`,line:a.JW`<path d="M6 19L18 5" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`,spark:a.JW`<path d="M12 2l2 8 8 2-8 2-2 8-2-8-8-2 8-2z"></path>`};function nf(e){return Wu(e)?a.qy`<svg class="glyph" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">${tf[e]}</svg>`:a.qy`<ha-icon class="glyph" icon=${Iu.find(t=>t.id===e).icon}></ha-icon>`}const sf=["#ef4444","#eab308","#22c55e","#3b82f6","#ec4899","#ffffff","#f97316","#8b5cf6"];let rf=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.emitter=0,this._shapes={},this._color=-1,this._chip=0,this._paused=!1,this._open={},this._baking=!1,this.all=!1,this._live="",this._seed=im(),this._bakeMs=0,this._bakeToken=0,this._applied=[],this._liveCss=new Map,this._previewCss="",this._shuffle=()=>{if(!this.doc)return;const e=this._multi&&this.all;let t=this.doc;for(let i=e?0:this._em;i<(e?zm(this.doc):this._em+1);i++)t=Rm(t,this._seed,i,e=>um(e,this._seed));this._emit(t,"Shuffle")},this._openExport=()=>{this.renderRoot.querySelector("mc-anim-svg-dialog")?.openExport(!0)},this._convert=()=>{this.doc&&(this._emit(function(e){const t=e.particles??ut,i=Pu(e),n=(i&&Du[i.id])??{},s="count"===i?.particles?t.intensity??i.defaults.intensity:void 0,r=void 0!==s&&Number.isFinite(s)?Eu(Math.round(s),1,ct):ut.count,{preset:a,intensity:o,...l}=t,c={...ut,...l,...n,count:r,size:[...n.size??l.size??ut.size],colors:[...n.colors??l.colors??[]]};return c.shape||delete c.shape,{...e,particles:c}}(this.doc),"Convert to custom particles"),this._focus('.mode-seg [aria-checked="true"]'))},this._addEmitter=()=>{if(!this.doc)return;const e=function(e,t){if(!jm(e))return e;const i=Em(e,t),n=structuredClone(i[0]);return delete n.name,n.id="",n.seed=im(i[0].seed,void 0),n.count=Math.min(10,i[0].count,Am(e)),Hm(e,t,[...i,n])}(this.doc,this._seed);e!==this.doc&&(this._emit(e,"Add emitter"),this._select(zm(e)-1),this._focus('.em-tabs [aria-selected="true"]'))},this._dupEmitter=()=>{if(!this.doc)return;const e=function(e,t,i){if(!Lm(e,i)||!jm(e))return e;const n=Em(e,t),s=structuredClone(n[i]);return s.id="",s.seed=im(n[i].seed,void 0),s.count=Math.min(n[i].count,Am(e)),s.name&&(s.name=as(1227,{name:s.name}).slice(0,40).trim()),n.splice(i+1,0,s),Hm(e,t,n)}(this.doc,this._seed,this._em);e!==this.doc&&(this._emit(e,"Duplicate emitter"),this._select(this._em+1),this._focus('.em-tabs [aria-selected="true"]'))},this._removeEmitter=()=>{if(!this.doc)return;const e=this._em,t=function(e,t,i){if(!Lm(e,i)||zm(e)<2)return e;const n=Em(e,t);return n.splice(i,1),Hm(e,t,n)}(this.doc,this._seed,e);t!==this.doc&&(this._emit(t,"Remove emitter"),this._select(Math.max(0,e-1)),this._focus('.em-tabs [aria-selected="true"]'))},this._onFocusOut=e=>{const t=e.target;this._pending&&["f-svg","f-emoji","f-grav","f-drag","f-turb","f-bounce"].includes(t.id)&&this._settle()}}_emit(e,t,i=!1){if(this.disabled||e===this.doc)return;this._pending=i?{doc:e,label:t}:void 0;const n=i?{doc:e,label:t,transient:!0}:{doc:e,label:t};this.dispatchEvent(new CustomEvent("doc-change",{detail:n,bubbles:!0,composed:!0}))}_settle(){if(this._pending){const{doc:e,label:t}=this._pending;if(this._pending=void 0,this.disabled)return;this.dispatchEvent(new CustomEvent("doc-change",{detail:{doc:e,label:t},bubbles:!0,composed:!0}))}}get _em(){return this.doc?Math.max(0,Math.min(Math.trunc(this.emitter)||0,zm(this.doc)-1)):0}get _vdoc(){const e=this.doc,t=this._em;return this._viewKey?.doc===e&&this._viewKey.em===t||(this._viewKey={doc:e,em:t,view:Pm(e,this._seed,t)}),this._viewKey.view}get _p(){return"particles"===this.doc?.kind?this._vdoc.particles:void 0}get _sim(){return rm(this._vdoc,this._seed)}_on(e){return Rm(this.doc,this._seed,this._em,e)}_patch(e,t,i=!1){this.doc&&this._emit(this._on(t=>Ou(t,e)),t,i)}_editSim(e,t,i=!1){this.doc&&this._emit(this._on(t=>cm(t,this._seed,e)),t,i)}_editAll(e,t,i=!1){if(!this.doc)return;let n=this.doc;for(let t=0;t<zm(n);t++)n=Rm(n,this._seed,t,t=>cm(t,this._seed,e));this._emit(n,t,i)}_select(e,t=!1){this.emitter=e,this.all=t,this.dispatchEvent(new CustomEvent("emitter-change",{detail:{index:e,all:t},bubbles:!0,composed:!0}))}get _multi(){return!!this.doc&&zm(this.doc)>1}_name(e){return this._multi?Dm(this.doc,this._seed,e):as(633)}willUpdate(e){if(e.has("emitter")&&void 0!==e.get("emitter")&&(this._svgDraft=void 0,this._emojiDraft=void 0,this._color=-1,this._chip=0,this._live=""),e.has("doc")){const t=e.get("doc");if(t&&t.id!==this.doc?.id&&(this._svgDraft=void 0,this._emojiDraft=void 0,this._shapes={},this._color=-1,this._chip=0,this._seed=im(),this._stats=void 0,this.all=!1,this._live=""),this._p&&!this._p.preset){for(const e of this._sim.shapes)"builtin"in e.shape||(this._shapes={...this._shapes,[Ku(e.shape)]:e.shape});const e=dm(this._sim).length;this._chip>=e&&(this._chip=e-1)}const i=this._p?.colors.length??0;this._color>=i&&(this._color=i-1)}}_preview(){const e=this.doc,t=this._p;if(!e||!t)return{css:""};if(t.preset)return{anim:xu({animations:[{id:"pv",preset:t.preset,intensity:t.intensity,duration:`${e.duration}s`,easing:e.easing,iterations:"infinite",direction:e.direction}]}),css:""};const i=Qn(e);if(!i.layer||!i.name)return{css:""};const n=+(e.duration/i.layer.speed).toFixed(3),s=[[i.name,i.layer],...i.split?[[i.split.name,i.split.layer]]:[]].map(([t,i])=>({preset:t,front:i.front,style:`--mc-fx-anim: ${t} ${n}s ${jn(e.easing)} 0s infinite ${e.direction??"normal"}; --mc-fx-dur: ${n}s; --mc-fx-delay: 0s`,particles:i.particles,...i.symbol?{symbol:i.symbol}:{}}));return{css:i.css,anim:{style:"",fx:s}}}updated(e){const t=this.renderRoot.querySelector("style[data-pv]");t&&t.textContent!==this._previewCss&&(t.textContent=this._previewCss),e.has("doc")&&this._scheduleBake(),this._applyModule()}disconnectedCallback(){super.disconnectedCallback(),this._release(),this._bakeToken++}_scheduleBake(){const e=Mm(),t=this.doc&&this._p?.sim&&!this._p.preset?Sm(this.doc):void 0,i=++this._bakeToken;if(!e||!t)return this._stats=void 0,void(this._baking=!1);this._bakeMs>150&&(this._baking=!0);const n=this.doc;setTimeout(()=>{if(i!==this._bakeToken)return;const s=performance.now();try{this._stats=e.bake({spec:t,period:tm(n),geometry:Lo}).stats}catch{this._stats=void 0}this._bakeMs=performance.now()-s,this._baking=!1},0)}_applyModule(){const e=Mm(),t=this.doc&&this._p?.sim&&!this._p.preset?Sm(this.doc):void 0,i=[...this.renderRoot.querySelectorAll(".stage .mc-anim-fx")];if(this._applied.some((e,t)=>e!==i[t])&&this._release(),!e||!t||!i.length||this._paused&&"live"===t.sim.mode)return void this._release();const n="function"==typeof matchMedia&&matchMedia(as(3)).matches;try{i.forEach((i,s)=>{e.apply(i,{useCss:(e,t)=>{this._liveCss.set(e,t);const i=this.renderRoot.querySelector("style[data-live]");i&&(i.textContent=[...this._liveCss.values()].join("\n"))},reducedMotion:n,content:()=>this.renderRoot.querySelector(".stage-module")??void 0,docId:this.doc.id,spec:t,period:tm(this.doc),...1===s?{part:1}:{}})}),this._applied=i}catch{}}_release(){for(const e of this._applied)Mm()?.release(e);this._applied=[]}_renderPreview(){const{anim:e,css:t}=this._preview();this._previewCss=t;const i=this._p,n=Pu(this.doc),s=i.preset?void 0:this._sim,r=s?this._baking?as(80):`${this._multi?as(1250,{particles:Cm(this.doc),emitters:zm(this.doc)}):as(1170,{count:i.count,flow:as(Fu[s.flow]).toLowerCase()})} · ${"live"===s.mode?as(1123):as(1258,{seconds:+tm(this.doc).toFixed(2)})}`:`${n?(0,te.t)(n.name):i.preset} · ${this.doc.duration} s`,o=!!s&&!!this._stats?.capped,l=!!s&&!o&&!!this._stats?.warn,c=!!s&&!!Mm();return a.qy`<div class="preview">
      <div class="stage" data-mc-anim-fx ?data-paused=${this._paused} aria-hidden="true">
        <div class="stage-module"><ha-icon icon="mdi:lightbulb-outline"></ha-icon><span>${as(424)}</span></div>
        ${e?function(e){return e.fx.some(e=>e.seasonal)&&window.MagicCard?.loadSeasonal?.(),a.qy`${e.fx.map(e=>e.seasonal?a.qy`<mc-seasonal class="mc-anim-seasonal" data-fx=${e.preset} .scenes=${e.seasonal.scenes} .intensity=${e.seasonal.intensity} .seed=${`pv|${e.preset}`}></mc-seasonal>`:e.ring?a.qy`<mc-ring class="mc-anim-ring" data-fx=${e.preset} style=${e.style} .ring=${e.ring}></mc-ring>`:a.qy`<span class="mc-anim-fx" data-fx=${e.preset} ?data-front=${e.front} style=${e.style} aria-hidden="true">${e.particles.map(t=>{return a.qy`<i data-s=${t.shape??a.s6} style="--mc-anim-x: ${t.x}%; --mc-anim-phase: ${t.phase}; --mc-anim-k: ${t.k}${t.style?`; ${t.style}`:""}"
                >${i=t.symbol??e.symbol,i?"icon"in i?a.qy`<ha-icon .icon=${i.icon}></ha-icon>`:i.text:a.s6}</i
              >`;var i})}</span>`)}`}(e):a.s6}
      </div>
      <div class="preview-foot">
        <span class="sum">${r}</span>
        ${o?a.qy`<span class="chip is-warn trimmed">${as(1022)}</span>`:a.s6}
        ${c?a.qy`<button type="button" class="icon-btn sm export" aria-label=${as(62)} title=${as(766)} ?disabled=${this.disabled} @click=${this._openExport}>
              <ha-icon icon="mdi:motion-play-outline"></ha-icon>
            </button>`:a.s6}
        ${s?a.qy`<button type="button" class="icon-btn sm shuffle" aria-label=${as(828)} title=${as(829)} ?disabled=${this.disabled} @click=${this._shuffle}>
              <ha-icon icon="mdi:dice-5-outline"></ha-icon>
            </button>`:a.s6}
        <button
          type="button"
          class="icon-btn sm pause"
          aria-pressed=${this._paused?"true":"false"}
          aria-label=${as(650)}
          title=${this._paused?as(670):as(650)}
          @click=${()=>this._paused=!this._paused}
        >
          <ha-icon icon=${this._paused?"mdi:play":"mdi:pause"}></ha-icon>
        </button>
      </div>
      ${o?a.qy`<p class="help cap-note">${as(1002)}</p>`:a.s6}
      ${l?a.qy`<p class="help cap-note">${as(1003)}</p>`:a.s6}
      <p class="help reduced-note">${as(707)}</p>
      ${c?a.qy`<mc-anim-svg-dialog .doc=${this.doc}></mc-anim-svg-dialog>`:a.s6}
    </div>`}_cols(e){if(!e||"function"!=typeof getComputedStyle)return 3;const t=getComputedStyle(e).gridTemplateColumns||"",i=/^repeat\((\d+)/.exec(t);return i?+i[1]:t.split(/\s+/).filter(e=>/px$/.test(e)).length||3}_radioKeys(e,t,i,n,s=0){const r=Math.max(0,t.indexOf(i));let a;const o="rtl"===x(this);if(e.key===(o?"ArrowLeft":"ArrowRight"))a=r+1;else if(e.key===(o?"ArrowRight":"ArrowLeft"))a=r-1;else if("ArrowDown"===e.key)a=r+(s||1);else if("ArrowUp"===e.key)a=r-(s||1);else if("Home"===e.key)a=0;else{if("End"!==e.key)return;a=t.length-1}e.preventDefault(),a=(a+t.length)%t.length,n(t[a])}_focus(e){this.updateComplete.then(()=>this.renderRoot.querySelector(e)?.focus())}_pickMode(e,t=!1){this.doc&&this._emit(function(e,t,i){return rm(e,t).mode===i?e:cm(e,t,e=>({...e,mode:i}))}(this.doc,this._seed,e),as("live"===e?1061:1056)),t&&this._focus(`.mode-seg [data-mode="${e}"]`)}_renderMode(e){const t=[["baked",as(79),"mdi:repeat"],["live",as(421),"mdi:pulse"]];return a.qy`<section class="group" aria-labelledby="h-mode">
      <div class="group-head"><h3 id="h-mode">${as(447)}</h3></div>
      <div
        class="seg full mode-seg"
        role="radiogroup"
        aria-label=${as(830)}
        @keydown=${t=>this._radioKeys(t,["baked","live"],e.mode,e=>this._pickMode(e,!0))}
      >
        ${t.map(([t,i,n])=>a.qy`<button
            type="button"
            role="radio"
            data-mode=${t}
            aria-checked=${e.mode===t?"true":"false"}
            tabindex=${e.mode===t?0:-1}
            @click=${()=>this._pickMode(t)}
          >
            <ha-icon icon=${n}></ha-icon>${i}
          </button>`)}
      </div>
      <div class="mode-status" role="status">
        ${"live"===e.mode?a.qy`<p class="note is-warn live-warning"><ha-icon icon="mdi:alert-outline" aria-hidden="true"></ha-icon><span>${as(423)}</span></p>`:a.qy`<p class="help">${as(984)}</p>`}
      </div>
    </section>`}_chips(){return dm(this._sim)}_setShapes(e,t,i=!1){this.doc&&this._emit(this._on(t=>function(e,t,i){const n=1===i.length?i[0].shape:void 0;return am(e)||i.length&&(!n||"builtin"in n&&"circle"!==n.builtin)?cm(e,t,e=>({...e,shapes:i.map(e=>({shape:e.shape,weight:e.weight}))})):function(e,t){const i=Ou(e,{});return t?i.particles.shape=t:delete i.particles.shape,i}(e,n&&!("builtin"in n)?n:void 0)}(t,this._seed,e)),t,i)}_setChip(e,t,i,n=!1){const s=this._chips().map((i,n)=>n===e?{shape:t,weight:i.weight}:i);this._setShapes(s,i,n)}_shapeFor(e){return Wu(e)?{builtin:e}:this._shapes[e]??$u[e]}_pickKind(e,t=!1){const i=this._chips()[this._chip];i&&Ku(i.shape)!==e&&(this._svgDraft=void 0,this._emojiDraft=void 0,this._setChip(this._chip,this._shapeFor(e),`Use ${e}`)),t&&this._focus(`.shapes.main [data-kind="${e}"]`)}_addShape(){const e=this._chips();e.length>=Gu||(this._chip=e.length,this._setShapes([...e,{shape:gm(e),weight:1}],as(34)))}_removeShape(e){const t=this._chips();t.length<=1||(this._chip=Math.max(0,Math.min(e,t.length-2)),this._setShapes(t.filter((t,i)=>i!==e),as(720)),this._focus(`.schip[data-i="${this._chip}"]`))}_shapeGrid(e,t,i,n){const s=Iu.map(e=>e.id),r=e??s[0];return a.qy`<div
      class="shapes ${t}"
      role="radiogroup"
      aria-label=${i}
      @keydown=${e=>this._radioKeys(e,s,r,e=>n(e,!0),this._cols(e.currentTarget))}
    >
      ${Iu.map(t=>a.qy`<button
          type="button"
          class="dir shape-tile"
          role="radio"
          data-kind=${t.id}
          aria-checked=${t.id===e?"true":"false"}
          tabindex=${t.id===r?0:-1}
          @click=${()=>n(t.id,!1)}
        >
          ${nf(t.id)}<span>${as(t.label)}</span>
        </button>`)}
    </div>`}_renderShape(){const e=this._chips(),t=Math.min(this._chip,e.length-1),i=e[t],n=Ku(i.shape),s=e.length>1,r=e.length>=Gu;return a.qy`<section class="group" aria-labelledby="h-shape">
      <div class="group-head"><h3 id="h-shape">${as(813)}</h3></div>
      <div class="schips" role="group" aria-label=${as(814)}>
        ${e.map((e,i)=>{return a.qy`<button
            type="button"
            class="schip"
            data-i=${i}
            aria-pressed=${i===t?"true":"false"}
            aria-label=${s?as(820,{n:i+1,shape:Uu(e.shape),weight:e.weight}):as(819,{n:i+1,shape:Uu(e.shape)})}
            title=${Uu(e.shape)}
            @click=${()=>this._chip=i}
            @keydown=${e=>{"Delete"!==e.key&&"Backspace"!==e.key||!s||(e.preventDefault(),this._removeShape(i))}}
          >
            ${n=e.shape,"emoji"in n?a.qy`<span class="emo" aria-hidden="true">${n.emoji}</span>`:"icon"in n?a.qy`<ha-icon class="glyph" icon=${n.icon}></ha-icon>`:nf(Ku(n))}${s?a.qy`<span>${e.weight}</span>`:a.s6}
          </button>`;var n})}
        <button type="button" class="schip add" aria-label=${as(34)} title=${r?as(1213,{mAX_SHAPES:Gu}):as(34)} ?disabled=${r} @click=${()=>this._addShape()}>
          <ha-icon icon="mdi:plus"></ha-icon>
        </button>
      </div>
      <div class="chip-edit">
        <div class="chip-edit-head">
          <span>${as(818,{n:t+1})}</span>
          ${s?a.qy`<button type="button" class="icon-btn sm danger remove-shape" aria-label=${as(721,{n:t+1})} title=${as(720)} @click=${()=>this._removeShape(t)}>
                <ha-icon icon="mdi:delete-outline"></ha-icon>
              </button>`:a.s6}
        </div>
        ${this._shapeGrid(n,"main",as(818,{n:t+1}),(e,t)=>this._pickKind(e,t))}
        ${"icon"===n?this._renderIcon(i.shape):"emoji"===n?this._renderEmoji(i.shape):"svg"===n?this._renderSvg(i.shape):a.s6}
        ${s?this._renderWeight(e,t):a.s6}
      </div>
      ${s?a.s6:a.qy`<p class="help">${as(24)}</p>`}
    </section>`}_renderWeight(e,t){const i=e[t].weight;return a.qy`<div class="field">
      <div class="field-head"><label for="f-weight">${as(1078)}</label></div>
      <input
        id="f-weight"
        class="input"
        type="number"
        inputmode="numeric"
        min=${Ju.weight.min}
        max=${Ju.weight.max}
        step="1"
        .value=${U(String(i))}
        aria-describedby="h-weight"
        @change=${n=>{const s=n.target,r=Qu("weight",s.value);void 0!==r&&r!==i?(s.value=String(r),this._setShapes(e.map((e,i)=>i===t?{shape:e.shape,weight:r}:e),as(133))):s.value=String(i)}}
      />
      <p class="help" id="h-weight">${as(21,{percent:mm(e,t)})}</p>
    </div>`}_renderIcon(e){const t="icon"in e?e.icon:"";return a.qy`<div class="field">
      <div class="field-head"><span class="lbl" id="l-icon">${as(370)}</span></div>
      <mc-icon-picker
        .hass=${this.hass}
        .value=${t}
        label=${as(629)}
        aria-labelledby="l-icon"
        @value-changed=${e=>{e.stopPropagation();const i=String(e.detail.value??"").trim();(e=>Mu.test(e.trim()))(i)&&i!==t&&this._setChip(this._chip,{icon:i},"Change icon")}}
      ></mc-icon-picker>
    </div>`}_renderEmoji(e){const t="emoji"in e?e.emoji:"",i=this._emojiDraft??t,n=void 0!==this._emojiDraft?Su(this._emojiDraft):void 0,s=(e,t,i)=>{Su(e)||e.trim()===this._lastEmoji()||this._setChip(this._chip,{emoji:e.trim()},t,i)};return a.qy`<div class="field">
      <div class="field-head"><label for="f-emoji">${as(296)}</label></div>
      <div class="emoji-row">
        <span class="emoji-big" aria-hidden="true">${t}</span>
        <input
          id="f-emoji"
          class="input"
          type="text"
          maxlength="24"
          autocomplete="off"
          .value=${i}
          aria-invalid=${n?"true":"false"}
          aria-describedby=${n?"e-emoji":a.s6}
          @input=${e=>{const t=e.target.value;this._emojiDraft=t,s(t,"Change emoji",!0)}}
          @change=${()=>{void 0===this._emojiDraft||Su(this._emojiDraft)||(this._emojiDraft=void 0),this._settle()}}
        />
      </div>
      ${n?a.qy`<p class="help error" id="e-emoji" role="alert">${n}</p>`:a.s6}
      <div class="emoji-grid" role="group" aria-label=${as(174)}>
        ${ku.map(e=>a.qy`<button
            type="button"
            aria-pressed=${e===t?"true":"false"}
            aria-label=${as(1064,{emoji:e})}
            @click=${()=>{this._emojiDraft=void 0,e!==t&&this._setChip(this._chip,{emoji:e},"Change emoji")}}
          >
            ${e}
          </button>`)}
      </div>
    </div>`}_lastEmoji(){const e=this._chips()[this._chip]?.shape;return e&&"emoji"in e?e.emoji:""}_renderSvg(e){const t="svg"in e?e.svg:"",i=this._svgDraft??t,n=void 0!==this._svgDraft?zu(this._svgDraft):void 0,s=Qn({...this.doc,particles:{...this._p,sim:void 0,shape:{svg:t}}}),r=/mask: (url\("[^"]*"\))/.exec(s.css)?.[1];return a.qy`<div class="field">
      <div class="field-head"><label for="f-svg">${as(618)}</label></div>
      <div class="svg-row">
        <textarea
          id="f-svg"
          class="input"
          rows="4"
          spellcheck="false"
          .value=${i}
          aria-invalid=${n?"true":"false"}
          aria-describedby=${n?"e-svg h-svg":"h-svg"}
          @input=${e=>{const i=e.target.value;this._svgDraft=i,zu(i)||i===t||this._setChip(this._chip,{svg:i},"Edit SVG",!0)}}
          @change=${()=>{void 0===this._svgDraft||zu(this._svgDraft)||(this._svgDraft=void 0),this._settle()}}
        ></textarea>
        <span class="svg-thumb" aria-hidden="true" title=${as(982)}>
          ${r?a.qy`<span style=${`-webkit-mask: ${r} center / contain no-repeat; mask: ${r} center / contain no-repeat;`}></span>`:a.s6}
        </span>
      </div>
      ${n?a.qy`<p class="help error" id="e-svg" role="alert">${n}</p>`:a.s6}
      <p class="help" id="h-svg">${as(648)}</p>
    </div>`}_pickFlow(e,t=!1){this.doc&&this._sim.flow!==e&&this._emit(this._on(t=>function(e,t,i){return!am(e)&&(n=i,Tu.has(n))?Ou(e,{direction:i}):cm(e,t,e=>({...e,flow:i}));var n}(t,this._seed,e)),"Change flow"),t&&this._focus(`.dir[data-dir="${e}"]`)}_number(e,t,i,n){const s=Lu[e],r="count"===e?Math.min(s.max,i+Am(this.doc)):s.max;return a.qy`<input
      id=${t}
      class="input"
      type="number"
      inputmode="decimal"
      min=${s.min}
      max=${r}
      step=${"speed"===e?.1:1}
      .value=${String(i)}
      @change=${t=>{const s=t.target,a=Vu(e,s.value),o=void 0===a?void 0:Math.min(a,r);void 0!==o&&o!==i?(s.value=String(o),this._patch({[e]:o},n)):s.value=String(i)}}
    />`}_unit(e,t,i,n,s,r){return a.qy`<mc-unit-field
      .inputId=${t}
      .value=${`${i}${n}`}
      .units=${[n]}
      noCustom
      .label=${s}
      ?disabled=${this.disabled}
      @value-changed=${t=>{t.stopPropagation();const n=String(t.detail.value??""),a=""===n?r:Vu(e,n);void 0!==a&&a!==i?this._patch({[e]:a},s):t.target.revert?.()}}
    ></mc-unit-field>`}_range(e,t,i,n,s,r,o={}){const l=o.scale??1,c=[+(n[0]*l).toFixed(2),+(n[1]*l).toFixed(2)],d=Ju[s].step;return a.qy`<div class="field">
      <div class="field-head"><span class="lbl" id=${`l-${e}`}>${t}</span></div>
      <div class="pair" role="group" aria-labelledby=${`l-${e}`}>
        ${[0,1].map(t=>a.qy`<div>
            <label class="sub-lbl" for=${`f-${e}-${t}`}>${as(0===t?345:1011)}</label>
            <input
              id=${`f-${e}-${t}`}
              class="input"
              type="number"
              inputmode="decimal"
              min=${Ju[s].min}
              max=${Ju[s].max}
              step=${d}
              aria-label=${as(0===t?437:367,{noun:i})}
              .value=${U(String(c[t]))}
              @change=${e=>{const i=e.target,n=Qu(s,i.value);if(void 0===n)return void(i.value=String(c[t]));const a=em(0===t?[n,c[1]]:[c[0],n]);a[0]!==c[0]||a[1]!==c[1]?r([+(a[0]/l).toFixed(4),+(a[1]/l).toFixed(4)]):i.value=String(c[t])}}
            />
          </div>`)}
      </div>
      ${o.help?a.qy`<p class="help">${o.help}</p>`:a.s6}
    </div>`}_slider(e,t,i,n,s,r={}){return a.qy`<div class="field">
      <div class="field-head"><label for=${e}>${t}</label><span class="val">${n}</span></div>
      <div class="slider">
        <input
          id=${e}
          type="range"
          min="0"
          max="1"
          step=${Ju.unit.step}
          .value=${U(String(i))}
          aria-valuetext=${n}
          ?disabled=${r.disabled}
          @input=${e=>{const t=Qu("unit",e.target.value);void 0!==t&&s(t,!0)}}
          @change=${()=>this._settle()}
        />
      </div>
      ${r.help?a.qy`<p class="help">${r.help}</p>`:a.s6}
    </div>`}_renderTiming(e){return a.qy`<section class="group" aria-labelledby="h-timing">
      <div class="group-head"><h3 id="h-timing">${as(1010)}</h3></div>
      <div class="field">
        <div class="field-head"><label for="f-speed">${as(435)}</label></div>
        ${this._number("speed","f-speed",e.speed,as(130))}
      </div>
    </section>`}_renderMovement(e,t,i=!0){return a.qy`<section class="group" aria-labelledby="h-move">
      <div class="group-head"><h3 id="h-move">${as(495)}</h3></div>
      <div class="field">
        <div class="field-head"><span class="lbl" id="l-dir">${as(337)}</span></div>
        <div
          class="dirs"
          role="radiogroup"
          aria-labelledby="l-dir"
          @keydown=${e=>this._radioKeys(e,Nu,t.flow,e=>this._pickFlow(e,!0),this._cols(e.currentTarget))}
        >
          ${Nu.map(e=>a.qy`<button
              type="button"
              class="dir"
              role="radio"
              data-dir=${e}
              aria-checked=${e===t.flow?"true":"false"}
              tabindex=${e===t.flow?0:-1}
              title=${as(Fu[e])}
              @click=${()=>this._pickFlow(e)}
            >
              <span class="dir-pv ${e}" aria-hidden="true"><i></i><i></i><i></i></span>
              <span>${as(Fu[e])}</span>
            </button>`)}
        </div>
      </div>
      <div class=${i?"pair":a.s6}>
        ${i?a.qy`<div class="field">
              <div class="field-head"><label for="f-speed">${as(435)}</label></div>
              ${this._number("speed","f-speed",e.speed,as(130))}
            </div>`:a.s6}
        <div class="field">
          <div class="field-head"><label for="f-spread">${n=t.flow,Bu.has(n)?as(701):as("drift"===n||"wave"===n||"wander"===n?870:869)}</label></div>
          ${this._unit("spread","f-spread",e.spread,"%",as(131),100)}
        </div>
      </div>
      ${"rain"===t.flow?this._renderWind(t):a.s6}
      ${this._range("pspeed",as(632),as(1137),t.ranges.speed,"pspeed",e=>this._editSim(t=>({...t,ranges:{...t.ranges,speed:e}}),"Change particle speed"),{help:as(283)})}
    </section>`;var n}_renderWind(e){const t=(i=e.physics.gravity.angle,Eu(-(i>180?i-360:i),Ju.wind.min,Ju.wind.max)||0);var i;return a.qy`<div class="field">
      <div class="field-head"><label for="f-wind">${as(1083)}</label></div>
      <input
        id="f-wind"
        class="input"
        type="number"
        inputmode="numeric"
        min=${Ju.wind.min}
        max=${Ju.wind.max}
        step=${Ju.wind.step}
        .value=${U(String(t))}
        aria-describedby="h-wind"
        @change=${e=>{const i=e.target,n=Qu("wind",i.value);void 0!==n&&n!==t?(i.value=String(n),this._emit(this._on(e=>function(e,t,i){const n=rm(e,t).physics.gravity;return hm(e,t,(360-Eu(Math.round(i),Ju.wind.min,Ju.wind.max))%360,n.strength>0?n.strength/Yu:.5)}(e,this._seed,n)),"Change wind angle")):i.value=String(t)}}
      />
      <p class="help" id="h-wind">${as(537)}</p>
    </div>`}_setSize(e,t,i){const n=this._p,s=""===t?void 0:parseFloat(t);if(void 0===s||!Number.isFinite(s))return void i.revert?.();const r=function(e,t,i){const n=Eu(i,Lu.size.min,Lu.size.max);return 0===t?[n,Math.max(n,e[1])]:[Math.min(e[0],n),n]}(n.size,e,s);r[0]===n.size[0]&&r[1]===n.size[1]?i.revert?.():this._patch({size:r},"Change size")}_renderLook(e,t){return a.qy`<section class="group" aria-labelledby="h-look">
      <div class="group-head"><h3 id="h-look">${as(431)}</h3></div>
      <div class="field">
        <div class="field-head"><label for="f-count">${as(193)}</label></div>
        ${this._number("count","f-count",e.count,as(127))}
        ${this._multi?a.qy`<p class="help count-help">${as(1048,{parentsLeft:e.count+Am(this.doc),parents:Ho.parents})}</p>`:a.s6}
      </div>
      <div class="field">
        <div class="field-head"><span class="lbl" id="l-size">${as(832)}</span></div>
        <div class="pair" role="group" aria-labelledby="l-size">
          ${[0,1].map(t=>a.qy`<div>
              <label class="sub-lbl" for=${`f-size-${t}`}>${as(0===t?345:1011)}</label>
              <mc-unit-field
                compact
                .inputId=${`f-size-${t}`}
                .value=${`${e.size[t]}px`}
                .units=${["px"]}
                noCustom
                .label=${as(0===t?839:402)}
                ?disabled=${this.disabled}
                @value-changed=${e=>{e.stopPropagation(),this._setSize(t,String(e.detail.value??""),e.target)}}
              ></mc-unit-field>
            </div>`)}
        </div>
      </div>
      ${this._range("opacity",as(609),as(1132),t.ranges.opacity,"opacity",e=>this._editSim(t=>({...t,ranges:{...t.ranges,opacity:e}}),"Change opacity"),{scale:100})}
      ${this._renderColors(e)}
      <div class="switch-row">
        <span class="txt" id="l-fade">${as(316)}<p class="help">${as(635)}</p></span>
        <button
          type="button"
          class="switch fade"
          role="switch"
          aria-labelledby="l-fade"
          aria-checked=${e.fade?"true":"false"}
          @click=${()=>this._patch({fade:!e.fade},e.fade?as(1028):as(1029))}
        ></button>
      </div>
    </section>`}_pickLayer(e,t=!1){if(this.doc&&Om(this.doc,this._em)!==e){const t=this._name(this._em),i=as("front"===e?1115:1100);this._live=as(1231,{name:t,where:i}),this._emit(function(e,t,i,n){if(!Lm(e,i)||Om(e,i)===n)return e;if(1===zm(e))return Ou(e,{layer:n});const s=Em(e,t);return s[i].layer=n,Hm(e,t,s)}(this.doc,this._seed,this._em,e),`${t} ${i}`)}t&&this._focus(`.layer-seg [data-layer="${e}"]`)}_renderPlacement(){const e=Om(this.doc,this._em);return a.qy`<div class="field placement">
      <div class="field-head"><span class="lbl" id="l-place">${as(663)}</span></div>
      <div
        class="seg full layer-seg"
        role="radiogroup"
        aria-label=${as(663)}
        @keydown=${t=>this._radioKeys(t,["back","front"],e,e=>this._pickLayer(e,!0))}
      >
        ${["back","front"].map(t=>a.qy`<button type="button" role="radio" data-layer=${t} aria-checked=${e===t?"true":"false"} tabindex=${e===t?0:-1} aria-describedby="h-place" @click=${()=>this._pickLayer(t)}>
            ${as("back"===t?82:384)}
          </button>`)}
      </div>
      <p class="help placement-help" id="h-place">${as(385)}</p>
      <p class="em-live" role="status">${this._live}</p>
    </div>`}_addColor(){const e=this._p;if(e.colors.length>=dt)return;const t=sf.find(t=>!e.colors.includes(t))??sf[e.colors.length%sf.length];this._color=e.colors.length,this._patch({colors:[...e.colors,t]},"Add colour")}_removeColor(e){const t=this._p.colors.filter((t,i)=>i!==e);this._color=t.length?Math.min(e,t.length-1):-1,this._patch({colors:t},"Remove colour"),this.updateComplete.then(()=>(this.renderRoot.querySelector(`.cchip[data-i="${this._color}"]`)??this.renderRoot.querySelector(".cchip.add"))?.focus())}_renderColors(e){const t=this._color>=0&&this._color<e.colors.length?this._color:-1,i=e.colors.length>=dt;return a.qy`<div class="field">
      <div class="field-head">
        <span class="lbl" id="l-colors">${as(173)}</span>
        ${e.colors.length?a.qy`<span class="val">${as(1191,{count:e.colors.length,colours:dt})}</span>`:a.s6}
      </div>
      <div class="chips" role="group" aria-labelledby="l-colors">
        ${e.colors.map((e,i)=>{const n=qu(e).startsWith("entity");return a.qy`<button
            type="button"
            class="cchip"
            data-i=${i}
            aria-pressed=${i===t?"true":"false"}
            aria-label=${n?as(170,{n:i+1}):as(171,{n:i+1,colour:e})}
            title=${n?as(302):e}
            @click=${()=>this._color=i===t?-1:i}
            @keydown=${e=>{"Delete"!==e.key&&"Backspace"!==e.key||(e.preventDefault(),this._removeColor(i))}}
          >
            <span style=${`background: ${n?"var(--mc-text-2)":e}`}></span>
            ${n?a.qy`<ha-icon class="ent" icon="mdi:palette-swatch-variant"></ha-icon>`:a.s6}
          </button>`})}
        <button type="button" class="cchip add" aria-label=${as(27)} title=${i?as(1160,{colours:dt}):as(27)} ?disabled=${i} @click=${()=>this._addColor()}>
          <ha-icon icon="mdi:plus"></ha-icon>
        </button>
      </div>
      ${t>=0?a.qy`<div class="color-edit">
            <div class="color-edit-head">
              <span>${as(169,{n:t+1})}</span>
              <button
                type="button"
                class="icon-btn sm danger remove-color"
                aria-label=${as(713,{n:t+1})}
                title=${as(711)}
                @click=${()=>this._removeColor(t)}
              >
                <ha-icon icon="mdi:delete-outline"></ha-icon>
              </button>
            </div>
            <mc-color-picker
              allowEntity
              .label=${as(169,{n:t+1})}
              .value=${qu(e.colors[t])}
              @value-changed=${i=>{i.stopPropagation();const n=ju(String(i.detail.value??""));if(!n||n===e.colors[t])return;const s=[...e.colors];s[t]=n,this._patch({colors:s},"Change colour")}}
            ></mc-color-picker>
          </div>`:a.qy`<p class="help">${e.colors.length?as(637):as(555)}</p>`}
    </div>`}_sector(e,t,i,n,s){const r=!!this._open[e];return a.qy`<div class="sector" data-sector=${e}>
      <button
        type="button"
        class="sector-btn"
        aria-expanded=${r?"true":"false"}
        aria-controls=${r?`sb-${e}`:a.s6}
        @click=${()=>this._open={...this._open,[e]:!r}}
      >
        <ha-icon icon=${t}></ha-icon>
        <span class="nm">${i}<span class="sr-only">, </span><span class="ssum">${n}</span></span>
        <ha-icon class="chev" icon="mdi:chevron-down"></ha-icon>
      </button>
      ${r?a.qy`<div class="sector-body" id=${`sb-${e}`}>${s()}</div>`:a.s6}
    </div>`}_renderVariation(e){const t=this._vdoc;return a.qy`<div class="field">
        <div class="field-head"><label for="f-seed">${as(783)}</label></div>
        <div class="seed-row">
          <input
            id="f-seed"
            class="input"
            type="number"
            inputmode="numeric"
            min="0"
            max=${Ju.seed.max}
            step="1"
            .value=${U(String(e.seed))}
            aria-describedby="h-seed"
            @change=${t=>{const i=t.target,n=Qu("seed",i.value);void 0===n||n===e.seed&&this._p?.sim?i.value=String(e.seed):this._editSim(e=>({...e,seed:n}),"Change seed")}}
          />
          <button type="button" class="btn btn-secondary btn-sm shuffle-seed" @click=${this._shuffle}><ha-icon icon="mdi:dice-5-outline"></ha-icon>${as(828)}</button>
        </div>
        <p class="help" id="h-seed">${as(980)}</p>
      </div>
      ${this._range("spin",as(858),as(1138),pm(t,e),"spin",e=>this._emit(this._on(t=>function(e,t,i){const n=em(i);if(!am(e)&&n[0]===n[1])return Ou(e,{spin:n[0]});const s=tm(e);return cm(e,t,e=>({...e,ranges:{...e.ranges,spin:[nm(n[0]/s),nm(n[1]/s)]}}))}(t,this._seed,e)),"Change spin"),{help:as(284)})}
      ${this._range("delay",as(879),as(1139),e.ranges.delay,"delay",e=>this._editSim(t=>({...t,ranges:{...t.ranges,delay:e}}),"Change start delay"))}
      ${this._range("life",as(415),as(1122),e.ranges.lifetime,"lifetime",e=>this._editSim(t=>({...t,ranges:{...t.ranges,lifetime:e}}),"Change lifetime"),{help:as(14)})}`}_pickGravityAngle(e,t=!1){const i=this._sim,n=i.physics.gravity.strength/Yu;this.doc&&e!==i.physics.gravity.angle&&this._emit(this._on(t=>hm(t,this._seed,e,n)),"Change gravity direction"),t&&this._focus(`.compass [data-angle="${e}"]`)}_renderPhysics(e){const t=e.physics.gravity,i=+(t.strength/Yu).toFixed(2),n=+(e.physics.drag/3).toFixed(2),s=+(e.physics.turbulence.strength/150).toFixed(2),r=bm.map(e=>String(e.angle)),o=bm.some(e=>e.angle===t.angle);return a.qy`${this._slider("f-grav",as(351),i,i?i.toFixed(2):as(568),(e,i)=>this._emit(this._on(i=>hm(i,this._seed,t.angle,e)),"Change gravity",i))}
      <div class="field">
        <div class="field-head"><span class="lbl" id="l-gdir">${as(352)}</span></div>
        <div
          class="seg full compass"
          role="radiogroup"
          aria-labelledby="l-gdir"
          @keydown=${e=>this._radioKeys(e,r,String(t.angle),e=>this._pickGravityAngle(+e,!0))}
        >
          ${bm.map((e,i)=>a.qy`<button
              type="button"
              role="radio"
              data-angle=${e.angle}
              aria-checked=${e.angle===t.angle?"true":"false"}
              aria-label=${as(e.name)}
              title=${as(e.name)}
              tabindex=${e.angle===t.angle||!o&&0===i?0:-1}
              @click=${()=>this._pickGravityAngle(e.angle)}
            >
              <ha-icon icon=${e.icon}></ha-icon>
            </button>`)}
        </div>
      </div>
      <div class="field">
        <div class="field-head"><label for="f-gangle">${as(61)}</label></div>
        <input
          id="f-gangle"
          class="input"
          type="number"
          inputmode="numeric"
          min="0"
          max="359"
          step="1"
          .value=${U(String(t.angle))}
          aria-describedby="h-gangle"
          @change=${e=>{const n=e.target,s=Qu("angle",n.value);void 0!==s&&s!==t.angle?this._emit(this._on(e=>hm(e,this._seed,s,i)),"Change gravity direction"):n.value=String(t.angle)}}
        />
        <p class="help" id="h-gangle">${as(7)}</p>
      </div>
      ${this._slider("f-drag",as(247),n,n.toFixed(2),(e,t)=>this._editSim(t=>({...t,physics:{...t.physics,drag:+(3*e).toFixed(2)}}),"Change drag",t),{help:as(837)})}
      ${this._slider("f-turb",as(1024),s,s.toFixed(2),(e,t)=>this._editSim(t=>({...t,physics:{...t.physics,turbulence:{...t.physics.turbulence,strength:+(150*e).toFixed(2)}}}),"Change turbulence",t),{help:as(42)})}`}_setCollider(e,t){this._editSim(i=>({...i,colliders:{...i.colliders,..."content"===e?{content:t?"icon":"none"}:{[e]:t}}}),as(t?1027:1026))}_renderCollisions(e){const t=e.colliders,i=fm(t);return a.qy`<div class="checks" role="group" aria-label=${as(164)}>
        ${wm.map(e=>a.qy`<label class="check">
            <input type="checkbox" data-collider=${e.id} .checked=${km(t,e.id)} @change=${t=>this._setCollider(e.id,t.target.checked)} />
            ${as(e.label)}
          </label>`)}
      </div>
      ${"none"!==t.content?a.qy`<div class="field">
            <div class="field-head"><span class="lbl">${as(180)}</span></div>
            <div
              class="seg full content-seg"
              role="radiogroup"
              aria-label=${as(180)}
              @keydown=${e=>this._radioKeys(e,["icon","text"],t.content,e=>{e!==t.content&&this._editSim(t=>({...t,colliders:{...t.colliders,content:e}}),"Change content box"),this._focus(`.content-seg [data-content="${e}"]`)})}
            >
              ${["icon","text"].map(e=>a.qy`<button
                  type="button"
                  role="radio"
                  data-content=${e}
                  aria-checked=${t.content===e?"true":"false"}
                  tabindex=${t.content===e?0:-1}
                  @click=${()=>t.content!==e&&this._editSim(t=>({...t,colliders:{...t.colliders,content:e}}),"Change content box")}
                >
                  ${as("icon"===e?370:921)}
                </button>`)}
            </div>
            <p class="help">${as(940)}</p>
          </div>`:a.s6}
      ${this._slider("f-bounce",as(99),e.physics.bounce,e.physics.bounce.toFixed(2),(e,t)=>this._editAll(t=>({...t,physics:{...t.physics,bounce:e}}),"Change bounce",t),{help:as(8),disabled:!i})}`}_child(e,t){this._editSim(t=>t.children?{...t,children:{...t.children,...e}}:t,t)}_renderChildren(e){const t=e.children,i=fm(e.colliders),n=a.qy`<div class="switch-row">
      <span class="txt" id="l-children">${as(854)}<p class="help">${as(139)}</p></span>
      <button
        type="button"
        class="switch children"
        role="switch"
        aria-labelledby="l-children"
        aria-checked=${t?"true":"false"}
        @click=${()=>{t?this._editSim(e=>{const{children:t,...i}=e;return i},"Turn child particles off"):this._editSim(e=>({...e,children:vm(e)}),"Turn child particles on")}}
      ></button>
    </div>`;if(!t)return n;const s=[["collision",as(599)],["death",as(71)]],r=(e,n=!1)=>{("collision"!==e||i)&&(e!==t.trigger&&this._child({trigger:e,at:void 0},"Change child trigger"),n&&this._focus(`.trigger-seg [data-trigger="${e}"]`))},o=Ku(t.shapes[0]?.shape??{builtin:"circle"}),l=!t.colors.length;return a.qy`${n}
      <div class="field">
        <div class="field-head"><span class="lbl" id="l-trigger">${as(853)}</span></div>
        <div
          class="seg full trigger-seg"
          role="radiogroup"
          aria-labelledby="l-trigger"
          @keydown=${e=>this._radioKeys(e,i?["collision","death"]:["death"],t.trigger,e=>r(e,!0))}
        >
          ${s.map(([e,n])=>a.qy`<button
              type="button"
              role="radio"
              data-trigger=${e}
              aria-checked=${t.trigger===e?"true":"false"}
              tabindex=${t.trigger===e||"time"===t.trigger&&"death"===e?0:-1}
              ?disabled=${"collision"===e&&!i}
              @click=${()=>r(e)}
            >
              ${n}
            </button>`)}
        </div>
        ${i?a.s6:a.qy`<p class="help">${as(1030)}</p>`}
        ${"time"===t.trigger?a.qy`<p class="help">${as(855,{seconds:t.at??0})}</p>`:a.s6}
      </div>
      <div class="field">
        <div class="field-head"><label for="f-ccount">${as(194)}</label></div>
        <input
          id="f-ccount"
          class="input"
          type="number"
          inputmode="numeric"
          min="1"
          max=${Ju.childCount.max}
          step="1"
          .value=${U(String(t.count))}
          @change=${e=>{const i=e.target,n=Qu("childCount",i.value);void 0!==n&&n!==t.count?(i.value=String(n),this._child({count:n},"Change child count")):i.value=String(t.count)}}
        />
      </div>
      <div class="field">
        <div class="field-head"><span class="lbl">${as(138)}</span></div>
        ${this._shapeGrid(o,"child",as(138),(e,t)=>{if(e!==o){const t=this._sim.shapes.find(t=>Ku(t.shape)===e)?.shape;this._child({shapes:[{shape:t??this._shapeFor(e),weight:1}]},"Change child shape")}t&&this._focus(`.shapes.child [data-kind="${e}"]`)})}
      </div>
      ${this._range("csize",as(833),as(1101),t.size,"childSize",e=>this._child({size:e},"Change child size"))}
      ${this._range("cspeed",as(857),as(1102),t.ranges.speed,"pspeed",e=>this._child({ranges:{...t.ranges,speed:e}},"Change child speed"))}
      <div class="field">
        <div class="field-head"><label for="f-clife">${as(415)}</label></div>
        <input
          id="f-clife"
          class="input"
          type="number"
          inputmode="decimal"
          min=${Ju.childLife.min}
          max=${Ju.childLife.max}
          step="0.1"
          .value=${U(String(t.ranges.lifetime[1]))}
          @change=${e=>{const i=e.target,n=Qu("childLife",i.value);void 0===n||n===t.ranges.lifetime[0]&&n===t.ranges.lifetime[1]?i.value=String(t.ranges.lifetime[1]):this._child({ranges:{...t.ranges,lifetime:[n,n]}},"Change child lifetime")}}
        />
      </div>
      <div class="switch-row">
        <span class="txt" id="l-ccolors">${as(1062)}</span>
        <button
          type="button"
          class="switch child-colors"
          role="switch"
          aria-labelledby="l-ccolors"
          aria-checked=${l?"true":"false"}
          @click=${()=>this._child({colors:l?[this._p?.colors[0]??"#ffffff"]:[]},as(l?619:1062))}
        ></button>
      </div>
      ${l?a.s6:a.qy`<mc-color-picker
            allowEntity
            label=${as(135)}
            .value=${qu(t.colors[0])}
            @value-changed=${e=>{e.stopPropagation();const i=ju(String(e.detail.value??""));i&&i!==t.colors[0]&&this._child({colors:[i]},"Change child colour")}}
          ></mc-color-picker>`}`}_renderSectors(e,t){return a.qy`<div class="sectors">
      ${"all"===t?a.s6:this._sector("variation","mdi:dice-multiple-outline",as(1075),function(e,t){return as(784,{seed:String(t.seed),span:_m(pm(e,t),"°")})}(this._vdoc,e),()=>this._renderVariation(e))}
      ${"all"===t?a.s6:this._sector("physics","mdi:weight",as(654),function(e){const{gravity:t,drag:i,turbulence:n}=e.physics,s=t.strength/Yu,r=[s>0?as(353,{strength:s.toFixed(1),direction:ym(t.angle)}):as(557)];return i>0&&r.push(as(1108,{value:xm(i/3)})),n.strength>0&&r.push(as(1148,{value:xm(n.strength/150)})),r.join(", ")}(e),()=>this._renderPhysics(e))}
      ${"emitter"===t?a.s6:this._sector("collisions","mdi:arrow-collapse-down",as(165),function(e){const t=wm.filter(t=>km(e.colliders,t.id)).map(e=>as(e.label));return t.length?as(1212,{list:t.join(", "),bounce:xm(e.physics.bounce)}):as(597)}(e),()=>this._renderCollisions(e))}
      ${"all"===t?a.s6:this._sector("children","mdi:creation-outline",as(136),function(e){const t=e.children;if(!t)return as(597);const i=t.shapes[0]?.shape??{builtin:"circle"},n=Ku(i),s="svg"===n?as(762):"emoji"===n?as(1111):Uu(i).toLowerCase();return as(1178,{count:t.count,shape:s,trigger:(r=t,"collision"===r.trigger?as(1131):"death"===r.trigger?as(1098):as(1096,{seconds:xm(r.at??0)}))});var r}(e),()=>a.qy`<div class="sector-body-lk" ?inert=${this._locks.kids.length>0}>${this._renderChildren(e)}</div>`)}
    </div>`}_renderPreset(e){const t=Pu(this.doc),i=t?((e,t)=>e.particles?.intensity??t.defaults.intensity)(this.doc,t):void 0;return a.qy`<section class="group preset-card" aria-labelledby="h-preset">
      <div class="preset-name">
        <span class="tile" aria-hidden="true"><ha-icon icon="mdi:shimmer"></ha-icon></span>
        <span class="txt">
          <strong id="h-preset">${t?(0,te.t)(t.name):e.preset}</strong>
          <span class="kind">${t?as(81,{kind:Ru(t).toLowerCase()}):as(1040)}</span>
        </span>
      </div>
      ${t?a.qy`<div class="field">
            <div class="field-head"><label for="f-intensity">${((e,t)=>e.intensity.unit?`${t(e.intensity.label)} (${e.intensity.unit})`:t(e.intensity.label))(t,as)}</label></div>
            <input
              id="f-intensity"
              class="input"
              type="number"
              inputmode="decimal"
              min=${t.intensity.min}
              max=${t.intensity.max}
              step=${t.intensity.step??1}
              placeholder=${String(t.defaults.intensity)}
              .value=${void 0===e.intensity?"":String(i)}
              @change=${i=>{const n=i.target.value,s=function(e,t,i){return void 0!==i&&Number.isFinite(i)?Ou(e,{intensity:Eu(i,t.intensity.min,t.intensity.max)}):Ou(e,{intensity:void 0})}(this.doc,t,""===n?void 0:Number(n));s.particles.intensity!==e.intensity?this._emit(s,"Change intensity"):i.target.value=void 0===e.intensity?"":String(e.intensity)}}
            />
            <p class="help">${as(83,{min:t.intensity.min,max:t.intensity.max,intensity:t.defaults.intensity})}</p>
          </div>`:a.qy`<p class="help error">${as(1006)}</p>`}
      <button type="button" class="btn btn-secondary btn-sm convert" @click=${this._convert}>
        <ha-icon icon="mdi:creation-outline"></ha-icon>${as(182)}
      </button>
      <p class="help">
        ${as(915)}
        ${!t||"count"!==t.particles||t.ring||t.seasonal?as(992):as(960)}
      </p>
    </section>`}get _locks(){const e=this.doc,t=this.layerView;if(!e||!t?.locked.length)return{own:[],kids:[]};const i=e.particles?.sim?uo(e):["main"],n=this.all&&i.length>1?i:[i[Math.min(this._em,i.length-1)]??"main"];return{own:n.filter(i=>wo(e,t,`emitter:${i}`)).map(e=>`emitter:${e}`),kids:n.filter(i=>wo(e,t,`children:${i}`)).map(e=>`children:${e}`)}}render(){const e=this._p;if(!this.doc||!e)return a.qy`<div class="empty"><ha-icon icon="mdi:shimmer"></ha-icon><p>${as(611)}</p></div>`;const t=e.preset?void 0:this._sim;return a.qy`<style data-pv></style>
      <style data-live></style>
      <div class="wrap">
        ${this._renderPreview()}
        <div class="form" ?inert=${this.disabled} @focusout=${this._onFocusOut}>
          ${this._locks.own.length?jo(this.doc,this.layerView,this._locks.own):a.s6}
          ${t?this._renderForm(e,t):a.qy`<div class="lk" ?inert=${this._locks.own.length>0}>${this._renderPreset(e)}</div>`}
        </div>
      </div>`}_renderForm(e,t){const i=this._multi,n=i&&this.all;return a.qy`${this._renderBar()}
      <div class="lk" ?inert=${this._locks.own.length>0}>
      ${n?a.qy`<p class="help all-note">${as(991)}</p>
            ${this._renderMode(t)}${this._renderTiming(e)}${this._renderSectors(t,"all")}`:a.qy`${i?this._renderEmitterHead():a.s6}${this._renderPlacement()}
            ${i?a.s6:this._renderMode(t)}${this._renderShape()}${this._renderMovement(e,t,!i)}${this._renderLook(e,t)}${this._renderSectors(t,i?"emitter":void 0)}`}
      </div>`}_renderBar(){const e=this.doc,t=zm(e),i=jm(e),n=this.all?"all":String(this._em),s=["all",...Array.from({length:t},(e,t)=>String(t))];return a.qy`<div class="em-bar">
      ${t>1?a.qy`<div class="em-tabs">${Nd({role:"tablist",label:as(294),value:n,items:s.map(e=>({value:e,label:"all"===e?as(48):this._name(+e)})),onChange:e=>{"all"===e?this._select(this._em,!0):this._select(+e),this._focus(`.em-tabs [data-val="${e}"]`)}})}</div>`:a.s6}
      <button type="button" class="btn btn-secondary btn-sm em-add" ?disabled=${!i||this.disabled} aria-describedby=${i?a.s6:"h-em-cap"} @click=${this._addEmitter}>
        <ha-icon icon="mdi:plus"></ha-icon>${as(28)}
      </button>
      ${i?a.s6:a.qy`<p class="help em-cap" id="h-em-cap">${t>=Ho.emitters?as(1192,{emitters:Ho.emitters}):as(556)}</p>`}
    </div>`}_renderEmitterHead(){const e=this._em,t=this.doc.particles.sim,i=(0===e?t.name:t.emitters?.[e-1]?.name)??"";return a.qy`<div class="em-head">
      <div class="field em-name-field">
        <div class="field-head"><label for="f-em-name">${as(293)}</label></div>
        <input
          id="f-em-name"
          class="input em-name"
          type="text"
          maxlength=${40}
          placeholder=${Dm(this.doc,this._seed,e)}
          .value=${U(i)}
          @change=${t=>{const i=t.target,n=Vm(this.doc,this._seed,e,i.value);i.value=(0===e?n.particles.sim.name:n.particles.sim.emitters?.[e-1]?.name)??"",this._emit(n,"Rename emitter")}}
        />
      </div>
      <button type="button" class="icon-btn sm em-dup" aria-label=${as(276)} title=${as(276)} ?disabled=${!jm(this.doc)||this.disabled} @click=${this._dupEmitter}>
        <ha-icon icon="mdi:content-copy"></ha-icon>
      </button>
      <button type="button" class="icon-btn sm danger em-remove" aria-label=${as(715)} title=${as(715)} ?disabled=${this.disabled} @click=${this._removeEmitter}>
        <ha-icon icon="mdi:delete-outline"></ha-icon>
      </button>
    </div>`}};rf.styles=[dh,Oh,Ao,a.AH`
      .lk[inert],
      .sector-body[inert] {
        opacity: 0.55;
      }
      :host {
        display: block;
        container-type: inline-size;
        color: var(--mc-text);
      }
      :host([disabled]) .form {
        opacity: 0.55;
      }
      .wrap {
        display: grid;
        gap: 20px;
      }
      .form {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        gap: 0;
        min-width: 0;
        container: form / inline-size;
      }
      .form > * {
        min-width: 0;
      }
      .form > .group {
        padding-bottom: 20px;
      }
      .form > .group:last-child,
      .form > .sectors {
        margin-bottom: 0;
      }
      .group-head h3 {
        color: var(--mc-text);
      }

      /* ── preview ── */
      .preview {
        display: grid;
        gap: 6px;
      }
      .stage {
        position: relative;
        height: 128px;
        border-radius: var(--mc-radius-lg);
        border: 1px solid var(--mc-divider);
        background-color: var(--mc-canvas);
        background-image: radial-gradient(var(--mc-canvas-dot) 1px, transparent 1.2px);
        background-size: 14px 14px;
        display: grid;
        place-items: center;
        overflow: hidden;
      }
      .stage-module {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 14px 8px 10px;
        padding-inline: 10px 14px;
        border-radius: 12px;
        background: var(--mc-surface);
        border: 1px solid var(--mc-divider);
        font-size: 0.8125rem;
        font-weight: 500;
        color: var(--mc-text);
        --mdc-icon-size: 20px;
      }
      .stage-module ha-icon {
        color: var(--mc-text-2);
      }
      .stage mc-seasonal {
        z-index: -1;
        pointer-events: none;
      }
      .stage[data-paused] .mc-anim-fx > i {
        animation-play-state: paused;
      }
      .preview-foot {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        min-width: 0;
      }
      .preview-foot .sum {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .reduced-note {
        display: none;
      }
      @media (prefers-reduced-motion: reduce) {
        .reduced-note {
          display: block;
        }
      }

      /* ── emitters ── */
      .em-bar {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
        padding-bottom: 16px;
      }
      .em-tabs {
        flex: 1 1 100%;
        min-width: 0;
        display: flex;
      }
      .em-tabs .seg,
      .placement .seg {
        flex-wrap: wrap;
        max-width: 100%;
      }
      .placement .seg > button {
        flex: 1 1 0;
        white-space: normal;
      }
      .em-tabs .seg > button {
        max-width: 160px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .em-cap {
        flex-basis: 100%;
        margin: 0;
      }
      .em-head {
        display: flex;
        align-items: flex-end;
        gap: 4px;
        padding-bottom: 16px;
      }
      .em-name-field {
        flex: 1;
        min-width: 0;
      }
      .all-note {
        margin: 0 0 16px;
      }
      .placement {
        padding-bottom: 20px;
      }
      .em-live {
        margin: 0;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .em-live:empty {
        display: none;
      }

      /* ── mode ── */
      .note.is-warn {
        display: flex;
        gap: 8px;
        align-items: flex-start;
        margin: 0;
        padding: 10px 12px;
        border-radius: var(--mc-radius);
        background: var(--mc-warn-tint);
        border: 1px solid color-mix(in srgb, var(--mc-warn-ink) 40%, transparent);
        color: var(--mc-text);
        font-size: 0.8125rem;
        line-height: 1.4;
      }
      .note.is-warn ha-icon {
        flex: none;
        --mdc-icon-size: 18px;
        color: var(--mc-warn-ink);
      }
      .mode-status > .help {
        margin: 0;
      }

      /* ── shape ── */
      .glyph {
        width: 18px;
        height: 18px;
        --mdc-icon-size: 18px;
      }
      .schips {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }
      .schip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        height: 32px;
        min-width: 32px;
        padding: 0 8px;
        border-radius: 16px;
        border: 1px solid var(--mc-field-border);
        background: var(--mc-surface);
        color: var(--mc-text);
        font-size: 0.75rem;
        font-variant-numeric: tabular-nums;
        justify-content: center;
      }
      .schip .emo {
        font-size: 1rem;
        line-height: 1;
      }
      .schip[aria-pressed='true'] {
        border-color: var(--mc-accent);
        box-shadow: 0 0 0 1px var(--mc-accent);
      }
      .schip.add {
        border-style: dashed;
        color: var(--mc-text-2);
        --mdc-icon-size: 18px;
      }
      .schip.add:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }
      .chip-edit {
        display: grid;
        gap: 12px;
        padding: 12px;
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius-lg);
      }
      .chip-edit-head {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 24px;
        font-size: 0.8125rem;
        font-weight: 500;
      }
      .chip-edit-head > span {
        flex: 1;
      }
      .chip-edit-head .icon-btn {
        margin: -4px -6px -4px 0;
        margin-inline: 0 -6px;
      }
      .emoji-grid {
        display: grid;
        grid-template-columns: repeat(8, minmax(0, 1fr));
        gap: 4px;
      }
      .emoji-grid button {
        height: 36px;
        min-width: 0;
        padding: 0;
        border: 1px solid transparent;
        border-radius: var(--mc-radius);
        background: transparent;
        font-size: 1.15rem;
        line-height: 1;
        transition: background-color 0.15s ease-out, border-color 0.15s ease-out;
      }
      .emoji-grid button:hover {
        background: var(--mc-surface-2);
      }
      .emoji-grid button[aria-pressed='true'] {
        border-color: color-mix(in srgb, var(--mc-accent) 55%, transparent);
        background: var(--mc-accent-tint);
      }
      .emoji-row {
        display: flex;
        gap: 8px;
        align-items: center;
      }
      .emoji-row .input {
        flex: 1;
        min-width: 0;
        font-size: 1rem;
      }
      .emoji-big {
        flex: none;
        width: 40px;
        height: 40px;
        display: grid;
        place-items: center;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface-2);
        font-size: 1.35rem;
      }
      .svg-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 56px;
        gap: 8px;
        align-items: start;
      }
      .svg-thumb {
        width: 56px;
        height: 56px;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface-2);
        display: grid;
        place-items: center;
      }
      .svg-thumb > span {
        width: 32px;
        height: 32px;
        background: var(--mc-text);
      }
      textarea.input[aria-invalid='true'],
      .input[aria-invalid='true'] {
        border-color: var(--mc-error-ink);
      }

      /* ── tiles (flows, shapes) ── */
      .dirs,
      .shapes {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 8px;
      }
      .dir {
        display: grid;
        gap: 4px;
        justify-items: center;
        align-content: center;
        min-height: 44px;
        padding: 6px 4px 6px;
        min-width: 0;
        border-radius: var(--mc-radius);
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface);
        color: var(--mc-text-2);
        font-size: 0.75rem;
        font-weight: 500;
        transition: border-color 0.15s ease-out, background-color 0.15s ease-out, color 0.15s ease-out;
      }
      .dir > span:last-child {
        max-width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .dir:hover {
        border-color: var(--mc-field-border);
        color: var(--mc-text);
      }
      .dir[aria-checked='true'] {
        border-color: var(--mc-accent);
        box-shadow: inset 0 0 0 1px var(--mc-accent);
        background: var(--mc-accent-tint);
        color: var(--mc-accent-ink);
      }
      .dir-pv {
        position: relative;
        width: 100%;
        height: 34px;
        overflow: hidden;
        border-radius: 6px;
        background: var(--mc-surface-2);
      }
      .dir[aria-checked='true'] .dir-pv {
        background: color-mix(in srgb, var(--mc-surface) 70%, transparent);
      }
      .dir-pv i {
        position: absolute;
        width: 5px;
        height: 5px;
        margin: -2.5px 0 0 -2.5px;
        border-radius: 50%;
        background: currentColor;
        animation: var(--a) 1.8s linear infinite;
        animation-delay: calc(var(--n) * -0.6s);
      }
      .dir-pv i:nth-child(1) { --n: 0; }
      .dir-pv i:nth-child(2) { --n: 1; }
      .dir-pv i:nth-child(3) { --n: 2; }
      .dir-pv.fall i, .dir-pv.rise i, .dir-pv.zigzag i, .dir-pv.rain i { left: calc(25% + var(--n) * 25%); /* physical */ top: 0; }
      .dir-pv.fall i { --a: pv-fall; }
      .dir-pv.rise i { --a: pv-rise; }
      .dir-pv.zigzag i { --a: pv-zigzag; animation-duration: 2.2s; animation-delay: calc(var(--n) * -0.73s); }
      .dir-pv.rain i { --a: pv-rain; width: 2px; height: 7px; border-radius: 1px; animation-duration: 0.9s; animation-delay: calc(var(--n) * -0.3s); }
      .dir-pv.drift i, .dir-pv.wave i { left: 0; /* physical */ top: calc(30% + var(--n) * 20%); animation-duration: 2.4s; animation-delay: calc(var(--n) * -0.8s); }
      .dir-pv.drift i { --a: pv-drift; }
      .dir-pv.wave i { --a: pv-wave; }
      .dir-pv.burst i, .dir-pv.orbit i, .dir-pv.spiral i, .dir-pv.vortex i, .dir-pv.explode i { left: 50%; /* physical */ top: 50%; }
      .dir-pv.burst i { --a: pv-burst; animation-delay: calc(var(--n) * -0.15s); animation-timing-function: ease-out; }
      .dir-pv.orbit i { --a: pv-orbit; animation-duration: 2.4s; animation-delay: calc(var(--n) * -0.8s); }
      .dir-pv.spiral i { --a: pv-spiral; animation-duration: 2.4s; animation-delay: calc(var(--n) * -0.8s); }
      .dir-pv.vortex i { --a: pv-vortex; animation-duration: 2.4s; animation-delay: calc(var(--n) * -0.8s); }
      .dir-pv.explode i { top: 30%; --a: pv-explode; animation-duration: 2s; animation-delay: calc(var(--n) * -0.1s); }
      .dir-pv.fountain i { left: 50%; /* physical */ top: 100%; --a: pv-fountain; animation-duration: 1.8s; }
      .dir-pv.wander i { left: calc(25% + var(--n) * 25%); /* physical */ top: 50%; --a: pv-wander; animation-duration: 3s; animation-delay: calc(var(--n) * -1s); }
      @keyframes pv-fall {
        from { translate: 0 -4px; opacity: 0; }
        20%, 80% { opacity: 1; }
        to { translate: 0 38px; opacity: 0; }
      }
      @keyframes pv-rise {
        from { translate: 0 38px; opacity: 0; }
        20%, 80% { opacity: 1; }
        to { translate: 0 -4px; opacity: 0; }
      }
      @keyframes pv-drift {
        from { translate: -4px 0; opacity: 0; }
        20%, 80% { opacity: 1; }
        to { translate: 80px 0; opacity: 0; }
      }
      @keyframes pv-wave {
        0% { translate: -4px 0; opacity: 0; }
        20% { opacity: 1; }
        25% { translate: 18px -6px; }
        50% { translate: 38px 0; }
        75% { translate: 58px 6px; }
        80% { opacity: 1; }
        100% { translate: 80px 0; opacity: 0; }
      }
      @keyframes pv-zigzag {
        0% { translate: 0 -4px; opacity: 0; }
        20% { opacity: 1; }
        25% { translate: 6px 6px; }
        50% { translate: -6px 16px; }
        75% { translate: 6px 26px; }
        80% { opacity: 1; }
        100% { translate: 0 38px; opacity: 0; }
      }
      @keyframes pv-rain {
        from { translate: 6px -8px; opacity: 0; }
        15%, 85% { opacity: 1; }
        to { translate: -6px 38px; opacity: 0; }
      }
      @keyframes pv-burst {
        from { transform: rotate(calc(var(--n) * 120deg)) translateY(0); opacity: 0; }
        10%, 60% { opacity: 1; }
        to { transform: rotate(calc(var(--n) * 120deg)) translateY(-15px); opacity: 0; }
      }
      @keyframes pv-explode {
        0% { translate: 0 0; opacity: 0; }
        10% { opacity: 1; }
        35% { translate: calc((var(--n) - 1) * 16px) -8px; }
        85% { opacity: 1; }
        100% { translate: calc((var(--n) - 1) * 24px) 26px; opacity: 0; }
      }
      @keyframes pv-fountain {
        0% { translate: 0 0; opacity: 0; }
        10% { opacity: 1; }
        45% { translate: calc((var(--n) - 1) * 10px) -30px; }
        85% { opacity: 1; }
        100% { translate: calc((var(--n) - 1) * 20px) 0; opacity: 0; }
      }
      @keyframes pv-orbit {
        from { transform: rotate(0deg) translateY(-11px); }
        to { transform: rotate(360deg) translateY(-11px); }
      }
      @keyframes pv-spiral {
        from { transform: rotate(0deg) translateY(0); opacity: 0; }
        25%, 75% { opacity: 1; }
        to { transform: rotate(540deg) translateY(-15px); opacity: 0; }
      }
      @keyframes pv-vortex {
        from { transform: rotate(0deg) translateY(-15px); opacity: 0; }
        25%, 75% { opacity: 1; }
        to { transform: rotate(540deg) translateY(0); opacity: 0; }
      }
      @keyframes pv-wander {
        0%, 100% { translate: 0 0; opacity: 0.3; }
        25% { translate: 8px -6px; opacity: 1; }
        50% { translate: -4px 6px; opacity: 0.5; }
        75% { translate: 6px 4px; opacity: 1; }
      }
      .shape-tile {
        min-height: 52px;
        --mdc-icon-size: 22px;
      }
      .shape-tile .glyph {
        width: 22px;
        height: 22px;
        --mdc-icon-size: 22px;
      }
      @media (prefers-reduced-motion: reduce) {
        .dir-pv i {
          animation-play-state: paused;
        }
      }

      /* ── numbers ── */
      .pair {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }
      .sub-lbl {
        display: block;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        margin-bottom: 4px;
      }
      .slider {
        display: grid;
        grid-template-columns: minmax(0, 1fr);
        align-items: center;
        min-height: 32px;
      }
      .slider input[type='range'] {
        width: 100%;
        margin: 0;
        accent-color: var(--mc-accent-fill);
      }
      .field-head .val {
        font-size: 0.75rem;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .seg.compass button {
        padding: 0;
        min-width: 32px;
        flex: 1;
        --mdc-icon-size: 18px;
      }

      /* ── colours ── */
      .chips {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }
      .cchip {
        position: relative;
        width: 32px;
        height: 32px;
        padding: 3px;
        border-radius: 50%;
        border: 1px solid var(--mc-field-border);
        background: var(--mc-surface);
        display: grid;
        place-items: center;
      }
      .cchip > span {
        display: block;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--mc-text) 18%, transparent);
      }
      .cchip > ha-icon.ent {
        position: absolute;
        --mdc-icon-size: 14px;
        color: var(--mc-surface);
      }
      .cchip[aria-pressed='true'] {
        border-color: var(--mc-accent);
        box-shadow: 0 0 0 1px var(--mc-accent);
      }
      .cchip.add {
        border-style: dashed;
        color: var(--mc-text-2);
        --mdc-icon-size: 18px;
      }
      .cchip.add:hover:not(:disabled) {
        color: var(--mc-text);
        border-color: var(--mc-text-2);
      }
      .cchip.add:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }
      .color-edit {
        display: grid;
        gap: 8px;
        padding: 12px;
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius-lg);
      }
      .color-edit-head {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 24px;
        font-size: 0.8125rem;
        font-weight: 500;
      }
      .color-edit-head > span {
        flex: 1;
      }
      .color-edit-head .icon-btn {
        margin: -4px -6px -4px 0;
        margin-inline: 0 -6px;
      }

      /* ── closed sections ── */
      .sector-btn .nm {
        display: grid;
        gap: 2px;
      }
      .sector-btn .ssum {
        font-size: 0.75rem;
        font-weight: 400;
        color: var(--mc-text-2);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .seed-row {
        display: flex;
        gap: 8px;
        align-items: center;
      }
      .seed-row .input {
        flex: 1;
        min-width: 0;
      }
      .checks {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 4px 12px;
      }
      .check {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 32px;
        font-size: 0.8125rem;
      }
      .check input {
        width: 18px;
        height: 18px;
        margin: 0;
        accent-color: var(--mc-accent-fill);
      }

      /* ── preset-based ── */
      .preset-card {
        display: grid;
        gap: 12px;
      }
      .preset-name {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
      }
      .preset-name .tile {
        flex: none;
        width: 36px;
        height: 36px;
        border-radius: var(--mc-radius);
        display: grid;
        place-items: center;
        background: var(--mc-surface-2);
        color: var(--mc-text-2);
        --mdc-icon-size: 20px;
      }
      .preset-name .txt {
        display: grid;
        gap: 2px;
        min-width: 0;
      }
      .preset-name strong {
        font-size: 0.875rem;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .preset-name .kind {
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .convert {
        justify-self: start;
      }

      /* the wide panel: preview beside the fields */
      @container (min-width: 640px) {
        .wrap {
          grid-template-columns: minmax(240px, 320px) minmax(0, 1fr);
          align-items: start;
          gap: 24px;
        }
        .preview {
          position: sticky;
          top: 0;
        }
        .stage {
          height: 180px;
        }
      }
      /* a wide form (the bottom panel): more tiles per row */
      @container form (min-width: 480px) {
        .dirs {
          grid-template-columns: repeat(5, minmax(0, 1fr));
        }
        .shapes {
          grid-template-columns: repeat(6, minmax(0, 1fr));
        }
        .checks {
          grid-template-columns: repeat(3, minmax(0, 1fr));
        }
      }
    `],ef([(0,o.MZ)({attribute:!1})],rf.prototype,"doc",void 0),ef([(0,o.MZ)({attribute:!1})],rf.prototype,"hass",void 0),ef([(0,o.MZ)({attribute:!1})],rf.prototype,"library",void 0),ef([(0,o.MZ)({attribute:!1})],rf.prototype,"time",void 0),ef([(0,o.MZ)({type:Boolean,reflect:!0})],rf.prototype,"disabled",void 0),ef([(0,o.MZ)({attribute:!1})],rf.prototype,"layerView",void 0),ef([(0,o.MZ)({type:Number})],rf.prototype,"emitter",void 0),ef([(0,o.wk)()],rf.prototype,"_shapes",void 0),ef([(0,o.wk)()],rf.prototype,"_svgDraft",void 0),ef([(0,o.wk)()],rf.prototype,"_emojiDraft",void 0),ef([(0,o.wk)()],rf.prototype,"_color",void 0),ef([(0,o.wk)()],rf.prototype,"_chip",void 0),ef([(0,o.wk)()],rf.prototype,"_paused",void 0),ef([(0,o.wk)()],rf.prototype,"_open",void 0),ef([(0,o.wk)()],rf.prototype,"_stats",void 0),ef([(0,o.wk)()],rf.prototype,"_baking",void 0),ef([(0,o.MZ)({type:Boolean})],rf.prototype,"all",void 0),ef([(0,o.wk)()],rf.prototype,"_live",void 0),rf=ef([(0,o.EM)("mc-anim-particles-editor")],rf);var af=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const of=[{value:"element",label:291,icon:"mdi:square-rounded-outline"},{value:"icon",label:370,icon:"mdi:star-outline"},{value:"particles",label:633,icon:"mdi:scatter-plot-outline"}],lf=[{value:"percent",label:2},{value:"px",label:662}],cf={count:3,size:[6,12],colors:[]},df={d:"",units:"percent",follow_rotation:!1,subject:"element"},pf=new Map;let hf=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1}get _spec(){return this.doc?.path??df}_locked(e){return!!this.layerView?.locked.includes(e)}_emit(e,t){if(!this.doc||this.disabled)return;const i={...this.doc,path:e};this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:i,label:t}}))}_set(e,t){this._emit({...this._spec,...e},t)}_edit(e,t){this._set({d:wa(e(_a(this._spec.d)))},t)}_template(e,t){const i=this._spec;this._set({d:ja(e,qa({subject:i.subject,units:"percent"})),units:"percent"},`Use ${t.toLowerCase()} path`)}_subject(e){const t=this._spec;if(e===t.subject)return;const i={subject:e},n="particles"===t.subject,s="particles"===e;if("percent"===t.units&&n!==s&&t.d){const e=s?50:-50;i.d=wa(Ma(_a(t.d),e,e))}s&&!t.particles&&(i.particles={...cf,size:[...cf.size],colors:[]}),this._set(i,"What moves")}_look(e,t){const i=this._spec.particles??cf;this._set({particles:{...i,size:[...i.size],colors:[...i.colors],...e}},t)}_seg(e,t,i,n){return a.qy`<div class="seg full" role="radiogroup" aria-label=${e} @keydown=${e=>{const s=t.findIndex(e=>e.value===i),r="rtl"===x(e.currentTarget)?-1:1,a={ArrowRight:r,ArrowDown:1,ArrowLeft:-r,ArrowUp:-1};if(!(e.key in a))return;e.preventDefault();const o=t[(s+a[e.key]+t.length)%t.length].value,l=e.currentTarget;n(o),requestAnimationFrame(()=>l.querySelector(`[data-val="${o}"]`)?.focus())}}>
      ${t.map(e=>{const t=e.value===i;return a.qy`<button
          type="button"
          role="radio"
          data-val=${e.value}
          aria-checked=${t?"true":"false"}
          tabindex=${t?"0":"-1"}
          ?disabled=${this.disabled}
          @click=${()=>n(e.value)}
        >
          ${e.icon?a.qy`<ha-icon icon=${e.icon}></ha-icon>`:a.s6}${as(e.label)}
        </button>`})}
    </div>`}_switch(e,t,i,n,s,r=!1){return a.qy`<div class="switch-row">
      <div class="txt">
        <span class="lbl">${e}</span>
        <p class="help">${t}</p>
      </div>
      <button
        type="button"
        class="switch ${s}"
        role="switch"
        aria-checked=${i?"true":"false"}
        aria-label=${e}
        ?disabled=${this.disabled||r}
        @click=${n}
      ></button>
    </div>`}_templates(){return a.qy`<div class="tiles">
      ${Ca.map(e=>{const t=function(e){let t=pf.get(e);if(!t){const i=ja(e),n=ka(_a(i))??{x:-40,y:-40,w:80,h:80},s=6;let r=n.w+2*s,a=n.h+2*s;const o=44/30;r/a<o?r=a*o:a=r/o;const l=n.x+n.w/2,c=n.y+n.h/2;t={d:i,box:`${(l-r/2).toFixed(2)} ${(c-a/2).toFixed(2)} ${r.toFixed(2)} ${a.toFixed(2)}`},pf.set(e,t)}return t}(e.id),i=_a(t.d).anchors[0];return a.qy`<button
          type="button"
          class="tile"
          data-template=${e.id}
          title=${as(734,{name:as(e.label).toLowerCase()})}
          ?disabled=${this.disabled}
          @click=${()=>this._template(e.id,as(e.label))}
        >
          <svg viewBox=${t.box} aria-hidden="true">
            <path d=${t.d}></path>
            ${i?a.JW`<circle cx=${i.x} cy=${i.y} r=${t.box.split(" ").map(Number)[2]/18}></circle>`:a.s6}
          </svg>
          <span>${as(e.label)}</span>
        </button>`})}
    </div>`}_pathSection(e){const t=e.anchors.length,i=e.anchors.filter(e=>e.in||e.out).length,n=t>1&&!this.disabled;return a.qy`<section class="sec" aria-label=${as(645)}><div class="lk-path" ?inert=${this._locked("path")}>
      <div class="field">
        <div class="field-head"><span class="lbl">${as(880)}</span></div>
        ${this._templates()}
      </div>
      <div class="stats" aria-live="polite">
        <span class="chip">${as(1172,{count:t})}</span>
        <span class="chip">${e.closed?as(160):as(610)}</span>
        ${t>1?a.qy`<span class="chip">${as(0===i?908:i===t?203:446)}</span>`:a.s6}
      </div>
      <div class="actions">
        <button type="button" class="btn btn-secondary btn-sm smooth-all" ?disabled=${!n} @click=${()=>this._edit(xa.smoothAll,"Smooth all points")}>
          <ha-icon icon="mdi:vector-curve"></ha-icon>${as(841)}
        </button>
        <button type="button" class="btn btn-secondary btn-sm straighten-all" ?disabled=${!n} @click=${()=>this._edit(xa.straightenAll,"Straighten all points")}>
          <ha-icon icon="mdi:vector-polyline"></ha-icon>${as(909)}
        </button>
        <button type="button" class="btn btn-secondary btn-sm reverse" ?disabled=${!n} @click=${()=>this._edit($a,"Reverse direction")}>
          <ha-icon icon="mdi:swap-horizontal"></ha-icon>${as(746)}
        </button>
      </div>
      ${this._switch(as(161),as(963),e.closed,()=>{t>1&&this._edit(t=>(0,xa.setClosed)(t,!e.closed),e.closed?as(612):as(159))},"closed-switch",t<2)}
      <ul class="tips help">
        <li>${as(151)}</li>
        <li>${as(249)} ${os(1198,{key:a.qy`<kbd>Alt</kbd>`})}</li>
        <li>${as(244)} ${os(1199,{key:a.qy`<kbd>${as(219)}</kbd>`})}</li>
        <li>${"px"===this._spec.units?os(683,{key:a.qy`<kbd>Shift</kbd>`}):os(684,{key:a.qy`<kbd>Shift</kbd>`})}</li>
      </ul>
      <div class="foot">
        <button type="button" class="btn btn-text btn-sm btn-danger clear" ?disabled=${0===t||this.disabled} @click=${()=>this._set({d:""},"Clear path")}>
          <ha-icon icon="mdi:eraser"></ha-icon>${as(146)}
        </button>
      </div>
    </div></section>`}_motionSection(){const e=this._spec;return a.qy`<section class="sec" aria-labelledby="pe-motion">
      <h3 id="pe-motion">${as(452)}</h3>
      <div class="lk-subject" ?inert=${this._locked("subject")}>
      <div class="field">
        <div class="field-head"><span class="lbl">${as(1079)}</span></div>
        ${this._seg(as(1079),of,e.subject,e=>this._subject(e))}
        <p class="help">
          ${"particles"===e.subject?as(638):"icon"===e.subject?as(962):as(989)}
        </p>
      </div>
      </div>
      <div class="lk-path" ?inert=${this._locked("path")}>
      <div class="field">
        <div class="field-head"><span class="lbl">${as(1039)}</span></div>
        ${this._seg(as(1039),lf,e.units,e=>this._set({units:e},"Units"))}
        <p class="help">${"percent"===e.units?as(679):as(680)}</p>
      </div>
      ${this._switch(as(340),as(1031),e.follow_rotation,()=>this._set({follow_rotation:!e.follow_rotation},"Follow rotation"),"follow-switch")}
      </div>
    </section>`}_particlesSection(){const e=this._spec.particles??cf,[t,i]=e.size,n=(n,s,r)=>a.qy`<div class="field">
      <div class="field-head"><span class="lbl">${s}</span></div>
      <mc-unit-field
        .value=${`${e.size[n]}px`}
        .label=${s}
        .units=${["px"]}
        .noCustom=${!0}
        .inputId=${r}
        .disabled=${this.disabled}
        @value-changed=${e=>{e.stopPropagation();const s=parseFloat(String(e.detail.value));if(!Number.isFinite(s))return;const r=Math.min(200,Math.max(1,Math.round(s))),a=0===n?[r,Math.max(r,i)]:[Math.min(t,r),r];this._look({size:a},"Particle size")}}
      ></mc-unit-field>
    </div>`;return a.qy`<section class="sec particles" aria-labelledby="pe-particles">
      <h3 id="pe-particles">${as(633)}</h3>
      <div class="field">
        <div class="field-head"><label for="pe-count">${as(193)}</label></div>
        <input
          class="input"
          id="pe-count"
          type="number"
          min="1"
          max=${ct}
          step="1"
          inputmode="numeric"
          .value=${String(e.count)}
          ?disabled=${this.disabled}
          @input=${e=>{const t=e.target.value,i=Number(t);""!==t.trim()&&Number.isInteger(i)&&i>=1&&i<=ct&&this._look({count:i},"Particle count")}}
        />
        <p class="help">${as(851,{particles:ct})}</p>
      </div>
      <div class="pair">${n(0,as(838),"pe-size-min")} ${n(1,as(401),"pe-size-max")}</div>
      <div class="field">
        <div class="field-head"><span class="lbl">${as(173)}</span></div>
        <div class="colors">
          ${e.colors.map((t,i)=>a.qy`<div class="color-row">
              <mc-color-picker
                .value=${t}
                .label=${as(168,{i:i+1})}
                @value-changed=${t=>{t.stopPropagation();const n=String(t.detail.value??"").trim();if(!n)return;const s=[...e.colors];s[i]=n,this._look({colors:s},"Particle colour")}}
              ></mc-color-picker>
              <button
                type="button"
                class="icon-btn sm danger remove-color"
                aria-label=${as(712,{i:i+1})}
                title=${as(711)}
                ?disabled=${this.disabled}
                @click=${()=>this._look({colors:e.colors.filter((e,t)=>t!==i)},"Remove particle colour")}
              >
                <ha-icon icon="mdi:close"></ha-icon>
              </button>
            </div>`)}
        </div>
        ${e.colors.length?a.s6:a.qy`<p class="help">${as(569)}</p>`}
        ${e.colors.length<dt?a.qy`<div>
              <button
                type="button"
                class="btn btn-text btn-sm add-color"
                ?disabled=${this.disabled}
                @click=${()=>this._look({colors:[...e.colors,e.colors[e.colors.length-1]??"#ffc107"]},"Add particle colour")}
              >
                <ha-icon icon="mdi:plus"></ha-icon>${as(27)}
              </button>
            </div>`:a.s6}
      </div>
    </section>`}render(){const e=_a(this._spec.d),t=["path","subject"].filter(e=>this._locked(e));return a.qy`<div class="ed">
      ${t.length?jo(this.doc,this.layerView,t):a.s6}
      ${this._pathSection(e)} ${this._motionSection()} ${"particles"===this._spec.subject?a.qy`<div class="lk-path" ?inert=${this._locked("path")}>${this._particlesSection()}</div>`:a.s6}
    </div>`}};function uf(){return i.e(3575).then(()=>i(9474)).then(e=>e,e=>{console.warn("Magic Card: path canvas not loaded",e)})}hf.styles=[dh,Ao,a.AH`
      .lk-path,
      .lk-subject {
        display: contents;
      }
      .lk-path[inert] > *,
      .lk-subject[inert] > * {
        opacity: 0.55;
      }
      :host {
        display: block;
        min-width: 0;
      }
      .ed {
        display: grid;
        gap: 16px;
      }
      .sec {
        display: grid;
        gap: 12px;
      }
      .sec + .sec {
        padding-top: 16px;
        border-top: 1px solid var(--mc-divider);
      }
      h3 {
        margin: 0;
        font-size: 0.875rem;
        font-weight: 500;
      }
      .tiles {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(72px, 1fr));
        gap: 8px;
      }
      .tile {
        display: grid;
        justify-items: center;
        align-content: center;
        gap: 4px;
        min-height: 64px;
        padding: 8px 4px 6px;
        border: 1px solid var(--mc-field-border);
        border-radius: var(--mc-radius);
        background: var(--mc-surface);
        color: var(--mc-text-2);
        font: inherit;
        font-size: 0.75rem;
        line-height: 1.3;
        cursor: pointer;
        transition: border-color 0.15s ease-out, background-color 0.15s ease-out, color 0.15s ease-out;
      }
      .tile:hover:not(:disabled) {
        background: var(--mc-surface-2);
        border-color: var(--mc-text-2);
        color: var(--mc-text);
      }
      .tile:focus-visible {
        outline: 2px solid var(--mc-accent);
        outline-offset: 2px;
      }
      .tile:disabled {
        opacity: 0.45;
        cursor: not-allowed;
      }
      .tile svg {
        width: ${44}px;
        height: ${30}px;
        overflow: visible;
      }
      .tile path {
        fill: none;
        stroke: currentColor;
        stroke-width: 1.75;
        stroke-linecap: round;
        stroke-linejoin: round;
        vector-effect: non-scaling-stroke;
      }
      .tile circle {
        fill: currentColor;
      }
      .stats {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
      }
      .actions {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
      }
      .actions .btn {
        flex: 1 1 auto;
      }
      .tips {
        margin: 0;
        padding: 0 0 0 18px;
        display: grid;
        gap: 2px;
      }
      kbd {
        font-family: var(--mc-mono);
        font-size: 0.6875rem;
        padding: 0 4px;
        border-radius: 3px;
        background: var(--mc-surface-2);
        border: 1px solid var(--mc-divider);
      }
      .pair {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px;
      }
      .colors {
        display: grid;
        gap: 8px;
      }
      .color-row {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .color-row mc-color-picker {
        flex: 1;
        min-width: 0;
      }
      .foot {
        display: flex;
        justify-content: flex-end;
      }
      .btn-danger {
        color: var(--mc-error-ink);
      }
      .btn-danger:hover:not(:disabled) {
        background: color-mix(in srgb, var(--error-color, #db4437) 10%, transparent);
      }
      @media (prefers-reduced-motion: reduce) {
        .tile {
          transition: none;
        }
      }
    `],af([(0,o.MZ)({attribute:!1})],hf.prototype,"doc",void 0),af([(0,o.MZ)({attribute:!1})],hf.prototype,"hass",void 0),af([(0,o.MZ)({attribute:!1})],hf.prototype,"library",void 0),af([(0,o.MZ)({type:Number})],hf.prototype,"time",void 0),af([(0,o.MZ)({type:Boolean,reflect:!0})],hf.prototype,"disabled",void 0),af([(0,o.MZ)({attribute:!1})],hf.prototype,"layerView",void 0),hf=af([(0,o.EM)("mc-anim-path-editor")],hf);var mf=i(3706);let gf=Date.now();const ff={"Add point":31,"Move point":472,"Move points":473,"Move path":469,"Move handle":467,"Delete point":227,"Delete points":228,"Delete handle":224,"Close path":159,"Change point type":129},vf=e=>ff[e]?as(ff[e]):e;function bf(e,t){const i=e?.screen;if(!(e&&i&&e.scale>0))return;const n=e.scale;return{left:i.left+t.x*n,top:i.top+t.y*n,width:t.width*n,height:t.height*n}}class yf extends a.WF{constructor(){super(...arguments),this.canvasState="idle",this._again=!1}ensureCanvas(){if("idle"!==this.canvasState||this._loading)return;this.canvasState="loading";const e=this._again;this._again=!1,this._loading=(e?function(){const e=i,t=e.u,n=++gf;e.u=e=>{const i=t(e);return`${i}${i.includes("?")?"&":"?"}r=${n}`};try{return uf()}finally{e.u=t}}():uf()).then(t=>{this._loading=void 0,t?(()=>{const e="undefined"==typeof customElements?void 0:customElements.get(mf.eo);return(e?.contractRevision??0)>=8})()?(this.chunk=t,this.canvasState="ready",e&&this.updateComplete.then(()=>this.toolsReady())):this.canvasState="old":this.canvasState="failed"})}retry(){this._again=!0,this.canvasState="idle",this.ensureCanvas()}toolsReady(){}_reload(){confirm(as(709))&&location.reload()}renderNotice(){return"failed"===this.canvasState?a.qy`<p class="host-notice" role="alert">${as(192)}<button type="button" @click=${()=>this.retry()}>${as(1023)}</button></p>`:"old"===this.canvasState?a.qy`<p class="host-notice" role="alert">
        ${as(944)}<button type="button" @click=${()=>this._reload()}>${as(708)}</button>
      </p>`:a.s6}}yf.styles=a.AH`
    :host {
      display: block;
      touch-action: none;
      user-select: none;
      -webkit-user-select: none;
      --ch-accent: var(--primary-color, #03a9f4);
      --ch-action: color-mix(in srgb, var(--ch-accent) 70%, #000);
      --ch-ink: var(--primary-text-color, #212121);
      --ch-surface: var(--card-background-color, #fff);
    }
    :host([disabled]) {
      opacity: 0.55;
    }
    .layer,
    mc-path-canvas {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
    }
    .layer {
      pointer-events: none;
      overflow: visible;
    }
    .host-notice {
      position: absolute;
      left: 50%; /* physical */
      top: 50%;
      transform: translate(-50%, -50%);
      display: flex;
      align-items: center;
      gap: 8px;
      max-width: calc(100% - 24px);
      margin: 0;
      padding: 6px 6px 6px 12px;
      padding-inline: 12px 6px;
      border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
      border-radius: 9999px;
      background: var(--ch-surface);
      color: var(--ch-ink);
      box-shadow:
        0 8px 24px rgba(0, 0, 0, 0.16),
        0 2px 6px rgba(0, 0, 0, 0.08);
      font-size: 0.8125rem;
      pointer-events: auto;
    }
    .host-notice button {
      min-height: 32px;
      padding: 0 12px;
      border: 0;
      border-radius: 9999px;
      background: var(--ch-action);
      color: var(--text-primary-color, #fff);
      font: inherit;
      font-weight: 600;
      cursor: pointer;
    }
    .host-notice button:focus-visible {
      outline: 2px solid var(--ch-ink);
      outline-offset: 2px;
    }
    .sr-only {
      position: absolute;
      width: 1px;
      height: 1px;
      overflow: hidden;
      clip: rect(0 0 0 0);
      white-space: nowrap;
    }
  `,function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);r>3&&a&&Object.defineProperty(t,i,a)}([(0,o.wk)()],yf.prototype,"canvasState",void 0);var xf=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const _f=[],wf=new Map,kf=(e,t)=>Object.entries(e).every(([e,i])=>Math.abs(t[e]-i)<.005);let $f=class extends yf{constructor(){super(...arguments),this.time=0,this.disabled=!1,this._live={anchors:[],closed:!1},this._list=[],this._path={anchors:[],closed:!1},this._announce="",this._onChange=e=>{e.stopPropagation();const t=e.detail,i=t.paths;if(this._setLive(i[0]??{anchors:[],closed:!1}),!t.commit||!this.doc)return;const n=wa(this._live);this._path=this._live,this._d=n;const s=vf(t.label),r={...this.doc,path:{...this.doc.path??{units:"percent",follow_rotation:!1,subject:"element"},d:n}};this._announce=s,this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:r,label:s}}))}}willUpdate(e){if(e.has("doc")){const e=this.doc?.path?.d??"";e!==this._d&&(this._path=_a(e),this._d=e,this._setLive(this._path))}"path"===this.doc?.kind&&this.ensureCanvas()}_setLive(e){this._live=e,this._list=e.anchors.length?[e]:[]}_geometry(){const e=this.doc?.path,t=this.stage,i=t?.rect.width??0,n=t?.rect.height??0;if(!(t&&e&&i>0&&n>0))return;const s="px"===e.units,r=this.stage?.subject??this.subjectRect,a="particles"===e.subject,o=!a&&r&&r.width>0&&r.height>0?r:{x:0,y:0,width:i,height:n},l=bf(t,o);if(!l)return;const c=s?o.width:100,d=s?o.height:100,p=a?{x:0,y:0,w:c,h:d}:{x:-c/2,y:-d/2,w:c,h:d},h=s?"px":"%",u=(e=>"px"===e?10:5)(e.units),m=this._geo;return m&&m.units===h&&m.step===u&&kf(m.frame,p)&&kf(m.place,l)?m:this._geo={frame:p,place:l,units:h,step:u}}_px(e,t){return[e.place.left+(t[0]-e.frame.x)*e.place.width/e.frame.w,e.place.top+(t[1]-e.frame.y)*e.place.height/e.frame.h]}toolsReady(){this._announce=as(943),this.renderRoot.querySelector("mc-path-canvas")?.focus({preventScroll:!0})}_mapD(e){const t=t=>this._px(e,t);return wa({closed:this._path.closed,anchors:this._path.anchors.map(e=>{const[i,n]=t([e.x,e.y]);return{...e,x:i,y:n,in:e.in?t(e.in):void 0,out:e.out?t(e.out):void 0}})})}_arrows(e){const t=this._d??"";return this._path.anchors.length<2||!t?[]:[.25,.5,.75].map(i=>{const n=za(t,i-.01),s=za(t,i+.01),r=za(t,i);if(!n||!s||!r)return a.JW``;const o=this._px(e,[n.x,n.y]),l=this._px(e,[s.x,s.y]),c=this._px(e,[r.x,r.y]);if(Math.hypot(l[0]-o[0],l[1]-o[1])<.5)return a.JW``;const d=180*Math.atan2(l[1]-o[1],l[0]-o[0])/Math.PI;return a.JW`<path class="arrow" d="M-4 -4 L4 0 L-4 4 Z" transform="translate(${c[0].toFixed(1)} ${c[1].toFixed(1)}) rotate(${d.toFixed(1)})"></path>`})}_dot(e,t,i,n,s){const r=za(t,i);if(!r)return a.s6;const[o,l]=this._px(e,[r.x,r.y]);let c=a.s6;if(n){const n=za(t,Math.max(0,i-.005)),s=za(t,Math.min(1,i+.005));if(n&&s){const t=this._px(e,[n.x,n.y]),i=this._px(e,[s.x,s.y]),r=180*Math.atan2(i[1]-t[1],i[0]-t[0])/Math.PI;c=a.JW`<path class="heading" d="M10 -4 L17 0 L10 4 Z" transform="rotate(${r.toFixed(1)})"></path>`}}return a.JW`<g class="subject" data-k=${s} transform="translate(${o.toFixed(1)} ${l.toFixed(1)})">
      <circle class="body" r="9"></circle><circle class="core" r="2.5"></circle>${c}
    </g>`}_subject(e){const t=this._d??"";if(this._path.anchors.length<2)return a.s6;const i=this.doc?.path,n=!!i?.follow_rotation,s=Math.min(1,Math.max(0,Number.isFinite(this.time)?this.time:0)),r="particles"===i?.subject?Math.min(60,Math.max(1,i.particles?.count??3)):1;return Array.from({length:r},(i,a)=>this._dot(e,t,0===a?s:(s+a/r)%1,n,a))}render(){const e=this._geometry();if(!e)return a.qy`${this.renderNotice()}`;const t=this._path.anchors.length,i=this._mapD(e),n=this._px(e,[0,0]),s=t>1?this._px(e,[this._path.anchors[0].x,this._path.anchors[0].y]):void 0,r="ready"===this.canvasState;return a.qy`
      <svg class="layer decor" aria-hidden="true">
        <path class="origin" d="M${n[0]-6} ${n[1]}h12M${n[0]} ${n[1]-6}v12"></path>
        ${i&&t>1?a.JW`<path class="line" d=${i}></path>`:a.s6} ${this._arrows(e)} ${this._subject(e)}
        ${s?a.JW`<text class="tag" x=${s[0]+10} y=${s[1]-9}>${as(877)}</text>`:a.s6}
      </svg>
      ${r?a.qy`<mc-path-canvas
            overlay
            .placement=${e.place}
            .frame=${e.frame}
            .units=${e.units}
            .paths=${this._list}
            .paint=${_f}
            .mode=${this.disabled?"view":this._live.closed?"nodes":"add"}
            .maxPaths=${1}
            .gridStep=${e.step}
            .snap=${(e=>{let t=wf.get(e);return t||wf.set(e,t={enabled:!0,grid:e,anchors:!1,frame:!1}),t})(e.step)}
            .nudge=${1}
            .bigNudge=${e.step}
            .fineNudge=${.1}
            aria-label=${as(454)}
            @mc-path-change=${this._onChange}
          ></mc-path-canvas>`:a.s6}
      ${0===t&&r&&!this.disabled?a.qy`<p class="hint">${as(154)}</p>`:1===t&&r&&!this.disabled?a.qy`<p class="hint">${as(153)}</p>`:a.s6}
      ${this.renderNotice()}
      <span class="sr-only" aria-live="polite">${this._announce}</span>
    `}};$f.styles=[yf.styles,a.AH`
      .decor {
        fill: none;
      }
      .origin {
        stroke: color-mix(in srgb, var(--ch-ink) 45%, transparent);
        stroke-width: 1.25;
      }
      .line {
        stroke: var(--ch-accent);
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
      }
      .arrow {
        fill: var(--ch-accent);
        stroke: var(--ch-surface);
        stroke-width: 1;
      }
      .tag {
        font:
          500 10px/1 Roboto,
          system-ui,
          sans-serif;
        fill: var(--ch-ink);
        paint-order: stroke;
        stroke: var(--ch-surface);
        stroke-width: 3px;
        stroke-linejoin: round;
      }
      .subject .body {
        fill: color-mix(in srgb, var(--ch-ink) 14%, transparent);
        stroke: color-mix(in srgb, var(--ch-ink) 75%, transparent);
        stroke-width: 1.5;
        stroke-dasharray: 3 2;
      }
      .subject .core,
      .subject .heading {
        fill: var(--ch-ink);
      }
      .hint {
        position: absolute;
        left: 50%; /* physical */
        top: 50%;
        transform: translate(-50%, -50%);
        margin: 0;
        padding: 6px 12px;
        border-radius: 9999px;
        background: var(--ch-surface);
        color: var(--ch-ink);
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        box-shadow:
          0 8px 24px rgba(0, 0, 0, 0.16),
          0 2px 6px rgba(0, 0, 0, 0.08);
        font-size: 0.75rem;
        font-weight: 500;
        white-space: nowrap;
        pointer-events: none;
      }
    `],xf([(0,o.MZ)({attribute:!1})],$f.prototype,"doc",void 0),xf([(0,o.MZ)({type:Number})],$f.prototype,"time",void 0),xf([(0,o.MZ)({type:Boolean,reflect:!0})],$f.prototype,"disabled",void 0),xf([(0,o.MZ)({attribute:!1})],$f.prototype,"stage",void 0),xf([(0,o.MZ)({attribute:!1})],$f.prototype,"subjectRect",void 0),xf([(0,o.MZ)({attribute:!1})],$f.prototype,"hass",void 0),xf([(0,o.MZ)({attribute:!1})],$f.prototype,"library",void 0),xf([(0,o.wk)()],$f.prototype,"_live",void 0),xf([(0,o.wk)()],$f.prototype,"_path",void 0),xf([(0,o.wk)()],$f.prototype,"_announce",void 0),$f=xf([(0,o.EM)("mc-anim-path-host")],$f);const Mf=e=>Math.round(1e3*e)/1e3;function Sf(e){return!!e&&("keyframes"===e.kind||"path"===e.kind&&"particles"!==e.path?.subject)}function zf(e){if(!e)return;const t=parseFloat(e);return Number.isFinite(t)?/ms\s*$/i.test(e)?t/1e3:t:void 0}function Cf(e,t,i){const n=(e??"").trim();if(!n)return{status:"invalid",name:as(548),kind:"",problem:as(655)};if(rt(n)){const e=at(n);if(i&&e===i)return{status:"invalid",name:e,kind:as(798),problem:as(18)};const s=t?.[e];if(!s)return{status:"missing",name:e,kind:"",problem:as(580)};if("keyframes"===s.kind)return{status:"ok",name:s.name||e,kind:as(398),defaultDuration:s.duration};if("path"===s.kind)return Sf(s)?{status:"ok",name:s.name||e,kind:as(645),defaultDuration:s.duration}:{status:"invalid",name:s.name||e,kind:as(645),problem:as(634)};const r="particles"===s.kind?as(633):as(798);return{status:"invalid",name:s.name||e,kind:r,problem:as(1200,{kind:r})}}const s=ge(n);return s?Mt.has(s.id)?{status:"ok",name:(0,te.t)(s.name),kind:as(687),defaultDuration:zf(s.defaults.duration)}:{status:"invalid",name:(0,te.t)(s.name),kind:as(687),problem:as(290)}:{status:"missing",name:n,kind:as(687),problem:as(1041)}}function Af(e,t,i){const n=[...e];if(t<0||t>=n.length||i<0||i>=n.length||t===i)return n;const[s]=n.splice(t,1);return n.splice(i,0,s),n}function jf(e){return`${Mf(e).toFixed(2).replace(/\.?0+$/,"")} s`}const qf={keyframes:"mdi:chart-bell-curve-cumulative",path:"mdi:vector-curve"},Ef=e=>(e?.length??0)<20;var Hf=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function Lf(e){const t=String(e??"").trim();if(!t)return;const i=parseFloat(t);return Number.isFinite(i)?/ms$/i.test(t)?i/1e3:i:void 0}const Vf=(e,t,i)=>Math.min(i,Math.max(t,e)),Of=e=>Math.round(1e3*e)/1e3;let Pf=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this._open=-1,this._query="",this._announce="",this._pick=null,this._trigger=null,this._focusSearch=!1,this._onDragKey=e=>{"Escape"===e.key&&this._drag&&(e.preventDefault(),e.stopPropagation(),this._cancelDrag())}}get _steps(){return this.doc?.steps??[]}_emit(e,t,i=!1){this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:i?{doc:e,label:t,transient:!0}:{doc:e,label:t}}))}_remap(e){const t=this.layerView,i=t&&e(t);i&&i!==t&&this.dispatchEvent(new CustomEvent("layer-view-change",{detail:{view:i},bubbles:!0,composed:!0}))}_writeSteps(e,t,i=!1){this.doc&&this._emit({...this.doc,steps:e},t,i)}_patchStep(e,t,i){const n=this._steps.map((i,n)=>{if(n!==e)return i;const s={...i,...t};return void 0===t.duration&&"duration"in t&&delete s.duration,s});this._writeSteps(n,i)}_addStep(e){if(!Ef(this._steps))return;const t=[...this._steps,{animation:e,delay:0,repeat:1}];this._open=t.length-1,this._focusAfter={index:t.length-1,part:"toggle"},this._writeSteps(t,"Add step"),this._announce=as(899,{count:t.length,name:Cf(e,this.library,this.doc?.id).name})}_locked(e,t=!1){const i=!!this.layerView?.locked.includes(`step:${e}`);return i&&t&&(this._announce=as(904,{i:e+1})),i}_deleteStep(e){if(this._steps.length<=1||this._locked(e,!0))return;const t=this._steps.filter((t,i)=>i!==e);this._open===e?this._open=-1:this._open>e&&this._open--,this._focusAfter=t.length?{index:Math.min(e,t.length-1),part:"toggle"}:void 0,this._writeSteps(t,"Delete step"),this._remap(t=>function(e,t){return Co(e,e=>e===t?-1:e>t?e-1:e)}(t,e)),this._announce=as(900,{index:e+1})}_move(e,t,i="handle"){const n=this._steps.length;e===t||t<0||t>=n||this._locked(e,!0)||(this._open=this._followMove(this._open,e,t),this._focusAfter={index:t,part:i},this._writeSteps(Af(this._steps,e,t),"Move step"),this._remap(i=>zo(i,e,t)),this._announce=as(898,{to:t+1,n}))}_followMove(e,t,i){return e<0?e:e===t?i:t<e&&e<=i?e-1:i<=e&&e<t?e+1:e}_onHandleDown(e,t){if(this.disabled||0!==e.button||this._steps.length<2||this._locked(t,!0))return;const i=[...this.renderRoot.querySelectorAll(".step")];if(!i[t])return;e.preventDefault(),e.currentTarget.setPointerCapture?.(e.pointerId);const n=i.map(e=>e.getBoundingClientRect()),s=n[t+1]??n[t-1],r=s?Math.abs(t+1<n.length?s.top-n[t].bottom:n[t].top-s.bottom):0;this._drag={from:t,to:t,dy:0,startY:e.clientY,pointerId:e.pointerId,mids:n.map(e=>e.top+e.height/2),shift:n[t].height+r,steps:this._steps,moved:!1},window.addEventListener("keydown",this._onDragKey,!0)}_endDrag(){const e=this._drag;return this._drag=void 0,window.removeEventListener("keydown",this._onDragKey,!0),e}disconnectedCallback(){super.disconnectedCallback(),this._endDrag()}_onHandleMove(e){const t=this._drag;if(!t||e.pointerId!==t.pointerId)return;const i=e.clientY-t.startY,n=e.clientY;let s=t.from;for(let e=t.from+1;e<t.mids.length;e++)n>t.mids[e]&&(s=e);for(let e=t.from-1;e>=0;e--)n<t.mids[e]&&(s=e);const r=s!==t.to;this._drag={...t,dy:i,to:s,moved:t.moved||r},r&&this.doc&&this._emit({...this.doc,steps:Af(t.steps,t.from,s)},"Move step",!0)}_onHandleUp(e){const t=this._drag;t&&e.pointerId===t.pointerId&&(this._endDrag(),t.to!==t.from&&(this._open=this._followMove(this._open,t.from,t.to),this._focusAfter={index:t.to,part:"handle"},this.doc&&this._emit({...this.doc,steps:Af(t.steps,t.from,t.to)},"Move step"),this._remap(e=>zo(e,t.from,t.to)),this._announce=as(897,{to:t.to+1,count:t.steps.length})))}_cancelDrag(){const e=this._endDrag();e&&e.moved&&this.doc&&this._emit({...this.doc,steps:e.steps},"Move step")}_onStepKey(e,t){if(!e.altKey||"ArrowUp"!==e.key&&"ArrowDown"!==e.key||this.disabled)return;e.preventDefault();const i=e.target.classList?.contains("handle");this._move(t,t+("ArrowUp"===e.key?-1:1),i?"handle":"toggle")}_dragOffset(e){const t=this._drag;return t?e===t.from?t.dy:t.from<t.to&&e>t.from&&e<=t.to?-t.shift:t.to<t.from&&e>=t.to&&e<t.from?t.shift:0:0}_popover(){return this.renderRoot.querySelector("mc-ui-popover.pick-pop")}_openPicker(e,t){if(this.disabled)return;const i=e.currentTarget;this._pick&&this._trigger===i?this._popover()?.close("action"):(this._trigger=i,this._pick=t,this._query="",this._focusSearch=!0)}_choose(e){const t=this._pick;this._popover()?.close("action"),this._pick=null,t&&("add"===t.mode?this._addStep(e):this._steps[t.index]?.animation!==e&&this._patchStep(t.index,{animation:e},"Change step animation"))}_onPickKey(e){const t="INPUT"===e.target.tagName;if(t&&("Home"===e.key||"End"===e.key))return;const i=[...this.renderRoot.querySelectorAll('.pick-pop [role="menuitem"]')],n=this.renderRoot.querySelector(".pick-pop .pick-search input"),s=i.indexOf(e.target),r=t=>{t&&(e.preventDefault(),t.focus())};"ArrowDown"===e.key?r(t?i[0]:i[Math.min(i.length-1,s+1)]):"ArrowUp"===e.key?r(s<=0?n:i[s-1]):"Home"===e.key?r(i[0]):"End"===e.key&&r(i[i.length-1])}_renderPicker(){const e=this._pick,t="step"===e?.mode?this._steps[e.index]?.animation:void 0,i=function(e,t,i=""){const n=(0,Ft.A)(i.trim()),s=(...e)=>!n||e.some(e=>e&&(0,Ft.A)(e).includes(n)),r=[],a=Object.values(e??{}).filter(e=>e.id!==t&&Sf(e)).sort((e,t)=>(e.name||e.id).localeCompare(t.name||t.id)).filter(e=>s(e.name,e.id,as(1127),e.kind)).map(e=>({value:st+e.id,name:e.name||e.id,kind:"path"===e.kind?as(645):as(398),icon:qf[e.kind],duration:e.duration}));a.length&&r.push({label:as(532),items:a});for(const e of he){const t=pe.filter(t=>t.group===e&&Mt.has(t.id)&&s((0,te.t)(t.name),t.id,e,(0,te.t)(ue[e]))).map(e=>({value:e.id,name:(0,te.t)(e.name),icon:"mdi:motion-play-outline",duration:zf(e.defaults.duration)}));t.length&&r.push({label:(0,te.t)(ue[e]),items:t})}return r}(this.library,this.doc?.id,this._query),n=as("add"===e?.mode?36:896);return a.qy`
      <mc-ui-popover
        class="pick-pop"
        label=${n}
        .anchor=${this._trigger}
        @mc-popover-close=${e=>{e.stopPropagation(),this._pick=null,this._query=""}}
      >
        <div class="pick" @keydown=${e=>this._onPickKey(e)}>
          <div class="pick-search">
            <ha-icon icon="mdi:magnify"></ha-icon>
            <input
              class="input"
              type="search"
              placeholder=${as(777)}
              aria-label=${as(777)}
              autocomplete="off"
              .value=${this._query}
              @input=${e=>this._query=e.target.value}
            />
          </div>
          <div class="pick-list" role="menu" aria-label=${n}>
            ${i.length?i.map(e=>a.qy`
                    <div class="pick-group" role="group" aria-label=${e.label}>
                      <div class="pick-head" aria-hidden="true">${e.label}</div>
                      ${e.items.map(e=>a.qy`<button
                          type="button"
                          role="menuitem"
                          class="pick-item ${e.value===t?"is-current":""}"
                          data-value=${e.value}
                          @click=${()=>this._choose(e.value)}
                        >
                          <ha-icon icon=${e.icon}></ha-icon>
                          <span class="pick-name">${e.name}${e.kind?a.qy`<span class="pick-kind"> · ${e.kind}</span>`:a.s6}</span>
                          ${void 0!==e.duration?a.qy`<span class="pick-dur">${jf(e.duration)}</span>`:a.s6}
                          ${e.value===t?a.qy`<ha-icon class="pick-check" icon="mdi:check"></ha-icon>`:a.s6}
                        </button>`)}
                    </div>
                  `):a.qy`<p class="menu-note">${as(549,{query:this._query})}</p>`}
          </div>
        </div>
      </mc-ui-popover>
    `}_field(e,t,i){return a.qy`<div class="field">
      <div class="field-head">${i?a.qy`<label for=${i}>${e}</label>`:a.qy`<span class="lbl">${e}</span>`}</div>
      ${t}
    </div>`}_renderSchedule(e){const t=e.total,i=function(e,t){if(!e.total)return-1;const i=Math.min(1,Math.max(0,t))*e.total,n=e.entries.find(t=>t.play>0&&i>=t.start&&(i<t.end||i===t.end&&t.end===e.total));return n?n.index:-1}(e,this.time),n=e=>t?e/t*100:0,s=this._steps.length,r=e.entries.filter(e=>"ok"!==e.status).length,o=!1!==this.doc?.loop,l=this._drag?this._followMove(this._open,this._drag.from,this._drag.to):this._open,c=new Map,d=t?as(1264,{steps:as(1175,{count:s}),total:jf(t),loop:as(o?1126:1134),skipped:r?as(5,{count:r}):""}):as(593);return a.qy`
      <div class="sched">
        <div class="bar" aria-hidden="true">
          ${e.entries.map(e=>{if("ok"!==e.status){const t=c.get(e.start)??0;return c.set(e.start,t+1),a.qy`<span class="mark" style="left:calc(${n(e.start)}% + ${8*t}px)" title=${as(901,{index:e.index+1})} @click=${()=>this._reveal(e.index)}></span>`}const t=["blk",e.index===l?"is-open":"",e.index===i?"is-live":""].join(" "),s=n(e.end-e.start);return a.qy`<span
              class=${t}
              style="left:${n(e.start)}%;width:${s}%;--plays:${e.repeat}"
              title=${as(902,{index:e.index+1,from:jf(e.start),to:jf(e.end)})}
              @click=${()=>this._reveal(e.index)}
              >${s>=6?e.index+1:""}</span
            >`})}
          ${t?a.qy`<span class="playhead" style="left:${100*Vf(this.time,0,1)}%"></span>`:a.s6}
        </div>
        <div class="ruler" aria-hidden="true">
          <span>0 s</span>
          ${o?a.qy`<span class="loop"><ha-icon icon="mdi:repeat"></ha-icon>${as(436)}</span>`:a.s6}
          <span>${jf(t)}</span>
        </div>
        <p class="sr-only">${d}</p>
      </div>
    `}_reveal(e){this._open=e,this.updateComplete.then(()=>this.renderRoot.querySelector(`.step[data-i="${e}"]`)?.scrollIntoView({block:"nearest"}))}_renderStep(e,t,i){const n=Cf(e.animation,this.library,this.doc?.id),s=this._open===t,r="ok"!==n.status,o=e=>`seq-${t}-${e}`,l=r?"missing"===n.status?as(579):as(115):function(e,t){const i=[];e.delay>0&&i.push(as(1095,{seconds:jf(e.delay)}));const n=e.duration??t.defaultDuration;return void 0!==n&&i.push(jf(n)),e.repeat>1&&i.push(`× ${e.repeat}`),i.join(" · ")}(e,n),c=this._drag?.from===t,d=this._dragOffset(t),p=void 0!==n.defaultDuration?String(Of(n.defaultDuration)):"",h=this._locked(t);return a.qy`
      <li
        class="step ${s?"is-open":""} ${r?"is-bad":""} ${c?"is-dragging":""}"
        data-i=${t}
        style=${d?`transform: translateY(${d}px)`:a.s6}
        @keydown=${e=>this._onStepKey(e,t)}
      >
        <div class="row">
          <button
            type="button"
            class="icon-btn sm handle"
            aria-label=${as(477,{i:t+1})}
            aria-describedby="seq-move-hint"
            title=${as(254)}
            ?disabled=${this.disabled||h||i<2}
            @pointerdown=${e=>this._onHandleDown(e,t)}
            @pointermove=${e=>this._onHandleMove(e)}
            @pointerup=${e=>this._onHandleUp(e)}
            @pointercancel=${()=>this._cancelDrag()}
            @lostpointercapture=${e=>this._onHandleUp(e)}
          >
            <ha-icon icon="mdi:drag-vertical"></ha-icon>
          </button>
          <button
            type="button"
            class="toggle"
            aria-expanded=${s?"true":"false"}
            aria-controls=${o("body")}
            @click=${()=>this._open=s?-1:t}
          >
            <span class="num">${t+1}</span>
            <span class="txt">
              <span class="nm">${n.name}</span>
              <span class="sum ${r?"error":""}">${r?a.qy`<ha-icon icon="mdi:alert-circle-outline"></ha-icon>`:a.s6}${l}</span>
            </span>
            <ha-icon class="chev" icon="mdi:chevron-down"></ha-icon>
          </button>
          <button
            type="button"
            class="icon-btn sm danger"
            aria-label=${as(233,{i:t+1})}
            title=${as(i<=1?20:232)}
            ?disabled=${this.disabled||h||i<=1}
            @click=${()=>this._deleteStep(t)}
          >
            <ha-icon icon="mdi:delete-outline"></ha-icon>
          </button>
        </div>
        ${s?a.qy`<div class="body" id=${o("body")}>
              ${h?jo(this.doc,this.layerView,[`step:${t}`]):a.s6}
              ${r?a.qy`<p class="help error problem" role="note">${n.problem}</p>`:a.s6}
              ${this._field(as(64),a.qy`<button
                  type="button"
                  class="input pick-btn"
                  id=${o("anim")}
                  aria-haspopup="menu"
                  aria-expanded=${"step"===this._pick?.mode&&this._pick.index===t?"true":"false"}
                  ?disabled=${this.disabled||h}
                  @click=${e=>this._openPicker(e,{mode:"step",index:t})}
                >
                  <span class="pick-val">${n.name}${n.kind&&n.kind!==as(687)?a.qy`<span class="pick-kind"> · ${n.kind}</span>`:a.s6}</span>
                  <ha-icon icon="mdi:chevron-down"></ha-icon>
                </button>`,o("anim"))}
              <div class="fields">
                ${this._field(as(215),a.qy`<mc-unit-field
                    .value=${e.delay?`${Of(e.delay)}s`:""}
                    .label=${as(215)}
                    .units=${["s"]}
                    .noCustom=${!0}
                    .placeholder=${"0"}
                    ?disabled=${this.disabled||h}
                    @value-changed=${e=>{e.stopPropagation(),this._patchStep(t,{delay:Vf(Of(Lf(e.detail.value)??0),0,600)},"Change step delay")}}
                  ></mc-unit-field>`)}
                ${this._field(as(282),a.qy`<mc-unit-field
                    .value=${void 0!==e.duration?`${Of(e.duration)}s`:""}
                    .label=${as(282)}
                    .units=${["s"]}
                    .noCustom=${!0}
                    .placeholder=${p}
                    ?disabled=${this.disabled||h}
                    @value-changed=${e=>{e.stopPropagation();const i=Lf(e.detail.value);this._patchStep(t,{duration:void 0===i||i<=0?void 0:Vf(Of(i),.05,600)},"Change step duration")}}
                  ></mc-unit-field>`)}
                ${this._field(as(675),a.qy`<input
                    class="input"
                    id=${o("plays")}
                    type="number"
                    min="1"
                    max="100"
                    step="1"
                    inputmode="numeric"
                    .value=${String(e.repeat)}
                    ?disabled=${this.disabled||h}
                    @change=${i=>{const n=i.target,s=Math.round(Number(n.value));if(!n.value.trim()||!Number.isFinite(s))return void(n.value=String(e.repeat));const r=Vf(s,1,100);n.value=String(r),r!==e.repeat&&this._patchStep(t,{repeat:r},"Change step plays")}}
                  />`,o("plays"))}
              </div>
              <p class="help">${p?as(217,{seconds:p}):as(218)}</p>
            </div>`:a.s6}
      </li>
    `}render(){const e=this.doc;if(!e)return a.qy``;const t=this._drag?this._drag.steps:this._steps,i=function(e,t,i){const n=[];let s=0;return(e??[]).forEach((e,r)=>{const a=Cf(e.animation,t,i),o="ok"===a.status?e.duration??a.defaultDuration??0:0,l=Math.max(1,Math.round(e.repeat||1));if(!o)return void n.push({index:r,status:"ok"===a.status?"invalid":a.status,start:Mf(s),play:0,repeat:l,end:Mf(s)});const c=s+Math.max(0,e.delay||0),d=c+o*l;n.push({index:r,status:"ok",start:Mf(c),play:Mf(o),repeat:l,end:Mf(d)}),s=d}),{entries:n,total:Mf(s)}}(this._drag?Af(this._drag.steps,this._drag.from,this._drag.to):t,this.library,e.id),n=!1!==e.loop,s=e.stagger??{children:!1,delay:.15},r=!Ef(t);return a.qy`
      <div class="wrap">
        <section class="group" aria-label=${as(776)}>${this._renderSchedule(i)}</section>

        <section class="group" aria-labelledby="seq-steps-h">
          <div class="group-head">
            <h3 id="seq-steps-h">${as(669)}</h3>
            <span class="chip is-count" title=${as(1263,{steps:20})}>${t.length} / ${20}</span>
          </div>
          <p class="sr-only" id="seq-move-hint">${as(256)}</p>
          ${t.length?a.qy`<ol class="steps ${this._drag?"is-sorting":""}">${t.map((e,i)=>this._renderStep(e,i,t.length))}</ol>`:a.qy`<div class="empty">
                <ha-icon icon="mdi:playlist-play"></ha-icon>
                <strong>${as(565)}</strong>
                <p>${as(37)}</p>
              </div>`}
          <div class="foot">
            <button
              type="button"
              class="btn btn-text btn-sm add"
              aria-haspopup="menu"
              aria-expanded=${"add"===this._pick?.mode?"true":"false"}
              ?disabled=${this.disabled||r}
              @click=${e=>this._openPicker(e,{mode:"add"})}
            >
              <ha-icon icon="mdi:plus"></ha-icon>${as(36)}
            </button>
            ${r?a.qy`<span class="help">${as(1262,{steps:20})}</span>`:a.s6}
          </div>
        </section>

        <section class="group" aria-labelledby="seq-play-h">
          <div class="group-head"><h3 id="seq-play-h">${as(672)}</h3></div>
          <div class="switch-row">
            <div class="txt">
              ${as(432)}
              <p class="help">${as(878)}</p>
            </div>
            <button
              type="button"
              class="switch"
              role="switch"
              aria-checked=${n?"true":"false"}
              aria-label=${as(432)}
              ?disabled=${this.disabled}
              @click=${()=>this._emit({...e,loop:!n},as(n?433:434))}
            ></button>
          </div>
          <div class="switch-row">
            <div class="txt">
              ${as(873)}
              <p class="help">${as(668)}</p>
            </div>
            <button
              type="button"
              class="switch stagger"
              role="switch"
              aria-checked=${s.children?"true":"false"}
              aria-label=${as(873)}
              ?disabled=${this.disabled}
              @click=${()=>this._emit({...e,stagger:{...s,children:!s.children}},s.children?as(874):as(875))}
            ></button>
          </div>
          ${s.children?this._field(as(216),a.qy`<mc-unit-field
                  class="stagger-delay"
                  .value=${`${Of(s.delay)}s`}
                  .label=${as(216)}
                  .units=${["s"]}
                  .noCustom=${!0}
                  .placeholder=${"0"}
                  ?disabled=${this.disabled}
                  @value-changed=${t=>{t.stopPropagation(),this._emit({...e,stagger:{...s,delay:Vf(Of(Lf(t.detail.value)??0),0,10)}},"Change stagger delay")}}
                ></mc-unit-field>`):a.s6}
        </section>
        <div class="sr-only" aria-live="polite">${this._announce}</div>
        ${this._pick?this._renderPicker():a.s6}
      </div>
    `}willUpdate(e){e.has("doc")&&this._open>=this._steps.length&&(this._open=-1)}updated(){const e=this._pick?this._popover():null;e&&!e.open&&(e.anchor=this._trigger,e.show()),this._focusSearch&&e&&(this._focusSearch=!1,e.updateComplete.then(()=>this.renderRoot.querySelector(".pick-pop .pick-search input")?.focus({preventScroll:!0})));const t=this._focusAfter;t&&(this._focusAfter=void 0,this.renderRoot.querySelector(`.step[data-i="${t.index}"] .${t.part}`)?.focus())}};Pf.styles=[dh,Ao,a.AH`
      :host {
        display: block;
        min-width: 0;
      }
      :host([disabled]) .steps,
      :host([disabled]) .sched {
        opacity: 0.6;
      }
      .wrap {
        display: grid;
        gap: 0;
      }
      .group + .group {
        margin-top: 20px;
      }
      .group-head .chip {
        flex: none;
      }

      /* ── schedule bar ── */
      .sched {
        display: grid;
        gap: 6px;
        direction: ltr; /* the schedule runs left to right */
      }
      .bar {
        position: relative;
        height: 32px;
        border-radius: var(--mc-radius);
        background: var(--mc-surface-2);
        border: 1px solid var(--mc-divider);
      }
      .blk {
        position: absolute;
        top: 4px;
        bottom: 4px;
        min-width: 3px;
        display: grid;
        place-items: center;
        overflow: hidden;
        border-radius: 4px;
        font-size: 0.75rem;
        font-weight: 500;
        color: var(--mc-text);
        cursor: pointer;
        background-color: color-mix(in srgb, var(--mc-text) 16%, var(--mc-surface));
        /* one segment per play, split by a 2px gap in the track colour */
        background-image: linear-gradient(to right, transparent calc(100% - 2px), var(--mc-surface-2) 0);
        background-size: calc(100% / var(--plays, 1)) 100%;
        box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--mc-text) 22%, transparent);
        transition: background-color 0.15s ease-out;
      }
      .blk:hover {
        background-color: color-mix(in srgb, var(--mc-text) 26%, var(--mc-surface));
      }
      .blk.is-live {
        background-color: color-mix(in srgb, var(--mc-text) 30%, var(--mc-surface));
      }
      .blk.is-open {
        background-color: var(--mc-accent-fill);
        color: var(--mc-on-accent);
        box-shadow: none;
      }
      .mark {
        position: absolute;
        top: 2px;
        bottom: 2px;
        width: 6px;
        margin-left: -3px; /* physical */
        border-radius: 3px;
        cursor: pointer;
        background: repeating-linear-gradient(45deg, var(--mc-error-ink) 0 2px, transparent 2px 4px);
        box-shadow: inset 0 0 0 1px var(--mc-error-ink);
      }
      .playhead {
        position: absolute;
        top: -5px;
        bottom: -5px;
        width: 2px;
        margin-left: -1px; /* physical */
        background: var(--mc-accent);
        border-radius: 1px;
        pointer-events: none;
      }
      .playhead::before {
        content: '';
        position: absolute;
        top: -3px;
        left: -4px; /* physical */
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: var(--mc-accent);
      }
      .ruler {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .ruler .loop {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        --mdc-icon-size: 14px;
      }

      /* ── steps ── */
      .steps {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 8px;
      }
      .step {
        border: 1px solid var(--mc-divider);
        border-radius: var(--mc-radius-lg);
        background: var(--mc-surface);
        min-width: 0;
      }
      .steps.is-sorting .step {
        transition: transform 0.15s ease-out;
      }
      .steps.is-sorting .step.is-dragging {
        transition: none;
        position: relative;
        z-index: 2;
        box-shadow: var(--mc-shadow-float);
      }
      .step.is-bad {
        border-color: color-mix(in srgb, var(--mc-error-ink) 55%, transparent);
      }
      .row {
        display: flex;
        align-items: center;
        gap: 2px;
        padding: 4px;
        min-height: 48px;
      }
      .handle {
        cursor: grab;
        touch-action: none;
      }
      .is-dragging .handle {
        cursor: grabbing;
      }
      .toggle {
        flex: 1;
        min-width: 0;
        display: flex;
        align-items: center;
        gap: 10px;
        min-height: 40px;
        padding: 4px 6px;
        border: 0;
        border-radius: var(--mc-radius);
        background: transparent;
        text-align: start;
      }
      .toggle:hover {
        background: var(--mc-surface-2);
      }
      .toggle:focus-visible {
        outline-offset: -2px;
      }
      .num {
        flex: none;
        display: inline-grid;
        place-items: center;
        min-width: 22px;
        height: 22px;
        padding: 0 6px;
        border-radius: 9999px;
        background: var(--mc-surface-2);
        border: 1px solid var(--mc-divider);
        font-size: 0.75rem;
        font-weight: 500;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .step.is-open .num {
        background: var(--mc-accent-fill);
        border-color: transparent;
        color: var(--mc-on-accent);
      }
      .txt {
        flex: 1;
        min-width: 0;
        display: grid;
      }
      .nm {
        font-size: 0.875rem;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .sum {
        font-size: 0.75rem;
        color: var(--mc-text-2);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: flex;
        align-items: center;
        gap: 4px;
        --mdc-icon-size: 14px;
      }
      .sum.error {
        color: var(--mc-error-ink);
      }
      .chev {
        flex: none;
        --mdc-icon-size: 20px;
        color: var(--mc-text-2);
        transition: transform 0.15s ease-out;
      }
      .toggle[aria-expanded='true'] .chev {
        transform: rotate(180deg);
      }
      .body {
        display: grid;
        gap: 16px;
        padding: 4px 12px 16px;
      }
      .problem {
        padding: 8px 10px;
        border-radius: var(--mc-radius);
        background: color-mix(in srgb, var(--error-color, #db4437) 10%, transparent);
      }
      .fields {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 128px), 1fr));
        gap: 16px 12px;
      }
      .pick-btn {
        display: flex;
        align-items: center;
        gap: 8px;
        text-align: start;
        cursor: pointer;
      }
      .pick-btn .pick-val {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .pick-btn > ha-icon {
        flex: none;
        --mdc-icon-size: 20px;
        color: var(--mc-text-2);
      }
      .pick-kind {
        color: var(--mc-text-2);
        font-weight: 400;
      }
      .foot {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 4px 12px;
      }

      /* ── step picker (the kit popover) ── */
      .pick {
        display: grid;
        width: min(320px, calc(100vw - 40px));
        font-size: 0.875rem;
      }
      .pick-search {
        position: relative;
        display: flex;
        align-items: center;
        padding-bottom: 6px;
      }
      .pick-search > ha-icon {
        position: absolute;
        left: 10px;
        inset-inline: 10px auto;
        --mdc-icon-size: 18px;
        color: var(--mc-text-2);
        pointer-events: none;
      }
      .pick-search .input {
        padding-inline-start: 36px;
      }
      .pick-list {
        display: grid;
        align-content: start;
        max-height: min(340px, 50vh);
        overflow: auto;
        overscroll-behavior: contain;
      }
      .pick-group {
        display: grid;
      }
      .pick-head {
        padding: 10px 12px 4px;
        font-size: 0.75rem;
        font-weight: 500;
        color: var(--mc-text-2);
      }
      .pick-item {
        display: flex;
        align-items: center;
        gap: 10px;
        width: 100%;
        min-height: var(--mc-hit, 40px);
        padding: 0 12px;
        border: 0;
        border-radius: var(--mc-radius);
        background: transparent;
        color: inherit;
        font: inherit;
        text-align: start;
        cursor: pointer;
      }
      .pick-item:hover,
      .pick-item:focus-visible {
        background: var(--mc-surface-2);
      }
      .pick-item:focus-visible {
        outline: 2px solid var(--mc-focus, var(--mc-accent));
        outline-offset: -2px;
      }
      .menu-note {
        margin: 0;
        padding: 8px 12px;
        color: var(--mc-text-2);
        font-size: 0.8125rem;
      }
      .pick-name {
        flex: 1;
        min-width: 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .pick-dur {
        flex: none;
        font-size: 0.75rem;
        color: var(--mc-text-2);
        font-variant-numeric: tabular-nums;
      }
      .pick-item.is-current {
        color: var(--mc-accent-ink);
        font-weight: 500;
      }
      .pick-item .pick-check {
        color: var(--mc-accent-ink);
      }
    `],Hf([(0,o.MZ)({attribute:!1})],Pf.prototype,"doc",void 0),Hf([(0,o.MZ)({attribute:!1})],Pf.prototype,"hass",void 0),Hf([(0,o.MZ)({attribute:!1})],Pf.prototype,"library",void 0),Hf([(0,o.MZ)({type:Number})],Pf.prototype,"time",void 0),Hf([(0,o.MZ)({type:Boolean,reflect:!0})],Pf.prototype,"disabled",void 0),Hf([(0,o.MZ)({attribute:!1})],Pf.prototype,"layerView",void 0),Hf([(0,o.wk)()],Pf.prototype,"_open",void 0),Hf([(0,o.wk)()],Pf.prototype,"_drag",void 0),Hf([(0,o.wk)()],Pf.prototype,"_query",void 0),Hf([(0,o.wk)()],Pf.prototype,"_announce",void 0),Hf([(0,o.wk)()],Pf.prototype,"_pick",void 0),Pf=Hf([(0,o.EM)("mc-anim-sequence-editor")],Pf);const Rf={hide:{name:362,tip:[363,826],key:"H",icon:["mdi:eye-outline","mdi:eye-off-outline"]},solo:{name:847,tip:[848,300],key:"S",icon:["mdi:radiobox-blank","mdi:radiobox-marked"]},lock:{name:428,tip:[428,1043],key:"L",icon:["mdi:lock-open-variant-outline","mdi:lock-outline"]}},Df=["hide","solo","lock"],Nf={hide:[1228,1241],solo:[1242,1239],lock:[1233,1243]};let Ff="";function Tf(e,t){const i=t??e.closest(".layers-body");return(i?[...i.querySelectorAll("[data-panel] > *")]:[e]).flatMap(e=>[...e.shadowRoot?.querySelectorAll("[data-lk]")??[]])}function Bf(e){const t=Tf(e),i=t.find(e=>e.dataset.lk===Ff)??t.find(e=>"true"===e.getAttribute("aria-pressed"))??t[0];for(const e of t){const t=e===i;e.tabIndex=t?0:-1,e.closest("li")?.querySelectorAll("[data-ctl]").forEach(e=>e.tabIndex=t?0:-1)}}class If{constructor(e,t){this.host=e,this.actions=t,this._n=0,e.addController(this),this.direction=new _(e)}hostUpdated(){Bf(this.host);const e=this._focus,t=this.host.renderRoot?.querySelector("mc-ui-menu");t&&this._menu?.first&&(this._menu.first=!1,t.anchor=this.host.renderRoot?.querySelector(`li[data-ref="${this._menu.key}"] [data-ctl="menu"]`)??void 0,t.show()),e&&this._refocus(e)}get view(){return this.host.layerView??po}announce(e,t=this.view){this.host.dispatchEvent(new CustomEvent("layer-view-change",{detail:{view:t,announce:e},bubbles:!0,composed:!0}))}locked(e){return!!this.host.doc&&wo(this.host.doc,this.view,e)}refuseLocked(e,t){return!!this.locked(e)&&(this.announce(as(1229,{name:t})),!0)}setOpen(e,t){const i=this.view;i.open.includes(e)!==t&&this.announce("",{...i,open:t?[...i.open,e]:i.open.filter(t=>t!==e)})}toggle(e,t,i){const n=function(e,t,i){const n=_o[i];return{...e,[n]:e[n].includes(t)?e[n].filter(e=>e!==t):[...e[n],t]}}(this.view,e,i),s=n["hide"===i?"hidden":"solo"===i?"solo":"locked"].includes(e);this.announce(as(Nf[i][s?0:1],{name:t}),n)}focusKey(e,t){this._focus={key:e,ctl:t},this._refocus(this._focus),this.host.requestUpdate()}async _refocus(e,t=0){await this.host.updateComplete;const i=Tf(this.host).find(t=>t.dataset.lk===e.key),n=i?e.ctl?i.closest("li")?.querySelector(`[data-ctl="${e.ctl}"]`):i:void 0;n?(this._focus===e&&(this._focus=void 0),Ff=e.key,n.focus(),n.scrollIntoView?.({block:"nearest"})):t<4&&this._focus===e?setTimeout(()=>{this._refocus(e,t+1)},16):this._focus===e&&(this._focus=void 0)}_key(e,t){const i=e.target;if(!i.matches?.("[data-lk]")||e.ctrlKey||e.metaKey)return;const n=Tf(this.host),s=n.indexOf(i),r=t=>{e.preventDefault(),n[Math.max(0,Math.min(n.length-1,t))]?.focus()};if(e.altKey&&("ArrowUp"===e.key||"ArrowDown"===e.key))return e.preventDefault(),void this._move(t,"ArrowUp"===e.key?"up":"down");if(e.altKey)return;if(!e.shiftKey&&"ArrowUp"===e.key)return r(s-1);if(!e.shiftKey&&"ArrowDown"===e.key)return r(s+1);if("Home"===e.key)return r(0);if("End"===e.key)return r(n.length-1);const a="rtl"===this.direction.direction;if(e.key===(a?"ArrowLeft":"ArrowRight")&&!1===t.expanded)e.preventDefault(),this.actions.open?.(t.key,!0);else if(e.key===(a?"ArrowRight":"ArrowLeft"))if(t.expanded)e.preventDefault(),this.actions.open?.(t.key,!1);else{const i=this.host.doc?xo(this.host.doc,t.key):void 0;i&&(e.preventDefault(),this.focusKey(i))}else if("F2"===e.key&&t.renamable&&this.actions.rename)e.preventDefault(),this._rename(t);else if(!e.shiftKey&&1===e.key.length){const i=Df.find(t=>Rf[t].key===e.key.toUpperCase());i&&this._toggles(t).includes(i)&&(e.preventDefault(),this.toggle(t.key,t.name,i))}}_toggles(e){return e.toggles??co[e.key.split(":")[0]]??[]}_move(e,t,i){const n="up"===t?e.up:e.down;n?.ok&&this.actions.move&&(this.refuseLocked(e.key,e.name)||(this.actions.move(e.key,t),this.focusKey(e.key,i)))}_rename(e){this.refuseLocked(e.key,e.name)||this.actions.rename?.(e.key)}_openMenu(e,t=!0){this._menu={key:e,first:t},this.host.requestUpdate()}_toggleMenu(e){if(this._menu?.key===e)return this._closeMenu();const t=this._outsideAt;this._outsideAt=void 0,t&&t.key===e&&Date.now()-t.at<400||this._openMenu(e)}_closeMenu(e=!0){const t=this._menu?.key;this._menu=void 0,this.host.requestUpdate(),t&&e&&this.focusKey(t,"menu")}_menuItems(e){const t=this.locked(e.key),i=[];if(this.actions.move)for(const n of["up","down"]){const s="up"===n?e.up:e.down;if(!s)continue;const r=s.menu??s.label,a=t?as(429):s.ok?void 0:as("up"===n?50:49);i.push({id:`move-${n}`,icon:"up"===n?"mdi:arrow-up":"mdi:arrow-down",label:t?r.replace(/ \(.*\)$/,""):r,reason:a,keys:as("up"===n?55:54),run:()=>this._move(e,n,"menu")})}e.renamable&&this.actions.rename&&i.push({id:"rename",icon:"mdi:rename-outline",label:as(725),reason:t?as(429):void 0,keys:"F2",run:()=>this._rename(e)});const n=this.view;return Df.filter(t=>this._toggles(e).includes(t)).forEach((t,s)=>{const r=n["hide"===t?"hidden":"solo"===t?"solo":"locked"].includes(e.key);i.push({id:t,icon:r?"mdi:checkbox-marked":"mdi:checkbox-blank-outline",label:as(Rf[t].name),checked:r,keys:Rf[t].key,separatorBefore:0===s&&i.length>0,run:()=>this.toggle(e.key,e.name,t)})}),i}_renderMenu(e){const t=this._menuItems(e);return a.qy`<mc-ui-menu
      .items=${t}
      .align=${"end"}
      label=${as(406,{name:e.name})}
      @mc-menu-pick=${e=>{e.stopPropagation();const i=t.find(t=>t.id===e.detail.id);this._closeMenu(),i?.run()}}
      @mc-menu-close=${e=>{e.stopPropagation();const t=e.detail.reason;"pick"!==t&&("outside"===t&&this._menu&&(this._outsideAt={key:this._menu.key,at:Date.now()}),this._closeMenu(!1))}}
    ></mc-ui-menu>`}row(e){const t=this.host,i=t.doc,n=this.view,s="compact"===t.density,r=this._toggles(e),o=i?function(e,t,i){if(t.hidden.includes(i))return{kind:"self"};const n=yo(e,t);if(n.has(i))return{kind:"solo"};for(let t=xo(e,i),s=0;t&&s<4;t=xo(e,t),s++)if(n.has(t))return{kind:"parent",by:t}}(i,n,e.key):void 0,l=n.solo.includes(e.key),c=n.locked.includes(e.key),d=!c&&this.locked(e.key),p=i&&!1===e.expanded?function(e,t,i){const n=yo(e,t);let s=0;for(const r of vo(e).keys())xo(e,r)===i&&(n.has(r)||t.solo.includes(r))&&s++;return s}(i,n,e.key):0,h=[e.describe,"self"===o?.kind&&as(1114),"solo"===o?.kind&&as(1112),"parent"===o?.kind&&as(1113,{name:(e=>e?this.actions.nameOf?.(e)??e.split(":").slice(1).join(":"):"")(o.by)}),l&&"solo",c&&"locked",d&&as(1125),p>0&&as(1157,{below:p})].filter(Boolean),u="ld"+this._n++,m=c||d,g=t=>{const i="up"===t?e.up:e.down;return i?a.qy`<button type="button" class="icon-btn xs lt mv ${t}" data-ctl=${t} tabindex="-1" aria-label=${i.label} title=${i.label} aria-disabled=${i.ok&&!m?a.s6:"true"} @click=${()=>this._move(e,t,t)}>
        <ha-icon icon=${"up"===t?"mdi:chevron-up":"mdi:chevron-down"}></ha-icon>
      </button>`:a.s6},f=r.length>0||!!e.up||!!e.down||e.renamable&&!!this.actions.rename,v=s?a.s6:a.qy`<span class="lfull">${r.length?Df.filter(e=>r.includes(e)).map(t=>{const i="hide"===t?"self"===o?.kind:"solo"===t?l:c,n=!i&&("hide"===t?!!o:"lock"===t&&d),s=Rf[t];return a.qy`<button type="button" class="icon-btn xs lt ${n?"soft":""}" data-ctl=${t} data-toggle=${t} tabindex="-1" aria-pressed=${i?"true":"false"} aria-label=${as(s.name)} title=${"hide"===t&&!i&&e.key.startsWith("lane:")?as(364):as(s.tip[i?1:0])} @click=${()=>this.toggle(e.key,e.name,t)}>
        <ha-icon icon=${s.icon[i||n?1:0]}></ha-icon>
      </button>`}):a.s6}${g("up")}${g("down")}</span>`;return a.qy`<li class="lr lvl-${e.level??1} ${s?"compact":""} ${e.selected?"sel":""} ${o?"is-hidden":""} ${m?"is-locked":""}" data-ref=${e.key} data-id=${e.key.slice(e.key.indexOf(":")+1)} @dblclick=${()=>this.actions.dblclick?.(e.key)} @keydown=${t=>this._key(t,e)}>
      <div class="lr-in">
        ${void 0===e.expanded?a.qy`<span class="lcaret-space"></span>`:a.qy`<button type="button" class="icon-btn xs lt lcaret" tabindex="-1" aria-label=${e.expanded?as(163,{name:e.name}):as(309,{name:e.name})} @click=${()=>this.actions.open?.(e.key,!e.expanded)}>
              <ha-icon icon=${e.expanded?"mdi:chevron-down":"rtl"===this.direction.direction?"mdi:chevron-left":"mdi:chevron-right"}></ha-icon>
            </button>`}
        <button type="button" class="lr-main" data-lk=${e.key} tabindex="-1" aria-pressed=${e.selected?"true":"false"} aria-expanded=${void 0===e.expanded?a.s6:e.expanded?"true":"false"} aria-describedby=${h.length?u:a.s6} aria-keyshortcuts="H S L Alt+ArrowUp Alt+ArrowDown" title=${(e.title??e.name)+(e.badge&&!e.title?` (${e.badge})`:"")} @focus=${e=>(Ff=e.currentTarget.dataset.lk,Bf(t))} @click=${t=>this.actions.select(e.key,t)}>
          ${e.thumb??(e.bare?a.s6:a.qy`<ha-icon class="kind" icon=${e.icon??"mdi:layers-outline"}></ha-icon>`)}
          ${e.renaming?a.s6:a.qy`<span class="nm"><span class="nm-t">${e.name}</span>${e.note?a.qy`<small>${e.note}</small>`:a.s6}</span>`}
          ${e.badge?a.qy`<span class="lbadge">${e.badge}</span>`:a.s6}
          ${p>0?a.qy`<span class="lbadge warn" aria-hidden="true">${as(1156,{below:p})}</span>`:a.s6}
        </button>
        ${e.renaming?a.qy`<div class="lrename">${e.renaming}</div>`:a.s6}
        <span class="lst" aria-hidden="true">
          ${o?a.qy`<ha-icon icon="mdi:eye-off-outline"></ha-icon>`:a.s6}${l?a.qy`<ha-icon icon="mdi:radiobox-marked"></ha-icon>`:a.s6}${m?a.qy`<ha-icon icon="mdi:lock-outline"></ha-icon>`:a.s6}
        </span>
        ${v}
        ${f?a.qy`<button type="button" class="icon-btn xs lt lm" data-ctl="menu" tabindex="-1" aria-haspopup="menu" aria-expanded=${this._menu?.key===e.key?"true":"false"} aria-label=${as(406,{name:e.name})} title=${as(405)} @click=${()=>this._toggleMenu(e.key)} @keydown=${t=>{"ArrowDown"!==t.key&&"ArrowUp"!==t.key||(t.preventDefault(),this._openMenu(e.key))}}>
              <ha-icon icon="mdi:dots-vertical"></ha-icon>
            </button>`:a.s6}
        ${e.extra??a.s6}
      </div>
      ${h.length?a.qy`<span id=${u} class="lr-sr">${h.join(", ")}</span>`:a.s6}
      ${this._menu?.key===e.key?this._renderMenu(e):a.s6}
    </li>`}}const Zf=a.AH`
  ${js}
  ${qs}
  .lr {
    list-style: none;
    container-type: inline-size;
    border-radius: var(--mc-radius, 8px);
  }
  .lr-in {
    display: flex;
    align-items: center;
    flex-wrap: nowrap;
    gap: 2px;
    min-height: 32px;
    padding-inline-end: 2px;
    border-radius: var(--mc-radius, 8px);
    --mdc-icon-size: 18px;
  }
  .lr:hover .lr-in {
    background: var(--mc-surface-2);
  }
  .lr.sel .lr-in {
    background: var(--mc-accent-tint);
    color: var(--mc-accent-ink);
  }
  .lr.lvl-2 .lr-in {
    padding-inline-start: 18px;
  }
  .lr.lvl-3 .lr-in {
    padding-inline-start: 36px;
  }
  .lr-main {
    all: unset;
    box-sizing: border-box;
    flex: 1 1 0;
    min-width: 0;
    min-height: 32px;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 2px 4px;
    border-radius: var(--mc-radius, 8px);
    color: inherit;
    font-size: 0.875rem;
    cursor: pointer;
  }
  .lr-main:focus-visible {
    outline: 2px solid var(--mc-focus, var(--mc-accent));
    outline-offset: -2px;
  }
  .kind {
    flex: none;
    color: var(--mc-text-2);
  }
  .lr.sel .kind {
    color: inherit;
  }
  .lr.is-hidden .kind,
  .lr.is-hidden .thumb {
    opacity: 0.5;
  }
  .nm {
    display: grid;
    min-width: 0;
    flex: 1;
  }
  .nm-t,
  .nm small {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .nm small {
    font-size: 0.75rem;
    color: var(--mc-text-2);
  }
  .lr.sel .nm small {
    color: inherit;
  }
  .lbadge {
    flex: none;
    padding: 0 6px;
    min-height: 20px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border-radius: 9999px;
    border: 1px solid var(--mc-divider);
    background: var(--mc-surface);
    color: var(--mc-text-2);
    font-size: 0.6875rem;
    font-weight: 500;
    white-space: nowrap;
  }
  .lbadge.warn {
    color: var(--mc-warn-ink);
    background: var(--mc-warn-tint);
  }
  .lcaret-space {
    width: 0;
  }
  .lrename {
    flex: 1;
    min-width: 0;
  }
  .lt:focus-visible {
    outline: 2px solid var(--mc-focus, var(--mc-accent));
    outline-offset: 0;
  }
  .lr .lt:hover:not(:disabled) {
    background: var(--mc-surface);
  }
  .lr.sel .lt {
    color: inherit;
  }
  .lt.soft {
    opacity: 0.6;
  }
  .lfull {
    display: contents;
  }
  .lst {
    display: none;
    flex: none;
    gap: 2px;
    color: var(--mc-text-2);
    --mdc-icon-size: 16px;
  }
  .lm {
    display: none;
  }
  .lr.compact .lm {
    display: inline-grid;
  }
  .lr.compact .lst:not(:empty) {
    display: flex;
  }
  .lr-sr {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
  }
  /* under 320 px the name needs the room: the count is read out (and in the tooltip) but not drawn */
  @container (max-width: 319px) {
    .lbadge:not(.warn) {
      position: absolute;
      width: 1px;
      height: 1px;
      padding: 0;
      overflow: hidden;
      clip: rect(0 0 0 0);
      border: 0;
      white-space: nowrap;
    }
  }
  @container (max-width: 199px) {
    .lfull {
      display: none;
    }
    .lm {
      display: inline-grid;
    }
    .lst:not(:empty) {
      display: flex;
    }
  }
  @container (min-width: 200px) and (max-width: 319px) {
    .lm {
      display: inline-grid;
    }
    .lfull .mv {
      display: none;
    }
  }
  @media (pointer: coarse) {
    @container (max-width: 319px) {
      .lfull {
        display: none;
      }
      .lst:not(:empty) {
        display: flex;
      }
    }
    .lr-main {
      min-height: var(--mc-hit, 44px);
    }
  }
  @media (prefers-reduced-motion: reduce) {
    .lr * {
      transition: none !important;
    }
  }
`;function Wf(e){const t=e.lastIndexOf("|");return{target:e.slice(5,t),lane:e.slice(t+1)}}const Kf=e=>Zs[Wf(e).lane]?Ks(Wf(e).lane):e,Uf=(e,t,i,n)=>go(e,i).length?t.open.includes(n):void 0;function Gf(e,t,i){const{target:n,lane:s}=Wf(i),r={kind:"keys",keys:fo(t,n,s).map(e=>({target:n,lane:s,at:e,id:`${s}@${e}`})),target:n,targets:[n]};e.dispatchEvent(new CustomEvent("selection-change",{detail:{selection:r},bubbles:!0,composed:!0}))}function Yf(e,t,i,n,s){return go(t,n).map(r=>{const a=((e,t)=>`lane:${e}|${t}`)(n,r),o=fo(t,n,r).length,l="keys"===i?.kind&&!!i.keys?.length&&i.keys.every(e=>e.target===n&&e.lane===r);return e.row({key:a,name:Kf(a),bare:!0,level:s,badge:as(1168,{count:o}),describe:as(1118),selected:l,title:as(1246,{name:Kf(a),count:o})})})}const Jf="0 0 24 24",Xf=new Map,Qf=new Map,ev=new Map,tv=new Set;let iv,nv,sv=0;const rv=new Set;let av=!1;const ov=e=>e.includes(":")?e.slice(0,e.indexOf(":")):"",lv=new Set(["mdi","hass","hassio","hademo"]);function cv(e){const t="undefined"==typeof window?{}:window,i=t.customIconsets?.[e];if("function"==typeof i)return i;const n=t.customIcons?.[e];return n&&"function"==typeof n.getIcon?e=>n.getIcon(e):void 0}function dv(e,t){for(Xf.delete(e),Xf.set(e,{g:t,at:Date.now()});Xf.size>200;)Xf.delete(Xf.keys().next().value);t&&(tv.delete(e),ev.get(e)?.forEach(e=>{try{e()}catch{}}))}function pv(e){const t=Xf.get(e);if(t?.g)return Xf.delete(e),Xf.set(e,t),t.g}const hv=new Map;function uv(e,t){t&&hv.delete(t);const i=t??`svg:${function(e){let t=2166136261;for(let i=0;i<e.length;i++)t^=e.charCodeAt(i),t=Math.imul(t,16777619);return(t>>>0).toString(36)+e.length.toString(36)}(e)}`;let n=i;for(let t=1;hv.has(n)&&hv.get(n).text!==e;t++)n=`${i}.${t}`;const s=function(e){const t=hv.get(e);return t&&(hv.delete(e),hv.set(e,t)),t}(n);if(s)return s.geometry&&!Xf.get(n)?.g&&dv(n,s.geometry),n;const r=function(e){try{return et(e)}catch{return Ye(Ge)}}(e),a={text:e};if(r.error)a.error=r.error;else{const e={paths:r.paths,viewBox:r.viewBox};r.accentPaths.length&&(e.secondary=r.accentPaths),r.strokes.length&&(e.strokes=r.strokes),r.evenodd&&(e.evenodd=r.evenodd),a.markup=r.markup,a.geometry=e}for(hv.set(n,a);hv.size>50;){const e=hv.keys().next().value;hv.delete(e),Xf.delete(e)}return a.geometry&&dv(n,a.geometry),n}async function mv(e){const t=cv(ov(e));if(!t)return;let i;try{i=await t((e=>e.slice(e.indexOf(":")+1))(e))}catch{return}if(!i||"object"!=typeof i)return;if("string"==typeof i.mc_svg){uv(i.mc_svg,e);const t=pv(e);if(t)return t}const n="string"==typeof i.path?i.path.trim():"";if("string"==typeof i.svg||n.startsWith("<"))return"markup";if(!n)return;const s={paths:[n],viewBox:"string"==typeof i.viewBox&&i.viewBox.trim()?i.viewBox.trim():Jf},r="string"==typeof i.secondaryPath?i.secondaryPath.trim():"";return r&&!r.startsWith("<")&&(s.secondary=[r]),s}function gv(e,t){return new Promise(i=>{const n=document.createElement("ha-icon");n.setAttribute("icon",e);let s,r=!1;const a=setInterval(()=>{p(),c()},50),o=setTimeout(()=>l(void 0),t),l=e=>{r||(r=!0,rv.delete(d),s?.disconnect(),clearInterval(a),clearTimeout(o),n.remove(),nv&&!nv.childElementCount&&(nv.remove(),nv=void 0),i(e))},c=()=>{if(r)return;const e=n.shadowRoot?.querySelector("ha-svg-icon"),t="string"==typeof e?.path?e.path.trim():"";if(!e||!t)return;const i={paths:[t],viewBox:"string"==typeof e.viewBox&&e.viewBox.trim()?e.viewBox.trim():Jf},s="string"==typeof e.secondaryPath?e.secondaryPath.trim():"";s&&(i.secondary=[s]),l(i)},d=()=>l(void 0);function p(){!s&&n.shadowRoot&&"undefined"!=typeof MutationObserver&&(s=new MutationObserver(c),s.observe(n.shadowRoot,{subtree:!0,childList:!0,attributes:!0}))}rv.add(d),(nv?.isConnected||(nv=document.createElement("div"),nv.setAttribute("aria-hidden","true"),nv.style.cssText="position:fixed;left:-9999px;top:0;width:0;height:0;overflow:hidden;pointer-events:none;",document.body.appendChild(nv)),nv).appendChild(n),p();const h=n;h.updateComplete?.then(()=>{p(),c()},()=>{}),c()})}function fv(){for(const e of[...tv]){if(!cv(ov(e))||Qf.has(e))continue;tv.delete(e);const t=mv(e).then(t=>(Qf.delete(e),dv(e,t&&"markup"!==t?t:null),t&&"markup"!==t?t:void 0));Qf.set(e,t)}}function vv(e){const t=e.detail;if("icons"===t?.kind)for(const e of t.ids?.length?t.ids.map(e=>`mcu:${e}`):[...Xf.keys(),...ev.keys()].filter(e=>e.startsWith("mcu:")))Xf.delete(e),hv.delete(e),ev.get(e)?.forEach(e=>e())}function bv(e,t={}){if(!e||!e.includes(":"))return Promise.resolve(void 0);if(e.startsWith("svg:"))return Promise.resolve(pv(e));av||"undefined"==typeof window||(av=!0,window.addEventListener("iconset-registered",fv),window.addEventListener("mcu-library-changed",vv));const i=Xf.get(e);if(i){if(i.g)return Promise.resolve(pv(e));const t=Date.now()-i.at>6e4,n=tv.has(e)&&!!cv(ov(e));if(!t&&!n)return Promise.resolve(void 0);n&&tv.delete(e),Xf.delete(e)}if(e.startsWith("svg:"))return Promise.resolve(void 0);const n=Qf.get(e);if(n)return n;const s=(async()=>{const i=!!cv(ov(e)),n=await mv(e);if("markup"===n)return void dv(e,null);if(n)return dv(e,n),n;const s=ov(e);if(!lv.has(s))return dv(e,null),void(i||(tv.add(e),function(){if(sv=10,iv||!tv.size)return;const e=()=>{iv=void 0,fv(),tv.size&&--sv>0&&(iv=setTimeout(e,500))};iv=setTimeout(e,500)}()));const r=t.timeoutMs??3e3,a=function(e,t){return"undefined"!=typeof document&&document.body&&"undefined"!=typeof customElements?customElements.get("ha-icon")?gv(e,t):new Promise(i=>{const n=Date.now();let s=!1;const r=()=>!s&&(s=!0,rv.delete(a),clearTimeout(o),!0),a=()=>{r()&&i(void 0)},o=setTimeout(a,t);rv.add(a),customElements.whenDefined("ha-icon").then(()=>{r()&&gv(e,Math.max(0,t-(Date.now()-n))).then(i)},a)}):Promise.resolve(void 0)}(e,Math.max(r,t.probeMaxMs??15e3));a.then(t=>{t&&(dv(e,t),fv())});const o=await new Promise(e=>{const t=setTimeout(()=>e(void 0),r);a.then(i=>{clearTimeout(t),e(i)})});if(o)return o;pv(e)||dv(e,null)})().finally(()=>Qf.delete(e));return Qf.set(e,s),s}const yv=e=>e.slice(e.indexOf(":")+1),xv=e=>`part:${e}`,_v=e=>`group:${e}`,wv=e=>"string"==typeof e&&/^(part|group):/.test(e),kv=e=>!!e.rig&&(e.rig.parts.length>0||!!e.rig.shapes?.length);function $v(e){return new Set([...(e?.parts??[]).map(e=>e.id),...(e?.groups??[]).map(e=>e.id),...(e?.shapes??[]).map(e=>e.id)])}function Mv(e,t,i=$v(e)){const n=t.toLowerCase().replace(/[^a-z0-9_-]+/g,"-").replace(/^[-_]+/,"").slice(0,24)||"part";for(let e=1;;e++){const t=`${n}-${e}`;if(!i.has(t)&&un.test(t))return t}}function Sv(e,t="icon"){return e.rig?.icon?e.rig.icon:e.rig?.svg?uv(e.rig.svg):String(ms(t,"m",!1).icon??"mdi:bell-ring")}const zv=e=>pv(e),Cv=e=>bv(e),Av=new WeakMap;function jv(e){let t=Av.get(e);return t||Av.set(e,t=(0,cg.WP)(e)),t}const qv=(e,t)=>!e.tracks?.some(e=>e.target===t)&&(e.tracks?.length??0)>=24,Ev=()=>as(1269,{tracks:24}),Hv=(e,t)=>e.tracks?.find(e=>e.target===t);function Lv(e,t,i){const n=(e.tracks??[]).filter(e=>e.target!==t),s=(e.tracks??[]).findIndex(e=>e.target===t);i&&n.splice(s<0?n.length:s,0,{...i,target:t});const r={...e,tracks:n};return n.length||delete r.tracks,r}function Vv(e,t){const i={...e};return e.tracks&&(i.tracks=e.tracks.filter(e=>!t.has(e.target)),i.tracks.length||delete i.tracks),e.bindings&&(i.bindings=e.bindings.filter(e=>!t.has(e.target)),i.bindings.length||delete i.bindings),i}const Ov=(e,t)=>({...e,rig:t});function Pv(e,t,i){const n=e.rig,s=i.trim();if(!n||!s)return e;const r=yv(t);return t.startsWith("part:")?Ov(e,{...n,parts:n.parts.map(e=>e.id===r?{...e,name:s}:e)}):t.startsWith("group:")?Ov(e,{...n,groups:(n.groups??[]).map(e=>e.id===r?{...e,name:s}:e)}):t.startsWith("shape:")?Ov(e,{...n,shapes:(n.shapes??[]).map(e=>e.id===r?{...e,name:s}:e)}):e}function Rv(e,t){const i=e.rig,n=[];for(const e of t){const t=yv(e),s=e.startsWith("group:")?i?.groups?.find(e=>e.id===t)?.parts??[]:e.startsWith("part:")?[t]:[];for(const e of s)!n.includes(e)&&i?.parts.some(t=>t.id===e)&&n.push(e)}return(i?.parts??[]).map(e=>e.id).filter(e=>n.includes(e))}const Dv=(e,t)=>e?.groups?.find(e=>e.parts.includes(t));function Nv(e,t){return Rv(e,t).length<2?as(789):(e.rig?.groups?.length??0)>=16?as(1194,{groups:16}):""}function Fv(e,t,i){const n=e.rig;if(!n||Nv(e,t))return{doc:e};const s=Rv(e,t),r=Mv(n,"group"),a=(n.groups??[]).map(e=>({...e,parts:e.parts.filter(e=>!s.includes(e))})),o=new Set(a.filter(e=>!e.parts.length).map(e=>_v(e.id))),l=[...a.filter(e=>e.parts.length),{id:r,name:i?.trim()||`Group ${(n.groups?.length??0)+1}`,parts:s}];return{doc:Ov(Vv(e,o),{...n,groups:l}),id:r}}function Tv(e,t){const i=e.rig;if(!i?.groups?.some(e=>e.id===t))return e;const n=i.groups.filter(e=>e.id!==t),s={...i,groups:n};return n.length||delete s.groups,Ov(Vv(e,new Set([_v(t)])),s)}function Bv(e,t,i){const n=e.rig;if(!n)return e;const s=yv(t),r=e=>Math.round(100*e)/100,a=e=>{if(e.id!==s)return e;const t={...e};return i?t.origin=[r(i[0]),r(i[1])]:delete t.origin,t};return t.startsWith("part:")?Ov(e,{...n,parts:n.parts.map(a)}):t.startsWith("group:")?Ov(e,{...n,groups:(n.groups??[]).map(a)}):t.startsWith("shape:")?Ov(e,{...n,shapes:(n.shapes??[]).map(a)}):e}const Iv=e=>/^(part|group|shape):/.test(e),Zv=(e,t)=>Iv(t)&&!!Hv(e,t)?.origin;function Wv(e,t,i){const n=Hv(e,t);if(!n||!Iv(t))return e;const s={...n},r=e=>Math.round(100*e)/100;return i?s.origin=`${r(i[0])}px ${r(i[1])}px`:delete s.origin,Lv(e,t,s.keyframes.length||s.path||s.origin?s:void 0)}function Kv(e,t,i){return Zv(e,t)?Wv(e,t,i):Bv(e,t,i)}function Uv(e,t,i){const n=e.rig;if(!n)return;const s=Rv(e,[t]).flatMap(e=>(n.parts.find(t=>t.id===e)?.from??[]).map(e=>i[e]?.bbox)).filter(e=>!!e);return(0,cg.Zg)(s)}function Gv(e,t,i,n){const s=function(e,t,i=[0,0,24,24]){const n=Iv(t)?Hv(e,t)?.origin?.trim():void 0;if(!n)return;const s=(e,t)=>{const n=i[2+t];if(!e||"center"===e)return n/2;if("left"===e||"top"===e)return 0;if("right"===e||"bottom"===e)return n;const s=parseFloat(e);return Number.isFinite(s)?e.endsWith("%")?n*s/100:s:n/2};let[r,a]=n.split(/\s+/);return"top"!==r&&"bottom"!==r&&("left"!==a&&"right"!==a||"center"!==r)||([r,a]=[a,r]),[s(r,0),s(a,1)]}(e,t,n);if(s)return s;const r=e.rig,a=yv(t),o=t.startsWith("part:")?r?.parts.find(e=>e.id===a)?.origin:t.startsWith("group:")?r?.groups?.find(e=>e.id===a)?.origin:void 0;if(o)return o;const l=Uv(e,t,i);return l?[l[0]+l[2]/2,l[1]+l[3]/2]:void 0}function Yv(e,t){const i=yv(t),n=e.rig;return t.startsWith("part:")?n?.parts.find(e=>e.id===i)?.name??i:t.startsWith("group:")?n?.groups?.find(e=>e.id===i)?.name??i:t.startsWith("shape:")?n?.shapes?.find(e=>e.id===i)?.name??i:t}function Jv(e,t){return(Hv(e,t)?.keyframes??[]).filter(e=>void 0!==e.draw).map(e=>[e.at,e.draw])}function Xv(e,t,i){const n=e.map(e=>e.at===t?{...e,...i}:e);return e.some(e=>e.at===t)||n.push({at:t,...i}),n.sort((e,t)=>e.at-t.at)}function Qv(e,t,i,n=0,s=60){if("none"!==i&&qv(e,t))return e;const r=Hv(e,t);let a=(r?.keyframes??[]).map(e=>{if(void 0===e.draw)return e;const t={...e};return delete t.draw,t});if(a=a.filter(e=>Object.keys(e).some(e=>"at"!==e&&"easing"!==e&&"easings"!==e)),"none"!==i){const[e,t]="on"===i?[0,1]:[1,0],r=Math.max(0,Math.min(100,n)),o=Math.max(r,Math.min(100,s));a=Xv(a,r,{draw:e}),a=Xv(a,o,{draw:t}),r>0&&(a=Xv(a,0,{draw:e})),o<100&&(a=Xv(a,100,{draw:t}))}return a.length||r?.path?Lv(e,t,{...r??{target:t},target:t,keyframes:a.slice(0,40)}):Lv(e,t,void 0)}const eb="M0 0 C 2 -3 4 -3 6 0 S 2 3 0 0";function tb(e,t,i){const n=Hv(e,t);if(!i){if(!n)return e;const i={...n};return delete i.path,Lv(e,t,i.keyframes.length?i:void 0)}return qv(e,t)?e:Lv(e,t,{...n??{target:t,keyframes:[]},target:t,path:i})}const ib=/^(part|group|shape):/;function nb(e){if(!e||"target"!==e.kind&&"keys"!==e.kind)return[];const t=[...e.target?[e.target]:[],...e.targets??[]];return[...new Set(t)].filter(e=>ib.test(e))}function sb(e,t){const i=[...new Set(e)];if(!i.length)return{kind:"none"};const n=t&&i.includes(t)?t:i[i.length-1];return{kind:"target",target:n,targets:[n,...i.filter(e=>e!==n)]}}function rb(e,t){e.dispatchEvent(new CustomEvent("selection-change",{detail:{selection:t},bubbles:!0,composed:!0}))}function ab(e,t,i,n=!1){e.dispatchEvent(new CustomEvent("doc-change",{detail:{doc:t,label:i,...n?{transient:!0}:{}},bubbles:!0,composed:!0}))}var ob=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const lb={part:"mdi:vector-square",group:"mdi:folder-outline",shape:"mdi:draw"};let cb=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection={kind:"none"},this.tile="icon",this.density="full",this._icon="",this._busy=!1,this._error="",this._confirm=!1,this._resplit=!1,this._collapsed=new Set,this._status="",this._notice="",this._iconTyped=!1,this._list=new If(this,{select:(e,t)=>{if(e.startsWith("tracks:"))return this._list.setOpen(e.slice(7),!this.layerView?.open.includes(e.slice(7)));if(e.startsWith("lane:"))return this.disabled?void 0:Gf(this,this.doc,e);const i=this._rows(),n=i.find(t=>t.ref===e);n&&t instanceof MouseEvent?this._onRowClick(t,n,i):n&&(this._anchor=n.ref,this._select([n.ref]))},move:(e,t)=>this._move("up"===t?1:-1,e),rename:e=>this._renaming=e,dblclick:e=>!this.disabled&&!this._list.refuseLocked(e,Yv(this.doc,e))&&(this._renaming=e),open:(e,t)=>e.startsWith("group:")?this._setOpen(e.slice(6),t):this._list.setOpen(e.startsWith("tracks:")?e.slice(7):e,t),nameOf:e=>e.startsWith("lane:")?Kf(e):this.doc?Yv(this.doc,e):e})}connectedCallback(){super.connectedCallback(),Os("mc-icon-picker")||"undefined"==typeof customElements||customElements.whenDefined("mc-icon-picker").then(()=>this.requestUpdate())}willUpdate(e){const t=e.get("doc");if(e.has("doc")&&t&&t.id!==this.doc?.id&&(this._icon="",this._iconTyped=!1,this._confirm=!1,this._resplit=!1,this._error="",this._notice=""),(e.has("doc")||e.has("tile"))&&!this._iconTyped&&this.doc){const e=Sv(this.doc,this.tile);this._icon=e.startsWith("svg:")?"":e}}get _sel(){return nb(this.selection)}_rows(){const e=this.doc,t=e?.rig;if(!e||!t)return[];const i=t=>Hv(e,t)?.keyframes.length??0,n=[],s=new Set,r=[...t.parts].reverse();for(const e of r){const a=Dv(t,e.id);if(a){if(!s.has(a.id)&&(s.add(a.id),n.push({ref:_v(a.id),level:1,kind:"group",name:a.name,count:a.parts.length,keys:i(_v(a.id))}),!this._collapsed.has(a.id)))for(const e of r.filter(e=>Dv(t,e.id)?.id===a.id))n.push({ref:xv(e.id),level:2,kind:"part",name:e.name,count:e.from?.length??1,keys:i(xv(e.id))})}else n.push({ref:xv(e.id),level:1,kind:"part",name:e.name,count:e.from?.length??1,keys:i(xv(e.id))})}return n}_change(e,t,i=t){this._status=i,ab(this,e,t)}_select(e,t){rb(this,sb(e,t))}async _split(){const e=this.doc;if(!e||this._busy||this.disabled)return;if(kv(e)&&!this._confirm)return void(this._confirm=!0);const t=!this._resplit&&e.rig?.svg?e.rig.svg:void 0,i=t?Sv(e,this.tile):this._icon.trim()||Sv(e,this.tile);if(t||/^[a-z0-9_-]+:[a-z0-9_-]+$/i.test(i)){this._busy=!0,this._error="";try{const n=await Cv(i);if(this.doc?.id!==e.id)return;if(!n)return void(this._error=as(996));const s=jv(n);if(!s.length)return void(this._error=as(998));const r=function(e,t,i){const n=e.rig,s=new Set([...(n?.parts??[]).map(e=>xv(e.id)),...(n?.groups??[]).map(e=>_v(e.id))]),r=function(e,t){const i=e.slice(0,pn).map((e,t)=>({id:`part-${t+1}`,name:as(626,{i:t+1}),from:[e.index]}));return{...t?.svg?{svg:t.svg}:t?.icon?{icon:t.icon}:{},parts:i}}(t,i);if(n?.shapes?.length){const e=new Set(n.shapes.map(e=>e.id));r.parts=r.parts.map(t=>e.has(t.id)?{...t,id:Mv(r,"part",new Set([...e,...r.parts.map(e=>e.id)]))}:t),r.shapes=n.shapes}return Ov(Vv(e,s),r)}(this.doc??e,s,t?{svg:t}:{icon:i}),a=r.rig?.parts.length??0,o=s.length>pn;this._notice=o?as(953,{count:s.length,parts:pn}):"",this._change(r,"Split icon",o?as(1188,{count:a,parts:pn}):as(1187,{count:a})),this._confirm=!1,this._resplit=!1,this._select([])}finally{this._busy=!1}}else this._error=as(1054)}_group(){const e=this.doc;if(!e||this.disabled)return;if(this._lockedSel())return;const t=Nv(e,this._sel);if(t)return void(this._status=t);const i=Fv(e,this._sel);i.id&&(this._change(i.doc,"Group parts",as(1184,{count:Rv(e,this._sel).length})),this._select([_v(i.id)]))}_ungroup(){const e=this.doc,t=this._sel.filter(e=>e.startsWith("group:"));if(!e||!t.length||this.disabled||this._lockedSel())return;let i=e;const n=[];for(const s of t)n.push(...(e.rig?.groups?.find(e=>`group:${e.id}`===s)?.parts??[]).map(xv)),i=Tv(i,s.slice(6));this._change(i,"Ungroup",as(1183,{count:t.length})),this._select(n)}_merge(){const e=this.doc;if(!e||this.disabled||this._lockedSel())return;const t=function(e,t){const i=e.rig,n=Rv(e,t).filter(e=>i?.parts.find(t=>t.id===e)?.from);if(!i||n.length<2)return{doc:e};const[s,...r]=n,a=[...new Set(n.flatMap(e=>i.parts.find(t=>t.id===e).from??[]))].sort((e,t)=>e-t),o=i.parts.filter(e=>!r.includes(e.id)).map(e=>e.id===s?{...e,from:a}:e),l=(i.groups??[]).map(e=>({...e,parts:e.parts.filter(e=>!r.includes(e))})),c=l.filter(e=>!e.parts.length).map(e=>_v(e.id)),d={...i,parts:o,...i.groups?{groups:l.filter(e=>e.parts.length)}:{}};return d.groups&&!d.groups.length&&delete d.groups,{doc:Ov(Vv(e,new Set([...r.map(xv),...c])),d),id:s}}(e,this._sel);t.id&&(this._change(t.doc,"Merge parts",as(640)),this._select([xv(t.id)]))}_splitBack(){const e=this.doc,t=this._sel.find(e=>e.startsWith("part:"));if(!e||!t||this.disabled||this._lockedSel())return;const i=function(e,t){const i=e.rig,n=i?.parts.find(e=>e.id===t);if(!i||!n?.from||n.from.length<2)return{doc:e,ids:[t]};const s=pn-i.parts.length+1,r=n.from.slice(0,Math.max(1,s)),a=$v(i),o=r.slice(1).map(e=>{const t=Mv(i,"part",a);return a.add(t),{id:t,name:as(627,{n:t.slice(5)}),from:[e]}}),l={...n,from:[r[0]]};delete l.origin;const c=i.parts.indexOf(n),d=[...i.parts.slice(0,c),l,...o,...i.parts.slice(c+1)],p=i.groups?.map(e=>e.parts.includes(t)?{...e,parts:[...e.parts,...o.map(e=>e.id)]}:e);return{doc:Ov(e,{...i,parts:d,...p?{groups:p}:{}}),ids:[t,...o.map(e=>e.id)]}}(e,t.slice(5));i.ids.length<2||(this._change(i.doc,"Split part",as(1187,{count:i.ids.length})),this._select(i.ids.map(xv)))}_lockedSel(){const e=this.doc,t=e&&this._sel.find(e=>this._list.locked(e));return!!t&&this._list.refuseLocked(t,Yv(e,t))}_move(e,t){const i=this.doc,n=t??this._sel.find(e=>e.startsWith("part:"));if(!i||!n||!n.startsWith("part:")||this.disabled)return;if(this._list.refuseLocked(n,Yv(i,n)))return;const s=function(e,t,i){const n=e.rig,s=n?.parts.findIndex(e=>e.id===t)??-1,r=s+i;if(!n||s<0||r<0||r>=n.parts.length)return e;const a=[...n.parts];return[a[s],a[r]]=[a[r],a[s]],Ov(e,{...n,parts:a})}(i,n.slice(5),e);s!==i&&(this._change(s,"Move part",as(e>0?494:493)),this._list.announce(as(1236,{name:Yv(i,n),direction:as(e>0?1152:1105)})))}_setOpen(e,t){const i=new Set(this._collapsed);t?i.delete(e):i.add(e),this._collapsed=i}_rename(e,t){if(this._renaming!==e)return;this._renaming=void 0;const i=this.doc;i&&t.trim()&&t.trim()!==Yv(i,e)&&!this._list.refuseLocked(e,Yv(i,e))&&this._change(Pv(i,e,t),"Rename part",as(729))}_onRowClick(e,t,i){if(this._renaming===t.ref)return;const n=this._sel;if(e.shiftKey&&this._anchor){const e=i.findIndex(e=>e.ref===this._anchor),n=i.findIndex(e=>e.ref===t.ref);if(e>=0&&n>=0){const[s,r]=e<n?[e,n]:[n,e];return void this._select(i.slice(s,r+1).map(e=>e.ref),t.ref)}}this._anchor=t.ref,e.ctrlKey||e.metaKey?this._select(n.includes(t.ref)?n.filter(e=>e!==t.ref):[...n,t.ref],t.ref):this._select([t.ref])}_onKey(e){if(this._renaming||this.disabled)return;const t=e.ctrlKey||e.metaKey,i=e.key.toLowerCase();if(t&&"g"===i)return e.preventDefault(),void(e.shiftKey?this._ungroup():this._group());const n=this._rows(),s=n.findIndex(t=>t.ref===(e.target.closest?.("li.lr")?.getAttribute("data-ref")??this.selection.target??this._anchor));if(e.shiftKey&&!e.altKey&&("ArrowDown"===e.key||"ArrowUp"===e.key)&&e.target.matches?.("[data-lk]")){if(/^(lane|tracks):/.test(e.target.dataset.lk??""))return;e.preventDefault();const t=n[Math.max(0,Math.min(n.length-1,s+("ArrowDown"===e.key?1:-1)))];if(!t)return;return s>=0?this._select([...this._sel,t.ref],t.ref):this._select([t.ref]),void this._focusRow(t.ref)}"Escape"===e.key&&this._sel.length&&e.target.matches?.("[data-lk]")&&(e.preventDefault(),this._select([]))}_focusRow(e){this._list.focusKey(e)}_iconBtn(e,t,i,n,s){return a.qy`<button
      type="button"
      class="icon-btn sm"
      title=${s?`${t} (${s})`:t}
      aria-label=${t}
      aria-keyshortcuts=${s??a.s6}
      ?disabled=${this.disabled||!n}
      @click=${i}
    >
      <ha-icon icon=${e}></ha-icon>
    </button>`}_renderSource(e){const t=this.doc,i=!!t.rig?.svg&&!this._resplit;return a.qy`<div class="source">
      ${i?a.qy`<p class="help">${as(968)}</p>`:Os("mc-icon-picker")?a.qy`<div class="field">
              <div class="field-head"><span class="lbl" id="pl-icon-l">${as(377)}</span></div>
              <mc-icon-picker
                .hass=${this.hass}
                .value=${this._icon}
                label=${as(377)}
                aria-labelledby="pl-icon-l"
                @value-changed=${e=>{e.stopPropagation(),this._icon=String(e.detail?.value??"").trim(),this._iconTyped=""!==this._icon,this._error="",this._confirm=!1}}
              ></mc-icon-picker>
            </div>`:a.qy`<div class="field">
            <div class="field-head"><label for="pl-icon">${as(377)}</label></div>
            <input
              id="pl-icon"
              class="input mono"
              .value=${this._icon}
              placeholder=${Sv(t,this.tile)}
              spellcheck="false"
              ?disabled=${this.disabled||this._busy}
              @input=${e=>{this._icon=e.target.value,this._iconTyped=""!==this._icon.trim(),this._error=""}}
              @keydown=${e=>"Enter"===e.key&&void this._split()}
            />
          </div>`}
      ${this._error?a.qy`<p class="help error" role="alert">${this._error}</p>`:a.s6}
      <div class="actions">
        <button type="button" class="btn ${e?"btn-secondary":"btn-primary"} btn-sm" ?disabled=${this.disabled||this._busy} @click=${()=>{this._split()}}>
          <ha-icon icon="mdi:scissors-cutting"></ha-icon>${this._busy?as(867):this._confirm?as(1186,{count:t.rig?.parts.length??0}):as(e?861:864)}
        </button>
        ${e?a.qy`<button
              type="button"
              class="btn btn-text btn-sm"
              @click=${()=>{this._resplit=!1,this._confirm=!1,this._error=""}}
            >
              ${as(114)}
            </button>`:a.s6}
      </div>
      ${this._confirm?a.qy`<p class="help">${as(866)}</p>`:a.s6}
    </div>`}_renderRow(e,t,i){const n=this.doc,s="group"===e.kind?e.ref.slice(6):"",r=n.rig?.parts??[],o="part"===e.kind?r.findIndex(t=>`part:${t.id}`===e.ref):-1,l=this._list.locked(e.ref),c=go(n,e.ref).length>0,d="group"===e.kind?void 0:Uf(n,this.layerView??po,e.ref,e.ref),p=this._list.row({key:e.ref,name:e.name,icon:lb[e.kind],note:"part"===e.kind&&e.count>1?as(1173,{count:e.count}):void 0,badge:e.keys?as(1168,{count:e.keys}):void 0,level:e.level,expanded:"group"===e.kind?!this._collapsed.has(s):d,selected:i.includes(e.ref)&&!(d&&"part"===e.kind&&"keys"===this.selection.kind),renamable:!0,up:"part"===e.kind?{ok:!this.disabled&&o>=0&&o<r.length-1&&!l,label:as(488,{name:e.name}),menu:as(481)}:void 0,down:"part"===e.kind?{ok:!this.disabled&&o>0&&!l,label:as(486,{name:e.name}),menu:as(460)}:void 0,renaming:this._renaming===e.ref?a.qy`<input
              class="input rename"
              aria-label=${as(533)}
              .value=${e.name}
              maxlength="80"
              @click=${e=>e.stopPropagation()}
              @keydown=${t=>{t.stopPropagation(),"Enter"===t.key&&(this._rename(e.ref,t.target.value),this._focusRow(e.ref)),"Escape"===t.key&&(this._renaming=void 0,this._focusRow(e.ref))}}
              @blur=${t=>this._rename(e.ref,t.target.value)}
            />`:void 0});if("group"===e.kind){if(!c||this._collapsed.has(s))return[p];const t=!!Uf(n,this.layerView??po,e.ref,e.ref),i=this._list.row({key:`tracks:${e.ref}`,name:as(1018),bare:!0,level:2,expanded:t,selected:!1,toggles:[],describe:as(1119,{name:e.name})});return t?[p,i,...Yf(this._list,n,this.selection,e.ref,3)]:[p,i]}return d?[p,...Yf(this._list,n,this.selection,e.ref,2===e.level?3:2)]:[p]}render(){const e=this.doc;if(!e||"keyframes"!==e.kind)return a.qy``;const t=kv(e),i=this._rows(),n=this._sel,s=Rv(e,n),r=1===n.length?n[0]:void 0,o=s.length>=2&&s.every(t=>e.rig?.parts.find(e=>e.id===t)?.from),l=!!r&&r.startsWith("part:")&&(e.rig?.parts.find(e=>`part:${e.id}`===r)?.from?.length??0)>1,c=r?.startsWith("part:")?e.rig.parts.findIndex(e=>`part:${e.id}`===r):-1;return a.qy`<div class="parts" @keydown=${this._onKey}>
      ${!t||this._resplit||this._confirm?a.qy`${t?a.s6:a.qy`<p class="lead">${as(865)}</p>`}${this._renderSource(t)}`:a.s6}
      ${t?a.qy`<div class="bar" role="toolbar" aria-label=${as(623)}>
              ${this._iconBtn("mdi:group",as(356),()=>this._group(),!Nv(e,n),as(198))}
              ${this._iconBtn("mdi:ungroup",as(1038),()=>this._ungroup(),n.some(e=>e.startsWith("group:")),as(199))}
              ${this._iconBtn("mdi:set-merge",as(442),()=>this._merge(),o)}
              ${this._iconBtn("mdi:call-split",as(863),()=>this._splitBack(),l)}
              ${this._iconBtn("mdi:arrow-up",as(481),()=>this._move(1),c>=0&&c<e.rig.parts.length-1,as(53))}
              ${this._iconBtn("mdi:arrow-down",as(461),()=>this._move(-1),c>0,as(52))}
            </div>
            <ul class="tree" aria-label=${as(375)}>
              ${i.map(e=>this._renderRow(e,i,n))}
            </ul>
            ${this._notice?a.qy`<p class="help notice" role="note">${this._notice}</p>`:a.s6}
            <p class="help">${as(148)}</p>
            ${this._resplit||this._confirm?a.s6:a.qy`<div>
                  <button type="button" class="btn btn-text btn-sm" ?disabled=${this.disabled} @click=${()=>(this._resplit=!0,this._confirm=!1)}>
                    <ha-icon icon="mdi:scissors-cutting"></ha-icon>${as(861)}
                  </button>
                </div>`}`:a.s6}
      <p class="sr-only" role="status" aria-live="polite">${this._status}</p>
    </div>`}};cb.styles=[Cs,As,Zf,a.AH`
      :host {
        display: block;
        font-size: 0.875rem;
        color: var(--mc-text);
      }
      .parts {
        display: grid;
        gap: 12px;
      }
      .lead {
        margin: 0;
        color: var(--mc-text-2);
        font-size: 0.8125rem;
        line-height: 1.5;
      }
      .source {
        display: grid;
        gap: 8px;
      }
      .actions {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 2px;
        flex-wrap: wrap;
      }
      .bar .spacer {
        flex: 1;
      }
      .tree {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 1px;
      }
      .help {
        margin: 0;
      }
    `],ob([(0,o.MZ)({attribute:!1})],cb.prototype,"doc",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"hass",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"library",void 0),ob([(0,o.MZ)({type:Number})],cb.prototype,"time",void 0),ob([(0,o.MZ)({type:Boolean})],cb.prototype,"disabled",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"selection",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"tile",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"stage",void 0),ob([(0,o.MZ)({attribute:!1})],cb.prototype,"layerView",void 0),ob([(0,o.MZ)()],cb.prototype,"density",void 0),ob([(0,o.wk)()],cb.prototype,"_renaming",void 0),ob([(0,o.wk)()],cb.prototype,"_icon",void 0),ob([(0,o.wk)()],cb.prototype,"_busy",void 0),ob([(0,o.wk)()],cb.prototype,"_error",void 0),ob([(0,o.wk)()],cb.prototype,"_confirm",void 0),ob([(0,o.wk)()],cb.prototype,"_resplit",void 0),ob([(0,o.wk)()],cb.prototype,"_collapsed",void 0),ob([(0,o.wk)()],cb.prototype,"_status",void 0),ob([(0,o.wk)()],cb.prototype,"_notice",void 0),cb=ob([(0,o.EM)("mc-anim-parts-layers")],cb),Ds({tag:"mc-anim-parts-layers",place:"layers",title:375,order:20,when:e=>"keyframes"===e.kind});var db=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};function pb(e){const t=(e??"").split(/[\s,]+/).map(Number);return 4===t.length&&t.every(Number.isFinite)&&t[2]>0&&t[3]>0?t:void 0}let hb=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection={kind:"none"},this.tile="icon",this._vb=[0,0,24,24],this._scale=1,this._watched=new WeakSet}connectedCallback(){super.connectedCallback(),"undefined"!=typeof ResizeObserver&&(this._watched=new WeakSet,this._ro=new ResizeObserver(()=>requestAnimationFrame(()=>this._measure())),this._ro.observe(this))}disconnectedCallback(){super.disconnectedCallback(),this._ro?.disconnect()}get _pieces(){return this._geom?jv(this._geom):[]}willUpdate(e){if((e.has("doc")||e.has("tile"))&&this.doc){const e=Sv(this.doc,this.tile);e!==this._ref&&(this._ref=e,this._geom=zv(e),this._geom||Cv(e).then(t=>{this._ref===e&&t&&(this._geom=t)}))}e.has("doc")&&!this._drag&&(this._live=void 0)}updated(){requestAnimationFrame(()=>this._measure())}_icon(){return this.iconEl??function(e){let t=e;for(;t;)if(t instanceof Element){const e=t.shadowRoot?.querySelector("magic-card")??t.querySelector("magic-card");if(e)return e.shadowRoot?.querySelector('[data-mc-part="icon"]')??void 0;t=t.parentElement??t.getRootNode().host??null}else t=t.host??null}(this)}_measure(){if(!this.isConnected)return;const e=this._icon(),t=this.getBoundingClientRect(),i=this.offsetWidth>0&&t.width>0?t.width/this.offsetWidth:1;let n,s;for(const t of[e,e?.getRootNode()?.host])t&&this._ro&&!this._watched.has(t)&&(this._watched.add(t),this._ro.observe(t));if(e){const r=e.shadowRoot?.querySelector('svg[part="svg"]'),a=(r??e).getBoundingClientRect();a.width>0&&(n={x:(a.left-t.left)/i,y:(a.top-t.top)/i,w:a.width/i,h:a.height/i}),s=pb(r?.getAttribute("viewBox"))}if(!n&&this.stage?.subject){const e=this.stage.subject;n={x:e.x,y:e.y,w:e.width,h:e.height}}s??=this.stage?.viewBox??pb(this._geom?.viewBox)??[0,0,24,24],((e,t)=>!!e&&!!t&&Math.abs(e.x-t.x)<.5&&Math.abs(e.y-t.y)<.5&&Math.abs(e.w-t.w)<.5&&Math.abs(e.h-t.h)<.5)(n,this._box)||!n&&!this._box||(this._box=n),s.join(" ")!==this._vb.join(" ")&&(this._vb=s);const r=this.offsetWidth>0&&t.width>0?i:this.stage&&this.stage.scale>0?this.stage.scale:1;Math.abs(r-this._scale)>.001&&(this._scale=r)}get _unit(){return this._box&&this._box.w>0?this._vb[2]/(this._box.w*(this._scale||1)):.1}_toVb(e){const t=this.renderRoot.querySelector("svg.ov"),i=t?.getBoundingClientRect();return i&&i.width?[this._vb[0]+(e.clientX-i.left)/i.width*this._vb[2],this._vb[1]+(e.clientY-i.top)/i.height*this._vb[3]]:[0,0]}_lk(e){return!!this.doc&&!!this.layerView?.locked.length&&wo(this.doc,this.layerView,e)}get _sel(){return nb(this.selection)}_pick(e,t){const i=this._sel;t.shiftKey?rb(this,sb([...i,e],e)):t.ctrlKey||t.metaKey?rb(this,sb(i.includes(e)?i.filter(t=>t!==e):[...i,e],e)):rb(this,sb([e],e))}_onDown(e){if(this.disabled||e.button>0||!this.doc)return;const t=e.target,i=t.closest("[data-pivot]")?.getAttribute("data-pivot"),n=t.closest("[data-anchor]")?.getAttribute("data-anchor"),s=t.closest("[data-ref]")?.getAttribute("data-ref"),r=this._toVb(e),a={pointerId:e.pointerId,kind:"band",start:r,startClient:[e.clientX,e.clientY],startDoc:this.doc,moved:!1,additive:e.shiftKey||e.ctrlKey||e.metaKey};if(i){if(this._lk(i))return;this._drag={...a,kind:"pivot",ref:i}}else if(null!=n&&this.selection.target){if(this._lk(this.selection.target))return;const e=Hv(this.doc,this.selection.target)?.path?.d;if(!e)return;this._drag={...a,kind:"anchor",ref:this.selection.target,index:Number(n),path:_a(e)}}else{if(s)return void this._pick(s,e);this._drag=a}e.preventDefault(),e.currentTarget.setPointerCapture?.(e.pointerId)}_onMove(e){const t=this._drag;if(!t){const t=e.target.closest?.("[data-ref]")?.getAttribute("data-ref");return void(t!==this._hover&&(this._hover=t))}if(e.pointerId!==t.pointerId)return;if(!t.moved&&Math.hypot(e.clientX-t.startClient[0],e.clientY-t.startClient[1])<3)return;t.moved=!0;const i=this._toVb(e),n=e.shiftKey?0:.25;if("band"===t.kind)this._band=[t.start,i];else if("pivot"===t.kind&&t.ref){const e=[(0,xa.snap)(i[0],n),(0,xa.snap)(i[1],n)];this._live={ref:t.ref,pivot:e},ab(this,Kv(this.doc,t.ref,e),"Move pivot",!0)}else if("anchor"===t.kind&&t.ref&&t.path&&void 0!==t.index){const e=this._pivotOf(t.ref)??[0,0],s=(0,xa.serialize)((0,xa.moveAnchor)(t.path,t.index,(0,xa.snap)(i[0]-e[0],n),(0,xa.snap)(i[1]-e[1],n)));this._live={ref:t.ref,path:s};const r=Hv(this.doc,t.ref);ab(this,tb(this.doc,t.ref,{...r.path,d:s}),"Move path point",!0)}}_onUp(e){const t=this._drag;if(!t||e.pointerId!==t.pointerId)return;this._drag=void 0;const i=this.doc,n=this._live;if(this._live=void 0,"band"===t.kind){const e=this._band;if(this._band=void 0,!t.moved||!e)return void(t.additive||rb(this,{kind:"none"}));const[n,s]=e,r=Math.min(n[0],s[0]),a=Math.max(n[0],s[0]),o=Math.min(n[1],s[1]),l=Math.max(n[1],s[1]),c=(i.rig?.parts??[]).map(e=>xv(e.id)).filter(e=>!this._lk(e)).filter(e=>{const t=Uv(i,e,this._pieces);return!!t&&t[0]>=r&&t[0]+t[2]<=a&&t[1]>=o&&t[1]+t[3]<=l});return void rb(this,sb(t.additive?[...this._sel,...c]:c))}if(t.moved&&("pivot"===t.kind&&t.ref&&n?.pivot&&ab(this,Kv(i,t.ref,n.pivot),"Move pivot"),"anchor"===t.kind&&t.ref&&n?.path)){const e=Hv(i,t.ref);e?.path&&ab(this,tb(i,t.ref,{...e.path,d:n.path}),"Move path point")}}_onCancel(e){const t=this._drag;t&&e.pointerId===t.pointerId&&(this._drag=void 0,this._band=void 0,this._live=void 0,t.moved&&"band"!==t.kind&&ab(this,t.startDoc,"pivot"===t.kind?as(471):as(470)))}_onPivotKey(e,t){const i={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(!i||this.disabled||!this.doc||this._lk(t))return;e.preventDefault();const n=e.shiftKey?1:.25,s=this._pivotOf(t)??[12,12];this._nudge?.ref!==t&&(this._nudge={ref:t,doc:this.doc}),ab(this,Kv(this.doc,t,[s[0]+i[0]*n,s[1]+i[1]*n]),"Move pivot",!0)}_onKeyUp(e){const t=this._nudge;t&&e.key.startsWith("Arrow")&&this.doc&&(this._nudge=void 0,this.doc!==t.doc&&ab(this,this.doc,"Move pivot"))}_onKey(e){if(this.doc&&!this.disabled)if(!e.ctrlKey&&!e.metaKey||"g"!==e.key.toLowerCase()||e.shiftKey)"Escape"===e.key&&this._sel.length&&(e.preventDefault(),rb(this,{kind:"none"}));else{if(this._sel.some(e=>this._lk(e)))return;const t=Fv(this.doc,this._sel);if(!t.id)return;e.preventDefault(),ab(this,t.doc,"Group parts"),rb(this,sb([_v(t.id)]))}}_pivotOf(e){return this._live?.ref===e&&this._live.pivot?this._live.pivot:this.doc?Gv(this.doc,e,this._pieces,this._vb):void 0}_partPaths(e){const t=this.doc,i=this._pieces;return Rv(t,[e]).flatMap(e=>(t.rig.parts.find(t=>t.id===e)?.from??[]).map(e=>i[e]?.d).filter(e=>!!e))}_selected(e,t){const i=this.doc;return e.flatMap(e=>{if(!/^(part|group):/.test(e))return[];const n=Uv(i,e,this._pieces),s=this._pivotOf(e),r=e===this.selection.target,o=[];if(o.push(a.JW`${this._partPaths(e).map(e=>a.JW`<path class="sel-outline" d=${e}></path>`)}`),n&&o.push(a.JW`<rect class="bbox" x=${n[0]} y=${n[1]} width=${n[2]} height=${n[3]}></rect>`),s&&r&&!this._lk(e)){const n=Yv(i,e);o.push(a.JW`<g
          class="pivot"
          data-pivot=${e}
          tabindex="0"
          role="slider"
          aria-label=${Zv(i,e)?as(689,{name:n}):as(658,{name:n})}
          aria-valuetext=${`x ${s[0].toFixed(2)}, y ${s[1].toFixed(2)}`}
          @keydown=${t=>this._onPivotKey(t,e)}
        >
          <circle class="pivot-hit" cx=${s[0]} cy=${s[1]} r=${12*t}></circle>
          <circle class="pivot-ring" cx=${s[0]} cy=${s[1]} r=${5*t} style=${"stroke-width: "+2*t}></circle>
          <path class="pivot-cross" d=${`M${s[0]-9*t} ${s[1]}H${s[0]+9*t}M${s[0]} ${s[1]-9*t}V${s[1]+9*t}`} style=${"stroke-width: "+1.5*t}></path>
        </g>`)}return o})}_motionPath(e){const t=this.selection.target;if(!t||!this.doc||!/^(part|group):/.test(t))return a.s6;const i=this._live?.ref===t&&this._live.path?this._live.path:Hv(this.doc,t)?.path?.d,n=this._pivotOf(t);if(!i||!n)return a.s6;const s=_a(i);return a.JW`<g class="mpath" transform=${`translate(${n[0]} ${n[1]})`}>
      <path class="mline" d=${i} style=${"stroke-width: "+2*e}></path>
      ${this._lk(t)?a.s6:s.anchors.map((t,i)=>a.JW`<g class="anchor" data-anchor=${i}>
          <circle class="anchor-hit" cx=${t.x} cy=${t.y} r=${12*e}></circle>
          <circle class="anchor-dot" cx=${t.x} cy=${t.y} r=${4.5*e} style=${"stroke-width: "+1.5*e}></circle>
        </g>`)}
    </g>`}render(){const e=this.doc;if(!e||!kv(e))return a.qy``;const t=this._box,i=this._unit,n=this._sel,s=this.layerView,r=s?yo(e,s):new Set,o=this._vb,l=this._band,c=this._hover&&!n.includes(this._hover)?this._hover:void 0,d=e.rig.parts.map(e=>xv(e.id)).filter(t=>!(r.has(t)||r.has(_v(Dv(e.rig,t.slice(5))?.id??""))||s&&wo(e,s,t))).map(e=>a.JW`<g class="hit" data-ref=${e}>${this._partPaths(e).map(e=>a.JW`<path d=${e} style=${"stroke-width: "+8*i}></path>`)}</g>`);return a.qy`<div
      class="layer"
      @pointerdown=${this._onDown}
      @pointermove=${this._onMove}
      @pointerup=${this._onUp}
      @pointercancel=${this._onCancel}
      @keyup=${this._onKeyUp}
      @pointerleave=${()=>!this._drag&&(this._hover=void 0)}
      @keydown=${this._onKey}
    >
      ${t?a.qy`<svg
            class="ov"
            viewBox=${o.join(" ")}
            style=${`left: ${t.x}px; top: ${t.y}px; width: ${t.w}px; height: ${t.h}px`}
            role="group"
            aria-label=${as(376)}
          >
            ${d}
            ${c?a.JW`${this._partPaths(c).map(e=>a.JW`<path class="hover" d=${e} style=${"stroke-width: "+2*i}></path>`)}`:a.s6}
            <g style=${`--u: ${i}`}>${this._selected(n,i)}</g>
            ${this._motionPath(i)}
            ${l?a.JW`<rect class="band" x=${Math.min(l[0][0],l[1][0])} y=${Math.min(l[0][1],l[1][1])}
                  width=${Math.abs(l[1][0]-l[0][0])} height=${Math.abs(l[1][1]-l[0][1])} style=${`stroke-width: ${i}`}></rect>`:a.s6}
          </svg>`:a.s6}
    </div>`}};hb.styles=a.AH`
    :host {
      display: block;
      position: relative;
      width: 100%;
      height: 100%;
      touch-action: none;
    }
    .layer {
      position: absolute;
      inset: 0;
    }
    svg.ov {
      position: absolute;
      overflow: visible;
    }
    .hit path {
      fill: transparent;
      stroke: transparent;
      cursor: pointer;
    }
    .hover {
      fill: none;
      stroke: var(--primary-color, #03a9f4);
      opacity: 0.7;
      vector-effect: non-scaling-stroke;
      stroke-width: 1.5px !important;
      pointer-events: none;
    }
    .sel-outline {
      fill: color-mix(in srgb, var(--primary-color, #03a9f4) 14%, transparent);
      stroke: var(--primary-color, #03a9f4);
      stroke-width: 2px;
      vector-effect: non-scaling-stroke;
      pointer-events: none;
    }
    .bbox {
      fill: none;
      stroke: var(--primary-color, #03a9f4);
      stroke-width: 1px;
      stroke-dasharray: 4 3;
      vector-effect: non-scaling-stroke;
      pointer-events: none;
    }
    .pivot {
      cursor: move;
      outline: none;
    }
    .pivot-hit {
      fill: transparent;
    }
    .pivot-ring {
      fill: var(--card-background-color, #fff);
      stroke: var(--primary-color, #03a9f4);
    }
    .pivot-cross {
      stroke: var(--primary-color, #03a9f4);
      pointer-events: none;
    }
    .pivot:focus-visible .pivot-ring {
      stroke: var(--primary-text-color, #212121);
    }
    .mline {
      fill: none;
      stroke: var(--primary-color, #03a9f4);
      stroke-dasharray: 3 2;
      vector-effect: non-scaling-stroke;
      stroke-width: 1.5px !important;
      pointer-events: none;
    }
    .anchor {
      cursor: grab;
    }
    .anchor-hit {
      fill: transparent;
    }
    .anchor-dot {
      fill: var(--card-background-color, #fff);
      stroke: var(--primary-color, #03a9f4);
    }
    .band {
      fill: color-mix(in srgb, var(--primary-color, #03a9f4) 10%, transparent);
      stroke: var(--primary-color, #03a9f4);
      vector-effect: non-scaling-stroke;
      stroke-width: 1px !important;
      pointer-events: none;
    }
    @media (prefers-reduced-motion: no-preference) {
      .sel-outline,
      .bbox {
        transition: opacity 0.15s ease-out;
      }
    }
  `,db([(0,o.MZ)({attribute:!1})],hb.prototype,"doc",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"hass",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"library",void 0),db([(0,o.MZ)({type:Number})],hb.prototype,"time",void 0),db([(0,o.MZ)({type:Boolean})],hb.prototype,"disabled",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"selection",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"tile",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"stage",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"layerView",void 0),db([(0,o.MZ)({attribute:!1})],hb.prototype,"iconEl",void 0),db([(0,o.wk)()],hb.prototype,"_box",void 0),db([(0,o.wk)()],hb.prototype,"_vb",void 0),db([(0,o.wk)()],hb.prototype,"_scale",void 0),db([(0,o.wk)()],hb.prototype,"_hover",void 0),db([(0,o.wk)()],hb.prototype,"_band",void 0),db([(0,o.wk)()],hb.prototype,"_geom",void 0),db([(0,o.wk)()],hb.prototype,"_live",void 0),hb=db([(0,o.EM)("mc-anim-parts-overlay")],hb),Ds({tag:"mc-anim-parts-overlay",place:"stage-tool",title:375,order:20,when:(e,t)=>"keyframes"===e.kind&&kv(e)&&"tool"!==t.kind});var ub=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const mb=[{fx:0,fy:0,label:1015},{fx:.5,fy:0,label:1014},{fx:1,fy:0,label:1016},{fx:0,fy:.5,label:411},{fx:.5,fy:.5,label:126},{fx:1,fy:.5,label:747},{fx:0,fy:1,label:97},{fx:.5,fy:1,label:96},{fx:1,fy:1,label:98}],gb=e=>Math.round(100*e)/100,fb=(e,t,i)=>[gb(e[0]+e[2]*t),gb(e[1]+e[3]*i)];let vb=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection={kind:"none"},this.tile="icon",this._drawFrom=0,this._drawTo=60}willUpdate(e){if((e.has("doc")||e.has("tile"))&&this.doc){const e=Sv(this.doc,this.tile);e!==this._ref&&(this._ref=e,this._geom=zv(e),this._geom||Cv(e).then(t=>{this._ref===e&&t&&(this._geom=t)}))}const t=this._target;if((e.has("selection")||e.has("doc"))&&t&&this.doc){const e=Jv(this.doc,t);if(e.length>=2){let t=0;for(;t+1<e.length&&e[t+1][1]===e[0][1];)t++;let i=e.length-1;for(;i-1>t&&e[i-1][1]===e[e.length-1][1];)i--;this._drawFrom=e[t][0],this._drawTo=e[i][0]}}}get _target(){const e=this.selection?.target;return wv(e)&&this.doc&&function(e,t){const i=yv(t);return t.startsWith("part:")?!!e.rig?.parts.some(e=>e.id===i):t.startsWith("group:")?!!e.rig?.groups?.some(e=>e.id===i):!!t.startsWith("shape:")&&!!e.rig?.shapes?.some(e=>e.id===i)}(this.doc,e)?e:void 0}_drawMode(e){const t=Jv(this.doc,e);if(!t.length)return"none";const i=t[0][1],n=t[t.length-1][1],s=t.every((e,s)=>0===s||(i<n?e[1]>=t[s-1][1]:e[1]<=t[s-1][1]));return s&&0===i&&1===n?"on":s&&1===i&&0===n?"off":"custom"}_emit(e,t){ab(this,e,t)}_renderName(e){const t=this.doc,i=e.startsWith("group:"),n=Rv(t,[e]),s=i?0:t.rig?.parts.find(t=>t.id===yv(e))?.from?.length??0,r=i?as(1182,{count:n.length}):s>1?as(1255,{pieces:s}):as(622);return a.qy`<div class="head">
        <span class="tile-icon"><ha-icon icon=${i?"mdi:folder-outline":"mdi:vector-square"}></ha-icon></span>
        <div class="titles">
          <span class="title">${Yv(t,e)}</span>
          <span class="caption">${r} · <span class="mono">${yv(e)}</span></span>
        </div>
      </div>
      <div class="field">
        <div class="field-head"><label for="pi-name">${as(533)}</label></div>
        <input
          id="pi-name"
          class="input"
          .value=${Yv(t,e)}
          maxlength="80"
          ?disabled=${this.disabled}
          @change=${n=>{const s=n.target.value;s.trim()&&s.trim()!==Yv(t,e)&&this._emit(Pv(t,e,s),as(i?726:727))}}
        />
      </div>
      ${i?a.qy`<div class="chips">
            ${n.map(e=>a.qy`<button type="button" class="chip" @click=${()=>rb(this,sb([`part:${e}`]))}>${Yv(t,`part:${e}`)}</button>`)}
          </div>`:a.s6}`}_renderPivot(e){const t=this.doc,i=this._geom?jv(this._geom):[],n=Uv(t,e,i),s=e.startsWith("group:"),r=s?t.rig?.groups?.find(t=>t.id===yv(e))?.origin:t.rig?.parts.find(t=>t.id===yv(e))?.origin,o=Zv(t,e),l=Gv(t,e,i,Na(this._geom?.viewBox))??r,c=(i,n)=>this._emit(Kv(t,e,[i,n]),"Move pivot"),d=()=>this._emit(o?Kv(t,e,fb(n,.5,.5)):Bv(t,e,void 0),as(o?471:737)),p=(e,t)=>a.qy`<div class="field">
      <div class="field-head"><label for="pi-p${e}">${t}</label></div>
      <div class="unit">
        <input
          id="pi-p${e}"
          class="input"
          type="number"
          step="0.25"
          inputmode="decimal"
          .value=${l?String(gb(l[e])):""}
          placeholder=${as(126)}
          ?disabled=${this.disabled}
          @change=${t=>{const i=Number(t.target.value);if(!Number.isFinite(i)||""===t.target.value)return;const n=l??[12,12];0===e?c(i,n[1]):c(n[0],i)}}
        />
        <span class="suffix" aria-hidden="true">${as(1150)}</span>
      </div>
    </div>`;return a.qy`<section class="group" aria-labelledby="pi-pivot">
      <div class="group-head">
        <ha-icon icon="mdi:crosshairs-gps"></ha-icon>
        <h3 id="pi-pivot">${as(657)}</h3>
        <span class=${o?"src is-preset":"src"} data-pivot-source=${o?"track":"part"}>${as(o?688:s?357:624)}</span>
        ${o?a.s6:(h=!!r,u=()=>this._emit(Bv(t,e,void 0),"Reset pivot"),h?a.qy`<button
    type="button"
    class="icon-btn sm field-reset"
    aria-label=${(0,te.t)(386,{label:"pivot"})}
    title=${(0,te.t)(385)}
    @click=${e=>{e.stopPropagation(),u()}}
  >
    <ha-icon icon="mdi:backup-restore"></ha-icon>
  </button>`:a.s6)}
      </div>
      <p class="help">
        ${as(o?s?974:975:s?972:973)}
      </p>
      <div class="pair">${p(0,"X")} ${p(1,"Y")}</div>
      ${n?a.qy`<div class="grid3" role="group" aria-label=${as(s?659:660)}>
            ${mb.map(e=>{const[t,i]=fb(n,e.fx,e.fy),s=!!l&&Math.abs(l[0]-t)<.01&&Math.abs(l[1]-i)<.01;return a.qy`<button
                type="button"
                class="cell"
                aria-label=${as(661,{position:as(e.label).toLowerCase()})}
                title=${as(e.label)}
                aria-pressed=${s?"true":"false"}
                ?disabled=${this.disabled}
                @click=${()=>.5===e.fx&&.5===e.fy?d():c(t,i)}
              >
                <i></i>
              </button>`})}
          </div>`:a.s6}
      ${o?a.qy`<div>
            <button type="button" class="btn btn-text btn-sm" ?disabled=${this.disabled} @click=${()=>this._emit(Wv(t,e,void 0),"Reset to part pivot")}>
              ${as(s?738:739)}
            </button>
          </div>`:a.s6}
    </section>`;var h,u}_renderDraw(e){const t=this.doc,i=this._drawMode(e),n=qv(t,e),s=i=>this._emit(Qv(t,e,i,this._drawFrom,this._drawTo),as("none"===i?714:"on"===i?261:260)),r=[{id:"none",label:as(597)},{id:"on",label:as(261)},{id:"off",label:as(260)}],o=(t,n,s,r)=>a.qy`<div class="field">
      <div class="field-head"><label for=${t}>${n}</label></div>
      <div class="unit">
        <input
          id=${t}
          class="input"
          type="number"
          min="0"
          max="100"
          step="1"
          inputmode="decimal"
          .value=${String(s)}
          ?disabled=${this.disabled}
          @change=${t=>{const n=Math.max(0,Math.min(100,Number(t.target.value)));Number.isFinite(n)&&(r(n),"on"!==i&&"off"!==i||this._emit(Qv(this.doc,e,i,this._drawFrom,this._drawTo),"Draw timing"))}}
        />
        <span class="suffix" aria-hidden="true">%</span>
      </div>
    </div>`;return a.qy`<section class="group" aria-labelledby="pi-draw">
      <div class="group-head">
        <ha-icon icon="mdi:draw"></ha-icon>
        <h3 id="pi-draw">${as(257)}</h3>
      </div>
      <p class="help">${as(966)}</p>
      <div class="seg full" role="radiogroup" aria-label=${as(257)}>
        ${r.map(e=>a.qy`<button type="button" role="radio" aria-checked=${i===e.id?"true":"false"} ?disabled=${this.disabled||n&&"none"!==e.id} @click=${()=>s(e.id)}>${e.label}</button>`)}
      </div>
      ${n?a.qy`<p class="help cap">${Ev()}</p>`:a.s6}
      ${"custom"===i?a.qy`<p class="help">${as(1004)}</p>`:a.s6}
      ${"none"!==i?a.qy`<div class="pair">
            ${o("pi-df",as(884),this._drawFrom,e=>this._drawFrom=e)}
            ${o("pi-dt",as(175),this._drawTo,e=>this._drawTo=Math.max(e,this._drawFrom))}
          </div>`:a.s6}
    </section>`}_renderPath(e){const t=this.doc,i=Hv(t,e)?.path,n=!i&&qv(t,e);return a.qy`<section class="group" aria-labelledby="pi-path">
      <div class="group-head">
        <ha-icon icon="mdi:vector-curve"></ha-icon>
        <h3 id="pi-path">${as(453)}</h3>
      </div>
      <div class="switch-row">
        <div class="txt">
          <span class="lbl">${as(339)}</span>
          <p class="help">${as(499)}</p>
        </div>
        <button type="button" class="switch" role="switch" aria-checked=${i?"true":"false"} aria-label=${as(339)} ?disabled=${this.disabled||n} @click=${()=>this._emit(tb(t,e,i?void 0:{d:eb}),as(i?719:30))}></button>
      </div>
      ${n?a.qy`<p class="help cap">${Ev()}</p>`:a.s6}
      ${i?a.qy`<div class="field">
              <div class="field-head"><label for="pi-tpl">${as(813)}</label></div>
              <div class="select">
                <select
                  id="pi-tpl"
                  class="input"
                  ?disabled=${this.disabled}
                  @change=${n=>{const s=n.target.value;if(!s)return;const r="arc"===s?eb:ja(s,[0,0],4);this._emit(tb(t,e,{...i,d:r}),"Path shape"),n.target.value=""}}
                >
                  <option value="">${as(735)}</option>
                  <option value="arc">${as(68)}</option>
                  ${Ca.map(e=>a.qy`<option value=${e.id}>${as(e.label)}</option>`)}
                </select>
                <ha-icon icon="mdi:chevron-down"></ha-icon>
              </div>
            </div>
            <div class="switch-row">
              <div class="txt"><span class="lbl">${as(1032)}</span></div>
              <button
                type="button"
                class="switch"
                role="switch"
                aria-checked=${i.follow_rotation?"true":"false"}
                aria-label=${as(1032)}
                ?disabled=${this.disabled}
                @click=${()=>this._emit(tb(t,e,{...i,follow_rotation:!i.follow_rotation}),"Path rotation")}
              ></button>
            </div>`:a.s6}
    </section>`}_renderKeys(e){const t=this.doc,i=Hv(t,e),n=i?.keyframes.length??0;return a.qy`<section class="group" aria-labelledby="pi-keys">
      <div class="group-head">
        <ha-icon icon="mdi:timeline-outline"></ha-icon>
        <h3 id="pi-keys">${as(399)}</h3>
      </div>
      <p class="help">
        ${n?as(1169,{count:n}):as(560)}
      </p>
      ${i?a.qy`<div>
            <button type="button" class="btn btn-text btn-sm" ?disabled=${this.disabled} @click=${()=>this._emit(Lv(t,e,void 0),"Remove part animation")}>
              ${as(723)}
            </button>
          </div>`:a.s6}
    </section>`}render(){const e=this._target;return this.doc&&e?a.qy`<div class="insp">
      ${this._renderName(e)} ${this._renderPivot(e)} ${this._renderDraw(e)} ${this._renderPath(e)} ${this._renderKeys(e)}
    </div>`:a.qy``}};vb.styles=[Cs,As,a.AH`
      :host {
        display: block;
        color: var(--mc-text);
        font-size: 0.875rem;
      }
      .insp {
        display: grid;
        gap: 16px;
      }
      .head {
        display: flex;
        align-items: center;
        gap: 12px;
      }
      .tile-icon {
        width: 40px;
        height: 40px;
        flex: none;
        display: grid;
        place-items: center;
        border-radius: var(--mc-radius-md, 8px);
        background: var(--mc-accent-tint);
        color: var(--mc-accent-ink);
        --mdc-icon-size: 22px;
      }
      .titles {
        display: grid;
        min-width: 0;
      }
      .title {
        font-size: 1rem;
        font-weight: 500;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .caption {
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
      .chips {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
      }
      .pair {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(min(100%, 120px), 1fr));
        gap: 12px;
      }
      .unit {
        position: relative;
        display: flex;
      }
      .unit .input {
        flex: 1;
        min-width: 0;
        padding-inline-end: 52px;
      }
      .suffix {
        position: absolute;
        right: 12px;
        inset-inline: auto 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--mc-text-2);
        font-size: 0.8125rem;
        pointer-events: none;
      }
      .grid3 {
        display: grid;
        grid-template-columns: repeat(3, 32px);
        gap: 4px;
      }
      .cell {
        width: 32px;
        height: 32px;
        display: grid;
        place-items: center;
        border: 1px solid var(--mc-field-border);
        border-radius: var(--mc-radius-sm, 6px);
        background: var(--mc-surface);
        padding: 0;
        cursor: pointer;
      }
      .cell i {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: var(--mc-text-2);
      }
      .cell[aria-pressed='true'] {
        border-color: var(--mc-accent);
        background: var(--mc-accent-tint);
      }
      .cell[aria-pressed='true'] i {
        background: var(--mc-accent-ink);
      }
      .cell:focus-visible {
        outline: 2px solid var(--mc-accent);
        outline-offset: 2px;
      }
      .help {
        margin: 0;
      }
      /* which pivot the fields edit (a chip look; not .chip, the member chips use that) */
      .src {
        display: inline-flex;
        align-items: center;
        min-height: 20px;
        padding: 0 8px;
        border-radius: 9999px;
        border: 1px solid var(--mc-divider);
        background: var(--mc-surface);
        font-size: 0.75rem;
        font-weight: 500;
        line-height: 1;
        color: var(--mc-text-2);
        white-space: nowrap;
      }
      .src.is-preset {
        color: var(--mc-accent-ink);
        border-color: color-mix(in srgb, var(--mc-accent) 45%, transparent);
        background: var(--mc-accent-tint);
      }
    `],ub([(0,o.MZ)({attribute:!1})],vb.prototype,"doc",void 0),ub([(0,o.MZ)({attribute:!1})],vb.prototype,"hass",void 0),ub([(0,o.MZ)({attribute:!1})],vb.prototype,"library",void 0),ub([(0,o.MZ)({type:Number})],vb.prototype,"time",void 0),ub([(0,o.MZ)({type:Boolean})],vb.prototype,"disabled",void 0),ub([(0,o.MZ)({attribute:!1})],vb.prototype,"selection",void 0),ub([(0,o.MZ)({attribute:!1})],vb.prototype,"tile",void 0),ub([(0,o.MZ)({attribute:!1})],vb.prototype,"stage",void 0),ub([(0,o.wk)()],vb.prototype,"_geom",void 0),ub([(0,o.wk)()],vb.prototype,"_drawFrom",void 0),ub([(0,o.wk)()],vb.prototype,"_drawTo",void 0),vb=ub([(0,o.EM)("mc-anim-part-inspector")],vb),Ds({tag:"mc-anim-part-inspector",place:"inspector",title:622,order:20,when:(e,t)=>"keyframes"===e.kind&&("target"===t.kind||"keys"===t.kind)&&wv(t.target)});const bb=["select","pen","line","rect","ellipse","freehand","erase","motion"],yb=e=>"string"==typeof e&&bb.includes(e),xb=e=>"string"==typeof e&&e.startsWith("shape:"),_b=e=>"string"==typeof e&&/^(part|group|shape):/.test(e);function wb(e,t){return"keyframes"===e.kind&&"tool"===t.kind&&yb(t.tool)}function kb(e){return"target"===e.kind||"tool"===e.kind&&"select"===e.tool?(e=>xb(e)?e.slice(6):void 0)(e.target):void 0}function $b(e){return"tool"===e.kind&&yb(e.tool)?e.tool:"select"}const Mb={select:{label:785,icon:"mdi:cursor-default-outline",base:"shape",hint:149},pen:{label:651,icon:"mdi:fountain-pen-tip",base:"path",hint:152},line:{label:419,icon:"mdi:vector-line",base:"line",hint:250},rect:{label:703,icon:"mdi:square-rounded-outline",base:"rect",hint:252},ellipse:{label:292,icon:"mdi:ellipse-outline",base:"ellipse",hint:251},freehand:{label:344,icon:"mdi:draw",base:"stroke",hint:258},erase:{label:306,icon:"mdi:eraser",base:"shape",hint:150},motion:{label:453,icon:"mdi:map-marker-path",base:"path",hint:263}},Sb={fill:"currentColor",stroke:"",strokeWidth:1.5,linecap:"round",layer:"over",radius:2,tolerance:.4,grid:!0,anchors:!0,follow:!1};function zb(e,t){const i=()=>({stroke:e.stroke||"currentColor",stroke_width:e.strokeWidth,linecap:e.linecap});if(!t)return i();const n={};return e.fill&&(n.fill=e.fill),e.stroke&&Object.assign(n,i()),e.fill||e.stroke||(n.fill="currentColor"),n}const Cb=new class{constructor(){this.options={...Sb},this.hint="",this._hintListeners=new Set,this._listeners=new Set}setHint(e){if(e!==this.hint){this.hint=e;for(const e of this._hintListeners)e()}}onHint(e){return this._hintListeners.add(e),()=>this._hintListeners.delete(e)}set(e){this.options={...this.options,...e},this._emit()}setLastFreehand(e){this.lastFreehand=e,this._emit()}subscribe(e){return this._listeners.add(e),()=>this._listeners.delete(e)}reset(){this.options={...Sb},this.lastFreehand=void 0,this._emit()}_emit(){for(const e of this._listeners)e()}};let Ab=e=>(0,cg.WP)(e).map(e=>({index:e.index,d:e.d,...e.stroke?{stroke:e.stroke}:{},...e.secondary?{accent:!0}:{},...e.evenodd?{evenodd:!0}:{}}));function jb(e){const t=ms(e??"icon","m",!1)?.icon;return"string"==typeof t?t:void 0}const qb=new Map;function Eb(e,t){return e?.svg?lg(e):Na(t?.viewBox).join(" ")}function Hb(e,t){const i=e.rig;if(i?.svg){const e=function(e){const t=et(e);if(t.error)return;const i={paths:t.paths,viewBox:t.viewBox};return t.accentPaths.length&&(i.secondary=t.accentPaths),t.strokes.length&&(i.strokes=t.strokes),t.evenodd&&(i.evenodd=t.evenodd),i}(i.svg);return Promise.resolve(e?{viewBox:e.viewBox,pieces:Ab(e)}:void 0)}const n=i?.icon??jb(t);if(!n)return Promise.resolve(void 0);let s=qb.get(n);return s||(s=bv(n,{timeoutMs:4e3}).then(e=>e?{viewBox:e.viewBox,pieces:Ab(e)}:void 0).catch(()=>{}),qb.set(n,s),s.then(e=>{e||qb.delete(n)})),s}const Lb="important",Vb=" !"+Lb,Ob=(0,I.u$)(class extends I.WL{constructor(e){if(super(e),e.type!==I.OA.ATTRIBUTE||"style"!==e.name||e.strings?.length>2)throw Error("The `styleMap` directive must be used in the `style` attribute and must be the only part in the attribute.")}render(e){return Object.keys(e).reduce((t,i)=>{const n=e[i];return null==n?t:t+`${i=i.includes("-")?i:i.replace(/(?:^(webkit|moz|ms|o)|)(?=[A-Z])/g,"-$&").toLowerCase()}:${n};`},"")}update(e,[t]){const{style:i}=e.element;if(void 0===this.ft)return this.ft=new Set(Object.keys(t)),this.render(t);for(const e of this.ft)null==t[e]&&(this.ft.delete(e),e.includes("-")?i.removeProperty(e):i[e]=null);for(const e in t){const n=t[e];if(null!=n){this.ft.add(e);const t="string"==typeof n&&n.endsWith(Vb);e.includes("-")||t?i.setProperty(e,t?n.slice(0,-11):n,t?Lb:""):i[e]=n}}return B.c0}});var Pb=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};class Rb extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this.density="full",this._list=new If(this,{select:(e,t)=>e.startsWith("lane:")?!this.disabled&&Gf(this,this.doc,e):this._pick(e.slice(6),t),move:(e,t)=>this._shift(e.slice(6),t),open:(e,t)=>this._list.setOpen(e,t),nameOf:e=>e.startsWith("lane:")?Kf(e):this.doc?.rig?.shapes?.find(t=>t.id===e.slice(6))?.name??e})}_emit(e,t){this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:e,label:t}}))}_select(e){this.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:e}}))}_pick(e,t){const i=`shape:${e}`;this._select("tool"===this.selection.kind?{kind:"tool",tool:"select",target:i}:{kind:"target",target:i})}_shift(e,t){const i=this.doc,n=i?.rig?.shapes?.find(t=>t.id===e);if(!i||!n)return;const s=no(i,e,t);if(s===i)return;const r="under"===this.side,a=i.rig.shapes.filter(e=>"under"===e.layer===r),o="up"===t?r&&a[a.length-1].id===e:!r&&a[0].id===e;this._emit(s,as("up"===t?o?104:103:o?793:792)),this._list.announce(as(1238,{name:n.name,where:as(o?"up"===t?1133:1149:"up"===t?1152:1105)}))}_delete(e){const t=this.doc,i=t?.rig?.shapes?.find(t=>t.id===e);t&&i&&!this.disabled&&!this._list.refuseLocked(`shape:${e}`,i.name)&&(this._emit(so(t,e),"Delete shape"),kb(this.selection)===e&&this._select({kind:"none"}))}_thumb(e,t){const i=e=>e?Ih(e)??e:"currentColor",n={fill:Ba(e)?i(e.fill):"none",stroke:Ia(e)?i(e.stroke):"none","stroke-width":String(Math.max(e.stroke_width??1,1))};return a.qy`<svg class="thumb" viewBox=${t} aria-hidden="true">
      ${a.JW`<path d=${e.d} style=${Ob(n)} stroke-linecap="round" stroke-linejoin="round"></path>`}
    </svg>`}render(){const e=this.doc,t=e?.rig?.shapes??[],i="under"===this.side;if(!e||!t.some(e=>"under"===e.layer===i))return a.qy``;const n=kb(this.selection),s=Eb(e.rig),r=t.map((e,t)=>({s:e,i:t})).filter(e=>"under"===e.s.layer===i).reverse(),o=r[0].s.id,l=r[r.length-1].s.id;return a.qy`<ul aria-label=${as(i?822:821)}>
      ${r.map(({s:t})=>{const r=`shape:${t.id}`,c=e.tracks?.find(e=>e.target===r),d=[oo(e,r)?as(1110):"",c?.path?"moves":""].filter(Boolean).join(", "),p=i&&o===t.id,h=!i&&l===t.id,u=Uf(e,this.layerView??po,r,r),m=this._list.row({key:r,expanded:u,name:t.name,thumb:this._thumb(t,s),note:d,describe:d,selected:t.id===n&&!(u&&"keys"===this.selection.kind),up:{ok:!this.disabled&&no(e,t.id,"up")!==e,label:as(p?106:105,{name:t.name}),menu:as(p?102:481)},down:{ok:!this.disabled&&no(e,t.id,"down")!==e,label:as(h?796:795,{name:t.name}),menu:as(h?794:460)},extra:t.id!==n?void 0:a.qy`<button type="button" class="icon-btn sm danger del" data-ctl="del" tabindex="-1" aria-label=${as(234,{name:t.name})} title=${as(229)} aria-disabled=${this.disabled||this._list.locked(r)?"true":a.s6} @click=${()=>this._delete(t.id)}>
                  <ha-icon icon="mdi:delete-outline"></ha-icon>
                </button>`});return u?[m,...Yf(this._list,e,this.selection,r,2)]:[m]})}
    </ul>
    ${t.length>=48?a.qy`<p class="empty-note">${as(979)}</p>`:a.s6}`}}Rb.styles=[dh,Zf,a.AH`
      :host {
        display: block;
      }
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 2px;
      }
      .thumb {
        flex: none;
        width: 28px;
        height: 28px;
        border-radius: 6px;
        background: var(--secondary-background-color, #f2f3f5);
        color: var(--state-icon-color, #44739e);
      }
      .empty-note {
        margin: 0;
        padding: 8px;
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
      }
    `],Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"doc",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"selection",void 0),Pb([(0,o.MZ)({type:Boolean})],Rb.prototype,"disabled",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"hass",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"library",void 0),Pb([(0,o.MZ)({type:Number})],Rb.prototype,"time",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"tile",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"stage",void 0),Pb([(0,o.MZ)({attribute:!1})],Rb.prototype,"layerView",void 0),Pb([(0,o.MZ)()],Rb.prototype,"density",void 0);let Db=class extends Rb{constructor(){super(...arguments),this.side="over"}};Db=Pb([(0,o.EM)("mc-anim-shapes-layers")],Db);let Nb=class extends Rb{constructor(){super(...arguments),this.side="under"}};Nb=Pb([(0,o.EM)("mc-anim-shapes-under-layers")],Nb),Ds({tag:"mc-anim-shapes-layers",place:"layers",when:e=>"keyframes"===e.kind&&!!e.rig?.shapes?.some(e=>"under"!==e.layer),title:821,order:5}),Ds({tag:"mc-anim-shapes-under-layers",place:"layers",when:e=>"keyframes"===e.kind&&!!e.rig?.shapes?.some(e=>"under"===e.layer),title:822,order:30});var Fb=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Tb=new Set(["line","rect","ellipse","freehand"]),Bb={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]},Ib=new Set(["select","line","rect","ellipse","freehand","erase","motion"]),Zb=[],Wb=[],Kb=[{fill:"none"}],Ub=new Map,Gb=e=>e?Ih(e)??e:void 0,Yb=(e,t)=>{e.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:t}}))};let Jb=class extends yf{constructor(){super(...arguments),this._selection={kind:"none"},this.disabled=!1,this.time=0,this.preview=!1,this._dropping=!1,this._announce="",this._piecesKey="",this._pointsSel=!1,this._onCanvas=e=>{e.stopPropagation();const t=e.detail,i=t.paths[0];if("pen"===$b(this.selection))return this._pen=i&&i.anchors.length?i:void 0,void(t.commit&&i?.closed&&this._finishPen(!0));const n=this._live,s=n?this._shapes.find(e=>e.id===n.id):void 0;if(!n||!s||!this.doc)return;if(this._live={...n,list:t.paths},this.requestUpdate(),!t.commit)return;if("Cancel"===t.label)return;if(!i||!i.anchors.length)return this._emitDoc(so(this.doc,s.id),"Delete shape"),void Yb(this,{kind:"tool",tool:"select"});const r=wa(i);this._live={id:s.id,d:r,list:t.paths},Cb.lastFreehand?.id===s.id&&Cb.setLastFreehand(void 0),this._emitDoc(to(this.doc,s.id,{d:r}),vf(t.label))},this._onCanvasSelect=e=>{this._pointsSel=(e.detail?.anchors.length??0)>0},this._endNudge=()=>{const e=this._nudge;if(!e)return;this._nudge=void 0;const t=Math.round(100*e.dx)/100,i=Math.round(100*e.dy)/100;this._emitDoc(to(e.base,e.id,{d:Oa(e.d,t,i)}),"Nudge shape"),this._followFreehand(e.id,t,i)},this._onKeyUp=e=>{/^Arrow/.test(e.key)&&this._endNudge()},this._onKeyCapture=e=>{const t=this._selectedId;if(this.disabled||!this.doc||!t||this._pen||this._drag)return;const i="Delete"===e.key||"Backspace"===e.key;return i||/^Arrow/.test(e.key)?this._refuseLocked(t)?(e.preventDefault(),void e.stopPropagation()):void(i&&!this._pointsSel&&(e.preventDefault(),e.stopPropagation(),this._emitDoc(so(this.doc,t),"Delete shape"),Yb(this,{kind:"tool",tool:"select"}))):void 0},this._onKey=e=>{if(this.disabled||!this.doc)return;if(this._drag&&"Escape"===e.key)return e.preventDefault(),e.stopPropagation(),void this._end(!1);if(this._kbKey(e))return;if(/^Arrow/.test(e.key)||this._endNudge(),this._pen)return void("Escape"===e.key&&(e.preventDefault(),e.stopPropagation(),this._finishPen(!1)));const t=this._selectedId;if("Escape"===e.key&&t)return e.preventDefault(),e.stopPropagation(),void Yb(this,{kind:"tool",tool:"select"});if(!t)return;const i={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];if(!i)return;if(e.preventDefault(),this._nudge&&this._nudge.id!==t&&this._endNudge(),!this._nudge){const e=this._shapes.find(e=>e.id===t);if(!e)return;this._nudge={id:t,base:this.doc,d:e.d,dx:0,dy:0}}const n=this._nudge,s=e.shiftKey?1:.1;n.dx+=i[0]*s,n.dy+=i[1]*s,this._emitDoc(to(n.base,t,{d:Oa(n.d,Math.round(100*n.dx)/100,Math.round(100*n.dy)/100)}),"Nudge shape",!0)},this._onDragOver=e=>{!this.disabled&&e.dataTransfer?.types?.includes("Files")&&(e.preventDefault(),this._dropping=!0)},this._onDragLeave=()=>{this._dropping=!1},this._onDrop=async e=>{this._dropping=!1;const t=e.dataTransfer?.files?.[0];if(!t||this.disabled)return;e.preventDefault();const i=await Xg(t);if(this._dialog??=this.renderRoot.querySelector("mc-anim-svg-dialog")??void 0,"error"in i)return this._announce=ys(i.error),void this._dialog?.openImport("",t.name);this._dialog?.openImport(i.text,t.name)},this._penList={list:Zb}}get selection(){return this._selection}set selection(e){const t=e??{kind:"none"};this._pen&&"pen"!==$b(t)&&this._finishPen(!1),$b(t)!==$b(this._selection)&&(this._kb=this._cross=void 0),this._selection=t}get penPath(){return this._pen}connectedCallback(){super.connectedCallback(),this._unsub=Cb.subscribe(()=>this.requestUpdate()),this._parent=this.parentNode,this.addEventListener("keydown",this._onKeyCapture,!0),this.addEventListener("keydown",this._onKey),this.addEventListener("keyup",this._onKeyUp),this.addEventListener("blur",this._endNudge),this.addEventListener("dragover",this._onDragOver),this.addEventListener("dragleave",this._onDragLeave),this.addEventListener("drop",this._onDrop)}disconnectedCallback(){super.disconnectedCallback(),this._unsub?.(),this.removeEventListener("keydown",this._onKeyCapture,!0),this.removeEventListener("keydown",this._onKey),this.removeEventListener("keyup",this._onKeyUp),this.removeEventListener("blur",this._endNudge),this.removeEventListener("dragover",this._onDragOver),this.removeEventListener("dragleave",this._onDragLeave),this.removeEventListener("drop",this._onDrop),this._end(!0),this._endNudge(),this._finishPen(!1),Cb.setHint("")}firstUpdated(){this.hasAttribute("tabindex")||(this.tabIndex=0)}willUpdate(e){if(e.has("selection")){const t=e.get("selection");t?.target!==this.selection.target&&(this._pointsSel=!1)}if((e.has("doc")||e.has("tile")||e.has("pieces"))&&!this.pieces&&this.doc){const e=`${this.doc.rig?.svg??this.doc.rig?.icon??""}|${this.tile??""}`;e!==this._piecesKey&&(this._piecesKey=e,Hb(this.doc,this.tile).then(t=>{this._piecesKey===e&&(this._resolved=t)}))}this.ensureCanvas()}get _viewBox(){return this.viewBox??this.stage?.viewBox?.join(" ")??Eb(this.doc?.rig,this._resolved)}_view(){const e=this.stage,t=e?.rect?.width||this.stageRect?.width||360,i=e?.rect?.height||this.stageRect?.height||240,n=Na(this._viewBox),s=this.iconRect??e?.subject??this.stageRect?.subject??this.subjectRect;let r;if(s&&s.width>8&&s.height>8)r=s;else{const e=Math.max(48,Math.min(t,i)-48);r={x:(t-e)/2,y:(i-e)/2,width:e,height:e}}const a=Math.min(r.width/n[2],r.height/n[3]),o=bf(e,{x:r.x+(r.width-n[2]*a)/2,y:r.y+(r.height-n[3]*a)/2,width:n[2]*a,height:n[3]*a});if(!(o&&a>0))return;const l=this._viewCache;return l&&l.vb.every((e,t)=>e===n[t])&&["left","top","width","height"].every(e=>Math.abs(l.place[e]-o[e])<.005)?l:this._viewCache={vb:n,place:o,ppu:o.width/n[2]}}_toPx(e,t){return[e.place.left+(t[0]-e.vb[0])*e.ppu,e.place.top+(t[1]-e.vb[1])*e.ppu]}_toVB(e,t){return[e.vb[0]+(t[0]-e.place.left)/e.ppu,e.vb[1]+(t[1]-e.place.top)/e.ppu]}_local(e){const t=this.getBoundingClientRect();return[e.clientX-t.left,e.clientY-t.top]}get _previewShapes(){return this.preview||!!this.tile&&!jb(this.tile)}get _shapes(){return this.doc?.rig?.shapes??[]}get _pieceList(){return this.pieces??this._resolved?.pieces??[]}_isLocked(e){return!!this.doc&&!!this.layerView?.locked.length&&wo(this.doc,this.layerView,`shape:${e}`)}_refuseLocked(e){return!!this._isLocked(e)&&(this._announce=as(1229,{name:this._shapes.find(t=>t.id===e)?.name??as(813)}),!0)}get _selectedId(){return kb(this.selection)}_snapAnchors(e){if(!Cb.options.anchors)return[];const t=this._anchorCache,i=this._shapes,n=this._pieceList;if(!t||t.shapes!==i||t.pieces!==n||t.exclude!==e){const t=[];for(const e of n)t.push(...Pa(e.d));for(const n of i)n.id!==e&&t.push(...Pa(n.d));this._anchorCache={shapes:i,pieces:n,exclude:e,pts:t}}return this._anchorCache.pts}_snap(e,t,i){if(i)return this._snapAt=void 0,[Math.round(100*t[0])/100,Math.round(100*t[1])/100];const n=function(e,t){if(t.anchors?.length&&t.radius){let i,n=t.radius;for(const s of t.anchors){const t=(0,$e.xg)(s,e);t<=n&&(n=t,i=s)}if(i)return{p:[i[0],i[1]],kind:"anchor"}}return t.grid&&t.grid>0?{p:[Ea(Math.round(e[0]/t.grid)*t.grid),Ea(Math.round(e[1]/t.grid)*t.grid)],kind:"grid"}:{p:[Ea(e[0]),Ea(e[1])],kind:null}}(t,{grid:Cb.options.grid?1:0,anchors:this._snapAnchors(),radius:10/e.ppu});return this._snapAt="anchor"===n.kind?n.p:void 0,n.p}_snapConfig(e){const t=Cb.options.grid?1:0;let i;if(Cb.options.anchors){const t=[this._shapes,this._pieceList,e];if(!this._lines||this._lines.key.some((e,i)=>e!==t[i])){const i=new Set,n=new Set;for(const t of this._snapAnchors(e))i.size<300&&i.add(t[0]),n.size<300&&n.add(t[1]);this._lines={key:t,extra:{x:[...i],y:[...n]}}}i=this._lines.extra}const n=`${t}|${e??""}`,s=Ub.get(n);if(s&&s.extra===i)return s;const r={enabled:!0,grid:t,anchors:!1,frame:!1,extra:i};return Ub.set(n,r),r}_emitDoc(e,t,i=!1){i||(this._announce=t),(this.isConnected?this:this._parent?.isConnected?this._parent:this).dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:i?{doc:e,label:t,transient:!0}:{doc:e,label:t}}))}_commitShape(e,t,i){if(!this.doc||!t)return;if(this._shapes.length>=hn)return void(this._announce=as(1179,{count:hn}));const n=Mb[e],s=Ya(Qa(this.doc),n.base),r=this._shapes.filter(e=>e.id.startsWith(`${n.base}-`)).length+1,a={id:s,name:`${as("pen"===e?645:"freehand"===e?911:n.label)} ${r}`,d:t,layer:Cb.options.layer,...zb(Cb.options,i)},o=eo(this.doc,a);return o?(this._emitDoc(o,`Draw ${e}`),this._announce="pen"===e?as(1190,{name:a.name,count:Pa(t).length}):as(1225,{name:a.name}),s):void 0}_finishPen(e){const t=this._pen;if(this._pen=void 0,!t||t.anchors.length<2)return;const i=e?{...t,closed:!0}:t;this._commitShape("pen",wa(i),i.closed)}_capture(e){e.preventDefault();try{this.renderRoot.querySelector("svg.tool")?.setPointerCapture(e.pointerId)}catch{}}_onDown(e){const t=this._view();if(this.disabled||e.button>0||!this.doc||this._drag||!t)return;this._endNudge(),this.focus({preventScroll:!0,focusVisible:!1});const i=this._local(e),n=this._toVB(t,i),s=$b(this.selection);if(!Tb.has(s)&&"motion"!==s||this.chunk)switch(s){case"select":{const s=Ua(this._shapes.filter(e=>!this._isLocked(e.id)),n,6/t.ppu);if(!s){const e=Ua(this._shapes,n,6/t.ppu);if(e&&this._refuseLocked(e))return;return void(this._selectedId&&Yb(this,{kind:"tool",tool:"select"}))}s!==this._selectedId&&Yb(this,{kind:"tool",tool:"select",target:`shape:${s}`});const r=this._shapes.find(e=>e.id===s);return this._capture(e),void(this._drag={kind:"move",pointerId:e.pointerId,id:s,base:this.doc,d:r.d,start:n,startPx:i,moved:!1,delta:[0,0]})}case"erase":return this._capture(e),this._drag={kind:"erase",pointerId:e.pointerId,base:this.doc,ids:[]},void this._eraseAt(n,t);case"line":case"rect":case"ellipse":{const i=this._snap(t,n,e.shiftKey&&"line"===s);return this._capture(e),void(this._drag={kind:"box",tool:s,pointerId:e.pointerId,a:i,b:i,shift:e.shiftKey,alt:e.altKey})}case"freehand":case"motion":return"motion"!==s||_b(this.selection.target)?"motion"===s&&this.layerView&&wo(this.doc,this.layerView,this.selection.target)?void(this._announce=as(924)):(this._capture(e),this._drag={kind:"free",tool:s,pointerId:e.pointerId,raw:[n],poly:`${i[0].toFixed(1)},${i[1].toFixed(1)}`,last:i},void this.requestUpdate()):void(this._announce=as(786))}else this._announce=as(942)}_boxPath(e,t,i,n,s){const r=this.chunk?.pathDraw;if(!r||Math.hypot(i[0]-t[0],i[1]-t[1])<.2)return;if("line"===e)return r.linePath(t,i);const a=function(e,t,i,n){let s=t[0]-e[0],r=t[1]-e[1];if(i){const e=Math.max(Math.abs(s),Math.abs(r));s=Math.sign(s||1)*e,r=Math.sign(r||1)*e}return n?{x:Ea(e[0]-Math.abs(s)),y:Ea(e[1]-Math.abs(r)),w:Ea(2*Math.abs(s)),h:Ea(2*Math.abs(r))}:{x:Ea(Math.min(e[0],e[0]+s)),y:Ea(Math.min(e[1],e[1]+r)),w:Ea(Math.abs(s)),h:Ea(Math.abs(r))}}(t,i,n,s);return a.w<.2||a.h<.2?void 0:"rect"===e?r.rectPath(a.x,a.y,a.w,a.h,Cb.options.radius):r.ellipsePath(a.x+a.w/2,a.y+a.h/2,a.w/2,a.h/2)}_commitBox(e,t,i,n,s){const r=this._boxPath(e,t,i,n,s);return r&&this._commitShape(e,r,"line"!==e),!!r}_eraseAt(e,t){const i=this._drag;if("erase"!==i?.kind)return;let n=i.base;for(const e of i.ids)n=so(n,e);const s=Ua((n.rig?.shapes??[]).filter(e=>!this._isLocked(e.id)),e,6/t.ppu);s&&(i.ids.push(s),this._emitDoc(so(n,s),"Erase shape",!0))}_onMove(e){const t=this._drag,i=this._view();if(!t||!i||e.pointerId!==t.pointerId)return;const n=this._local(e),s=this._toVB(i,n);switch(t.kind){case"box":return t.b=this._snap(i,s,e.shiftKey&&"line"===t.tool),t.shift=e.shiftKey,t.alt=e.altKey,void this.requestUpdate();case"free":{const n="function"==typeof e.getCoalescedEvents?e.getCoalescedEvents():[];let s=!1;for(const r of n.length?n:[e]){if(t.raw.length>=4e3)break;const e=this._local(r);Math.hypot(e[0]-t.last[0],e[1]-t.last[1])<.75||(t.raw.push(this._toVB(i,e)),t.poly+=` ${e[0].toFixed(1)},${e[1].toFixed(1)}`,t.last=e,s=!0)}return void(s&&this.requestUpdate())}case"erase":return void this._eraseAt(s,i);case"move":{if(!t.moved&&Math.hypot(n[0]-t.startPx[0],n[1]-t.startPx[1])<3)return;t.moved=!0;let i=s[0]-t.start[0],r=s[1]-t.start[1];return!e.shiftKey&&Cb.options.grid&&(i=Math.round(i),r=Math.round(r)),t.delta=[Math.round(100*i)/100,Math.round(100*r)/100],void this._emitDoc(to(t.base,t.id,{d:Oa(t.d,t.delta[0],t.delta[1])}),"Move shape",!0)}}}_onUp(e){const t=this._drag;t&&e.pointerId===t.pointerId&&this._end(!0)}_end(e){const t=this._drag;if(!t)return;this._drag=void 0,this._snapAt=void 0;try{const e=this.renderRoot.querySelector("svg.tool");e?.hasPointerCapture?.(t.pointerId)&&e.releasePointerCapture(t.pointerId)}catch{}if(!e||!this.doc)return"move"===t.kind&&t.moved&&this._emitDoc(t.base,"Move shape"),"erase"===t.kind&&t.ids.length&&this._emitDoc(t.base,"Erase shape"),void this.requestUpdate();const i=this.chunk?.pathDraw;switch(t.kind){case"box":this._commitBox(t.tool,t.a,t.b,t.shift,t.alt);break;case"free":{const e=i?.fitFreehand(t.raw,Cb.options.tolerance);if(!e?.d)break;if("freehand"===t.tool){const i=this._commitShape("freehand",e.d,e.closed);i&&Cb.setLastFreehand({id:i,raw:t.raw})}else{const t=this.selection.target,i=lo(this.doc,t,e.d,Cb.options.follow);i?this._emitDoc(i,"Draw motion path"):this._announce=as(1268,{tracks:24})}break}case"move":t.moved&&(this._emitDoc(to(t.base,t.id,{d:Oa(t.d,t.delta[0],t.delta[1])}),"Move shape"),this._followFreehand(t.id,t.delta[0],t.delta[1]));break;case"erase":{if(!t.ids.length)break;let e=t.base;for(const i of t.ids)e=so(e,i);this._emitDoc(e,as(1181,{count:t.ids.length}));break}}this.requestUpdate()}_followFreehand(e,t,i){const n=Cb.lastFreehand;n?.id===e&&(t||i)&&Cb.setLastFreehand({id:e,raw:n.raw.map(e=>[e[0]+t,e[1]+i])})}_finishButton(){this._kb?this._finishStroke():this._finishPen(!1),this._focusArea()}_focusArea(){this.updateComplete.then(()=>{(("view"!==this._canvasPaths().mode?this.renderRoot.querySelector("mc-path-canvas"):null)??this).focus({preventScroll:!0})})}_finishStroke(){const e=this._kb;this._kb=void 0;const t=this.chunk?.pathDraw;if(!e||!t||e.pts.length<2)return;const i=[e.pts[0]];for(let t=1;t<e.pts.length;t++){const n=e.pts[t-1],s=e.pts[t],r=Math.max(1,Math.ceil(Math.hypot(s[0]-n[0],s[1]-n[1])/.5));for(let e=1;e<=r;e++)i.push([n[0]+(s[0]-n[0])*e/r,n[1]+(s[1]-n[1])*e/r])}const n=t.fitFreehand(i,Cb.options.tolerance);if(!n?.d)return;const s=this._commitShape("freehand",n.d,n.closed);s&&Cb.setLastFreehand({id:s,raw:i})}_kbKey(e){const t=$b(this.selection);if(!Tb.has(t)||this._selectedId||this._pen||e.composedPath()[0]!==this||e.ctrlKey||e.metaKey)return!1;if("Escape"===e.key)return!!this._kb&&(e.preventDefault(),e.stopPropagation(),this._kb=void 0,this._announce=as(266),!0);const i=Bb[e.key];if(!i&&"Enter"!==e.key)return!1;e.preventDefault(),e.stopPropagation();const n=this._view();if(!n)return!0;if(!this.chunk)return this._announce=as(942),!0;const s=t,r=this._cross??[n.vb[0]+n.vb[2]/2,n.vb[1]+n.vb[3]/2],a=e=>String(Math.round(100*e)/100);if(i){const t=e.altKey?.1:e.shiftKey?5:1,o=Cb.options.grid&&!e.altKey,l=(e,t,i)=>{const n=Math.min(t+i,Math.max(t,e));return o?Math.round(n):Math.round(100*n)/100},c=[l(r[0]+i[0]*t,n.vb[0],n.vb[2]),l(r[1]+i[1]*t,n.vb[1],n.vb[3])];this._cross=c;const d="freehand"!==s&&!!this._kb,p={x:a(c[0]),y:a(c[1])};return this._announce=as("freehand"===s?200:d?201:202,p),!0}this._cross=r;const o=this._kb;if("freehand"===s){const e=o?.pts[o.pts.length-1];if(o&&e&&e[0]===r[0]&&e[1]===r[1])return o.pts.length>1?this._finishStroke():this._announce=as(459),!0;const t=[...o?.pts??[],r];return this._kb={tool:s,pts:t},this._announce=as(678,{count:t.length}),!0}return o?this._commitBox(s,o.pts[0],r,!1,!1)?this._kb=void 0:this._announce=as(459):(this._kb={tool:s,pts:[r]},this._announce=as(883,{x:a(r[0]),y:a(r[1])})),!0}toolsReady(){this._announce=as(943),this._focusArea()}_grid(e){const t=$b(this.selection);if(!Cb.options.grid||e.ppu<6||"select"===t||"erase"===t)return a.s6;const[i,n,s,r]=e.vb,o=[];for(let t=0;t<=s;t++)o.push(`M${(e.place.left+t*e.ppu).toFixed(1)} ${e.place.top.toFixed(1)}v${e.place.height.toFixed(1)}`);for(let t=0;t<=r;t++)o.push(`M${e.place.left.toFixed(1)} ${(e.place.top+t*e.ppu).toFixed(1)}h${e.place.width.toFixed(1)}`);return a.JW`<path class="grid" d=${o.join("")}></path>`}_shapesLayer(e){if(!this._previewShapes||!this._shapes.length)return a.s6;const t=this._selectedId;return a.JW`<g class="shapes" transform="translate(${e.place.left-e.vb[0]*e.ppu} ${e.place.top-e.vb[1]*e.ppu}) scale(${e.ppu})">
      ${Wa(this._shapes).map(e=>a.JW`<path class="${e.id===t?"sel":""} ${e.layer}" data-id=${e.id} d=${e.d} style=${Ob(function(e){return{fill:Ba(e)?Gb(e.fill)??"currentColor":"none",stroke:Ia(e)?Gb(e.stroke)??"currentColor":"none","stroke-width":String(e.stroke_width??1),"stroke-linecap":e.linecap??"butt","stroke-linejoin":"round"}}(e))}></path>`)}
    </g>`}_pxD(e,t){return t?(0,$e.Mj)(t).map(t=>{if(!t.length)return"";const i=t=>this._toPx(e,t),n=i(t[0][0]);return`M${n[0].toFixed(1)} ${n[1].toFixed(1)}${t.map(e=>`C${[e[1],e[2],e[3]].map(e=>i(e).map(e=>e.toFixed(1)).join(" ")).join(" ")}`).join("")}`}).join(""):""}_selectionBox(e){const t=this._selectedId,i=t?this._shapes.find(e=>e.id===t):void 0,n=i?Da(i.d):void 0;if(!n)return a.s6;const[s,r]=this._toPx(e,[n.x,n.y]);return a.JW`<rect class="bbox" x=${s-4} y=${r-4} width=${n.w*e.ppu+8} height=${n.h*e.ppu+8} rx="2"></rect>`}_dragLayer(e){const t=this._drag,i=this._kb;if(i&&this._cross){if("freehand"===i.tool)return a.JW`<polyline class="draft" points=${[...i.pts,this._cross].map(t=>this._toPx(e,t).map(e=>e.toFixed(1)).join(",")).join(" ")}></polyline>`;const t=this._boxPath(i.tool,i.pts[0],this._cross,!1,!1);return t?a.JW`<path class="draft ${"line"===i.tool?"":"fillable"}" d=${this._pxD(e,t)}></path>`:a.s6}if(!t)return a.s6;if("box"===t.kind){const i=this._boxPath(t.tool,t.a,t.b,t.shift,t.alt);return i?a.JW`<path class="draft ${"line"===t.tool?"":"fillable"}" d=${this._pxD(e,i)}></path>`:a.s6}return"free"===t.kind?a.JW`<polyline class="draft" points=${t.poly}></polyline>`:a.s6}_ghost(e){const t=Cb.lastFreehand;if(!t||!this._shapes.some(e=>e.id===t.id))return a.s6;const i=$b(this.selection);if(this._selectedId!==t.id&&"freehand"!==i)return a.s6;const n=`${e.ppu}|${e.place.left}|${e.place.top}`;this._ghostCache?.raw===t.raw&&this._ghostCache.key===n||(this._ghostCache={raw:t.raw,key:n,pts:t.raw.map(t=>this._toPx(e,t).map(e=>e.toFixed(1)).join(",")).join(" ")});const s=this._ghostCache.pts;return a.JW`<polyline class="ghost-casing" points=${s}></polyline><polyline class="ghost" points=${s}></polyline>`}_motion(e){const t=this.selection.target;if(!_b(t))return a.s6;const i=this.doc?.tracks?.find(e=>e.target===t);if(!i?.path?.d)return a.s6;const n=this._targetCentre(t);return n?a.JW`<path class="motion" d=${this._pxD(e,Oa(i.path.d,n[0],n[1]))}></path>`:a.s6}_targetCentre(e){const[t,i]=e.split(":"),n=this.doc?.rig,s="group"===t?n?.groups?.find(e=>e.id===i)?.parts??[]:[i],r=new Set(s.flatMap(e=>n?.parts.find(t=>t.id===e)?.from??[])),a="shape"===t?this._shapes.find(e=>e.id===i)?.d??"":this._pieceList.filter(e=>r.has(e.index)).map(e=>e.d).join(" "),o=a?Da(a):void 0;if(o)return[o.x+o.w/2,o.y+o.h/2];const l=Na(this._viewBox);return[l[0]+l[2]/2,l[1]+l[3]/2]}_crossMark(e){if(!this._cross||!Tb.has($b(this.selection)))return a.s6;const[t,i]=this._toPx(e,this._cross),n=`M${t-9} ${i}h18M${t} ${i-9}v18`;return a.JW`<path class="cross-casing" d=${n}></path><path class="cross" d=${n}></path>`}_dots(e){return("box"===this._drag?.kind||this._pen)&&Cb.options.anchors?a.JW`<g class="dots">${this._snapAnchors().slice(0,600).map(t=>{const[i,n]=this._toPx(e,t);return a.JW`<circle cx=${i} cy=${n} r="1.5"></circle>`})}</g>`:a.s6}_hint(){const e=$b(this.selection);return this._pen?this._pen.anchors.length<2?as(153):as(Mb.pen.hint):"motion"!==e||_b(this.selection.target)?"select"!==e||this._shapes.length?this._drag||this._selectedId?"":as(Mb[e].hint):as(564):as(787)}_labelArea(){const e=$b(this.selection);if(this.disabled||!Ib.has(e)){for(const e of["role","aria-roledescription","aria-label"])this.removeAttribute(e);return}this.setAttribute("role","application"),this.setAttribute("aria-roledescription",as(1109));const t=Tb.has(e)?` ${as(69)}`:"";this.setAttribute("aria-label",as(1209,{label:as(Mb[e].label),hint:as(Mb[e].hint)})+t)}updated(){this._labelArea(),Cb.setHint(this.disabled?"":this._hint())}_canvasPaths(){if(this.disabled||"ready"!==this.canvasState)return{mode:"view",paths:Zb,paint:Wb};if("pen"===$b(this.selection))return this._penList.src!==this._pen&&(this._penList={src:this._pen,list:this._pen?[this._pen]:Zb}),{mode:"add",paths:this._penList.list,paint:Wb};const e=this._selectedId,t=e?this._shapes.find(t=>t.id===e):void 0;return!t||this._isLocked(t.id)||1!==(0,$e.Mj)(t.d).length?{mode:"view",paths:Zb,paint:Wb}:(this._live?.id===t.id&&this._live.d===t.d||(this._live={id:t.id,d:t.d,list:[_a(t.d)]}),{mode:"nodes",paths:this._live.list,paint:Kb,exclude:t.id})}render(){const e=this._view();if(!e)return a.qy`${this.renderNotice()}`;const t=$b(this.selection),i=this._canvasPaths(),n=Ib.has(t)&&!this.disabled,s={x:e.vb[0],y:e.vb[1],w:e.vb[2],h:e.vb[3]};return a.qy`
      <svg class="layer" aria-hidden="true">
        ${this._grid(e)}
        <rect class="board" x=${e.place.left} y=${e.place.top} width=${e.place.width} height=${e.place.height} rx="2"></rect>
        ${this._shapesLayer(e)} ${this._ghost(e)} ${this._motion(e)} ${this._dots(e)} ${this._selectionBox(e)} ${this._dragLayer(e)} ${this._crossMark(e)}
        ${this._snapAt?a.JW`<circle class="snap" cx=${this._toPx(e,this._snapAt)[0]} cy=${this._toPx(e,this._snapAt)[1]} r="7"></circle>`:a.s6}
      </svg>
      ${n?a.qy`<svg
            class="tool t-${t}"
            aria-hidden="true"
            @pointerdown=${e=>this._onDown(e)}
            @pointermove=${e=>this._onMove(e)}
            @pointerup=${e=>this._onUp(e)}
            @pointercancel=${()=>this._end(!1)}
            @lostpointercapture=${e=>{this._drag&&e.pointerId===this._drag.pointerId&&this._end(!0)}}
          >
            <rect class="bg" x="0" y="0" width="100%" height="100%"></rect>
          </svg>`:a.s6}
      ${"ready"===this.canvasState?a.qy`<mc-path-canvas
            overlay
            .placement=${e.place}
            .frame=${s}
            .paths=${i.paths}
            .paint=${i.paint}
            .mode=${i.mode}
            .maxPaths=${1}
            .gridStep=${1}
            .snap=${this._snapConfig(i.exclude)}
            .nudge=${1}
            .bigNudge=${5}
            .fineNudge=${.1}
            aria-label=${as("pen"===t?652:816)}
            @mc-path-change=${this._onCanvas}
            @mc-path-select=${this._onCanvasSelect}
            @mc-path-limit=${()=>this._announce=as(970)}
          ></mc-path-canvas>`:a.s6}
      ${this._pen&&this._pen.anchors.length>=2||"freehand"===this._kb?.tool&&this._kb.pts.length>=2?a.qy`<button type="button" class="finish" @click=${()=>this._finishButton()}>${as(327)}</button>`:a.s6}
      ${this._dropping?a.qy`<div class="drop">${as(274)}</div>`:a.s6} ${this.renderNotice()}
      <span class="sr-only" aria-live="polite">${this._announce}</span>
      <mc-anim-svg-dialog .doc=${this.doc} .pieces=${this._pieceList} .viewBox=${this._viewBox}></mc-anim-svg-dialog>
    `}};Jb.styles=[yf.styles,a.AH`
      :host {
        position: absolute;
        inset: 0;
        color: var(--state-icon-color, #44739e);
        --do-fill: color-mix(in srgb, var(--primary-color, #03a9f4) 70%, #000);
      }
      :host(:focus) {
        outline: none;
      }
      :host(:focus-visible) {
        outline: 2px solid var(--ch-accent);
        outline-offset: -2px;
      }
      svg.tool {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        overflow: visible;
        pointer-events: auto;
        cursor: crosshair;
      }
      svg.tool.t-select {
        cursor: default;
      }
      svg.tool.t-erase {
        cursor: cell;
      }
      .bg {
        fill: transparent;
      }
      .grid {
        fill: none;
        stroke: color-mix(in srgb, var(--ch-ink) 6%, transparent);
      }
      .board {
        fill: none;
        stroke: color-mix(in srgb, var(--ch-ink) 30%, transparent);
        stroke-dasharray: 4 3;
      }
      .shapes .under {
        opacity: 0.5;
      }
      .ghost-casing {
        fill: none;
        stroke: var(--ch-surface);
        stroke-width: 3;
        stroke-linejoin: round;
        opacity: 0.85;
      }
      .ghost {
        fill: none;
        stroke: var(--ch-ink);
        stroke-width: 1.25;
        stroke-dasharray: 2 3;
        stroke-linecap: round;
      }
      .draft {
        fill: none;
        stroke: var(--ch-accent);
        stroke-width: 2;
        stroke-linecap: round;
        stroke-linejoin: round;
      }
      .draft.fillable {
        fill: color-mix(in srgb, var(--ch-accent) 12%, transparent);
      }
      .motion {
        fill: none;
        stroke: var(--ch-accent);
        stroke-width: 1.5;
        stroke-dasharray: 5 4;
      }
      .bbox {
        fill: none;
        stroke: var(--ch-accent);
        stroke-width: 1;
      }
      .snap {
        fill: none;
        stroke: var(--ch-accent);
        stroke-width: 1.5;
      }
      .cross {
        fill: none;
        stroke: var(--ch-ink);
        stroke-width: 1.5;
        stroke-linecap: round;
      }
      .cross-casing {
        fill: none;
        stroke: var(--ch-surface);
        stroke-width: 4;
        stroke-linecap: round;
      }
      .dots circle {
        fill: color-mix(in srgb, var(--ch-ink) 50%, transparent);
      }
      .finish {
        position: absolute;
        left: 50%; /* physical */
        bottom: 12px;
        transform: translateX(-50%);
        min-height: 32px;
        padding: 0 14px;
        border: 0;
        border-radius: 9999px;
        background: var(--ch-action);
        color: var(--text-primary-color, #fff);
        font: inherit;
        font-size: 0.8125rem;
        font-weight: 600;
        cursor: pointer;
        pointer-events: auto;
      }
      .finish:focus-visible {
        outline: 2px solid var(--ch-ink);
        outline-offset: 2px;
      }
      .drop {
        position: absolute;
        inset: 0;
        display: grid;
        place-items: center;
        background: color-mix(in srgb, var(--ch-accent) 10%, transparent);
        border: 2px dashed var(--ch-accent);
        border-radius: 12px;
        color: var(--ch-ink);
        font-size: 0.875rem;
        font-weight: 500;
        pointer-events: none;
      }
    `],Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"doc",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"selection",null),Fb([(0,o.MZ)({type:Boolean,reflect:!0})],Jb.prototype,"disabled",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"layerView",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"tile",void 0),Fb([(0,o.MZ)({type:Number})],Jb.prototype,"time",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"hass",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"library",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"stage",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"stageRect",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"subjectRect",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"iconRect",void 0),Fb([(0,o.MZ)({attribute:!1})],Jb.prototype,"pieces",void 0),Fb([(0,o.MZ)({type:String})],Jb.prototype,"viewBox",void 0),Fb([(0,o.MZ)({type:Boolean})],Jb.prototype,"preview",void 0),Fb([(0,o.wk)()],Jb.prototype,"_resolved",void 0),Fb([(0,o.wk)()],Jb.prototype,"_pen",void 0),Fb([(0,o.wk)()],Jb.prototype,"_snapAt",void 0),Fb([(0,o.wk)()],Jb.prototype,"_dropping",void 0),Fb([(0,o.wk)()],Jb.prototype,"_announce",void 0),Fb([(0,o.wk)()],Jb.prototype,"_cross",void 0),Fb([(0,o.wk)()],Jb.prototype,"_kb",void 0),Jb=Fb([(0,o.EM)("mc-anim-draw-host")],Jb),Ds({tag:"mc-anim-draw-host",place:"stage-tool",when:wb,title:265,order:40,dock:"canvas"});var Xb=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Qb=[{value:"round",label:755},{value:"butt",label:332},{value:"square",label:871}],ey=[{value:"over",label:617,icon:"mdi:arrange-bring-forward"},{value:"under",label:1035,icon:"mdi:arrange-send-backward"}],ty=e=>Math.min(100,Math.max(0,Math.round(100*e)/100));let iy=class extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this._drawLoading=!1,this._refitting=!1}connectedCallback(){super.connectedCallback(),this._unsub=Cb.subscribe(()=>this.requestUpdate())}willUpdate(){this._draw||this._drawLoading||(Cb.lastFreehand||"freehand"===$b(this.selection))&&(this._drawLoading=!0,uf().then(e=>{this._drawLoading=!1,e&&(this._draw=e.pathDraw)}))}disconnectedCallback(){super.disconnectedCallback(),this._unsub?.()}get _shape(){const e=kb(this.selection);return e?this.doc?.rig?.shapes?.find(t=>t.id===e):void 0}_emit(e,t,i=!1){e&&this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:i?{doc:e,label:t,transient:!0}:{doc:e,label:t}}))}_select(e){this.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:e}}))}_patch(e,t,i){this.doc&&this._emit(to(this.doc,e.id,t),i)}_seg(e,t,i,n,s=""){return a.qy`<div class="field">
      <div class="field-head"><span class="lbl">${e}</span></div>
      <div class="seg full ${s}" role="radiogroup" aria-label=${e} @keydown=${e=>{const s=t.findIndex(e=>e.value===i),r="rtl"===x(e.currentTarget)?-1:1,a={ArrowRight:r,ArrowDown:1,ArrowLeft:-r,ArrowUp:-1};if(!(e.key in a))return;e.preventDefault();const o=t[(s+a[e.key]+t.length)%t.length].value,l=e.currentTarget;n(o),requestAnimationFrame(()=>l.querySelector(`[data-val="${o}"]`)?.focus())}}>
        ${t.map(e=>{const t=e.value===i;return a.qy`<button
            type="button"
            role="radio"
            data-val=${e.value}
            aria-checked=${t?"true":"false"}
            tabindex=${t?"0":"-1"}
            ?disabled=${this.disabled}
            @click=${()=>t||n(e.value)}
          >
            ${e.icon?a.qy`<ha-icon icon=${e.icon}></ha-icon>`:a.s6}${as(e.label)}
          </button>`})}
      </div>
    </div>`}_switch(e,t,i,n,s,r=!1){return a.qy`<div class="switch-row">
      <div class="txt">
        <span class="lbl">${e}</span>
        ${t?a.qy`<p class="help">${t}</p>`:a.s6}
      </div>
      <button
        type="button"
        class="switch ${s}"
        role="switch"
        aria-checked=${i?"true":"false"}
        aria-label=${e}
        ?disabled=${this.disabled||r}
        @click=${n}
      ></button>
    </div>`}_color(e,t,i,n){return a.qy`<mc-color-picker
      class=${n}
      allowEntity
      .label=${e}
      .value=${t}
      ?disabled=${this.disabled}
      @value-changed=${e=>{e.stopPropagation();const n=function(e){const t=e.trim();if(t)return/^entity( \d{1,3}%)?$/.test(t)?t:vt(t,"color")}(String(e.detail.value??""));n&&n!==t&&i(n)}}
    ></mc-color-picker>`}_number(e,t,i,n,s,r){return a.qy`<div class="field">
      <div class="field-head"><label for=${e}>${t}</label></div>
      <input
        id=${e}
        class="input"
        type="number"
        inputmode="decimal"
        min="0"
        max=${s}
        step=${n}
        .value=${String(i)}
        ?disabled=${this.disabled}
        @change=${e=>{const t=e.target,n=Number(t.value);if(""===t.value||!Number.isFinite(n))return void(t.value=String(i));const a=Math.min(s,Math.max(0,Math.round(100*n)/100));t.value=String(a),a!==i&&r(a)}}
      />
    </div>`}_paint(e,t){return a.qy`<section class="group" aria-labelledby="h-paint">
      <div class="group-head"><h3 id="h-paint">${as(621)}</h3></div>
      ${e.closed?a.qy`<div class="paint">
            ${this._switch(as(322),"",void 0!==e.fill,()=>t.fill(void 0!==e.fill?void 0:"currentColor"),"fill-on",void 0!==e.fill&&void 0===e.stroke)}
            ${void 0!==e.fill?this._color(as(323),e.fill,e=>t.fill(e),"fill-color"):a.s6}
          </div>`:a.s6}
      <div class="paint">
        ${this._switch(as(911),e.closed?"":as(58),void 0!==e.stroke,()=>t.stroke(void 0!==e.stroke?void 0:"currentColor"),"stroke-on",!e.closed||void 0!==e.stroke&&void 0===e.fill)}
        ${void 0!==e.stroke?a.qy`${this._color(as(912),e.stroke,e=>t.stroke(e),"stroke-color")}
              <div class="two">
                ${this._number("f-width",as(913),e.width,.25,100,t.width)}
              </div>
              ${this._seg(as(420),Qb,e.cap,t.cap,"caps")}`:a.s6}
      </div>
    </section>`}_smoothing(e,t,i=!1){const n=Cb.options.tolerance;return a.qy`<div class="field">
      <div class="field-head"><label for="f-tol">${as(842)}</label><span class="val">${n.toFixed(2)}</span></div>
      <div class="slider">
        <span aria-hidden="true">${as(237)}</span>
        <input
          id="f-tol"
          type="range"
          min=${.05}
          max=${2}
          step=${.05}
          .value=${String(n)}
          aria-valuetext=${as(1261,{size:n.toFixed(2)})}
          ?disabled=${this.disabled||i}
          @input=${t=>e(Number(t.target.value),!1)}
          @change=${t=>e(Number(t.target.value),!0)}
        />
        <span aria-hidden="true">${as(840)}</span>
      </div>
      <p class="help">${t}</p>
    </div>`}_refit(e,t){Cb.set({tolerance:e});const i=Cb.lastFreehand,n=i&&this.doc?.rig?.shapes?.find(e=>e.id===i.id);if(!n||!this.doc)return;const s=this._draw?.fitFreehand(i.raw,e);if(s&&s.d){if(!t){if(s.d===n.d)return;return this._refitting=!0,void this._emit(to(this.doc,n.id,{d:s.d}),"Smooth stroke",!0)}(s.d!==n.d||this._refitting)&&this._emit(to(this.doc,n.id,{d:s.d}),"Smooth stroke"),this._refitting=!1}}_renderShape(e){const t=this.doc,i=`shape:${e.id}`,n=/[Zz]\s*$/.test(e.d)||Ba(e),s=t.rig?.shapes??[],r=s.findIndex(t=>t.id===e.id),o=t.tracks?.find(e=>e.target===i),l=Cb.lastFreehand?.id===e.id;return a.qy`
      <section class="group" aria-labelledby="h-shape">
        <div class="group-head"><h3 id="h-shape">${as(813)}</h3><span class="id" title=${as(920)}>${i}</span></div>
        <div class="field">
          <div class="field-head"><label for="f-name">${as(533)}</label></div>
          <input
            id="f-name"
            class="input"
            .value=${e.name}
            maxlength="80"
            ?disabled=${this.disabled}
            @change=${t=>{const i=t.target,n=i.value.trim();n?n!==e.name&&this._patch(e,{name:n},"Rename shape"):i.value=e.name}}
          />
        </div>
        ${this._seg(as(404),ey,e.layer,t=>this._patch(e,{layer:t},as("under"===t?817:815)),"layer")}
        <div class="row">
          <button type="button" class="btn btn-text btn-sm forward" ?disabled=${this.disabled||r>=s.length-1} @click=${()=>this._emit(io(t,e.id,r+1),"Bring shape forward")}>
            <ha-icon icon="mdi:arrange-bring-forward"></ha-icon>${as(101)}
          </button>
          <button type="button" class="btn btn-text btn-sm backward" ?disabled=${this.disabled||r<=0} @click=${()=>this._emit(io(t,e.id,r-1),"Send shape backward")}>
            <ha-icon icon="mdi:arrange-send-backward"></ha-icon>${as(791)}
          </button>
        </div>
      </section>
      ${this._paint({fill:Ba(e)?e.fill??"currentColor":void 0,stroke:Ia(e)?e.stroke:void 0,width:e.stroke_width??1,cap:e.linecap??"butt",closed:n},{fill:t=>this._patch(e,{fill:t},as(t?128:716)),stroke:t=>this._patch(e,t?{stroke:t,stroke_width:e.stroke_width??1}:{stroke:void 0,stroke_width:void 0,linecap:void 0},as(t?132:722)),width:t=>this._patch(e,{stroke_width:ty(t)},"Change stroke width"),cap:t=>this._patch(e,{linecap:t},"Change line ends")})}
      ${l?a.qy`<section class="group" aria-labelledby="h-smooth">
            <div class="group-head"><h3 id="h-smooth">${as(344)}</h3></div>
            ${this._smoothing((e,t)=>this._refit(e,t),as(451),!this._draw)}
          </section>`:a.s6}
      <section class="group" aria-labelledby="h-anim">
        <div class="group-head"><h3 id="h-anim">${as(64)}</h3></div>
        ${this._switch(as(261),Ba(e)?as(965):as(959),oo(t,i),()=>oo(t,i)?this._emit(function(e,t){const i=ro(e,t);if(!i)return e;const n=i.keyframes.map(e=>{const t={...e};return delete t.draw,t}).filter(e=>Object.keys(e).some(e=>"at"!==e&&"easing"!==e)),s={...i,keyframes:n};return ao(e,n.length||s.path?s:void 0,t)??e}(t,i),"Remove draw on"):this._emit(function(e,t){const i=ro(e,t),n=(i?.keyframes??[]).map(e=>({...e}));for(const[e,t]of[[0,0],[100,1]]){const i=n.find(t=>t.at===e);i?i.draw=t:n.push({at:e,draw:t})}return n.sort((e,t)=>e.at-t.at),ao(e,{...i??{target:t},target:t,keyframes:n},t)}(t,i),"Draw on"),"draw-on")}
        <div class="field">
          <div class="field-head"><span class="lbl">${as(453)}</span></div>
          <div class="row">
            <button type="button" class="btn btn-secondary btn-sm draw-motion" ?disabled=${this.disabled} @click=${()=>this._select({kind:"tool",tool:"motion",target:i})}>
              <ha-icon icon="mdi:map-marker-path"></ha-icon>${as(o?.path?705:259)}
            </button>
            ${o?.path?a.qy`<button type="button" class="btn btn-text btn-sm remove-motion" ?disabled=${this.disabled} @click=${()=>this._emit(lo(t,i,void 0,!1),"Remove motion path")}>
                  ${as(710)}
                </button>`:a.s6}
          </div>
          ${o?.path?this._switch(as(341),as(983),!!o.path.follow_rotation,()=>{const e=(t.tracks??[]).map(e=>e===o?{...e,path:{...e.path,follow_rotation:!e.path.follow_rotation}}:e);this._emit({...t,tracks:e},"Follow the path")},"follow"):a.qy`<p class="help">${as(262)}</p>`}
        </div>
      </section>
      <section class="group">
        <button type="button" class="btn btn-text btn-sm danger-text delete" ?disabled=${this.disabled} @click=${()=>{this._emit(so(t,e.id),"Delete shape"),this._select({kind:"tool",tool:"select"})}}>
          <ha-icon icon="mdi:delete-outline"></ha-icon>${as(229)}
        </button>
      </section>
    `}_opt(e){Cb.set(e)}_renderTool(e){const t=Cb.options,i=Mb[e],n="pen"===e||"line"===e||"rect"===e||"ellipse"===e||"freehand"===e,s="rect"===e||"ellipse"===e||"pen"===e,r=this.selection.target;return a.qy`
      <section class="group" aria-labelledby="h-tool">
        <div class="group-head tool-head"><ha-icon icon=${i.icon}></ha-icon><h3 id="h-tool">${as(i.label)}</h3></div>
        <p class="help lead">${as(i.hint)}</p>
        ${"motion"===e?_b(r)?a.qy`<p class="help">${os(501,{target:a.qy`<span class="id">${r}</span>`})}</p>
                ${this._switch(as(341),as(391),t.follow,()=>this._opt({follow:!t.follow}),"follow-opt")}`:a.qy`<p class="help">${as(786)}</p>`:a.s6}
        ${"rect"===e?this._number("f-radius",as(191),t.radius,.5,12,e=>this._opt({radius:e})):a.s6}
        ${"freehand"===e||"motion"===e?this._smoothing((t,i)=>"freehand"===e?this._refit(t,i):this._opt({tolerance:t}),"freehand"===e&&Cb.lastFreehand?as(134):as(450),"freehand"===e&&!this._draw):a.s6}
      </section>
      ${n?a.qy`${this._paint({fill:s&&t.fill||void 0,stroke:t.stroke||(s?void 0:"currentColor"),width:t.strokeWidth,cap:t.linecap,closed:s},{fill:e=>this._opt({fill:e??""}),stroke:e=>this._opt({stroke:e??""}),width:e=>this._opt({strokeWidth:ty(e)}),cap:e=>this._opt({linecap:e})})}
            <section class="group" aria-labelledby="h-new">
              <div class="group-head"><h3 id="h-new">${as(545)}</h3></div>
              ${this._seg(as(404),ey,t.layer,e=>this._opt({layer:e}),"layer")}
            </section>`:a.s6}
      ${"erase"!==e&&"select"!==e?a.qy`<section class="group" aria-labelledby="h-snap">
            <div class="group-head"><h3 id="h-snap">${as(846)}</h3></div>
            ${this._switch(as(355),as(682),t.grid,()=>this._opt({grid:!t.grid}),"snap-grid")}
            ${this._switch(as(59),as(681),t.anchors,()=>this._opt({anchors:!t.anchors}),"snap-anchors")}
          </section>`:a.s6}
    `}render(){if(!this.doc)return a.qy``;const e=this._shape;return e?this._renderShape(e):"tool"===this.selection.kind&&yb(this.selection.tool)?this._renderTool($b(this.selection)):a.qy``}};iy.styles=[dh,a.AH`
      :host {
        display: block;
      }
      .id {
        font: 0.75rem/1.5 'Roboto Mono', ui-monospace, SFMono-Regular, Consolas, monospace;
        color: var(--secondary-text-color, #5f6368);
      }
      .row {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }
      .slider {
        display: grid;
        grid-template-columns: auto minmax(0, 1fr) auto;
        align-items: center;
        gap: 8px;
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
        min-height: 32px;
      }
      .slider input[type='range'] {
        width: 100%;
        margin: 0;
        accent-color: color-mix(in srgb, var(--primary-color, #03a9f4) 70%, #000);
      }
      .field-head .val {
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
        font-variant-numeric: tabular-nums;
      }
      .paint {
        display: grid;
        gap: 8px;
      }
      .danger-text {
        color: color-mix(in srgb, var(--error-color, #db4437) 80%, var(--primary-text-color, #212121));
      }
      .tool-head {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .tool-head ha-icon {
        --mdc-icon-size: 20px;
        color: var(--secondary-text-color, #5f6368);
      }
    `],Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"doc",void 0),Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"selection",void 0),Xb([(0,o.MZ)({type:Boolean})],iy.prototype,"disabled",void 0),Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"hass",void 0),Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"library",void 0),Xb([(0,o.MZ)({type:Number})],iy.prototype,"time",void 0),Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"tile",void 0),Xb([(0,o.MZ)({attribute:!1})],iy.prototype,"stage",void 0),Xb([(0,o.wk)()],iy.prototype,"_draw",void 0),iy=Xb([(0,o.EM)("mc-anim-shape-inspector")],iy),Ds({tag:"mc-anim-shape-inspector",place:"inspector",when:function(e,t){return"keyframes"===e.kind&&("tool"===t.kind?yb(t.tool):"target"===t.kind&&xb(t.target)&&!!e.rig?.shapes?.some(e=>`shape:${e.id}`===t.target))},title:265,order:30});var ny=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const sy=(e,t)=>{e.dispatchEvent(new CustomEvent("selection-change",{bubbles:!0,composed:!0,detail:{selection:t}}))},ry=["select","pen","line","rect","ellipse","freehand","erase","motion"];let ay=class extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this._key=""}connectedCallback(){super.connectedCallback(),this._offHint=Cb.onHint(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this._offHint?.()}willUpdate(e){if((e.has("doc")||e.has("tile"))&&this.doc&&!this.pieces){const e=`${this.doc.rig?.svg??this.doc.rig?.icon??""}|${this.tile??""}`;e!==this._key&&(this._key=e,Hb(this.doc,this.tile).then(t=>{this._key===e&&(this._resolved=t)}))}}get _dialog(){return this.renderRoot.querySelector("mc-anim-svg-dialog")}openExport(e=!1){this._dialog?.openExport(e)}openImport(e="",t=""){this._dialog?.openImport(e,t)}_choose(e){const t=this.selection;if((this.doc&&wb(this.doc,t)?$b(t):void 0)===e&&"tool"===t.kind)return void sy(this,{kind:"none"});const i=_b(t.target)?t.target:void 0;sy(this,{kind:"tool",tool:e,...i?{target:i}:{}})}render(){const e=this.doc;if(!e||"keyframes"!==e.kind)return a.qy``;const t=wb(e,this.selection),i=t?$b(this.selection):void 0,n=t?Cb.hint:"",s=this.pieces??this._resolved?.pieces??[],r=a.qy`<mc-anim-svg-dialog
      .doc=${e}
      .pieces=${s}
      .viewBox=${Eb(this.doc?.rig,this._resolved)}
      ?disabled=${this.disabled}
    ></mc-anim-svg-dialog>`;if(!t)return a.qy`<button type="button" class="btn btn-secondary btn-sm open" ?disabled=${this.disabled} @click=${()=>this._choose("select")}>
          <ha-icon icon="mdi:draw-pen"></ha-icon>${as(257)}
        </button>
        ${r}`;const o=_b(this.selection.target);return a.qy`<div class="bar" role="toolbar" aria-label=${as(267)}>
        ${ry.map(e=>{const t=Mb[e],n=this.disabled||"motion"===e&&!o;return a.qy`<button
            type="button"
            class="icon-btn tool"
            data-tool=${e}
            aria-pressed=${i===e?"true":"false"}
            aria-label=${as(t.label)}
            title=${as("motion"!==e||o?t.label:455)}
            ?disabled=${n}
            @click=${()=>this._choose(e)}
          >
            <ha-icon icon=${t.icon}></ha-icon>
          </button>`})}
        <span class="sep" aria-hidden="true"></span>
        <button type="button" class="icon-btn import" aria-label=${as(381)} title=${as(381)} ?disabled=${this.disabled} @click=${()=>this.openImport()}>
          <ha-icon icon="mdi:file-import-outline"></ha-icon>
        </button>
        <button type="button" class="icon-btn export" aria-label=${as(767)} title=${as(767)} ?disabled=${this.disabled} @click=${()=>this.openExport()}>
          <ha-icon icon="mdi:content-save-outline"></ha-icon>
        </button>
        <button type="button" class="icon-btn done" aria-label=${as(907)} title=${as(907)} @click=${()=>sy(this,{kind:"none"})}>
          <ha-icon icon="mdi:close"></ha-icon>
        </button>
      </div>
      ${n?a.qy`<p class="hint">${n}</p>`:a.s6}
      ${r}`}};ay.styles=[dh,a.AH`
      :host {
        position: absolute;
        top: 8px;
        left: 8px; /* physical */
        right: 8px; /* physical */
        z-index: 2;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 6px;
        pointer-events: none;
      }
      /* what to do next with the tool (the overlay's hint), under the bar and off the card */
      .hint {
        max-width: 100%;
        box-sizing: border-box;
        margin: 0;
        padding: 4px 12px;
        border-radius: 9999px;
        background: var(--card-background-color, #fff);
        color: var(--primary-text-color, #212121);
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        font-size: 0.75rem;
        font-weight: 500;
        text-align: center;
      }
      .bar {
        pointer-events: auto;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        gap: 2px;
        padding: 3px;
        border-radius: 10px;
        background: var(--card-background-color, #fff);
        border: 1px solid var(--divider-color, rgba(0, 0, 0, 0.12));
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.16), 0 2px 6px rgba(0, 0, 0, 0.08);
      }
      .bar .icon-btn {
        width: 36px;
        height: 36px;
        border-radius: 7px;
      }
      .bar .icon-btn[aria-pressed='true'] {
        background: color-mix(in srgb, var(--primary-color, #03a9f4) 12%, transparent);
        color: color-mix(in srgb, var(--primary-color, #03a9f4) 60%, var(--primary-text-color, #212121));
      }
      .sep {
        width: 1px;
        align-self: stretch;
        margin: 4px 3px;
        background: var(--divider-color, rgba(0, 0, 0, 0.12));
      }
      /* the dialog's window sits under this host, so it takes presses itself instead of passing them to the canvas */
      mc-anim-svg-dialog {
        pointer-events: auto;
      }
      .open {
        pointer-events: auto;
        height: 36px;
        border-radius: 10px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.16), 0 2px 6px rgba(0, 0, 0, 0.08);
      }
    `],ny([(0,o.MZ)({attribute:!1})],ay.prototype,"doc",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"selection",void 0),ny([(0,o.MZ)({type:Boolean})],ay.prototype,"disabled",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"tile",void 0),ny([(0,o.MZ)({type:Number})],ay.prototype,"time",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"hass",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"library",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"stage",void 0),ny([(0,o.MZ)({attribute:!1})],ay.prototype,"pieces",void 0),ny([(0,o.wk)()],ay.prototype,"_resolved",void 0),ay=ny([(0,o.EM)("mc-anim-draw-toolbar")],ay),Ds({tag:"mc-anim-draw-toolbar",place:"stage-tool",when:e=>"keyframes"===e.kind,title:257,order:90,dock:"top"});var oy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const ly=[{target:"element",label:291,icon:"mdi:square-rounded-outline"},{target:"icon",label:370,icon:"mdi:star-outline"},{target:"name",label:533,icon:"mdi:format-title"},{target:"state",label:885,icon:"mdi:numeric"},{target:"background",label:78,icon:"mdi:rectangle-outline"}];function cy(e,t){return!!e.tracks?.some(e=>e.target===t&&(e.keyframes.length>0||!!e.path))||("element"===t||"icon"===t)&&(e.target??"element")===t&&(e.keyframes?.length??0)>0}const dy=ds;let py=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection=Ps,this.tile="icon",this.density="full",this._list=new If(this,{select:e=>e.startsWith("lane:")?!this.disabled&&Gf(this,this.doc,e):this._select(e.slice(7)),open:(e,t)=>this._list.setOpen(e,t),nameOf:e=>e.startsWith("lane:")?Kf(e):(e=>{const t=ly.find(t=>t.target===e)?.label;return void 0===t?void 0:as(t)})(e.slice(7))??e})}_select(e){if(this.disabled)return;const t={kind:"target",target:e};this.dispatchEvent(new CustomEvent("selection-change",{detail:{selection:t},bubbles:!0,composed:!0}))}_row(e,t,i){const n=this.doc,s=cy(n,e.target)?(e.target===n.target&&"keyframes"===n.kind?n.keyframes?.length??0:0)+(n.tracks?.find(t=>t.target===e.target)?.keyframes.length??0):0,r=`target:${e.target}`,a=Uf(n,this.layerView??po,e.target,r),o=this._list.row({key:r,expanded:a,name:as(e.label),icon:e.icon,note:t?void 0:as(583),badge:s?as(1168,{count:s}):void 0,describe:[cy(n,e.target)?as(1097):"",t?"":as(1128,{tile:as(us(this.tile).label)})].filter(Boolean).join(", "),selected:i===e.target&&!(a&&"keys"===this.selection.kind),toggles:"element"===e.target?["lock"]:void 0,title:t?as(e.label):as(1206,{label:as(e.label),tile:as(us(this.tile).label)})});return a?[o,...Yf(this._list,n,this.selection,e.target,2)]:[o]}render(){const e=this.doc;if(!e)return a.s6;const t=us(this.tile),i=(n=this.selection,"target"===n?.kind||"keys"===n?.kind?n.target??n.keys?.[0]?.target:void 0);var n;const s=e=>t.targets.includes(e),r=ly.filter(t=>s(t.target)||cy(e,t.target)||i===t.target),o=ly.filter(e=>!s(e.target));return a.qy`
      <ul aria-label=${as(121)}>
        ${r.map(e=>this._row(e,s(e.target),i))}
      </ul>
      ${o.length?a.qy`<p class="hint">
            ${as(1189,{count:o.length,names:dy(o.map(e=>as(e.label))),tile:as(t.label)})}
          </p>`:a.s6}
    `}};py.styles=[dh,Zf,a.AH`
      :host {
        display: block;
        color: var(--mc-text);
        font-size: 0.875rem;
      }
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 2px;
      }
      .hint {
        margin: 8px 10px 0;
        font-size: 0.75rem;
        line-height: 1.4;
        color: var(--mc-text-2);
      }
    `],oy([(0,o.MZ)({attribute:!1})],py.prototype,"doc",void 0),oy([(0,o.MZ)({attribute:!1})],py.prototype,"hass",void 0),oy([(0,o.MZ)({attribute:!1})],py.prototype,"library",void 0),oy([(0,o.MZ)({type:Number})],py.prototype,"time",void 0),oy([(0,o.MZ)({type:Boolean})],py.prototype,"disabled",void 0),oy([(0,o.MZ)({attribute:!1})],py.prototype,"selection",void 0),oy([(0,o.MZ)({attribute:!1})],py.prototype,"tile",void 0),oy([(0,o.MZ)({attribute:!1})],py.prototype,"layerView",void 0),oy([(0,o.MZ)()],py.prototype,"density",void 0),py=oy([(0,o.EM)("mc-anim-targets-layers")],py),Ds({tag:"mc-anim-targets-layers",place:"layers",when:e=>"keyframes"===e.kind,title:121,order:40});var hy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const uy=["lock"],my=["hide","lock"],gy=[];let fy=class extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this.density="full",this.emitter=0,this.all=!1,this._open=new Map,this._list=new If(this,{select:e=>this._pick(e),move:(e,t)=>this._move(e,t),rename:e=>this._renaming=e,dblclick:e=>!this.disabled&&/^emitter:/.test(e)&&this._multi&&!this._list.refuseLocked(e,this._nameOfKey(e))&&(this._renaming=e),open:(e,t)=>this._open=new Map(this._open).set(e,t),nameOf:e=>this._nameOfKey(e)})}get _multi(){return!!this.doc&&zm(this.doc)>1}_ems(e){const t=e.particles?.sim?uo(e):["main"];return Array.from({length:zm(e)},(i,n)=>({i:n,id:t[n]??`e${n+1}`,name:Dm(e,0,n),side:Om(e,n)}))}_nameOfKey(e){const t=e.slice(e.indexOf(":")+1).replace(/[|/].*$/,""),i=this.doc?this._ems(this.doc).find(e=>e.id===t):void 0;return e.startsWith("children:")?as(137,{name:i?.name??t}):i?.name??t}_emit(e,t){this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:e,label:t}}))}_select(e){this.dispatchEvent(new CustomEvent("emitter-change",{bubbles:!0,composed:!0,detail:{index:e,all:!1}}))}_pick(e){if(this.disabled||!this.doc)return;const t=e.slice(e.indexOf(":")+1).replace(/[|/].*$/,""),i=this._ems(this.doc).find(e=>e.id===t);i&&(this._sub=e.startsWith("emitter:")?void 0:e,this._select(i.i))}_side(e,t){return e.filter(e=>e.side===t).reverse()}_move(e,t){const i=this.doc;if(!i||this.disabled)return;const n=this._ems(i),s=n.find(t=>`emitter:${t.id}`===e);if(!s)return;const r=this._side(n,s.side),a=r.indexOf(s),o=n[Math.max(0,Math.min(n.length-1,this.emitter))]?.id;let l,c,d;if("up"===t?"back"===s.side&&0===a:"front"===s.side&&a===r.length-1){const e="back"===s.side?"front":"back";l=function(e,t,i,n){if(!Lm(e,i)||Om(e,i)===n)return{doc:e,index:i};if(1===zm(e))return{doc:Ou(e,{layer:n}),index:0};const s=Em(e,0),[r]=s.splice(i,1);r.layer=n;let a=Math.min(i,s.length);if("front"===n){const e=s.findIndex(e=>"front"===e.layer);e>=0&&(a=e)}else{const e=s.map(e=>e.layer).lastIndexOf("back");e>=0&&(a=e+1)}return s.splice(a,0,r),{doc:Hm(e,0,s),index:a}}(i,0,s.i,e).doc,c=as("front"===e?465:463),d=as("front"===e?1235:1234,{name:s.name})}else{const e=r["up"===t?a-1:a+1];if(!e)return;l=function(e,t,i,n){if(!Lm(e,i)||!Lm(e,n)||i===n)return e;const s=Em(e,0);return s.splice(n,0,s.splice(i,1)[0]),Hm(e,0,s)}(i,0,s.i,e.i),c=as("up"===t?466:464),d=as(1237,{name:s.name,direction:as("up"===t?1152:1105),position:"up"===t?a:a+2,count:r.length})}if(l===i)return;this._emit(l,c),this._list.announce(d);const p=uo(l).indexOf(o??"");p>=0&&p!==this.emitter&&l.particles?.sim&&this._select(p)}_rename(e,t){if(this._renaming!==e)return;this._renaming=void 0;const i=this.doc,n=i?this._ems(i).find(t=>`emitter:${t.id}`===e):void 0;if(!i||!n||this._list.refuseLocked(e,n.name))return;const s=Vm(i,0,n.i,t);s!==i&&this._emit(s,"Rename emitter")}_moveInfo(e,t,i){const n=i.indexOf(e),s="up"===t?"back"===e.side&&0===n:"front"===e.side&&n===i.length-1,r="up"===t?0===n:n===i.length-1,a=!this.disabled&&(s||!r);if(s){const i=as("up"===t?1115:1100);return{ok:a,label:as(490,{name:e.name,where:i}),menu:as(491,{where:i})}}return"up"===t?{ok:a,label:as(488,{name:e.name}),menu:as(481)}:{ok:a,label:as(485,{name:e.name}),menu:as(460)}}_focusRow(e){this._list.focusKey(e)}_renameField(e,t){return a.qy`<input
      class="input rename"
      aria-label=${as(407)}
      maxlength=${40}
      .value=${e.name}
      @click=${e=>e.stopPropagation()}
      @keydown=${e=>{e.stopPropagation(),"Enter"===e.key?(this._rename(t,e.target.value),this._focusRow(t)):"Escape"===e.key&&(this._renaming=void 0,this._focusRow(t))}}
      @blur=${e=>this._rename(t,e.target.value)}
    />`}_rowsOf(e,t,i,n){const s=`emitter:${t.id}`,r=rm(e,0),a=0===t.i?r:r.emitters[t.i-1],o=0===t.i?r.children:r.emitters[t.i-1].children,l=!this.all&&Math.min(this.emitter,i.length-1)===t.i,c=this._open.get(s)??(1===i.length||l),d=this._side(i,t.side),p=[this._list.row({key:s,name:t.name,icon:"mdi:shimmer",selected:l&&!this._sub,expanded:c,toggles:n,up:this._moveInfo(t,"up",d),down:this._moveInfo(t,"down",d),renamable:this._multi,renaming:this._renaming===s?this._renameField(t,s):void 0,describe:"front"===t.side?as(1115):as(1100),title:"front"===t.side?as(1245,{name:t.name}):as(1244,{name:t.name})})];if(!c)return p;o&&p.push(this._list.row({key:`children:${t.id}`,name:as(136),icon:"mdi:dots-hexagon",level:2,selected:this._sub===`children:${t.id}`,toggles:n}));const h=(e,t,i)=>{dm({shapes:e}).forEach((e,n)=>{const s=`pshape:${t}|${n}`;p.push(this._list.row({key:s,name:`${i} ${n+1}: ${Uu(e.shape)}`,icon:"mdi:shape-outline",level:2,selected:this._sub===s,toggles:gy}))})};return h(a.shapes,t.id,as(813)),o&&h(o.shapes,`${t.id}/c`,as(138)),p}updated(e){if((e.has("emitter")&&void 0!==e.get("emitter")||e.has("all")&&void 0!==e.get("all"))&&this.doc&&!this.all){const e=this._ems(this.doc)[Math.min(this.emitter,zm(this.doc)-1)]?.id;this.renderRoot.querySelector(`[data-lk="emitter:${e}"]`)?.scrollIntoView?.({block:"nearest"})}}render(){const e=this.doc;if(!e||"particles"!==e.kind)return a.s6;const t=this._ems(e),i=!!e.particles?.sim,n=i&&!!Sd(e),s=i?n?void 0:uy:my,r=this._side(t,"front"),o=this._side(t,"back");return a.qy`<ul aria-label=${as(630)}>
        ${r.flatMap(i=>this._rowsOf(e,i,t,s))}
        <li class="lcontent" title=${as(120)}>
          <ha-icon icon="mdi:card-text-outline" aria-hidden="true"></ha-icon><span>${as(119)}</span><span class="sr">${as(6)}</span>
        </li>
        ${o.flatMap(i=>this._rowsOf(e,i,t,s))}
      </ul>
      ${i&&!n?a.qy`<p class="note">${as(361)}</p>`:a.s6}`}};fy.styles=[dh,Zf,a.AH`
      :host {
        display: block;
        color: var(--mc-text);
        font-size: 0.875rem;
      }
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 2px;
      }
      .lcontent {
        display: flex;
        align-items: center;
        gap: 8px;
        min-height: 32px;
        padding: 2px 8px;
        border-top: 1px dashed var(--mc-divider);
        border-bottom: 1px dashed var(--mc-divider);
        color: var(--mc-text-2);
        --mdc-icon-size: 18px;
      }
      .lcontent ha-icon {
        flex: none;
      }
      .sr {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip-path: inset(50%);
        white-space: nowrap;
      }
      .note {
        margin: 6px 8px 0;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
    `],hy([(0,o.MZ)({attribute:!1})],fy.prototype,"doc",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"selection",void 0),hy([(0,o.MZ)({type:Boolean})],fy.prototype,"disabled",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"hass",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"library",void 0),hy([(0,o.MZ)({type:Number})],fy.prototype,"time",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"tile",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"stage",void 0),hy([(0,o.MZ)({attribute:!1})],fy.prototype,"layerView",void 0),hy([(0,o.MZ)()],fy.prototype,"density",void 0),hy([(0,o.MZ)({type:Number})],fy.prototype,"emitter",void 0),hy([(0,o.MZ)({type:Boolean})],fy.prototype,"all",void 0),hy([(0,o.wk)()],fy.prototype,"_open",void 0),hy([(0,o.wk)()],fy.prototype,"_renaming",void 0),hy([(0,o.wk)()],fy.prototype,"_sub",void 0),fy=hy([(0,o.EM)("mc-anim-particles-layers")],fy),Ds({tag:"mc-anim-particles-layers",place:"layers",when:e=>"particles"===e.kind,title:630,order:10});var vy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const by={element:291,icon:370,particles:633};let yy=class extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this.density="full",this._sel="path",this._list=new If(this,{select:e=>this._sel=e,nameOf:e=>"path"===e?as(453):as(497,{subject:this._subject()})})}_subject(){const e=by[this.doc?.path?.subject??"element"]??by.element;return as(e)}render(){const e=this.doc;return e&&"path"===e.kind?e.path?.d.trim()?a.qy`<ul aria-label=${as(647)}>
      ${this._list.row({key:"path",name:as(453),icon:"mdi:vector-curve",selected:"path"===this._sel})}
      ${this._list.row({key:"subject",name:as(497,{subject:this._subject()}),icon:"mdi:arrow-right-bold-outline",selected:"subject"===this._sel})}
    </ul>`:a.qy`<p class="empty-note">${as(561)}</p>`:a.s6}};yy.styles=[dh,Zf,a.AH`
      :host {
        display: block;
        color: var(--mc-text);
        font-size: 0.875rem;
      }
      ul {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 2px;
      }
      .empty-note {
        margin: 0;
        padding: 8px;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
    `],vy([(0,o.MZ)({attribute:!1})],yy.prototype,"doc",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"selection",void 0),vy([(0,o.MZ)({type:Boolean})],yy.prototype,"disabled",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"hass",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"library",void 0),vy([(0,o.MZ)({type:Number})],yy.prototype,"time",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"tile",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"stage",void 0),vy([(0,o.MZ)({attribute:!1})],yy.prototype,"layerView",void 0),vy([(0,o.MZ)()],yy.prototype,"density",void 0),vy([(0,o.wk)()],yy.prototype,"_sel",void 0),yy=vy([(0,o.EM)("mc-anim-path-layers")],yy),Ds({tag:"mc-anim-path-layers",place:"layers",when:e=>"path"===e.kind,title:646,order:10});var xy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let _y=class extends a.WF{constructor(){super(...arguments),this.selection={kind:"none"},this.disabled=!1,this.time=0,this.density="full",this._list=new If(this,{select:e=>this._sel=e,move:(e,t)=>this._move(Number(e.slice(5)),t),nameOf:e=>this._name(Number(e.slice(5)))})}_name(e){const t=this.doc?.steps?.[e];return t?Cf(t.animation,this.library,this.doc?.id).name:as(903,{i:e+1})}_move(e,t){const i=this.doc,n=i?.steps??[],s="up"===t?e-1:e+1;if(!i||this.disabled||s<0||s>=n.length)return;const r=this._name(e);let a;try{a=this.renderRoot.activeElement?.getAttribute("data-ctl")??void 0}catch{a=void 0}this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:{...i,steps:Af(n,e,s)},label:as(476)}})),this._list.announce(as(1230,{name:r,to:s+1,count:n.length}),zo(this.layerView??{hidden:[],solo:[],locked:[],open:[]},e,s)),this._sel===`step:${e}`&&(this._sel=`step:${s}`),queueMicrotask(()=>this._list.focusKey(`step:${s}`,a))}render(){const e=this.doc;if(!e||"sequence"!==e.kind)return a.s6;const t=e.steps??[];return t.length?a.qy`<ol aria-label=${as(800)}>
      ${t.map((i,n)=>{const s=Cf(i.animation,this.library,e.id),r="ok"===s.status?i.duration??s.defaultDuration:void 0,o=`step:${n}`,l=s.name;return this._list.row({key:o,name:l,thumb:a.qy`<span class="num" aria-hidden="true">${n+1}</span>`,note:s.problem,badge:void 0!==r?jf(r):void 0,describe:s.problem?as(1142,{i:n+1,count:t.length,problem:s.problem}):as(1141,{i:n+1,count:t.length}),selected:this._sel===o,up:{ok:!this.disabled&&n>0,label:as(489,{name:l}),menu:as(482)},down:{ok:!this.disabled&&n<t.length-1,label:as(487,{name:l}),menu:as(462)}})})}
    </ol>`:a.qy`<p class="empty-note">${as(566)}</p>`}};_y.styles=[dh,Zf,a.AH`
      :host {
        display: block;
        color: var(--mc-text);
        font-size: 0.875rem;
      }
      ol {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 2px;
      }
      .num {
        flex: none;
        display: grid;
        place-items: center;
        min-width: 22px;
        height: 22px;
        border-radius: 9999px;
        border: 1px solid var(--mc-divider);
        font-size: 0.75rem;
        font-variant-numeric: tabular-nums;
      }
      .lr.is-hidden .num {
        text-decoration: line-through;
        opacity: 0.6;
      }
      .empty-note {
        margin: 0;
        padding: 8px;
        font-size: 0.75rem;
        color: var(--mc-text-2);
      }
    `],xy([(0,o.MZ)({attribute:!1})],_y.prototype,"doc",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"selection",void 0),xy([(0,o.MZ)({type:Boolean})],_y.prototype,"disabled",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"hass",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"library",void 0),xy([(0,o.MZ)({type:Number})],_y.prototype,"time",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"tile",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"stage",void 0),xy([(0,o.MZ)({attribute:!1})],_y.prototype,"layerView",void 0),xy([(0,o.MZ)()],_y.prototype,"density",void 0),xy([(0,o.wk)()],_y.prototype,"_sel",void 0),_y=xy([(0,o.EM)("mc-anim-steps-layers")],_y),Ds({tag:"mc-anim-steps-layers",place:"layers",when:e=>"sequence"===e.kind,title:799,order:10});const wy=[{id:"state",label:886},{id:"state_not",label:887},{id:"entity_on",label:304},{id:"entity_off",label:303},{id:"above",label:1068},{id:"below",label:1070}],ky=[{id:"cut",label:210,hint:918},{id:"crossfade",label:196,hint:317},{id:"finish",label:326,hint:413}];function $y(e,t){const i=Number(t),n=""!==t.trim()&&Number.isFinite(i)?i:0,s=t.trim()||"on";switch(e){case"state":return{state:s};case"state_not":return{state_not:s};case"entity_on":return{entity_on:!0};case"entity_off":return{entity_on:!1};case"above":return{above:n};case"below":return{below:n}}}function My(e){return e&&"object"==typeof e?(e instanceof Map?[...e.values()]:Array.isArray(e)?e:Object.values(e)).filter(e=>!!e&&"object"==typeof e&&"string"==typeof e.id):[]}const Sy=e=>(e?.length??0)<12;var zy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let Cy=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection=Ps,this._announce=""}get _clips(){return Array.isArray(this.doc?.clips)?this.doc.clips:[]}_write(e,t){if(!this.doc)return;const i={...this.doc};e.length?i.clips=e:delete i.clips,this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:i,label:t}}))}_patch(e,t,i){this._write(this._clips.map((i,n)=>n===e?{...i,...t}:i),i)}_add(){if(!Sy(this._clips))return;const e=function(e){const t=new Set(e.map(e=>"state"in e.when?e.when.state:""));if(t.has("on")&&t.has("off"))return{when:{above:50},animation:"self",transition:"crossfade"};const i=t.has("on")?"off":"on";return{when:{state:i},animation:"off"===i?"none":"self",transition:"crossfade"}}(this._clips);this._write([...this._clips,e],"Add state"),this._focusAfter=`.clip[data-i="${this._clips.length}"] select.when`,this._announce=as(891,{count:this._clips.length+1,when:ep(e.when)})}_remove(e){const t=this._clips.filter((t,i)=>i!==e);this._write(t,"Delete state"),this._focusAfter=t.length?`.clip[data-i="${Math.min(e,t.length-1)}"] .del`:".add",this._announce=as(893,{i:e+1})}_move(e,t){t<0||t>=this._clips.length||(this._write(function(e,t,i){if(t===i||t<0||i<0||t>=e.length||i>=e.length)return[...e];const n=[...e],[s]=n.splice(t,1);return n.splice(i,0,s),n}(this._clips,e,t),"Reorder states"),this._focusAfter=`.clip[data-i="${t}"] .${t<e?"up":"down"}`,this._announce=as(890,{to:t+1}))}updated(){const e=this._focusAfter;if(!e)return;this._focusAfter=void 0;const t=this.renderRoot.querySelector(e);(t&&!t.disabled?t:this.renderRoot.querySelector(".add"))?.focus()}_when(e,t){const i="state"in(n=e.when)?"state":"state_not"in n?"state_not":"entity_on"in n?n.entity_on?"entity_on":"entity_off":"above"in n?"above":"below";var n;const s=function(e){return"state"in e?e.state:"state_not"in e?e.state_not:"above"in e?String(e.above):"below"in e?String(e.below):""}(e.when),r=`st-${t}`,o="above"===i||"below"===i;return a.qy`<div class="pair">
      <div class="field">
        <div class="field-head"><label for="${r}-k">${as(1081)}</label></div>
        <div class="select">
          <select
            class="input when"
            id="${r}-k"
            ?disabled=${this.disabled}
            @change=${e=>this._patch(t,{when:$y(e.target.value,s)},"Change state condition")}
          >
            ${wy.map(e=>a.qy`<option value=${e.id} ?selected=${e.id===i}>${as(e.label)}</option>`)}
          </select>
          <ha-icon icon="mdi:chevron-down"></ha-icon>
        </div>
      </div>
      ${"entity_on"===i||"entity_off"===i?a.qy`<div class="field"><div class="field-head"><span class="lbl">${as(1067)}</span></div><p class="help fill">${as(600)}</p></div>`:a.qy`<div class="field">
            <div class="field-head"><label for="${r}-v">${as(o?596:885)}</label></div>
            <input
              class="input ${o?"":"mono"}"
              id="${r}-v"
              type=${o?"number":"text"}
              step="any"
              inputmode=${o?"decimal":"text"}
              placeholder=${o?"0":as(1130)}
              autocomplete="off"
              spellcheck="false"
              ?disabled=${this.disabled}
              .value=${s}
              @change=${e=>{const n=e.target.value;!o||""!==n.trim()&&Number.isFinite(Number(n))?this._patch(t,{when:$y(i,n)},"Change state value"):e.target.value=s}}
            />
          </div>`}
    </div>`}_play(e,t){const i=`st-${t}-a`,n=function(e,t){const i=[{label:as(993),items:[{value:"self",label:as(620)},{value:"none",label:as(590)}]}],n=My(e).filter(e=>((e,t)=>!!e&&e.id!==t&&Sf(e)&&!(Array.isArray(e.clips)&&e.clips.length>0))(e,t)).sort((e,t)=>(e.name||e.id).localeCompare(t.name||t.id)).map(e=>({value:st+e.id,label:e.name||e.id}));n.length&&i.push({label:as(532),items:n});for(const e of he){const t=pe.filter(t=>t.group===e&&Mt.has(t.id)).map(e=>({value:e.id,label:(0,te.t)(e.name)}));t.length&&i.push({label:(0,te.t)(ue[e]),items:t})}return i}(this.library,this.doc?.id),s=n.some(t=>t.items.some(t=>t.value===e.animation));return a.qy`<div class="field">
      <div class="field-head"><label for=${i}>${as(665)}</label></div>
      <div class="select">
        <select class="input play" id=${i} ?disabled=${this.disabled} @change=${e=>this._patch(t,{animation:e.target.value},"Change state animation")}>
          ${s?a.s6:a.qy`<option value=${e.animation} selected>${function(e,t,i){if("self"===e)return as(620);if("none"===e)return as(589);if(rt(e)){const n=at(e),s=My(t).find(e=>e.id===n);return s?s.name||s.id:n===i?as(620):as(1195,{id:n})}const n=ge(e)?.name;return void 0!==n?(0,te.t)(n):as(1155,{animation:e})}(e.animation,this.library,this.doc?.id)}</option>`}
          ${n.map(t=>a.qy`<optgroup label=${t.label}>
              ${t.items.map(t=>a.qy`<option value=${t.value} ?selected=${t.value===e.animation}>${t.label}</option>`)}
            </optgroup>`)}
        </select>
        <ha-icon icon="mdi:chevron-down"></ha-icon>
      </div>
    </div>`}_transition(e,t){const i=e.transition??"cut",n=e=>{e!==i&&this._patch(t,{transition:e},"Change state transition")},s=(ky.find(e=>e.id===i)??ky[0]).hint;return a.qy`<div class="field">
      <div class="field-head"><span class="lbl" id="st-${t}-t">${as(1020)}</span></div>
      <div class="seg full" role="radiogroup" aria-labelledby="st-${t}-t" aria-describedby="st-${t}-th" @keydown=${e=>{const s=ky.findIndex(e=>e.id===i),r="rtl"===x(e.currentTarget),a={[r?"ArrowLeft":"ArrowRight"]:(s+1)%ky.length,[r?"ArrowRight":"ArrowLeft"]:(s-1+ky.length)%ky.length,Home:0,End:ky.length-1}[e.key];void 0!==a&&(e.preventDefault(),n(ky[a].id),this._focusAfter=`.clip[data-i="${t}"] .seg [aria-checked="true"]`)}}>
        ${ky.map(e=>{const t=e.id===i;return a.qy`<button type="button" role="radio" aria-checked=${t?"true":"false"} tabindex=${t?"0":"-1"} ?disabled=${this.disabled} @click=${()=>n(e.id)}>
            ${as(e.label)}
          </button>`})}
      </div>
      <p class="help" id="st-${t}-th">${as(s)}.</p>
    </div>`}_clip(e,t,i){const n=function(e,t,i){if(!rt(e.animation)){if("self"===e.animation||"none"===e.animation)return;return ge(e.animation)?Mt.has(e.animation)?void 0:as(289):as(1042)}const n=at(e.animation);if(n===i)return as(1051);const s=My(t).find(e=>e.id===n);return s?Array.isArray(s.clips)&&s.clips.length?as(923):Sf(s)?void 0:as(628):as(582)}(e,this.library,this.doc?.id);return a.qy`<li class="cond clip" data-i=${t}>
      <div class="cond-head">
        <span class="n">${as(892,{i:t+1})} <span class="sub">· ${ep(e.when)}</span></span>
        <button type="button" class="icon-btn sm up" aria-label=${as(475,{i:t+1})} title=${as(480)} ?disabled=${this.disabled||0===t} @click=${()=>this._move(t,t-1)}>
          <ha-icon icon="mdi:arrow-up"></ha-icon>
        </button>
        <button type="button" class="icon-btn sm down" aria-label=${as(474,{i:t+1})} title=${as(460)} ?disabled=${this.disabled||t===i-1} @click=${()=>this._move(t,t+1)}>
          <ha-icon icon="mdi:arrow-down"></ha-icon>
        </button>
        <button type="button" class="icon-btn sm danger del" aria-label=${as(231,{i:t+1})} title=${as(230)} ?disabled=${this.disabled} @click=${()=>this._remove(t)}>
          <ha-icon icon="mdi:delete-outline"></ha-icon>
        </button>
      </div>
      ${n?a.qy`<p class="help error">${n}</p>`:a.s6}
      ${this._when(e,t)} ${this._play(e,t)} ${this._transition(e,t)}
    </li>`}render(){const e=this._clips,t=!Sy(e);return a.qy`
      <div class="wrap">
        <p class="help lead">
          ${e.length?as(950):as(671)}
        </p>
        ${e.length?a.qy`<ol class="clips">${e.map((t,i)=>this._clip(t,i,e.length))}</ol>`:a.s6}
        <div class="foot">
          <button type="button" class="btn btn-text btn-sm add" ?disabled=${this.disabled||t} @click=${()=>this._add()}>
            <ha-icon icon="mdi:plus"></ha-icon>${as(35)}
          </button>
          ${t?a.qy`<span class="help">${as(1158,{cLIPS_MAX:12})}</span>`:a.s6}
        </div>
        <div class="sr-only" role="status" aria-live="polite">${this._announce}</div>
      </div>
    `}};Cy.styles=[dh,a.AH`
      :host {
        display: block;
        min-width: 0;
      }
      .wrap {
        display: grid;
        gap: 12px;
      }
      .help.lead {
        margin: 0;
      }
      .clips {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 12px;
      }
      .pair {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        gap: 8px;
        align-items: start;
      }
      .help.fill {
        margin: 0;
        min-height: 40px;
        display: flex;
        align-items: center;
      }
      .help.error {
        margin: 0;
      }
      .seg.full button {
        flex: 1;
        min-width: 0;
        padding: 0 6px;
        white-space: nowrap;
      }
      .foot {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }
      .foot .help {
        margin: 0;
      }
    `],zy([(0,o.MZ)({attribute:!1})],Cy.prototype,"doc",void 0),zy([(0,o.MZ)({attribute:!1})],Cy.prototype,"hass",void 0),zy([(0,o.MZ)({attribute:!1})],Cy.prototype,"library",void 0),zy([(0,o.MZ)({type:Number})],Cy.prototype,"time",void 0),zy([(0,o.MZ)({type:Boolean,reflect:!0})],Cy.prototype,"disabled",void 0),zy([(0,o.MZ)({attribute:!1})],Cy.prototype,"selection",void 0),zy([(0,o.MZ)({attribute:!1})],Cy.prototype,"tile",void 0),zy([(0,o.wk)()],Cy.prototype,"_announce",void 0),Cy=zy([(0,o.EM)("mc-anim-states-panel")],Cy),Ds({tag:"mc-anim-states-panel",place:"inspector",when:(e,t)=>"none"===t.kind,title:894,order:60});const Ay=[{id:"rotate_speed",label:754,unit:"°/s",output:[0,720],step:10,hint:859},{id:"rotate",label:753,unit:"°",output:[0,180],step:5,hint:1033},{id:"x",label:457,unit:"px",output:[0,12],step:1,hint:498},{id:"y",label:458,unit:"px",output:[0,-12],step:1,hint:500},{id:"scale",label:772,unit:"×",output:[.8,1.2],step:.05,hint:358},{id:"opacity",label:608,unit:"0-1",output:[.3,1],step:.05,hint:318},{id:"draw",label:257,unit:"0-1",output:[0,1],step:.05,rigOnly:!0,hint:269},{id:"color_mix",label:167,unit:"",output:["#9e9e9e","#ffb300"],step:1,hint:93},{id:"speed",label:673,unit:"×",output:[.25,2],step:.05,hint:677}],jy=e=>Ay.find(t=>t.id===e)??Ay[0],qy=e=>Ay.filter(t=>!t.rigOnly||(e=>/^(part|group|shape):/.test(e))(e)),Ey=e=>(e?.bindings?.length??0)<8;function Hy(e,t){const i={...e};return t.length?i.bindings=t:delete i.bindings,i}const Ly=/^[a-z0-9_][a-z0-9_.-]{0,63}$/i;var Vy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Oy={element:291,icon:370,name:533,state:885,background:78},Py={element:1144,icon:1145,name:1146,state:1147,background:1143},Ry=e=>e.target??e.keys?.[0]?.target;let Dy=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection=Ps,this._announce="",this._badAttr=new Set}get _target(){return Ry(this.selection)}_write(e,t){this.doc&&this.dispatchEvent(new CustomEvent("doc-change",{bubbles:!0,composed:!0,detail:{doc:Hy(this.doc,e),label:t}}))}_patch(e,t,i){this._write((this.doc?.bindings??[]).map((i,n)=>n===e?t:i),i)}_add(){const e=this._target;if(!e||!this.doc||!Ey(this.doc))return;const t=this.doc.bindings??[],i=function(e){const t=qy(e)[0];return{target:e,property:t.id,input:{min:0,max:100},output:[...t.output],smoothing:.4}}(e);this._write([...t,i],"Add value binding"),this._focusAfter=`.bind[data-i="${t.length}"] select.prop`,this._announce=as(85,{property:as(jy(i.property).label)})}_remove(e){const t=(this.doc?.bindings??[]).filter((t,i)=>i!==e);this._write(t,"Delete value binding"),this._focusAfter=".add",this._announce=as(86)}_checkAttr(e,t){const i=!t.trim()||Ly.test(t.trim());if(i!==!this._badAttr.has(e)){const t=new Set(this._badAttr);i?t.delete(e):t.add(e),this._badAttr=t}return i}updated(){const e=this._focusAfter;e&&(this._focusAfter=void 0,this.renderRoot.querySelector(e)?.focus())}_num(e,t,i,n,s){return a.qy`<div class="field">
      <div class="field-head"><label for=${e}>${t}</label></div>
      <input
        class="input"
        id=${e}
        type="number"
        step=${n}
        inputmode="decimal"
        ?disabled=${this.disabled}
        .value=${String(i)}
        @change=${e=>{const t=e.target,n=Number(t.value);""!==t.value.trim()&&Number.isFinite(n)?n!==i&&s(n):t.value=String(i)}}
      />
    </div>`}_output(e,t){const i=jy(e.property),n=`bd-${t}`;if("color_mix"===e.property){const[i,n]=e.output,s=(s,r)=>{if(!r)return;const a=[i,n];a[s]=r,this._patch(t,{...e,output:a},"Change binding colours")};return a.qy`<div class="field">
          <div class="field-head"><span class="lbl">${as(346)}</span></div>
          <mc-color-picker .value=${i} .label=${as(346)} @value-changed=${e=>s(0,e.detail.value)}></mc-color-picker>
        </div>
        <div class="field">
          <div class="field-head"><span class="lbl">${as(1012)}</span></div>
          <mc-color-picker .value=${n} .label=${as(1012)} @value-changed=${e=>s(1,e.detail.value)}></mc-color-picker>
        </div>`}const[s,r]=e.output,o=i.unit?` (${i.unit})`:"";return a.qy`<div class="pair">
      ${this._num(`${n}-from`,as(347,{unit:o}),s,i.step,i=>this._patch(t,{...e,output:[i,r]},"Change binding output"))}
      ${this._num(`${n}-to`,as(1017,{unit:o}),r,i.step,i=>this._patch(t,{...e,output:[s,i]},"Change binding output"))}
    </div>`}_binding(e,t,i){const n=`bd-${t}`,s=jy(e.property),r=qy(e.target),o=function(e){return e.input.min===e.input.max?as(444):void 0===e.input.attribute||""===e.input.attribute||Ly.test(e.input.attribute)?void 0:as(77)}(e),l=function(e,t){if(!e)return;const i="element"===t.target||"icon"===t.target?e.keyframes:e.tracks?.find(e=>e.target===t.target)?.keyframes;if(!i?.length)return;const n=i,s=e=>n.some(t=>void 0!==e(t));switch(t.property){case"opacity":return s(e=>e.opacity)?as(986):void 0;case"draw":return s(e=>e.draw)?as(985):void 0;case"color_mix":return("background"===t.target?s(e=>e.background):s(e=>e.color))?as(987):void 0;case"rotate":case"x":case"y":case"scale":return s(e=>e.transform?.skew_x??e.transform?.skew_y)?as(988):void 0;default:return}}(this.doc,e),c=this._badAttr.has(t);return a.qy`<li class="cond bind" data-i=${t}>
      <div class="cond-head">
        <span class="n">${as(87,{n:i+1})} <span class="sub">· ${as(s.label)}</span></span>
        <button type="button" class="icon-btn sm danger del" aria-label=${as(223,{n:i+1})} title=${as(222)} ?disabled=${this.disabled} @click=${()=>this._remove(t)}>
          <ha-icon icon="mdi:delete-outline"></ha-icon>
        </button>
      </div>
      <div class="field">
        <div class="field-head"><label for="${n}-p">${as(698)}</label></div>
        <div class="select">
          <select
            class="input prop"
            id="${n}-p"
            aria-describedby="${n}-ph"
            ?disabled=${this.disabled}
            @change=${i=>this._patch(t,function(e,t){return e.property===t?e:{...e,property:t,output:[...jy(t).output]}}(e,i.target.value),"Change bound property")}
          >
            ${r.map(t=>a.qy`<option value=${t.id} ?selected=${t.id===e.property}>${as(t.label)}</option>`)}
          </select>
          <ha-icon icon="mdi:chevron-down"></ha-icon>
        </div>
        <p class="help" id="${n}-ph">${as(s.hint)}</p>
      </div>
      <fieldset>
        <legend>${as(305)}</legend>
        <div class="field">
          <div class="field-head"><label for="${n}-a">${as(75)}</label></div>
          <input
            class="input mono"
            id="${n}-a"
            type="text"
            placeholder=${as(1140)}
            autocomplete="off"
            spellcheck="false"
            aria-describedby="${n}-ah"
            aria-invalid=${c?"true":"false"}
            ?disabled=${this.disabled}
            .value=${e.input.attribute??""}
            @input=${e=>this._checkAttr(t,e.target.value)}
            @change=${i=>{const n=i.target.value.trim();if(!this._checkAttr(t,n))return;const s={...e.input};n?s.attribute=n:delete s.attribute,this._patch(t,{...e,input:s},"Change binding attribute")}}
          />
          <p class="help ${c?"error":""}" id="${n}-ah">
            ${as(c?76:298)}
          </p>
        </div>
        <div class="pair">
          ${this._num(`${n}-min`,as(443),e.input.min,1,i=>this._patch(t,{...e,input:{...e.input,min:i}},"Change binding range"))}
          ${this._num(`${n}-max`,as(439),e.input.max,1,i=>this._patch(t,{...e,input:{...e.input,max:i}},"Change binding range"))}
        </div>
      </fieldset>
      <fieldset>
        <legend>${as(616)}</legend>
        ${this._output(e,t)}
        ${this._num(`${n}-s`,as(843),e.smoothing??0,.1,i=>{const n={...e};i>0?n.smoothing=Math.min(10,i):delete n.smoothing,this._patch(t,n,"Change binding smoothing")})}
      </fieldset>
      ${l?a.qy`<p class="help warn">${l}</p>`:a.s6}
      ${o?a.qy`<p class="help error" role="alert">${o}</p>`:a.s6}
    </li>`}render(){const e=this._target;if(!e||!this.doc)return a.qy``;const t=function(e,t){return t&&Array.isArray(e?.bindings)?e.bindings.map((e,t)=>({b:e,index:t})).filter(e=>e.b.target===t):[]}(this.doc,e),i=!Ey(this.doc),n=Py[e]?as(Py[e]):`“${function(e,t){if(Oy[t])return as(Oy[t]);const i=/^(part|group|shape):(.+)$/.exec(t);if(!i)return t;const n="part"===i[1]?e?.rig?.parts:"group"===i[1]?e?.rig?.groups:e?.rig?.shapes;return n?.find(e=>e.id===i[2])?.name||i[2]}(this.doc,e)}”`;return a.qy`
      <div class="wrap">
        <p class="help lead">
          ${t.length?a.qy`${as(946,{name:n})}`:a.qy`${as(271,{name:n})}`}
        </p>
        ${t.length?a.qy`<ol class="binds">${t.map((e,t)=>this._binding(e.b,e.index,t))}</ol>`:a.s6}
        <div class="foot">
          <button type="button" class="btn btn-text btn-sm add" ?disabled=${this.disabled||i} @click=${()=>this._add()}>
            <ha-icon icon="mdi:plus"></ha-icon>${as(39)}
          </button>
          ${i?a.qy`<span class="help">${as(1215,{max:8})}</span>`:a.s6}
        </div>
        <div class="sr-only" role="status" aria-live="polite">${this._announce}</div>
      </div>
    `}};Dy.styles=[dh,a.AH`
      :host {
        display: block;
        min-width: 0;
      }
      .wrap {
        display: grid;
        gap: 12px;
      }
      .binds {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 12px;
      }
      fieldset {
        margin: 0;
        padding: 0;
        border: 0;
        display: grid;
        gap: 12px;
        min-width: 0;
      }
      legend {
        padding: 0;
        margin-bottom: 8px;
        font-size: 0.75rem;
        font-weight: 500;
        color: var(--mc-text-2);
      }
      .pair {
        display: grid;
        grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
        gap: 8px;
        align-items: start;
      }
      .help.warn {
        color: var(--mc-warn-ink, var(--mc-text-2));
      }
      .input[aria-invalid='true'] {
        border-color: var(--mc-error-ink);
      }
      .foot {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }
    `],Vy([(0,o.MZ)({attribute:!1})],Dy.prototype,"doc",void 0),Vy([(0,o.MZ)({attribute:!1})],Dy.prototype,"hass",void 0),Vy([(0,o.MZ)({attribute:!1})],Dy.prototype,"library",void 0),Vy([(0,o.MZ)({type:Number})],Dy.prototype,"time",void 0),Vy([(0,o.MZ)({type:Boolean,reflect:!0})],Dy.prototype,"disabled",void 0),Vy([(0,o.MZ)({attribute:!1})],Dy.prototype,"selection",void 0),Vy([(0,o.MZ)({attribute:!1})],Dy.prototype,"tile",void 0),Vy([(0,o.wk)()],Dy.prototype,"_announce",void 0),Vy([(0,o.wk)()],Dy.prototype,"_badAttr",void 0),Dy=Vy([(0,o.EM)("mc-anim-bindings-panel")],Dy),Ds({tag:"mc-anim-bindings-panel",place:"inspector",when:(e,t)=>"keyframes"===e.kind&&"target"===t.kind&&!!Ry(t),title:1072,order:60});var Ny=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Fy=[{id:"on",label:598},{id:"off",label:597},{id:"unavailable",label:1034},{id:"value",label:1067,numeric:!0},{id:"custom",label:204}];let Ty=class extends a.WF{constructor(){super(...arguments),this.disabled=!1,this.selection=Ps,this.time=0,this._choice="on",this._custom="idle",this._value=Ud.value,this._sent="",this._picked=!1}get detail(){return{state:"value"===this._choice?function(e,t){const[i,n]=Jd(e).stateRange??[0,100];return String(Gd(i+(n-i)*Math.min(1,Math.max(0,t))))}(this.doc,this._value):"custom"===this._choice?this._custom.trim()||"idle":this._choice,value:this._value,attributes:Xd(this.doc,this._value)}}_emit(){const e=this.detail,t=JSON.stringify(e);t!==this._sent&&(this._sent=t,this.dispatchEvent(new CustomEvent("preview-change",{bubbles:!0,composed:!0,detail:e})))}willUpdate(e){e.has("doc")&&!this._picked&&(this._choice=Jd(this.doc).numericState?"value":"on")}updated(e){(e.has("doc")||e.has("_choice")||e.has("_custom")||e.has("_value"))&&this._emit()}_pick(e){this._picked=!0,this._choice=e,"custom"===e&&this.updateComplete.then(()=>this.renderRoot.querySelector(".custom")?.focus())}_states(e){const t=Fy.filter(t=>!t.numeric||e||this._choice===t.id);return a.qy`<div class="seg" role="radiogroup" aria-label=${as(693)} @keydown=${e=>{const i=t.findIndex(e=>e.id===this._choice),n={ArrowRight:(i+1)%t.length,ArrowLeft:(i-1+t.length)%t.length,Home:0,End:t.length-1}[e.key];void 0!==n&&(e.preventDefault(),this._picked=!0,this._choice=t[n].id,this.updateComplete.then(()=>this.renderRoot.querySelector('.seg [aria-checked="true"]')?.focus()))}}>
      ${t.map(e=>{const t=e.id===this._choice;return a.qy`<button type="button" role="radio" aria-checked=${t?"true":"false"} tabindex=${t?"0":"-1"} ?disabled=${this.disabled} @click=${()=>this._pick(e.id)}>${as(e.label)}</button>`})}
    </div>`}render(){if(!Kd(this.doc))return a.qy``;const e=Jd(this.doc),t=Math.round(100*this._value);return a.qy`<div class="bar" role="group" aria-label=${as(691)}>
      <span class="lbl" aria-hidden="true"><ha-icon icon="mdi:lightbulb-outline"></ha-icon></span>
      ${this._states(e.numericState)}
      ${"custom"===this._choice?a.qy`<input
            class="input mono custom"
            type="text"
            aria-label=${as(207)}
            placeholder=${as(885)}
            autocomplete="off"
            spellcheck="false"
            ?disabled=${this.disabled}
            .value=${this._custom}
            @change=${e=>this._custom=e.target.value}
          />`:a.s6}
      ${e.value?a.qy`<label class="value">
            <span class="sr-only">${as(695)}</span>
            <input
              type="range"
              min="0"
              max="100"
              step="1"
              ?disabled=${this.disabled}
              .value=${String(t)}
              aria-valuetext=${as(1253,{pct:t})}
              @input=${e=>this._value=Number(e.target.value)/100}
            />
            <output aria-hidden="true">${t}%</output>
          </label>`:a.s6}
    </div>`}};Ty.styles=[dh,a.AH`
      :host {
        position: absolute;
        left: 12px;
        right: 12px;
        inset-inline: 12px;
        bottom: 12px;
        display: flex;
        justify-content: center;
        pointer-events: none;
        z-index: 3;
      }
      .bar {
        pointer-events: auto;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
        max-width: 100%;
        padding: 6px 10px;
        background: var(--mc-surface);
        border: 1px solid var(--mc-divider);
        border-radius: 10px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.16), 0 2px 6px rgba(0, 0, 0, 0.08);
      }
      .lbl {
        display: inline-flex;
        color: var(--mc-text-2);
        --mdc-icon-size: 18px;
      }
      .custom {
        width: 120px;
        min-height: 32px;
        padding: 4px 8px;
      }
      .value {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        min-height: 32px;
      }
      .value input {
        width: 140px;
        min-height: 24px;
        accent-color: var(--mc-accent);
        margin: 0;
      }
      .value output {
        min-width: 4ch;
        font-size: 0.8125rem;
        font-variant-numeric: tabular-nums;
        color: var(--mc-text-2);
        text-align: right;
        text-align: end;
      }
      input[type='range']:focus-visible {
        outline: 2px solid var(--mc-accent);
        outline-offset: 2px;
      }
    `],Ny([(0,o.MZ)({attribute:!1})],Ty.prototype,"doc",void 0),Ny([(0,o.MZ)({type:Boolean,reflect:!0})],Ty.prototype,"disabled",void 0),Ny([(0,o.MZ)({attribute:!1})],Ty.prototype,"selection",void 0),Ny([(0,o.MZ)({type:Number})],Ty.prototype,"time",void 0),Ny([(0,o.wk)()],Ty.prototype,"_choice",void 0),Ny([(0,o.wk)()],Ty.prototype,"_custom",void 0),Ny([(0,o.wk)()],Ty.prototype,"_value",void 0),Ty=Ny([(0,o.EM)("mc-anim-stage-sim")],Ty),Ds({tag:"mc-anim-stage-sim",place:"stage-tool",when:e=>Kd(e),title:691,order:80,dock:"bottom"});var By=i(5084),Iy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};const Zy=e=>!!e&&/^(part|group|shape):/.test(e),Wy=(e,t)=>"intensity"===e.id?`${t}×`:"direction"===e.id?as(t<0?745:342):`${t} %`;let Ky=class extends a.WF{constructor(){super(...arguments),this.time=0,this.disabled=!1,this.selection={kind:"none"},this.tile="icon",this._applied=new Map,this._status=""}willUpdate(e){if((e.has("doc")||e.has("tile"))&&this.doc){const e=Sv(this.doc,this.tile);e!==this._ref&&(this._ref=e,this._geom=zv(e),this._geom||Cv(e).then(t=>{this._ref===e&&(this._geom=t)}))}}get _targets(){const e=nb(this.selection).filter(Zy),t=this.selection.target;Zy(t)&&!e.includes(t)&&e.unshift(t);for(const t of this.selection.targets??[])Zy(t)&&!e.includes(t)&&e.push(t);return e}get _key(){return this._targets.join(",")}_apply(e,t,i=!1){const n=i?this._dragBase??=this.doc:this._dragBase??this.doc;if(!n)return;const s=this._geom?jv(this._geom):void 0,r=(0,By.ar)(n,this._targets,e.id,t,{pieces:s});if(i||(this._dragBase=void 0),r===n)return void(i||(this._status=as(994)));const a=new Map(this._applied);a.set(this._key,{preset:e.id,params:t}),this._applied=a;const o=this._targets.map(e=>Yv(n,e));this._status=i?"":as(1256,{preset:(0,te.t)(e.name),targets:o.length>2?as(1171,{count:o.length}):ds(o)}),ab(this,r,`Preset: ${e.id}`,i)}_pickPreset(e,t){const i=By.tP.find(t=>t.id===e.value);i&&(this._apply(i,t?.preset===i.id?t.params:{}),this._applied.get(this._key)?.preset!==i.id&&(e.value=t?.preset??""))}_clear(){if(!this.doc)return;const e=this._targets.reduce((e,t)=>(0,By.di)(e,t),this.doc),t=new Map(this._applied);t.delete(this._key),this._applied=t,this._status=as(456),ab(this,e,"Remove motion")}_openSvg(){this.renderRoot.querySelector("mc-anim-svg-dialog")?.openExport(!0)}_renderParams(e,t){const i=(0,By.Cq)(e.id,t);return a.qy`<div class="params" role="group" aria-label=${as(1240,{name:(0,te.t)(e.name)})}>
      ${e.params.map(t=>{const n=i[t.id];if("direction"===t.id)return a.qy`<div class="field">
            <div class="field-head"><span class="lbl" id="pp-dir">${as(239)}</span></div>
            <div class="seg full" role="radiogroup" aria-labelledby="pp-dir">
              ${[1,-1].map(t=>a.qy`<button
                  type="button"
                  role="radio"
                  data-dir=${t}
                  aria-checked=${n===t?"true":"false"}
                  tabindex=${n===t?0:-1}
                  ?disabled=${this.disabled}
                  @click=${()=>this._apply(e,{...i,direction:t})}
                >
                  <ha-icon icon=${t>0?"mdi:rotate-right":"mdi:rotate-left"}></ha-icon>${as(t>0?342:745)}
                </button>`)}
            </div>
          </div>`;const s=`pp-${t.id}`;return a.qy`<div class="field">
          <div class="field-head"><label for=${s}>${(0,te.t)(t.label)}</label><span class="val">${Wy(t,n)}</span></div>
          <input
            id=${s}
            class="range"
            type="range"
            data-param=${t.id}
            min=${t.min}
            max=${t.max}
            step=${t.step}
            .value=${String(n)}
            aria-valuetext=${Wy(t,n)}
            ?disabled=${this.disabled}
            @input=${n=>this._apply(e,{...i,[t.id]:Number(n.target.value)},!0)}
            @change=${n=>this._apply(e,{...i,[t.id]:Number(n.target.value)})}
          />
        </div>`})}
    </div>`}updated(){const e=this.renderRoot.querySelector("select#pp-preset"),t=this._applied.get(this._key)?.preset??"";e&&e.value!==t&&(e.value=t)}render(){const e=this.doc,t=this._targets;if(!e||!t.length)return a.qy``;const i=this._applied.get(this._key),n=i?By.tP.find(e=>e.id===i.preset):void 0,s=t.some(t=>(Hv(e,t)?.keyframes.length??0)>0),r=this._geom?jv(this._geom):[];return a.qy`
      <p class="help">${t.length>1?as(1176,{count:t.length}):as(601)}</p>
      <div class="field">
        <div class="field-head"><label for="pp-preset">${as(687)}</label></div>
        <div class="select">
          <select
            class="input"
            id="pp-preset"
            aria-describedby=${n?.help?"pp-preset-help":a.s6}
            ?disabled=${this.disabled}
            @change=${e=>this._pickPreset(e.target,i)}
          >
            <option value="" ?selected=${!n} ?disabled=${!!n} ?hidden=${!!n}>${as(141)}</option>
            ${By.tP.map(e=>a.qy`<option value=${e.id} data-preset=${e.id} ?selected=${n?.id===e.id}>${(0,te.t)(e.name)}</option>`)}
          </select>
          <ha-icon icon="mdi:chevron-down"></ha-icon>
        </div>
        ${n?.help?a.qy`<p class="help" id="pp-preset-help">${(0,te.t)(n.help)}</p>`:a.s6}
      </div>
      ${n?this._renderParams(n,i.params):a.s6}
      <div class="actions">
        ${s?a.qy`<button type="button" class="btn btn-text btn-sm clear" ?disabled=${this.disabled} @click=${()=>this._clear()}>${as(718)}</button>`:a.s6}
        <span class="grow"></span>
        <button type="button" class="btn btn-secondary btn-sm export" @click=${()=>this._openSvg()}>
          <ha-icon icon="mdi:motion-play-outline"></ha-icon>${as(62)}
        </button>
      </div>
      <p class="status" role="status" aria-live="polite">${this._status}</p>
      <mc-anim-svg-dialog .doc=${e} .pieces=${r} .viewBox=${this._geom?.viewBox??"0 0 24 24"}></mc-anim-svg-dialog>
    `}};function Uy(e){const t=(e.includes(":")?e.slice(e.indexOf(":")+1):e).split(/[-_\s]+/).filter(Boolean).join(" ");return t?t.charAt(0).toUpperCase()+t.slice(1):""}Ky.styles=[Cs,As,a.AH`
      :host {
        display: grid;
        gap: 12px;
      }
      .help {
        margin: 0;
      }
      .field {
        display: grid;
        gap: 6px;
      }
      .params {
        display: grid;
        gap: 10px;
        padding: 10px 12px;
        border-radius: var(--mc-radius, 8px);
        background: var(--mc-surface-2, var(--secondary-background-color, #f2f3f5));
      }
      .field-head .val {
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
        font-variant-numeric: tabular-nums;
      }
      input.range {
        width: 100%;
        min-height: 24px;
        margin: 0;
        accent-color: color-mix(in srgb, var(--primary-color, #03a9f4) 70%, #000);
      }
      .actions {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 8px;
        margin-top: 4px;
      }
      .grow {
        flex: 1;
      }
      .status {
        margin: 0;
        min-height: 1em;
        font-size: 0.75rem;
        color: var(--secondary-text-color, #5f6368);
      }
    `],Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"doc",void 0),Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"hass",void 0),Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"library",void 0),Iy([(0,o.MZ)({type:Number})],Ky.prototype,"time",void 0),Iy([(0,o.MZ)({type:Boolean})],Ky.prototype,"disabled",void 0),Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"selection",void 0),Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"tile",void 0),Iy([(0,o.MZ)({attribute:!1})],Ky.prototype,"stage",void 0),Iy([(0,o.wk)()],Ky.prototype,"_applied",void 0),Iy([(0,o.wk)()],Ky.prototype,"_geom",void 0),Iy([(0,o.wk)()],Ky.prototype,"_status",void 0),Ky=Iy([(0,o.EM)("mc-anim-part-presets")],Ky),Ds({tag:"mc-anim-part-presets",place:"inspector",title:625,order:15,when:(e,t)=>"keyframes"===e.kind&&("target"===t.kind||"keys"===t.kind)&&Zy(t.target)}),new Map;var Gy=i(1474);let Yy,Jy;function Xy(){return Yy??=Promise.all([i.e(3626),i.e(2334)]).then(()=>i(1402)).then(e=>(0,$p.t)("magic-card-icon-library.js",e)??Promise.reject(new Error("the icon library is from another release"))).then(async e=>await e.iconNamesReady()?e:Promise.reject(new Error("the icon names could not be loaded"))).then(e=>Jy=e,e=>{throw Yy=void 0,console.warn("Magic Card: icon library not loaded",e),e}),Yy}var Qy=function(e,t,i,n){var s,r=arguments.length,a=r<3?t:null===n?n=Object.getOwnPropertyDescriptor(t,i):n;if("object"==typeof Reflect&&"function"==typeof Reflect.decorate)a=Reflect.decorate(e,t,i,n);else for(var o=e.length-1;o>=0;o--)(s=e[o])&&(a=(r<3?s(a):r>3?s(t,i,a):s(t,i))||a);return r>3&&a&&Object.defineProperty(t,i,a),a};let ex=class extends a.WF{constructor(){super(...arguments),this._visible="undefined"==typeof IntersectionObserver}connectedCallback(){super.connectedCallback(),"undefined"!=typeof IntersectionObserver&&(this._io=new IntersectionObserver(e=>{const t=e.some(e=>e.isIntersecting);t!==this._visible&&(this._visible=t)}),this._io.observe(this)),customElements.get("magic-card")||customElements.whenDefined("magic-card").then(()=>this.requestUpdate())}disconnectedCallback(){super.disconnectedCallback(),this._io?.disconnect(),this._io=void 0}willUpdate(e){if(e.has("entry")&&(this._card=void 0),this._card)return void(e.has("hass")&&this.hass&&(this._card.hass=this.hass));const t=this.entry;if(!this._visible||!t||!customElements.get("magic-card"))return;const i=t.build(),n=document.createElement("magic-card");try{n.setConfig({type:"custom:magic-card",custom_animations:[i],rows:[{id:"r",columns:[{id:"c",vertical_align:"center",modules:[{id:"m",type:"icon",icon:t.icon,size:"40px",design:{text_align:"center",animations:[{id:"a",preset:`custom:${i.id}`}]}}]}]}]})}catch{return}n.hass=this.hass??lp(!1),this._card=n}render(){const e=this._visible?this._card:void 0;return a.qy`<div class="box" aria-hidden="true">${e??a.qy`<ha-icon icon=${this.entry?.icon??""}></ha-icon>`}</div>`}};ex.styles=[Cs,a.AH`
      :host {
        display: block;
        width: 100%;
        height: 64px;
      }
      .box {
        width: 100%;
        height: 100%;
        display: grid;
        place-items: center;
        overflow: hidden;
        border-radius: var(--mc-radius, 8px);
        background-color: var(--mc-canvas);
        background-image: radial-gradient(var(--mc-canvas-dot) 1px, transparent 1.2px);
        background-size: 8px 8px;
        color: var(--state-icon-color, #44739e);
        --mdc-icon-size: 40px;
      }
      magic-card {
        display: block;
        width: 100%;
        pointer-events: none;
        --ha-card-background: transparent;
        --card-background-color: transparent;
        --ha-card-border-width: 0;
        --ha-card-box-shadow: none;
      }
    `],Qy([(0,o.MZ)({attribute:!1})],ex.prototype,"entry",void 0),Qy([(0,o.MZ)({attribute:!1})],ex.prototype,"hass",void 0),Qy([(0,o.wk)()],ex.prototype,"_visible",void 0),ex=Qy([(0,o.EM)("mc-anim-icon-thumb")],ex);const tx={alarm_control_panel:43,binary_sensor:84,button:111,calendar:112,camera:113,climate:155,cover:195,device_tracker:238,event:307,fan:320,humidifier:369,lawn_mower:403,light:417,lock:428,media_player:441,person:653,plant:664,sensor:797,siren:831,sun:914,switch:917,timer:1009,vacuum:1066,valve:1074,weather:1077,zone:1088},ix=(e,t)=>t?.localize?.(`component.${e}.title`)||(void 0!==tx[e]?as(tx[e]):null)||e.replace(/_/g," ").replace(/^./,e=>e.toUpperCase());let nx=class extends a.WF{constructor(){super(...arguments),this.lookup=()=>{},this._icon="mdi:bell-ring",this._query="",this._domain="",this._busy=!1,this._error="",this._lib=Jy,this._libFailed=!1}connectedCallback(){super.connectedCallback(),this._lib||this._loadLibrary(),Os("mc-icon-picker")||"undefined"==typeof customElements||customElements.whenDefined("mc-icon-picker").then(()=>this.requestUpdate())}async _loadLibrary(){this._libFailed=!1;try{this._lib=await Xy()}catch{this._libFailed=!0}}_emit(e,t){this.dispatchEvent(new CustomEvent("icon-start",{detail:{doc:e,from:t},bubbles:!0,composed:!0}))}async start(){const e=this._icon.trim();if(wt.test(e)){this._busy=!0,this._error="";try{const t=this._lib??await Xy().catch(()=>{}),i=t?.mdiGeometry(e)??await bv(e);if(!i)return void(this._error=as(996));const n=as(1226,{name:Uy(e)}),s=(0,Gy.a)(e,i,e.slice(e.indexOf(":")+1),n,{embed:!0});if(!s.rig?.parts.length)return void(this._error=as(997));this._emit(s,"icon")}finally{this._busy=!1}}else this._error=as(656)}focusStart(){const e=this.renderRoot.querySelector("mc-icon-picker, .icon-input");(e?.shadowRoot?.querySelector("input")??e)?.focus({preventScroll:!0})}_renderPick(){const e=Os("mc-icon-picker");return a.qy`<section class="pick" aria-labelledby="is-pick">
      <h3 id="is-pick">${as(881)}</h3>
      <p class="help">${as(954)}</p>
      <div class="pick-row">
        <div class="field grow">
          ${e?a.qy`<mc-icon-picker
                .hass=${this.hass}
                .value=${this._icon}
                label=${as(370)}
                @value-changed=${e=>{e.stopPropagation(),this._icon=String(e.detail?.value??"").trim(),this._error=""}}
              ></mc-icon-picker>`:a.qy`<input
                class="input mono icon-input"
                aria-label=${as(370)}
                spellcheck="false"
                .value=${U(this._icon)}
                @input=${e=>{this._icon=e.target.value,this._error=""}}
                @keydown=${e=>"Enter"===e.key&&void this.start()}
              />`}
        </div>
        <button type="button" class="btn btn-primary btn-sm start" ?disabled=${this._busy} @click=${()=>{this.start()}}>
          <ha-icon icon="mdi:scissors-cutting"></ha-icon>${this._busy?as(867):as(862)}
        </button>
      </div>
      ${this._error?a.qy`<p class="help error" role="alert">${this._error}</p>`:a.s6}
    </section>`}_renderLibrary(){const e=this._lib,t=a.qy`<div class="lib-head">
      <h3 id="is-lib">${as(613)}</h3>
      ${e?a.qy`<span class="chip is-count">${e.ICON_LIBRARY.length}</span>`:a.s6}
    </div>`;if(!e)return a.qy`<section class="lib" aria-labelledby="is-lib">
        ${t}
        ${this._libFailed?a.qy`<p class="help error lib-error" role="alert">${as(955)}</p>
              <div><button type="button" class="btn btn-secondary btn-sm lib-retry" @click=${()=>{this._loadLibrary()}}><ha-icon icon="mdi:refresh"></ha-icon>${as(1023)}</button></div>`:a.qy`<p class="help lib-loading" role="status">${as(425)}</p>`}
      </section>`;const i=e.searchLibrary(this._query,this._domain||void 0);return a.qy`<section class="lib" aria-labelledby="is-lib">
      ${t}
      <div class="filters">
        <div class="with-icon grow">
          <ha-icon icon="mdi:magnify"></ha-icon>
          <input
            class="input lib-search"
            type="search"
            placeholder=${as(778)}
            aria-label=${as(780)}
            .value=${U(this._query)}
            @input=${e=>this._query=e.target.value}
          />
        </div>
        <select class="input domain" aria-label=${as(241)} .value=${U(this._domain)} @change=${e=>this._domain=e.target.value}>
          <option value="">${as(45)}</option>
          ${[...e.LIBRARY_DOMAINS].sort((e,t)=>ix(e,this.hass).localeCompare(ix(t,this.hass))).map(e=>a.qy`<option value=${e} ?selected=${e===this._domain}>${ix(e,this.hass)}</option>`)}
        </select>
      </div>
      ${i.length?a.qy`<ul class="grid" role="list">
            ${i.map(t=>a.qy`<li>
                <button type="button" class="entry" data-id=${t.id} title="${t.name} (${t.icon})" @click=${()=>this._emit({...t.build(),...t.mirror?{mirror:t.mirror}:{}},"library")}>
                  <mc-anim-icon-thumb .entry=${t} .hass=${this.hass}></mc-anim-icon-thumb>
                  ${e.isNewInRelease(t.id)?a.qy`<span class="new-mark" aria-hidden="true"></span><span class="sr-only">${as(540)}</span>`:a.s6}
                  <span class="nm">${t.name}</span>
                  <span class="dm">${ix(t.domain,this.hass)}</span>
                  ${(()=>{const i=e.mirrorBadge(t.mirror);return a.qy`<span class="mirror-badge ${i.unset?"is-unset":""}">${i.label}</span>`})()}
                </button>
              </li>`)}
          </ul>`:a.qy`<p class="help no-results">${as(558,{query:this._query})}</p>`}
    </section>`}render(){return a.qy`${this._renderPick()} ${this._renderLibrary()}`}};nx.styles=[Cs,As,a.AH`
      :host {
        display: grid;
        gap: 20px;
        min-height: 0;
      }
      h3 {
        margin: 0;
        font-size: 0.875rem;
        font-weight: 500;
      }
      section {
        display: grid;
        gap: 10px;
        min-height: 0;
      }
      .help {
        margin: 0;
      }
      .pick-row,
      .filters,
      .lib-head {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .grow {
        flex: 1;
        min-width: 0;
      }
      .pick-row .field {
        margin: 0;
      }
      select.domain {
        width: auto;
        min-width: 150px;
      }
      .grid {
        list-style: none;
        margin: 0;
        padding: 2px;
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(116px, 1fr));
        gap: 8px;
        max-height: min(46vh, 420px);
        overflow: auto;
      }
      .grid > li {
        display: flex;
      }
      .entry {
        position: relative;
        width: 100%;
        align-content: start;
        display: grid;
        justify-items: center;
        gap: 4px;
        padding: 8px 6px;
        border-radius: var(--mc-radius, 8px);
        border: 1px solid var(--mc-divider, var(--divider-color, rgba(0, 0, 0, 0.12)));
        background: var(--mc-surface, var(--card-background-color, #fff));
        color: var(--mc-text, var(--primary-text-color, #212121));
        font: inherit;
        cursor: pointer;
        text-align: center;
      }
      .entry:hover {
        border-color: color-mix(in srgb, var(--primary-color, #03a9f4) 60%, transparent);
      }
      .entry:focus-visible {
        outline: 2px solid var(--mc-accent-ink, #01579b);
        outline-offset: 2px;
      }
      .new-mark {
        position: absolute;
        top: 6px;
        right: 6px;
        inset-inline: auto 6px;
        width: 8px;
        height: 8px;
        background: var(--mc-accent-ink, #01579b);
        box-shadow: 0 0 0 1.5px var(--mc-surface, var(--card-background-color, #fff));
        transform: rotate(45deg);
      }
      @media (forced-colors: active) {
        .new-mark {
          background: CanvasText;
        }
      }
      .mirror-badge {
        font-size: 0.6875rem;
        color: var(--mc-text-secondary, var(--secondary-text-color, #727272));
      }
      .mirror-badge.is-unset {
        padding: 0 6px;
        border-radius: 999px;
        font-weight: 600;
        color: var(--mc-accent-ink, #01579b);
        background: color-mix(in srgb, var(--primary-color, #03a9f4) 16%, transparent);
        outline: 1px solid currentColor;
      }
      .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        overflow: hidden;
        clip: rect(0 0 0 0);
        white-space: nowrap;
      }
      .pick-row {
        align-items: flex-start;
      }
      .pick-row .start {
        min-height: 40px;
      }
      .nm {
        font-size: 0.8125rem;
        line-height: 1.25;
      }
      .dm {
        font-size: 0.6875rem;
        color: var(--mc-text-2, var(--secondary-text-color, #5f6368));
      }
    `],Qy([(0,o.MZ)({attribute:!1})],nx.prototype,"hass",void 0),Qy([(0,o.MZ)({attribute:!1})],nx.prototype,"lookup",void 0),Qy([(0,o.wk)()],nx.prototype,"_icon",void 0),Qy([(0,o.wk)()],nx.prototype,"_query",void 0),Qy([(0,o.wk)()],nx.prototype,"_domain",void 0),Qy([(0,o.wk)()],nx.prototype,"_busy",void 0),Qy([(0,o.wk)()],nx.prototype,"_error",void 0),Qy([(0,o.wk)()],nx.prototype,"_lib",void 0),Qy([(0,o.wk)()],nx.prototype,"_libFailed",void 0),nx=Qy([(0,o.EM)("mc-anim-icon-start")],nx),function(e){$m=e}(kd),function(e,t){nt.particles=e,nt.checkSim=t,nt.epoch++}($d,kd.validateSim);const sx=[["magic-card-animation-studio",sh],["mcas-stage",dp],["mcas-thumb",ah],["mc-preset-grid",kp],["mc-preset-thumb",wp]];for(const[e,t]of sx)customElements.get(e)||customElements.define(e,t)})();